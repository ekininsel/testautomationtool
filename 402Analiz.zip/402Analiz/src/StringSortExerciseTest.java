import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ StringSortExerciseTest0.class })
public class StringSortExerciseTest {
}

