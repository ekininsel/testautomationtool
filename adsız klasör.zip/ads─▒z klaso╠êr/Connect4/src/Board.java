
enum Chip {
    NONE, RED, YELLOW
}

public class Board {
    public static final int NUM_COLUMNS = 7;
    public static final int NUM_ROWS = 6;

    Board board = new Board();
    /**
     * Creates an empty Connect4 board.
     * The first player to play will be the RED one.
     */
    public Board() {

    }

    /**
     * Creates a Connect4 board with the given initial configuration.
     * For the format of the configuration, see
     * http://blog.gamesolver.org/solving-connect-four/02-test-protocol/
     *
     * @param configuration The initial configuration of the board.
     *
     * @throws IllegalArgumentException if <code>configuration</code> is not a valid configuration.
     * A configuration is not valid if it is an impossible combination
     * or it contains moves after forming a 4-connection.
     */
    public Board(String configuration) {

    }

    /**
     * Inserts a chip for the current player at the specified <code>column</code>
     * (indexing starts at 1). After the chip is inserted, it wil be the other player's turn.
     *
     * @param column The index of the column into which to put a chip.
     *
     * @throws IllegalArgumentException if no column at the specified index exists.
     * @throws RuntimeException if inserting a chip at the specified column is not possible (e.g. when the column is full)
     */
    public void insertChipAt(int column) {

    }

    /**
     *
     * @return the winner Chip (RED or YELLOW) if there exists a 4-connection;
     *         NONE, otherwise.
     */
    public Chip getWinner() {
        return Chip.NONE;
    }

    /**
     * @return The current state of the board as a "configuration".
     */
    public String getConfiguration() {
       return "";
    }


    /**
     * @return The Chip of the current player.
     */
    public Chip getCurrentPlayer() {
        return null;
    }

    /**
     * @return this board's string representation.
     * E.g. here is the output for the configuration 3432554:
     *
     * |_ _ _ _ _ _ _|
     * |_ _ _ _ _ _ _|
     * |_ _ _ _ _ _ _|
     * |_ _ _ _ _ _ _|
     * |_ _ R R Y _ _|
     * |_ Y R Y R _ _|
     *
     */
    public String toString() {
        // Hint: You can override the toString() method of an enum.
        return "";
    }
}
