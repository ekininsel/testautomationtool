

import org.junit.Test;

import static org.junit.Assert.*;

public class BoardTest {
    @Test
    public void testConstructorNoArg00() {
        Board board = new Board();
        assertEquals(7, board.getConfiguration());
    }

    @Test
    public void testConstructorNoArg01() {
        Board board = new Board();
        if (board.getConfiguration().equals(-1))
            assertFalse("Enter a valid number:", false);
    }

    @Test
    public void testWinningCondition00() {
        Board board = new Board();
        board.insertChipAt(4);
        board.insertChipAt(5);
        board.insertChipAt(2);
        board.insertChipAt(4);
        board.insertChipAt(1);
        board.insertChipAt(6);
        assertEquals(Chip.NONE, board.getWinner());
    }

    @Test
    public void testWinningCondition01() {
        Board board = new Board();
        board.insertChipAt(1);
        board.insertChipAt(2);
        board.insertChipAt(1);
        board.insertChipAt(2);
        board.insertChipAt(1);
        board.insertChipAt(2);
        board.insertChipAt(1);
        assertEquals(Chip.RED, board.getWinner());
    }

    @Test
    public void testWinningCondition02() {
        Board board = new Board();
        board.insertChipAt(1);
        board.insertChipAt(2);
        board.insertChipAt(1);
        board.insertChipAt(1);
        board.insertChipAt(2);
        board.insertChipAt(3);
        board.insertChipAt(2);
        board.insertChipAt(3);
        board.insertChipAt(2);
        assertEquals(Chip.NONE, board.getWinner());
    }

    @Test
    public void testWinningCondition03() {
        Board board = new Board();
        for (int i = 0; i < 7; i++) {
            if (i % 2 != 0)
                board.insertChipAt(4);
            else board.insertChipAt(5);
        }
        assertEquals(Chip.YELLOW, board.getWinner());
    }

    @Test
    public void testWinningCondition04() {
        Board board = new Board();
        board.insertChipAt(5);
        board.insertChipAt(3);
        board.insertChipAt(7);
        board.insertChipAt(6);
        board.insertChipAt(7);
        board.insertChipAt(6);
        board.insertChipAt(7);
        board.insertChipAt(6);
        board.insertChipAt(7);
        assertEquals(Chip.RED, board.getWinner());
    }

    @Test
    public void testWinningCondition05() {
        Board board = new Board();
        board.insertChipAt(5);
        board.insertChipAt(3);
        board.insertChipAt(7);
        board.insertChipAt(6);
        board.insertChipAt(7);
        board.insertChipAt(6);
        board.insertChipAt(7);
        board.insertChipAt(6);
        board.insertChipAt(1);
        board.insertChipAt(6);
        assertEquals(Chip.YELLOW, board.getWinner());
    }

    @Test
    public void testWinningCondition06() {
        Board board = new Board();
        board.insertChipAt(1);
        board.insertChipAt(2);
        board.insertChipAt(1);
        board.insertChipAt(1);
        board.insertChipAt(2);
        board.insertChipAt(3);
        board.insertChipAt(2);
        board.insertChipAt(3);
        board.insertChipAt(2);
        assertEquals(Chip.NONE, board.getWinner());
    }

    @Test
    public void testWinningCondition07() {
        Board board = new Board();
        board.insertChipAt(1);
        board.insertChipAt(2);
        board.insertChipAt(3);
        board.insertChipAt(4);
        board.insertChipAt(5);
        board.insertChipAt(6);
        board.insertChipAt(7);
        board.insertChipAt(6);
        board.insertChipAt(7);
        board.insertChipAt(6);
        board.insertChipAt(7);
        board.insertChipAt(6);
        assertEquals(Chip.RED, board.getWinner());
    }

    @Test
    public void testWinningCondition08() {
        Board board = new Board();
        board.insertChipAt(1);
        board.insertChipAt(1);
        board.insertChipAt(1);
        board.insertChipAt(1);
        board.insertChipAt(5);
        board.insertChipAt(6);
        board.insertChipAt(7);
        board.insertChipAt(6);
        board.insertChipAt(7);
        assertEquals(Chip.RED, board.getWinner());
    }

    @Test
    public void testWinningCondition09() {
        Board board = new Board();
        board.insertChipAt(3);
        board.insertChipAt(4);
        board.insertChipAt(5);
        board.insertChipAt(6);
        board.insertChipAt(3);
        board.insertChipAt(7);
        board.insertChipAt(4);
        board.insertChipAt(7);
        board.insertChipAt(5);
        board.insertChipAt(7);
        board.insertChipAt(6);
        assertEquals(Chip.RED, board.getWinner());
    }

    @Test
    public void testWinningCondition10() {
        Board board = new Board();
        board.insertChipAt(4);
        assertEquals("4", board.getConfiguration());
    }

    @Test
    public void testWinningCondition11() {
        Board board = new Board("1231231");
        board.insertChipAt(4);
        assertEquals("12312314", board.getConfiguration());
    }

    @Test
    public void testWinningCondition12() {
        Board board = new Board();
        board.insertChipAt(4);
        board.insertChipAt(6);
        assertEquals("46", board.getConfiguration());
    }

    @Test
    public void testWinningCondition13() {
        Board board = new Board();
        assertEquals(Chip.NONE, board.getWinner());
        assertEquals(Chip.RED, board.getCurrentPlayer());
        assertEquals("", board.getConfiguration());
    }

    @Test
    public void testWinningCondition14() {
        Board board = new Board();
        board.insertChipAt(1);
        board.insertChipAt(2);
        board.insertChipAt(2);
        board.insertChipAt(3);
        board.insertChipAt(3);
        board.insertChipAt(4);
        board.insertChipAt(3);
        board.insertChipAt(4);
        board.insertChipAt(5);
        board.insertChipAt(4);
        board.insertChipAt(4);
        assertEquals(Chip.RED, board.getWinner());
    }

    @Test
    public void testCurrentCondition01() {
        Board board = new Board();
        board.insertChipAt(3);
        board.insertChipAt(4);
        board.insertChipAt(3);
        board.insertChipAt(2);
        board.insertChipAt(5);
        board.insertChipAt(5);
        board.insertChipAt(4);
        assertEquals("|_ _ _ _ _ _ _|/n" + "|_ _ _ _ _ _ _|/n" + "|_ _ _ _ _ _ _|/n" + "|_ _ _ _ _ _ _|/n" + "|_ _ _ _ _ _ _|/n" + "|_ _ R R Y _ _|/n" + "|_ Y R Y R _ _|", board.getCurrentPlayer());
    }
}
