import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ GameOverExceptionTest0.class, GameOverExceptionTest1.class, GameOverExceptionTest2.class, GameOverExceptionTest3.class, GameOverExceptionTest4.class })
public class GameOverExceptionTest {
}

