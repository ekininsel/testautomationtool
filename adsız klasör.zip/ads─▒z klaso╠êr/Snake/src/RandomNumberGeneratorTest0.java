import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RandomNumberGeneratorTest0 {

    public static boolean debug = false;

    @Test
    public void test0001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0001");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        try {
            int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 100, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=100 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test0002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0002");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        try {
            int int3 = randomNumberGenerator0.getRandomNumber(100, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=100 max=10");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test0003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0003");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        try {
            int int10 = randomNumberGenerator0.getRandomNumber(73, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=73 max=4");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 80 + "'", int7 == 80);
    }

    @Test
    public void test0004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0004");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        try {
            int int10 = randomNumberGenerator0.getRandomNumber((int) '4', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=52 max=10");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 49 + "'", int7 == 49);
    }

    @Test
    public void test0005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0005");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        try {
            int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 100, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=100 max=97");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test0006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0006");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        try {
            int int11 = randomNumberGenerator0.getRandomNumber((int) (byte) 10, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=10 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 71 + "'", int4 == 71);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test0007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0007");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass2 = randomNumberGenerator0.getClass();
        try {
            int int5 = randomNumberGenerator0.getRandomNumber((int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=100 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test0008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0008");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        try {
            int int8 = randomNumberGenerator0.getRandomNumber((int) ' ', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=32 max=1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 65 + "'", int4 == 65);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test0009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0009");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        try {
            int int8 = randomNumberGenerator0.getRandomNumber(10, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=10 max=4");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test0010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0010");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        try {
            int int9 = randomNumberGenerator0.getRandomNumber(27, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=27 max=-1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test0011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0011");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(41, 39);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=41 max=39");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 85 + "'", int4 == 85);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 34 + "'", int10 == 34);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test0012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0012");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(72, 41);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=72 max=41");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 46 + "'", int4 == 46);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 27 + "'", int10 == 27);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test0013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0013");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        try {
            int int10 = randomNumberGenerator0.getRandomNumber(91, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=91 max=32");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test0014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0014");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        try {
            int int10 = randomNumberGenerator0.getRandomNumber((int) (byte) 100, 87);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=100 max=87");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test0015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0015");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        try {
            int int12 = randomNumberGenerator0.getRandomNumber((int) '#', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=35 max=1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 94 + "'", int4 == 94);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test0016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0016");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        try {
            int int8 = randomNumberGenerator0.getRandomNumber(87, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=87 max=10");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 93 + "'", int4 == 93);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test0017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0017");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        try {
            int int11 = randomNumberGenerator0.getRandomNumber(73, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=73 max=31");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 21 + "'", int4 == 21);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
    }

    @Test
    public void test0018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0018");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        try {
            int int13 = randomNumberGenerator0.getRandomNumber(87, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=87 max=-1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 49 + "'", int7 == 49);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 78 + "'", int10 == 78);
    }

    @Test
    public void test0019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0019");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass2 = randomNumberGenerator0.getClass();
        try {
            int int5 = randomNumberGenerator0.getRandomNumber(76, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=76 max=-1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test0020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0020");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        try {
            int int11 = randomNumberGenerator0.getRandomNumber(38, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=38 max=1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 11 + "'", int4 == 11);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test0021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0021");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        try {
            int int13 = randomNumberGenerator0.getRandomNumber(94, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=94 max=31");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test0022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0022");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(34, 39);
        int int13 = randomNumberGenerator0.getRandomNumber(37, 43);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(6, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=6 max=5");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 36 + "'", int10 == 36);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 38 + "'", int13 == 38);
    }

    @Test
    public void test0023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0023");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(5, 73);
        try {
            int int15 = randomNumberGenerator0.getRandomNumber((int) (byte) 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=10 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 42 + "'", int12 == 42);
    }

    @Test
    public void test0024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0024");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        try {
            int int15 = randomNumberGenerator0.getRandomNumber(86, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=86 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 76 + "'", int4 == 76);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 44 + "'", int10 == 44);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test0025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0025");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        int int9 = randomNumberGenerator0.getRandomNumber(73, (int) (short) 100);
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        try {
            int int13 = randomNumberGenerator0.getRandomNumber(83, 49);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=83 max=49");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 89 + "'", int9 == 89);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test0026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0026");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass2 = randomNumberGenerator0.getClass();
        try {
            int int5 = randomNumberGenerator0.getRandomNumber(93, 79);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=93 max=79");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test0027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0027");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(5, 73);
        try {
            int int15 = randomNumberGenerator0.getRandomNumber(33, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=33 max=1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 53 + "'", int4 == 53);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 14 + "'", int12 == 14);
    }

    @Test
    public void test0028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0028");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        try {
            int int3 = randomNumberGenerator0.getRandomNumber(9, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=9 max=2");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test0029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0029");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(49, 36);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=49 max=36");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 70 + "'", int4 == 70);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 43 + "'", int13 == 43);
    }

    @Test
    public void test0030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0030");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(49, 86);
        try {
            int int15 = randomNumberGenerator0.getRandomNumber(97, 84);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=97 max=84");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 71 + "'", int4 == 71);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 80 + "'", int12 == 80);
    }

    @Test
    public void test0031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0031");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass2 = randomNumberGenerator0.getClass();
        try {
            int int5 = randomNumberGenerator0.getRandomNumber(72, 38);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=72 max=38");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test0032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0032");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(40, 52);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(31, 22);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=31 max=22");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 41 + "'", int4 == 41);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 41 + "'", int10 == 41);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test0033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0033");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(4, 5);
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        int int18 = randomNumberGenerator0.getRandomNumber(9, 43);
        try {
            int int21 = randomNumberGenerator0.getRandomNumber(89, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=89 max=5");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 96 + "'", int4 == 96);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 21 + "'", int18 == 21);
    }

    @Test
    public void test0034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0034");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        try {
            int int8 = randomNumberGenerator0.getRandomNumber(93, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=93 max=21");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test0035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0035");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        try {
            int int15 = randomNumberGenerator0.getRandomNumber((int) 'a', 88);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=97 max=88");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 75 + "'", int4 == 75);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test0036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0036");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        try {
            int int15 = randomNumberGenerator0.getRandomNumber(94, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=94 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57 + "'", int4 == 57);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 62 + "'", int10 == 62);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test0037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0037");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        try {
            int int12 = randomNumberGenerator0.getRandomNumber(9, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=9 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test0038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0038");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber(79, (int) (short) 100);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        try {
            int int12 = randomNumberGenerator0.getRandomNumber(14, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=14 max=4");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 14 + "'", int4 == 14);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 89 + "'", int8 == 89);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test0039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0039");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(4, 5);
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(5, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=5 max=-1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 54 + "'", int10 == 54);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test0040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0040");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        try {
            int int8 = randomNumberGenerator0.getRandomNumber(46, 33);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=46 max=33");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test0041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0041");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber((int) '#', 76);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(92, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=92 max=15");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 92 + "'", int7 == 92);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 92 + "'", int10 == 92);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 54 + "'", int13 == 54);
    }

    @Test
    public void test0042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0042");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(34, 39);
        int int13 = randomNumberGenerator0.getRandomNumber(37, 43);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(39, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=39 max=10");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 66 + "'", int7 == 66);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 37 + "'", int10 == 37);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 39 + "'", int13 == 39);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test0043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0043");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(93, 93);
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(87, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=87 max=2");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 46 + "'", int4 == 46);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 55 + "'", int10 == 55);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 93 + "'", int15 == 93);
    }

    @Test
    public void test0044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0044");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(12, 27);
        int int13 = randomNumberGenerator0.getRandomNumber((int) ' ', 52);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(85, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=85 max=52");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 51 + "'", int13 == 51);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test0045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0045");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber((-1), (int) (short) 10);
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=10 max=-1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 7 + "'", int7 == 7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 91 + "'", int10 == 91);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 42 + "'", int13 == 42);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
    }

    @Test
    public void test0046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0046");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber((int) ' ', 72);
        int int13 = randomNumberGenerator0.getRandomNumber(23, 97);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(39, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=39 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 46 + "'", int10 == 46);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 87 + "'", int13 == 87);
    }

    @Test
    public void test0047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0047");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(12, 27);
        int int13 = randomNumberGenerator0.getRandomNumber((int) ' ', 52);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(56, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=56 max=24");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 21 + "'", int10 == 21);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 37 + "'", int13 == 37);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test0048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0048");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        int int11 = randomNumberGenerator0.getRandomNumber(0, 51);
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        try {
            int int15 = randomNumberGenerator0.getRandomNumber(83, 67);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=83 max=67");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 76 + "'", int4 == 76);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 44 + "'", int11 == 44);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test0049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0049");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        try {
            int int8 = randomNumberGenerator0.getRandomNumber(84, 49);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=84 max=49");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test0050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0050");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(0, 12);
        int int15 = randomNumberGenerator0.getRandomNumber(36, 93);
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(79, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=79 max=35");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 78 + "'", int4 == 78);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 7 + "'", int8 == 7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86 + "'", int15 == 86);
    }

    @Test
    public void test0051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0051");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber((-1), 51);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        try {
            int int11 = randomNumberGenerator0.getRandomNumber(72, 71);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=72 max=71");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test0052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0052");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber((int) 'a', 59);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=97 max=59");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 63 + "'", int4 == 63);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 74 + "'", int13 == 74);
    }

    @Test
    public void test0053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0053");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber((int) ' ', 72);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(72, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=72 max=1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 38 + "'", int4 == 38);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 67 + "'", int10 == 67);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test0054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0054");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(93, 93);
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(77, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=77 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 90 + "'", int4 == 90);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 53 + "'", int10 == 53);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 93 + "'", int15 == 93);
    }

    @Test
    public void test0055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0055");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        int int9 = randomNumberGenerator0.getRandomNumber((int) (short) 0, 21);
        try {
            int int12 = randomNumberGenerator0.getRandomNumber(82, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=82 max=-1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 88 + "'", int4 == 88);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 14 + "'", int9 == 14);
    }

    @Test
    public void test0056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0056");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(34, 39);
        int int13 = randomNumberGenerator0.getRandomNumber(37, 43);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(39, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=39 max=16");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 70 + "'", int7 == 70);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 35 + "'", int10 == 35);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 38 + "'", int13 == 38);
    }

    @Test
    public void test0057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0057");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        try {
            int int3 = randomNumberGenerator0.getRandomNumber(94, 82);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=94 max=82");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test0058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0058");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber((int) ' ', 72);
        int int13 = randomNumberGenerator0.getRandomNumber(23, 97);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(41, 25);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=41 max=25");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 68 + "'", int4 == 68);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 51 + "'", int10 == 51);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 67 + "'", int13 == 67);
    }

    @Test
    public void test0059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0059");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(31, 31);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(76, 29);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=76 max=29");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test0060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0060");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        int int9 = randomNumberGenerator0.getRandomNumber((int) (short) 0, 21);
        try {
            int int12 = randomNumberGenerator0.getRandomNumber(87, 79);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=87 max=79");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
    }

    @Test
    public void test0061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0061");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        try {
            int int13 = randomNumberGenerator0.getRandomNumber(81, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=81 max=-1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 14 + "'", int4 == 14);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test0062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0062");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        try {
            int int8 = randomNumberGenerator0.getRandomNumber(19, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=19 max=3");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test0063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0063");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(4, 5);
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(65, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=65 max=20");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 17 + "'", int4 == 17);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test0064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0064");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        try {
            int int15 = randomNumberGenerator0.getRandomNumber(58, 25);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=58 max=25");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 21 + "'", int4 == 21);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57 + "'", int10 == 57);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test0065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0065");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        int int9 = randomNumberGenerator0.getRandomNumber(73, (int) (short) 100);
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        try {
            int int13 = randomNumberGenerator0.getRandomNumber(94, 72);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=94 max=72");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 89 + "'", int9 == 89);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test0066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0066");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        int int13 = randomNumberGenerator0.getRandomNumber(4, 69);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(62, 26);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=62 max=26");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 16 + "'", int10 == 16);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 62 + "'", int13 == 62);
    }

    @Test
    public void test0067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0067");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(35, 56);
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(83, 67);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=83 max=67");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 45 + "'", int11 == 45);
    }

    @Test
    public void test0068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0068");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(86, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=86 max=16");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 74 + "'", int7 == 74);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 91 + "'", int10 == 91);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test0069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0069");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        try {
            int int12 = randomNumberGenerator0.getRandomNumber(18, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=18 max=5");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 33 + "'", int4 == 33);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test0070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0070");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        try {
            int int10 = randomNumberGenerator0.getRandomNumber((int) (byte) 100, 59);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=100 max=59");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test0071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0071");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(40, 52);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(0, 88);
        int int17 = randomNumberGenerator0.getRandomNumber((int) (short) 0, 49);
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(94, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=94 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 18 + "'", int4 == 18);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 51 + "'", int10 == 51);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 26 + "'", int14 == 26);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 18 + "'", int17 == 18);
    }

    @Test
    public void test0072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0072");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(34, 39);
        int int13 = randomNumberGenerator0.getRandomNumber(37, 43);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(82, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=82 max=52");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 23 + "'", int7 == 23);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 37 + "'", int10 == 37);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 40 + "'", int13 == 40);
    }

    @Test
    public void test0073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0073");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(0, 12);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(0, 66);
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(18, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=18 max=-1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 34 + "'", int4 == 34);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
    }

    @Test
    public void test0074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0074");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(4, 5);
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(34, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=34 max=9");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 85 + "'", int4 == 85);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 35 + "'", int10 == 35);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
    }

    @Test
    public void test0075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0075");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber((int) ' ', 72);
        int int13 = randomNumberGenerator0.getRandomNumber(23, 97);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(89, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=89 max=8");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 51 + "'", int10 == 51);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
    }

    @Test
    public void test0076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0076");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        try {
            int int9 = randomNumberGenerator0.getRandomNumber(99, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=99 max=10");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test0077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0077");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        try {
            int int9 = randomNumberGenerator0.getRandomNumber(68, 50);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=68 max=50");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 29 + "'", int4 == 29);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test0078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0078");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(19, 82);
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(43, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=43 max=13");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 33 + "'", int11 == 33);
    }

    @Test
    public void test0079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0079");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(99, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=99 max=97");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 65 + "'", int10 == 65);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test0080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0080");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        try {
            int int10 = randomNumberGenerator0.getRandomNumber(72, 14);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=72 max=14");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 25 + "'", int4 == 25);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test0081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0081");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber((int) '#', 76);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(66, 27);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=66 max=27");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 45 + "'", int7 == 45);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 81 + "'", int10 == 81);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 40 + "'", int13 == 40);
    }

    @Test
    public void test0082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0082");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, 76);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(11, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=11 max=5");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 95 + "'", int4 == 95);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
    }

    @Test
    public void test0083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0083");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(5, 72);
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(41, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=41 max=20");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 89 + "'", int4 == 89);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 11 + "'", int8 == 11);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 19 + "'", int16 == 19);
    }

    @Test
    public void test0084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0084");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber((-1), 51);
        int int10 = randomNumberGenerator0.getRandomNumber(52, 89);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(55, 22);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=55 max=22");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 81 + "'", int10 == 81);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test0085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0085");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        try {
            int int3 = randomNumberGenerator0.getRandomNumber(9, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=9 max=-1");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test0086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0086");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber((-1), (int) (short) 10);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(99, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=99 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 55 + "'", int7 == 55);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 84 + "'", int10 == 84);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 51 + "'", int13 == 51);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test0087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0087");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(25, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=25 max=21");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test0088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0088");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(28, 58);
        try {
            int int15 = randomNumberGenerator0.getRandomNumber(79, 25);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=79 max=25");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 79 + "'", int4 == 79);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57 + "'", int12 == 57);
    }

    @Test
    public void test0089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0089");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(0, 12);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(0, 66);
        int int19 = randomNumberGenerator0.getRandomNumber(25, 83);
        try {
            int int22 = randomNumberGenerator0.getRandomNumber((int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=10 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 92 + "'", int4 == 92);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 14 + "'", int8 == 14);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 48 + "'", int16 == 48);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 78 + "'", int19 == 78);
    }

    @Test
    public void test0090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0090");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(4, 5);
        int int17 = randomNumberGenerator0.getRandomNumber(21, 37);
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        int int21 = randomNumberGenerator0.getRandomNumber(41, 76);
        try {
            int int24 = randomNumberGenerator0.getRandomNumber(99, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=99 max=97");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 79 + "'", int4 == 79);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 37 + "'", int17 == 37);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 61 + "'", int21 == 61);
    }

    @Test
    public void test0091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0091");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(85, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=85 max=6");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 72 + "'", int7 == 72);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 42 + "'", int10 == 42);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test0092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0092");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        try {
            int int12 = randomNumberGenerator0.getRandomNumber(3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=3 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 55 + "'", int4 == 55);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test0093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0093");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(0, 12);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(0, 66);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(89, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=89 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test0094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0094");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber(2, 73);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        int int20 = randomNumberGenerator0.getRandomNumber((int) (byte) 10, 97);
        java.lang.Class<?> wildcardClass21 = randomNumberGenerator0.getClass();
        int int24 = randomNumberGenerator0.getRandomNumber(37, 60);
        try {
            int int27 = randomNumberGenerator0.getRandomNumber(51, 14);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=51 max=14");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 55 + "'", int7 == 55);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 53 + "'", int10 == 53);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 35 + "'", int16 == 35);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 45 + "'", int20 == 45);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 41 + "'", int24 == 41);
    }

    @Test
    public void test0095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0095");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber((int) '#', 76);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(31, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=31 max=-1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 71 + "'", int7 == 71);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 50 + "'", int10 == 50);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test0096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0096");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(40, 52);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(0, 88);
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(33, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=33 max=18");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 51 + "'", int10 == 51);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 14 + "'", int14 == 14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test0097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0097");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (byte) 100);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(51, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=51 max=4");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 83 + "'", int4 == 83);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 78 + "'", int12 == 78);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test0098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0098");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        int int16 = randomNumberGenerator0.getRandomNumber(41, 94);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        int int20 = randomNumberGenerator0.getRandomNumber(0, 24);
        try {
            int int23 = randomNumberGenerator0.getRandomNumber(65, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=65 max=-1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 81 + "'", int16 == 81);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
    }

    @Test
    public void test0099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0099");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(78, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=78 max=15");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 89 + "'", int7 == 89);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 61 + "'", int10 == 61);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test0100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0100");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        int int16 = randomNumberGenerator0.getRandomNumber(41, 94);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        int int21 = randomNumberGenerator0.getRandomNumber(50, 92);
        java.lang.Class<?> wildcardClass22 = randomNumberGenerator0.getClass();
        try {
            int int25 = randomNumberGenerator0.getRandomNumber(90, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=90 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 67 + "'", int16 == 67);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 56 + "'", int21 == 56);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test0101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0101");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(0, 12);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(0, 66);
        int int19 = randomNumberGenerator0.getRandomNumber(25, 83);
        try {
            int int22 = randomNumberGenerator0.getRandomNumber(90, 75);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=90 max=75");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 42 + "'", int4 == 42);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 55 + "'", int16 == 55);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 83 + "'", int19 == 83);
    }

    @Test
    public void test0102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0102");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, 76);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(75, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=75 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 55 + "'", int4 == 55);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 67 + "'", int10 == 67);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 46 + "'", int13 == 46);
    }

    @Test
    public void test0103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0103");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(5, 73);
        try {
            int int15 = randomNumberGenerator0.getRandomNumber(59, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=59 max=24");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 7 + "'", int8 == 7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 60 + "'", int12 == 60);
    }

    @Test
    public void test0104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0104");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) 10, 84);
        int int11 = randomNumberGenerator0.getRandomNumber(11, 29);
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(76, 64);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=76 max=64");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 26 + "'", int11 == 26);
    }

    @Test
    public void test0105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0105");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        int int11 = randomNumberGenerator0.getRandomNumber(0, 51);
        int int14 = randomNumberGenerator0.getRandomNumber(34, 43);
        int int17 = randomNumberGenerator0.getRandomNumber(0, 79);
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(79, 62);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=79 max=62");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 27 + "'", int4 == 27);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 38 + "'", int11 == 38);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 43 + "'", int14 == 43);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 68 + "'", int17 == 68);
    }

    @Test
    public void test0106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0106");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        try {
            int int12 = randomNumberGenerator0.getRandomNumber(49, 25);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=49 max=25");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test0107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0107");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        try {
            int int3 = randomNumberGenerator0.getRandomNumber(29, 26);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=29 max=26");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test0108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0108");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(40, 52);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(0, 88);
        int int17 = randomNumberGenerator0.getRandomNumber((int) (short) 0, 49);
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(60, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=60 max=18");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 17 + "'", int4 == 17);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 43 + "'", int10 == 43);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 27 + "'", int14 == 27);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 43 + "'", int17 == 43);
    }

    @Test
    public void test0109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0109");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        int int9 = randomNumberGenerator0.getRandomNumber(73, (int) (short) 100);
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(9, (int) ' ');
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(61, 50);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=61 max=50");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 90 + "'", int9 == 90);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
    }

    @Test
    public void test0110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0110");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(52, 55);
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(88, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=88 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 22 + "'", int4 == 22);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 49 + "'", int10 == 49);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 54 + "'", int15 == 54);
    }

    @Test
    public void test0111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0111");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(28, 71);
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(83, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=83 max=32");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 81 + "'", int4 == 81);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 56 + "'", int16 == 56);
    }

    @Test
    public void test0112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0112");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber((int) '#', 76);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        int int17 = randomNumberGenerator0.getRandomNumber(15, 55);
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(78, 73);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=78 max=73");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 46 + "'", int7 == 46);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 68 + "'", int10 == 68);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 54 + "'", int13 == 54);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 18 + "'", int17 == 18);
    }

    @Test
    public void test0113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0113");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(4, 5);
        int int17 = randomNumberGenerator0.getRandomNumber(21, 37);
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        int int21 = randomNumberGenerator0.getRandomNumber(41, 76);
        try {
            int int24 = randomNumberGenerator0.getRandomNumber(66, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=66 max=12");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 76 + "'", int4 == 76);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 53 + "'", int10 == 53);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 36 + "'", int17 == 36);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 42 + "'", int21 == 42);
    }

    @Test
    public void test0114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0114");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        try {
            int int7 = randomNumberGenerator0.getRandomNumber(65, 38);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=65 max=38");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 65 + "'", int4 == 65);
    }

    @Test
    public void test0115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0115");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        int int16 = randomNumberGenerator0.getRandomNumber(41, 94);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        int int21 = randomNumberGenerator0.getRandomNumber(50, 92);
        java.lang.Class<?> wildcardClass22 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass23 = randomNumberGenerator0.getClass();
        try {
            int int26 = randomNumberGenerator0.getRandomNumber(54, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=54 max=-1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 44 + "'", int13 == 44);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test0116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0116");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        int int3 = randomNumberGenerator0.getRandomNumber(28, 59);
        try {
            int int6 = randomNumberGenerator0.getRandomNumber((int) (short) 100, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=100 max=15");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 54 + "'", int3 == 54);
    }

    @Test
    public void test0117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0117");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(93, 93);
        int int18 = randomNumberGenerator0.getRandomNumber(11, 20);
        java.lang.Class<?> wildcardClass19 = randomNumberGenerator0.getClass();
        int int22 = randomNumberGenerator0.getRandomNumber(82, 93);
        try {
            int int25 = randomNumberGenerator0.getRandomNumber(53, 50);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=53 max=50");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39 + "'", int10 == 39);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 93 + "'", int15 == 93);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 84 + "'", int22 == 84);
    }

    @Test
    public void test0118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0118");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        int int16 = randomNumberGenerator0.getRandomNumber(41, 94);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        try {
            int int20 = randomNumberGenerator0.getRandomNumber((int) (short) 10, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=10 max=9");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 16 + "'", int13 == 16);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 79 + "'", int16 == 79);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test0119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0119");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        try {
            int int14 = randomNumberGenerator0.getRandomNumber((int) 'a', 66);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=97 max=66");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 77 + "'", int7 == 77);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test0120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0120");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber((-1), (int) (short) 10);
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(45, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=45 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 62 + "'", int7 == 62);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 76 + "'", int10 == 76);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 39 + "'", int13 == 39);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
    }

    @Test
    public void test0121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0121");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(35, 56);
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(78, 38);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=78 max=38");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 53 + "'", int11 == 53);
    }

    @Test
    public void test0122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0122");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        int int16 = randomNumberGenerator0.getRandomNumber(41, 94);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        try {
            int int21 = randomNumberGenerator0.getRandomNumber(75, 17);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=75 max=17");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 43 + "'", int4 == 43);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 72 + "'", int13 == 72);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 64 + "'", int16 == 64);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test0123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0123");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        int int11 = randomNumberGenerator0.getRandomNumber(0, 51);
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(76, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=76 max=15");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 61 + "'", int4 == 61);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 26 + "'", int11 == 26);
    }

    @Test
    public void test0124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0124");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(49, 86);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(13, (int) ' ');
        int int19 = randomNumberGenerator0.getRandomNumber(6, 31);
        int int22 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, 44);
        try {
            int int25 = randomNumberGenerator0.getRandomNumber(61, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=61 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 51 + "'", int4 == 51);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 64 + "'", int7 == 64);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 77 + "'", int12 == 77);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 30 + "'", int19 == 30);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 34 + "'", int22 == 34);
    }

    @Test
    public void test0125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0125");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber((int) ' ', 72);
        try {
            int int13 = randomNumberGenerator0.getRandomNumber(26, 25);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=26 max=25");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 87 + "'", int4 == 87);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 71 + "'", int10 == 71);
    }

    @Test
    public void test0126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0126");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        try {
            int int12 = randomNumberGenerator0.getRandomNumber(80, 37);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=80 max=37");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 67 + "'", int4 == 67);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test0127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0127");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(49, 86);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(55, 59);
        int int19 = randomNumberGenerator0.getRandomNumber(0, 93);
        try {
            int int22 = randomNumberGenerator0.getRandomNumber(34, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=34 max=19");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 27 + "'", int4 == 27);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 70 + "'", int7 == 70);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 77 + "'", int12 == 77);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 55 + "'", int16 == 55);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
    }

    @Test
    public void test0128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0128");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(5, 72);
        int int19 = randomNumberGenerator0.getRandomNumber((-1), 37);
        try {
            int int22 = randomNumberGenerator0.getRandomNumber(99, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=99 max=31");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 40 + "'", int4 == 40);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 50 + "'", int16 == 50);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 12 + "'", int19 == 12);
    }

    @Test
    public void test0129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0129");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        int int13 = randomNumberGenerator0.getRandomNumber((int) (short) 0, (int) (byte) 1);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(32, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=32 max=15");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 64 + "'", int4 == 64);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test0130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0130");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        int int16 = randomNumberGenerator0.getRandomNumber(41, 94);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        int int21 = randomNumberGenerator0.getRandomNumber(50, 92);
        try {
            int int24 = randomNumberGenerator0.getRandomNumber(47, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=47 max=2");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 37 + "'", int4 == 37);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 19 + "'", int13 == 19);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 51 + "'", int16 == 51);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 89 + "'", int21 == 89);
    }

    @Test
    public void test0131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0131");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(49, 86);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(65, 55);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=65 max=55");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 39 + "'", int4 == 39);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 63 + "'", int12 == 63);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test0132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0132");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        int int13 = randomNumberGenerator0.getRandomNumber(4, 69);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(28, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=28 max=9");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 64 + "'", int4 == 64);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 44 + "'", int10 == 44);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 63 + "'", int13 == 63);
    }

    @Test
    public void test0133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0133");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber((int) ' ', 72);
        int int13 = randomNumberGenerator0.getRandomNumber(23, 97);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(78, 72);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=78 max=72");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 63 + "'", int4 == 63);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 42 + "'", int10 == 42);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 94 + "'", int13 == 94);
    }

    @Test
    public void test0134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0134");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber(2, 73);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        try {
            int int21 = randomNumberGenerator0.getRandomNumber((int) 'a', 94);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=97 max=94");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 37 + "'", int7 == 37);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 89 + "'", int10 == 89);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 28 + "'", int13 == 28);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 69 + "'", int16 == 69);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test0135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0135");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 2);
        try {
            int int15 = randomNumberGenerator0.getRandomNumber(76, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=76 max=21");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 76 + "'", int4 == 76);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 11 + "'", int8 == 11);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test0136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0136");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(4, 5);
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(44, 25);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=44 max=25");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 60 + "'", int4 == 60);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 72 + "'", int10 == 72);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test0137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0137");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(0, 14);
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(8, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=8 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 37 + "'", int4 == 37);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
    }

    @Test
    public void test0138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0138");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        try {
            int int15 = randomNumberGenerator0.getRandomNumber((int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=1 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 90 + "'", int4 == 90);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39 + "'", int10 == 39);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test0139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0139");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(49, 86);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(55, 59);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(62, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=62 max=28");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 58 + "'", int4 == 58);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 11 + "'", int7 == 11);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 69 + "'", int12 == 69);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 55 + "'", int16 == 55);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test0140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0140");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber(79, (int) (short) 100);
        int int11 = randomNumberGenerator0.getRandomNumber(4, 81);
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(51, 26);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=51 max=26");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 78 + "'", int4 == 78);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 89 + "'", int8 == 89);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 30 + "'", int11 == 30);
    }

    @Test
    public void test0141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0141");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(28, 71);
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(69, 44);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=69 max=44");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 40 + "'", int4 == 40);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 11 + "'", int8 == 11);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 65 + "'", int16 == 65);
    }

    @Test
    public void test0142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0142");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber(2, 73);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        try {
            int int21 = randomNumberGenerator0.getRandomNumber(73, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=73 max=4");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 7 + "'", int7 == 7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 56 + "'", int10 == 56);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 66 + "'", int16 == 66);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test0143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0143");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(12, 27);
        int int13 = randomNumberGenerator0.getRandomNumber(65, 69);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(98, 46);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=98 max=46");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 18 + "'", int10 == 18);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 66 + "'", int13 == 66);
    }

    @Test
    public void test0144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0144");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        try {
            int int12 = randomNumberGenerator0.getRandomNumber(67, 17);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=67 max=17");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 29 + "'", int4 == 29);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 64 + "'", int7 == 64);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test0145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0145");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(5, 72);
        int int19 = randomNumberGenerator0.getRandomNumber((-1), 37);
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        int int23 = randomNumberGenerator0.getRandomNumber((int) (short) -1, 60);
        java.lang.Class<?> wildcardClass24 = randomNumberGenerator0.getClass();
        try {
            int int27 = randomNumberGenerator0.getRandomNumber(67, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=67 max=24");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 50 + "'", int4 == 50);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 14 + "'", int16 == 14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 14 + "'", int19 == 14);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 54 + "'", int23 == 54);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test0146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0146");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, (int) (byte) 1);
        try {
            int int11 = randomNumberGenerator0.getRandomNumber(88, 17);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=88 max=17");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test0147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0147");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber((-1), 51);
        int int10 = randomNumberGenerator0.getRandomNumber((int) (short) 0, 10);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(97, 82);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=97 max=82");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 7 + "'", int7 == 7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test0148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0148");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber((-1), 51);
        int int10 = randomNumberGenerator0.getRandomNumber(52, 89);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(56, 64);
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(82, 65);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=82 max=65");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 30 + "'", int7 == 30);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 89 + "'", int10 == 89);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 64 + "'", int15 == 64);
    }

    @Test
    public void test0149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0149");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(52, 55);
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(51, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=51 max=15");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
    }

    @Test
    public void test0150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0150");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(76, (int) (byte) 100);
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(0, 0);
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(77, 73);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=77 max=73");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 61 + "'", int4 == 61);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 78 + "'", int11 == 78);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test0151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0151");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, 76);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        int int17 = randomNumberGenerator0.getRandomNumber(53, 66);
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(99, 46);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=99 max=46");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 56 + "'", int4 == 56);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 63 + "'", int10 == 63);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 27 + "'", int13 == 27);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 53 + "'", int17 == 53);
    }

    @Test
    public void test0152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0152");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(31, 31);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(77, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=77 max=13");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test0153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0153");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(49, 86);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(55, 59);
        int int19 = randomNumberGenerator0.getRandomNumber(0, 93);
        try {
            int int22 = randomNumberGenerator0.getRandomNumber(50, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=50 max=-1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 48 + "'", int4 == 48);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 90 + "'", int7 == 90);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 54 + "'", int12 == 54);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 57 + "'", int16 == 57);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 35 + "'", int19 == 35);
    }

    @Test
    public void test0154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0154");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        int int11 = randomNumberGenerator0.getRandomNumber(0, 51);
        int int14 = randomNumberGenerator0.getRandomNumber(34, 43);
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(42, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=42 max=32");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 41 + "'", int11 == 41);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 43 + "'", int14 == 43);
    }

    @Test
    public void test0155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0155");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(67, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=67 max=4");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 40 + "'", int4 == 40);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 11 + "'", int8 == 11);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test0156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0156");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        int int11 = randomNumberGenerator0.getRandomNumber(0, 51);
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber((int) '4', 80);
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(34, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=34 max=11");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 91 + "'", int4 == 91);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 7 + "'", int11 == 7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 65 + "'", int16 == 65);
    }

    @Test
    public void test0157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0157");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(0, 12);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(0, 66);
        int int19 = randomNumberGenerator0.getRandomNumber(25, 83);
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass21 = randomNumberGenerator0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 81 + "'", int4 == 81);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 18 + "'", int16 == 18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 79 + "'", int19 == 79);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test0158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0158");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber((int) '#', 76);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(65, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=65 max=5");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 51 + "'", int10 == 51);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 60 + "'", int13 == 60);
    }

    @Test
    public void test0159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0159");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(19, 82);
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        try {
            int int15 = randomNumberGenerator0.getRandomNumber(80, 75);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=80 max=75");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 61 + "'", int11 == 61);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test0160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0160");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(12, 27);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber((int) (short) 0, (int) (byte) 0);
        int int17 = randomNumberGenerator0.getRandomNumber(0, 82);
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(65, 61);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=65 max=61");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 36 + "'", int17 == 36);
    }

    @Test
    public void test0161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0161");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        int int17 = randomNumberGenerator0.getRandomNumber((int) (short) 10, 79);
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(76, 71);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=76 max=71");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 38 + "'", int10 == 38);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 23 + "'", int13 == 23);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 75 + "'", int17 == 75);
    }

    @Test
    public void test0162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0162");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        int int17 = randomNumberGenerator0.getRandomNumber(0, 98);
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(90, 61);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=90 max=61");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 75 + "'", int7 == 75);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 90 + "'", int10 == 90);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 67 + "'", int17 == 67);
    }

    @Test
    public void test0163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0163");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(42, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=42 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 78 + "'", int7 == 78);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 42 + "'", int13 == 42);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test0164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0164");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(7, 67);
        int int14 = randomNumberGenerator0.getRandomNumber(33, 93);
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(95, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=95 max=52");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43 + "'", int11 == 43);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 46 + "'", int14 == 46);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test0165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0165");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(52, 55);
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(71, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=71 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 72 + "'", int4 == 72);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 17 + "'", int10 == 17);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 55 + "'", int15 == 55);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test0166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0166");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        try {
            int int3 = randomNumberGenerator0.getRandomNumber(96, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=96 max=8");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test0167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0167");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber((-1), 51);
        int int10 = randomNumberGenerator0.getRandomNumber(52, 89);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(56, 64);
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(25, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=25 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 14 + "'", int7 == 14);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 75 + "'", int10 == 75);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 57 + "'", int15 == 57);
    }

    @Test
    public void test0168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0168");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber((int) '#', 76);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(49, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=49 max=-1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 80 + "'", int7 == 80);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 54 + "'", int10 == 54);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 42 + "'", int13 == 42);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test0169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0169");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(5, 72);
        int int19 = randomNumberGenerator0.getRandomNumber((-1), 37);
        int int22 = randomNumberGenerator0.getRandomNumber(9, 57);
        try {
            int int25 = randomNumberGenerator0.getRandomNumber((int) 'a', 65);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=97 max=65");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 14 + "'", int4 == 14);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 8 + "'", int19 == 8);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 35 + "'", int22 == 35);
    }

    @Test
    public void test0170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0170");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(47, 47);
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(61, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=61 max=1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 47 + "'", int14 == 47);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test0171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0171");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(27, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=27 max=24");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 93 + "'", int7 == 93);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 48 + "'", int10 == 48);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test0172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0172");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        int int17 = randomNumberGenerator0.getRandomNumber(52, 73);
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        try {
            int int21 = randomNumberGenerator0.getRandomNumber(97, 58);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=97 max=58");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 41 + "'", int7 == 41);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 72 + "'", int10 == 72);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 14 + "'", int13 == 14);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 67 + "'", int17 == 67);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test0173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0173");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        int int9 = randomNumberGenerator0.getRandomNumber(73, (int) (short) 100);
        try {
            int int12 = randomNumberGenerator0.getRandomNumber(72, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=72 max=18");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 98 + "'", int9 == 98);
    }

    @Test
    public void test0174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0174");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(55, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=55 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 47 + "'", int7 == 47);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 83 + "'", int10 == 83);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test0175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0175");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(0, 12);
        int int15 = randomNumberGenerator0.getRandomNumber(36, 93);
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        try {
            int int21 = randomNumberGenerator0.getRandomNumber(49, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=49 max=28");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 41 + "'", int4 == 41);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 72 + "'", int15 == 72);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test0176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0176");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(40, 52);
        int int13 = randomNumberGenerator0.getRandomNumber(38, 61);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(25, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=25 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 46 + "'", int4 == 46);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 57 + "'", int13 == 57);
    }

    @Test
    public void test0177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0177");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        try {
            int int10 = randomNumberGenerator0.getRandomNumber(97, 62);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=97 max=62");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 17 + "'", int4 == 17);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test0178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0178");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(76, (int) (byte) 100);
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        try {
            int int15 = randomNumberGenerator0.getRandomNumber(91, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=91 max=19");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 98 + "'", int11 == 98);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test0179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0179");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(52, 55);
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        int int19 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 48);
        try {
            int int22 = randomNumberGenerator0.getRandomNumber(87, 17);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=87 max=17");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 29 + "'", int4 == 29);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 73 + "'", int10 == 73);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
    }

    @Test
    public void test0180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0180");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        try {
            int int11 = randomNumberGenerator0.getRandomNumber(89, 56);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=89 max=56");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test0181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0181");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(76, (int) (byte) 100);
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(0, 0);
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(92, 39);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=92 max=39");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 37 + "'", int4 == 37);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 90 + "'", int11 == 90);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test0182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0182");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(12, 27);
        int int13 = randomNumberGenerator0.getRandomNumber(65, 69);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(78, 57);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=78 max=57");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 22 + "'", int10 == 22);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test0183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0183");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(0, 14);
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        try {
            int int15 = randomNumberGenerator0.getRandomNumber(77, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=77 max=10");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 53 + "'", int4 == 53);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 11 + "'", int11 == 11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test0184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0184");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber(2, 73);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        int int20 = randomNumberGenerator0.getRandomNumber((int) (byte) 10, 97);
        java.lang.Class<?> wildcardClass21 = randomNumberGenerator0.getClass();
        int int24 = randomNumberGenerator0.getRandomNumber(37, 60);
        try {
            int int27 = randomNumberGenerator0.getRandomNumber(23, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=23 max=-1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 41 + "'", int7 == 41);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57 + "'", int10 == 57);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 63 + "'", int16 == 63);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 13 + "'", int20 == 13);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 55 + "'", int24 == 55);
    }

    @Test
    public void test0185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0185");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(0, 12);
        int int15 = randomNumberGenerator0.getRandomNumber(36, 93);
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        int int19 = randomNumberGenerator0.getRandomNumber(61, 68);
        try {
            int int22 = randomNumberGenerator0.getRandomNumber(35, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=35 max=32");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 95 + "'", int4 == 95);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 66 + "'", int15 == 66);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 62 + "'", int19 == 62);
    }

    @Test
    public void test0186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0186");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(31, 31);
        int int13 = randomNumberGenerator0.getRandomNumber(0, 100);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(56, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=56 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 62 + "'", int13 == 62);
    }

    @Test
    public void test0187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0187");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(5, 73);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(32, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=32 max=15");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 11 + "'", int8 == 11);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 38 + "'", int12 == 38);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test0188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0188");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(4, 5);
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        int int20 = randomNumberGenerator0.getRandomNumber(47, 99);
        try {
            int int23 = randomNumberGenerator0.getRandomNumber(66, 43);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=66 max=43");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 56 + "'", int10 == 56);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 94 + "'", int20 == 94);
    }

    @Test
    public void test0189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0189");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(40, 52);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(0, 88);
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(27, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=27 max=8");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 49 + "'", int10 == 49);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
    }

    @Test
    public void test0190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0190");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(35, 56);
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        try {
            int int15 = randomNumberGenerator0.getRandomNumber(73, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=73 max=7");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 37 + "'", int11 == 37);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test0191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0191");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(19, 82);
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(51, 71);
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(84, 82);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=84 max=82");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 56 + "'", int11 == 56);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 65 + "'", int16 == 65);
    }

    @Test
    public void test0192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0192");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(49, 86);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(13, (int) ' ');
        int int19 = randomNumberGenerator0.getRandomNumber(6, 31);
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        int int23 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 74);
        java.lang.Class<?> wildcardClass24 = randomNumberGenerator0.getClass();
        try {
            int int27 = randomNumberGenerator0.getRandomNumber(84, 23);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=84 max=23");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 87 + "'", int4 == 87);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 49 + "'", int7 == 49);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 73 + "'", int12 == 73);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 30 + "'", int16 == 30);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 21 + "'", int19 == 21);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 25 + "'", int23 == 25);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test0193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0193");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber((int) ' ', 72);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        try {
            int int15 = randomNumberGenerator0.getRandomNumber(70, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=70 max=21");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 54 + "'", int4 == 54);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 35 + "'", int10 == 35);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test0194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0194");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(93, 93);
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(28, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=28 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 33 + "'", int4 == 33);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 40 + "'", int10 == 40);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 93 + "'", int15 == 93);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test0195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0195");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(93, 93);
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(24, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=24 max=4");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 59 + "'", int4 == 59);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 93 + "'", int15 == 93);
    }

    @Test
    public void test0196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0196");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(85, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=85 max=11");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 25 + "'", int4 == 25);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 11 + "'", int8 == 11);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 83 + "'", int13 == 83);
    }

    @Test
    public void test0197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0197");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        int int9 = randomNumberGenerator0.getRandomNumber(73, (int) (short) 100);
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(9, (int) ' ');
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(60, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=60 max=20");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 92 + "'", int9 == 92);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 14 + "'", int15 == 14);
    }

    @Test
    public void test0198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0198");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(0, 12);
        int int15 = randomNumberGenerator0.getRandomNumber(36, 93);
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(59, 53);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=59 max=53");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 53 + "'", int4 == 53);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 90 + "'", int15 == 90);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test0199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0199");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) 10, 84);
        int int11 = randomNumberGenerator0.getRandomNumber(11, 29);
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        try {
            int int15 = randomNumberGenerator0.getRandomNumber(62, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=62 max=12");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 78 + "'", int8 == 78);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test0200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0200");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(12, 27);
        int int13 = randomNumberGenerator0.getRandomNumber(65, 69);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(70, 42);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=70 max=42");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 66 + "'", int13 == 66);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test0201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0201");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(4, 5);
        int int17 = randomNumberGenerator0.getRandomNumber(21, 37);
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        try {
            int int21 = randomNumberGenerator0.getRandomNumber(100, 73);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=100 max=73");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 40 + "'", int10 == 40);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 30 + "'", int17 == 30);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test0202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0202");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber(2, 73);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass19 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        try {
            int int23 = randomNumberGenerator0.getRandomNumber(71, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=71 max=16");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 94 + "'", int10 == 94);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 57 + "'", int16 == 57);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test0203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0203");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber(2, 73);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        int int20 = randomNumberGenerator0.getRandomNumber((int) (byte) 10, 97);
        try {
            int int23 = randomNumberGenerator0.getRandomNumber(84, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=84 max=52");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 76 + "'", int7 == 76);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 64 + "'", int10 == 64);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 25 + "'", int16 == 25);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 53 + "'", int20 == 53);
    }

    @Test
    public void test0204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0204");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(49, 86);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(13, (int) ' ');
        int int19 = randomNumberGenerator0.getRandomNumber(5, 71);
        try {
            int int22 = randomNumberGenerator0.getRandomNumber(100, 17);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=100 max=17");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 82 + "'", int4 == 82);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 64 + "'", int7 == 64);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 75 + "'", int12 == 75);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 26 + "'", int16 == 26);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 17 + "'", int19 == 17);
    }

    @Test
    public void test0205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0205");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber((int) ' ', 72);
        try {
            int int13 = randomNumberGenerator0.getRandomNumber((int) (short) 100, 95);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=100 max=95");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 58 + "'", int4 == 58);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
    }

    @Test
    public void test0206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0206");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        try {
            int int10 = randomNumberGenerator0.getRandomNumber(74, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=74 max=11");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test0207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0207");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(0, 12);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(0, 66);
        int int19 = randomNumberGenerator0.getRandomNumber(25, 83);
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        try {
            int int23 = randomNumberGenerator0.getRandomNumber(96, 57);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=96 max=57");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 42 + "'", int4 == 42);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 7 + "'", int8 == 7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 54 + "'", int16 == 54);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 42 + "'", int19 == 42);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test0208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0208");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber(79, (int) (short) 100);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(31, 80);
        try {
            int int15 = randomNumberGenerator0.getRandomNumber(14, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=14 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 98 + "'", int8 == 98);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 75 + "'", int12 == 75);
    }

    @Test
    public void test0209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0209");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(5, 72);
        int int19 = randomNumberGenerator0.getRandomNumber((-1), 37);
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        int int23 = randomNumberGenerator0.getRandomNumber((int) (short) -1, 60);
        int int26 = randomNumberGenerator0.getRandomNumber(0, 3);
        try {
            int int29 = randomNumberGenerator0.getRandomNumber(72, 25);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=72 max=25");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 33 + "'", int4 == 33);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 26 + "'", int16 == 26);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 15 + "'", int23 == 15);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test0210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0210");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        int int18 = randomNumberGenerator0.getRandomNumber(39, 72);
        int int21 = randomNumberGenerator0.getRandomNumber(0, 75);
        try {
            int int24 = randomNumberGenerator0.getRandomNumber(67, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=67 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 14 + "'", int7 == 14);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 47 + "'", int10 == 47);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 55 + "'", int13 == 55);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 57 + "'", int18 == 57);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 27 + "'", int21 == 27);
    }

    @Test
    public void test0211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0211");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(49, 86);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(16, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=16 max=-1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 76 + "'", int12 == 76);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test0212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0212");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber((-1), (int) (short) 10);
        int int19 = randomNumberGenerator0.getRandomNumber(9, 32);
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        try {
            int int23 = randomNumberGenerator0.getRandomNumber(11, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=11 max=4");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 68 + "'", int10 == 68);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 30 + "'", int13 == 30);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 7 + "'", int16 == 7);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test0213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0213");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(40, 52);
        try {
            int int13 = randomNumberGenerator0.getRandomNumber(77, 75);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=77 max=75");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 41 + "'", int10 == 41);
    }

    @Test
    public void test0214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0214");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        int int13 = randomNumberGenerator0.getRandomNumber((int) (short) 0, (int) (byte) 1);
        int int16 = randomNumberGenerator0.getRandomNumber(13, 41);
        try {
            int int19 = randomNumberGenerator0.getRandomNumber((int) '4', 43);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=52 max=43");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 91 + "'", int4 == 91);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 21 + "'", int10 == 21);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 21 + "'", int16 == 21);
    }

    @Test
    public void test0215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0215");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(76, (int) (byte) 100);
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(0, 0);
        try {
            int int18 = randomNumberGenerator0.getRandomNumber((int) (short) 100, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=100 max=31");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 53 + "'", int4 == 53);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 82 + "'", int11 == 82);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test0216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0216");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(40, 52);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(60, 14);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=60 max=14");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 72 + "'", int4 == 72);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 40 + "'", int10 == 40);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test0217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0217");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(40, 52);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(0, 88);
        int int17 = randomNumberGenerator0.getRandomNumber(1, 87);
        int int20 = randomNumberGenerator0.getRandomNumber((int) (short) 0, 76);
        try {
            int int23 = randomNumberGenerator0.getRandomNumber(74, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=74 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 42 + "'", int10 == 42);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 55 + "'", int14 == 55);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 67 + "'", int17 == 67);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 72 + "'", int20 == 72);
    }

    @Test
    public void test0218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0218");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        int int13 = randomNumberGenerator0.getRandomNumber(61, 94);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(97, 74);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=97 max=74");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 76 + "'", int4 == 76);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 70 + "'", int10 == 70);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 76 + "'", int13 == 76);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test0219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0219");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        int int9 = randomNumberGenerator0.getRandomNumber(73, (int) (short) 100);
        try {
            int int12 = randomNumberGenerator0.getRandomNumber(92, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=92 max=12");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78 + "'", int9 == 78);
    }

    @Test
    public void test0220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0220");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        int int18 = randomNumberGenerator0.getRandomNumber(39, 72);
        int int21 = randomNumberGenerator0.getRandomNumber(0, 75);
        try {
            int int24 = randomNumberGenerator0.getRandomNumber(35, 27);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=35 max=27");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 67 + "'", int7 == 67);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 77 + "'", int10 == 77);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 63 + "'", int18 == 63);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 26 + "'", int21 == 26);
    }

    @Test
    public void test0221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0221");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(0, 12);
        int int15 = randomNumberGenerator0.getRandomNumber(36, 93);
        int int18 = randomNumberGenerator0.getRandomNumber((int) (short) 10, 53);
        try {
            int int21 = randomNumberGenerator0.getRandomNumber((int) ' ', 31);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=32 max=31");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 96 + "'", int4 == 96);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 75 + "'", int15 == 75);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 16 + "'", int18 == 16);
    }

    @Test
    public void test0222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0222");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(12, 27);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber((int) (short) 0, (int) (byte) 0);
        int int17 = randomNumberGenerator0.getRandomNumber((int) (short) 1, 60);
        try {
            int int20 = randomNumberGenerator0.getRandomNumber((int) '4', 44);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=52 max=44");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
    }

    @Test
    public void test0223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0223");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(58, 78);
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(70, 40);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=70 max=40");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 96 + "'", int4 == 96);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 65 + "'", int11 == 65);
    }

    @Test
    public void test0224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0224");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber((-1), 51);
        int int10 = randomNumberGenerator0.getRandomNumber((int) (short) 0, 10);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        int int17 = randomNumberGenerator0.getRandomNumber(67, 93);
        try {
            int int20 = randomNumberGenerator0.getRandomNumber((int) 'a', 8);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=97 max=8");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 69 + "'", int17 == 69);
    }

    @Test
    public void test0225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0225");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(4, 5);
        int int17 = randomNumberGenerator0.getRandomNumber(21, 37);
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(46, 39);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=46 max=39");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 64 + "'", int4 == 64);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 51 + "'", int10 == 51);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 25 + "'", int17 == 25);
    }

    @Test
    public void test0226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0226");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(76, (int) (byte) 100);
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(0, 0);
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        int int19 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass21 = randomNumberGenerator0.getClass();
        try {
            int int24 = randomNumberGenerator0.getRandomNumber(71, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=71 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 46 + "'", int4 == 46);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 80 + "'", int11 == 80);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 82 + "'", int19 == 82);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test0227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0227");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(5, 72);
        int int19 = randomNumberGenerator0.getRandomNumber((-1), 37);
        int int22 = randomNumberGenerator0.getRandomNumber(9, 57);
        int int25 = randomNumberGenerator0.getRandomNumber(35, 46);
        try {
            int int28 = randomNumberGenerator0.getRandomNumber(86, 70);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=86 max=70");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 67 + "'", int4 == 67);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 61 + "'", int16 == 61);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 15 + "'", int22 == 15);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 36 + "'", int25 == 36);
    }

    @Test
    public void test0228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0228");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(79, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=79 max=35");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 62 + "'", int10 == 62);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test0229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0229");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(5, 72);
        int int19 = randomNumberGenerator0.getRandomNumber((-1), 37);
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        int int23 = randomNumberGenerator0.getRandomNumber((int) (short) -1, 60);
        int int26 = randomNumberGenerator0.getRandomNumber(0, 3);
        try {
            int int29 = randomNumberGenerator0.getRandomNumber(8, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=8 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 90 + "'", int4 == 90);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 43 + "'", int16 == 43);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 38 + "'", int23 == 38);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3 + "'", int26 == 3);
    }

    @Test
    public void test0230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0230");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(72, 59);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=72 max=59");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 11 + "'", int7 == 11);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 77 + "'", int10 == 77);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test0231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0231");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        int int9 = randomNumberGenerator0.getRandomNumber((int) (short) 0, 21);
        try {
            int int12 = randomNumberGenerator0.getRandomNumber(89, 22);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=89 max=22");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 45 + "'", int4 == 45);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
    }

    @Test
    public void test0232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0232");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        int int11 = randomNumberGenerator0.getRandomNumber(0, 51);
        int int14 = randomNumberGenerator0.getRandomNumber(34, 43);
        int int17 = randomNumberGenerator0.getRandomNumber(0, 71);
        int int20 = randomNumberGenerator0.getRandomNumber(24, 88);
        try {
            int int23 = randomNumberGenerator0.getRandomNumber(47, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=47 max=2");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 34 + "'", int14 == 34);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 30 + "'", int17 == 30);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 65 + "'", int20 == 65);
    }

    @Test
    public void test0233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0233");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        int int11 = randomNumberGenerator0.getRandomNumber(0, 51);
        int int14 = randomNumberGenerator0.getRandomNumber(34, 43);
        int int17 = randomNumberGenerator0.getRandomNumber(0, 71);
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(59, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=59 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 93 + "'", int4 == 93);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 33 + "'", int11 == 33);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 43 + "'", int14 == 43);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 26 + "'", int17 == 26);
    }

    @Test
    public void test0234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0234");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(7, 67);
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(90, 69);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=90 max=69");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 52 + "'", int11 == 52);
    }

    @Test
    public void test0235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0235");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(41, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=41 max=28");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 85 + "'", int4 == 85);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 19 + "'", int13 == 19);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test0236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0236");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber((-1), 51);
        int int10 = randomNumberGenerator0.getRandomNumber((int) (short) 0, 10);
        try {
            int int13 = randomNumberGenerator0.getRandomNumber(73, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=73 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 11 + "'", int7 == 11);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test0237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0237");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(34, 39);
        int int13 = randomNumberGenerator0.getRandomNumber((int) ' ', 97);
        int int16 = randomNumberGenerator0.getRandomNumber(80, 89);
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(57, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=57 max=19");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 66 + "'", int7 == 66);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 36 + "'", int10 == 36);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 87 + "'", int13 == 87);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 89 + "'", int16 == 89);
    }

    @Test
    public void test0238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0238");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass2 = randomNumberGenerator0.getClass();
        try {
            int int5 = randomNumberGenerator0.getRandomNumber(21, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=21 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test0239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0239");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(34, 39);
        int int13 = randomNumberGenerator0.getRandomNumber((int) ' ', 97);
        int int16 = randomNumberGenerator0.getRandomNumber(80, 89);
        int int19 = randomNumberGenerator0.getRandomNumber(17, 20);
        try {
            int int22 = randomNumberGenerator0.getRandomNumber(84, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=84 max=10");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 91 + "'", int7 == 91);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 35 + "'", int10 == 35);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 38 + "'", int13 == 38);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 83 + "'", int16 == 83);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
    }

    @Test
    public void test0240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0240");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(28, 58);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(59, 53);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=59 max=53");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 85 + "'", int4 == 85);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 41 + "'", int12 == 41);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test0241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0241");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, 76);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        int int17 = randomNumberGenerator0.getRandomNumber(0, 42);
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(92, 85);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=92 max=85");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 26 + "'", int4 == 26);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 67 + "'", int10 == 67);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 66 + "'", int13 == 66);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 7 + "'", int17 == 7);
    }

    @Test
    public void test0242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0242");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, 76);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(60, 53);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=60 max=53");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 21 + "'", int4 == 21);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 61 + "'", int13 == 61);
    }

    @Test
    public void test0243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0243");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(31, 31);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber((int) '4', 55);
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        try {
            int int21 = randomNumberGenerator0.getRandomNumber(84, 58);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=84 max=58");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test0244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0244");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(52, 55);
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        int int19 = randomNumberGenerator0.getRandomNumber(7, 81);
        try {
            int int22 = randomNumberGenerator0.getRandomNumber(13, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=13 max=10");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 69 + "'", int10 == 69);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 53 + "'", int15 == 53);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 17 + "'", int19 == 17);
    }

    @Test
    public void test0245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0245");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber((-1), (int) (short) 10);
        int int19 = randomNumberGenerator0.getRandomNumber(9, 32);
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        int int23 = randomNumberGenerator0.getRandomNumber(30, 45);
        int int26 = randomNumberGenerator0.getRandomNumber(15, 86);
        try {
            int int29 = randomNumberGenerator0.getRandomNumber((int) (short) 100, 77);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=100 max=77");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 78 + "'", int7 == 78);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 85 + "'", int10 == 85);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 53 + "'", int13 == 53);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 28 + "'", int19 == 28);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 40 + "'", int23 == 40);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 27 + "'", int26 == 27);
    }

    @Test
    public void test0246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0246");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(12, 27);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(52, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=52 max=2");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 14 + "'", int10 == 14);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test0247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0247");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        int int18 = randomNumberGenerator0.getRandomNumber(39, 72);
        int int21 = randomNumberGenerator0.getRandomNumber(0, 75);
        java.lang.Class<?> wildcardClass22 = randomNumberGenerator0.getClass();
        int int25 = randomNumberGenerator0.getRandomNumber(19, 80);
        java.lang.Class<?> wildcardClass26 = randomNumberGenerator0.getClass();
        try {
            int int29 = randomNumberGenerator0.getRandomNumber(56, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=56 max=-1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 33 + "'", int7 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 45 + "'", int10 == 45);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 60 + "'", int18 == 60);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 52 + "'", int21 == 52);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 79 + "'", int25 == 79);
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test0248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0248");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        int int11 = randomNumberGenerator0.getRandomNumber(0, 51);
        int int14 = randomNumberGenerator0.getRandomNumber(18, 86);
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(90, 36);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=90 max=36");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 35 + "'", int4 == 35);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 33 + "'", int14 == 33);
    }

    @Test
    public void test0249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0249");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        int int9 = randomNumberGenerator0.getRandomNumber((int) (short) 0, 21);
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        try {
            int int13 = randomNumberGenerator0.getRandomNumber(32, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=32 max=1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 50 + "'", int4 == 50);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test0250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0250");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(52, 55);
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(69, 25);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=69 max=25");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 77 + "'", int4 == 77);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 53 + "'", int10 == 53);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 54 + "'", int15 == 54);
    }

    @Test
    public void test0251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0251");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber((-1), (int) (short) 10);
        int int19 = randomNumberGenerator0.getRandomNumber(9, 32);
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        try {
            int int23 = randomNumberGenerator0.getRandomNumber(85, 77);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=85 max=77");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 43 + "'", int7 == 43);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 36 + "'", int10 == 36);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 19 + "'", int13 == 19);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 5 + "'", int16 == 5);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 14 + "'", int19 == 14);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test0252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0252");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber((int) '#', 76);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(7, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=7 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 75 + "'", int7 == 75);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 67 + "'", int13 == 67);
    }

    @Test
    public void test0253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0253");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber((int) ' ', 72);
        int int13 = randomNumberGenerator0.getRandomNumber(23, 97);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(93, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=93 max=1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 93 + "'", int4 == 93);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 64 + "'", int10 == 64);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 43 + "'", int13 == 43);
    }

    @Test
    public void test0254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0254");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber((-1), (int) (short) 10);
        int int19 = randomNumberGenerator0.getRandomNumber(9, 32);
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        int int23 = randomNumberGenerator0.getRandomNumber(30, 45);
        try {
            int int26 = randomNumberGenerator0.getRandomNumber(50, 33);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=50 max=33");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 27 + "'", int7 == 27);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 67 + "'", int10 == 67);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 40 + "'", int13 == 40);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 44 + "'", int23 == 44);
    }

    @Test
    public void test0255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0255");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        int int16 = randomNumberGenerator0.getRandomNumber(41, 94);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(61, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=61 max=2");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 83 + "'", int13 == 83);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 94 + "'", int16 == 94);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test0256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0256");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        int int16 = randomNumberGenerator0.getRandomNumber(41, 94);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        int int20 = randomNumberGenerator0.getRandomNumber(0, 24);
        int int23 = randomNumberGenerator0.getRandomNumber(10, 47);
        java.lang.Class<?> wildcardClass24 = randomNumberGenerator0.getClass();
        int int27 = randomNumberGenerator0.getRandomNumber(0, 89);
        try {
            int int30 = randomNumberGenerator0.getRandomNumber(64, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=64 max=35");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 14 + "'", int8 == 14);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 39 + "'", int13 == 39);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 61 + "'", int16 == 61);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 20 + "'", int20 == 20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 18 + "'", int23 == 18);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
    }

    @Test
    public void test0257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0257");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber((-1), 51);
        int int10 = randomNumberGenerator0.getRandomNumber((int) (short) 0, 10);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(55, 42);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=55 max=42");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test0258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0258");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber((-1), (int) (short) 10);
        int int19 = randomNumberGenerator0.getRandomNumber((int) ' ', (int) '4');
        try {
            int int22 = randomNumberGenerator0.getRandomNumber(87, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=87 max=34");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 72 + "'", int10 == 72);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 56 + "'", int13 == 56);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 37 + "'", int19 == 37);
    }

    @Test
    public void test0259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0259");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(34, 39);
        int int13 = randomNumberGenerator0.getRandomNumber(37, 43);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(87, 59);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=87 max=59");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 78 + "'", int7 == 78);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 36 + "'", int10 == 36);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 37 + "'", int13 == 37);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test0260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0260");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(34, 39);
        int int13 = randomNumberGenerator0.getRandomNumber(37, 43);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        int int17 = randomNumberGenerator0.getRandomNumber((-1), (int) (short) 0);
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(11, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=11 max=5");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 90 + "'", int7 == 90);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 35 + "'", int10 == 35);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 42 + "'", int13 == 42);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test0261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0261");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        int int11 = randomNumberGenerator0.getRandomNumber(0, 51);
        int int14 = randomNumberGenerator0.getRandomNumber(93, 94);
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(90, 62);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=90 max=62");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 51 + "'", int4 == 51);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 93 + "'", int14 == 93);
    }

    @Test
    public void test0262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0262");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(0, 12);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(0, 20);
        try {
            int int19 = randomNumberGenerator0.getRandomNumber((int) 'a', 90);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=97 max=90");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 39 + "'", int4 == 39);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
    }

    @Test
    public void test0263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0263");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(19, 82);
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(69, 49);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=69 max=49");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 51 + "'", int11 == 51);
    }

    @Test
    public void test0264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0264");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(40, 52);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(98, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=98 max=10");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 55 + "'", int4 == 55);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 47 + "'", int10 == 47);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test0265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0265");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(4, 5);
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        int int18 = randomNumberGenerator0.getRandomNumber(9, 43);
        java.lang.Class<?> wildcardClass19 = randomNumberGenerator0.getClass();
        try {
            int int22 = randomNumberGenerator0.getRandomNumber(50, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=50 max=1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 17 + "'", int10 == 17);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 21 + "'", int18 == 21);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test0266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0266");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) 10, 84);
        int int11 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 0);
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(83, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=83 max=18");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 25 + "'", int8 == 25);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test0267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0267");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(31, 31);
        try {
            int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 100, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=100 max=52");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
    }

    @Test
    public void test0268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0268");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(34, 39);
        int int13 = randomNumberGenerator0.getRandomNumber(37, 43);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        int int17 = randomNumberGenerator0.getRandomNumber((-1), (int) (short) 0);
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        try {
            int int21 = randomNumberGenerator0.getRandomNumber((int) ' ', 24);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=32 max=24");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 35 + "'", int10 == 35);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 39 + "'", int13 == 39);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test0269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0269");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(12, 27);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber((int) (short) 0, (int) (byte) 0);
        int int17 = randomNumberGenerator0.getRandomNumber((int) (short) 1, 60);
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        try {
            int int21 = randomNumberGenerator0.getRandomNumber(3, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=3 max=1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 25 + "'", int10 == 25);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 7 + "'", int17 == 7);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test0270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0270");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(5, 73);
        try {
            int int15 = randomNumberGenerator0.getRandomNumber(97, 43);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=97 max=43");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
    }

    @Test
    public void test0271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0271");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(12, 27);
        int int13 = randomNumberGenerator0.getRandomNumber(19, (int) (short) 100);
        int int16 = randomNumberGenerator0.getRandomNumber((int) '4', 59);
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(84, 74);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=84 max=74");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 26 + "'", int10 == 26);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 77 + "'", int13 == 77);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
    }

    @Test
    public void test0272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0272");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(12, 27);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber((int) (short) 0, (int) (byte) 0);
        int int17 = randomNumberGenerator0.getRandomNumber((int) (short) 1, 60);
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(59, 46);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=59 max=46");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 16 + "'", int10 == 16);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 49 + "'", int17 == 49);
    }

    @Test
    public void test0273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0273");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (byte) 100);
        int int15 = randomNumberGenerator0.getRandomNumber(13, 23);
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(97, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=97 max=35");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 63 + "'", int4 == 63);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 37 + "'", int7 == 37);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 19 + "'", int15 == 19);
    }

    @Test
    public void test0274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0274");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber(2, 73);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass19 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        try {
            int int23 = randomNumberGenerator0.getRandomNumber(14, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=14 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 22 + "'", int7 == 22);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 44 + "'", int16 == 44);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test0275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0275");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber(2, 73);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        int int20 = randomNumberGenerator0.getRandomNumber((int) (byte) 10, 97);
        try {
            int int23 = randomNumberGenerator0.getRandomNumber(55, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=55 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 74 + "'", int10 == 74);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 44 + "'", int13 == 44);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 23 + "'", int16 == 23);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 70 + "'", int20 == 70);
    }

    @Test
    public void test0276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0276");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(12, 27);
        int int13 = randomNumberGenerator0.getRandomNumber(19, (int) (short) 100);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        int int18 = randomNumberGenerator0.getRandomNumber(55, 62);
        try {
            int int21 = randomNumberGenerator0.getRandomNumber(34, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=34 max=24");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 23 + "'", int10 == 23);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 91 + "'", int13 == 91);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 56 + "'", int18 == 56);
    }

    @Test
    public void test0277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0277");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(98, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=98 max=28");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 60 + "'", int4 == 60);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 47 + "'", int13 == 47);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test0278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0278");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber(79, (int) (short) 100);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(31, 80);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(50, 88);
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(78, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=78 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 80 + "'", int4 == 80);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 91 + "'", int8 == 91);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 38 + "'", int12 == 38);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 80 + "'", int16 == 80);
    }

    @Test
    public void test0279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0279");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(49, 86);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(13, (int) ' ');
        int int19 = randomNumberGenerator0.getRandomNumber(6, 31);
        int int22 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, 44);
        try {
            int int25 = randomNumberGenerator0.getRandomNumber(88, 70);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=88 max=70");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 14 + "'", int4 == 14);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 14 + "'", int7 == 14);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 71 + "'", int12 == 71);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 32 + "'", int16 == 32);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 29 + "'", int19 == 29);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 35 + "'", int22 == 35);
    }

    @Test
    public void test0280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0280");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        int int16 = randomNumberGenerator0.getRandomNumber(55, 79);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        try {
            int int21 = randomNumberGenerator0.getRandomNumber(66, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=66 max=12");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 35 + "'", int13 == 35);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 74 + "'", int16 == 74);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test0281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0281");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(7, 67);
        int int14 = randomNumberGenerator0.getRandomNumber(33, 93);
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(70, 45);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=70 max=45");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 21 + "'", int11 == 21);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 56 + "'", int14 == 56);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test0282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0282");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(34, 39);
        int int13 = randomNumberGenerator0.getRandomNumber(37, 43);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(37, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=37 max=32");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 73 + "'", int7 == 73);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 38 + "'", int10 == 38);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 39 + "'", int13 == 39);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test0283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0283");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber(79, (int) (short) 100);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber(71, 83);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 92 + "'", int8 == 92);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 74 + "'", int13 == 74);
    }

    @Test
    public void test0284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0284");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(12, 27);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber((int) (short) 0, (int) (byte) 0);
        int int17 = randomNumberGenerator0.getRandomNumber((int) (short) 1, 60);
        int int20 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 6);
        try {
            int int23 = randomNumberGenerator0.getRandomNumber(83, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=83 max=24");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
    }

    @Test
    public void test0285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0285");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(40, 52);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber((int) '4', 54);
        int int17 = randomNumberGenerator0.getRandomNumber(35, 41);
        int int20 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 21);
        java.lang.Class<?> wildcardClass21 = randomNumberGenerator0.getClass();
        try {
            int int24 = randomNumberGenerator0.getRandomNumber(39, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=39 max=34");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 44 + "'", int4 == 44);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 44 + "'", int10 == 44);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 39 + "'", int17 == 39);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 16 + "'", int20 == 16);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test0286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0286");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        int int9 = randomNumberGenerator0.getRandomNumber(73, (int) (short) 100);
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(9, (int) ' ');
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        try {
            int int19 = randomNumberGenerator0.getRandomNumber((int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=10 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 76 + "'", int9 == 76);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 17 + "'", int15 == 17);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test0287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0287");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        int int16 = randomNumberGenerator0.getRandomNumber(41, 94);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        int int21 = randomNumberGenerator0.getRandomNumber(50, 92);
        java.lang.Class<?> wildcardClass22 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass23 = randomNumberGenerator0.getClass();
        try {
            int int26 = randomNumberGenerator0.getRandomNumber(98, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=98 max=6");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 56 + "'", int4 == 56);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 57 + "'", int16 == 57);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 83 + "'", int21 == 83);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test0288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0288");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        int int11 = randomNumberGenerator0.getRandomNumber(0, 51);
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(55, 98);
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(93, 55);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=93 max=55");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 43 + "'", int4 == 43);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 45 + "'", int11 == 45);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 72 + "'", int16 == 72);
    }

    @Test
    public void test0289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0289");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(40, 52);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(0, 88);
        int int17 = randomNumberGenerator0.getRandomNumber(1, 87);
        int int20 = randomNumberGenerator0.getRandomNumber((int) (short) 0, 76);
        try {
            int int23 = randomNumberGenerator0.getRandomNumber(68, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=68 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 49 + "'", int10 == 49);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 81 + "'", int14 == 81);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 33 + "'", int20 == 33);
    }

    @Test
    public void test0290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0290");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(49, 86);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(13, (int) ' ');
        int int19 = randomNumberGenerator0.getRandomNumber(6, 31);
        int int22 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, 44);
        java.lang.Class<?> wildcardClass23 = randomNumberGenerator0.getClass();
        int int26 = randomNumberGenerator0.getRandomNumber(59, 68);
        java.lang.Class<?> wildcardClass27 = randomNumberGenerator0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 23 + "'", int4 == 23);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 65 + "'", int7 == 65);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 66 + "'", int12 == 66);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 23 + "'", int16 == 23);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 7 + "'", int19 == 7);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 42 + "'", int22 == 42);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 59 + "'", int26 == 59);
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

    @Test
    public void test0291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0291");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber((int) ' ', 72);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(84, 46);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=84 max=46");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 45 + "'", int4 == 45);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 46 + "'", int10 == 46);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test0292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0292");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        int int16 = randomNumberGenerator0.getRandomNumber(41, 94);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        int int21 = randomNumberGenerator0.getRandomNumber(50, 92);
        java.lang.Class<?> wildcardClass22 = randomNumberGenerator0.getClass();
        try {
            int int25 = randomNumberGenerator0.getRandomNumber(36, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=36 max=10");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 29 + "'", int4 == 29);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 72 + "'", int13 == 72);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 47 + "'", int16 == 47);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 54 + "'", int21 == 54);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test0293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0293");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        int int16 = randomNumberGenerator0.getRandomNumber(41, 94);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass19 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        try {
            int int23 = randomNumberGenerator0.getRandomNumber(36, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=36 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 64 + "'", int4 == 64);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 38 + "'", int13 == 38);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 45 + "'", int16 == 45);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test0294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0294");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(88, 43);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=88 max=43");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 35 + "'", int4 == 35);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 66 + "'", int10 == 66);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test0295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0295");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber(2, 73);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        int int20 = randomNumberGenerator0.getRandomNumber((int) (byte) 10, 97);
        java.lang.Class<?> wildcardClass21 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass22 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass23 = randomNumberGenerator0.getClass();
        try {
            int int26 = randomNumberGenerator0.getRandomNumber(61, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=61 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 86 + "'", int7 == 86);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 60 + "'", int10 == 60);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 21 + "'", int13 == 21);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 33 + "'", int16 == 33);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 92 + "'", int20 == 92);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test0296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0296");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(0, 12);
        int int15 = randomNumberGenerator0.getRandomNumber(36, 93);
        int int18 = randomNumberGenerator0.getRandomNumber((int) (short) 10, 53);
        java.lang.Class<?> wildcardClass19 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass21 = randomNumberGenerator0.getClass();
        try {
            int int24 = randomNumberGenerator0.getRandomNumber(80, 54);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=80 max=54");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 70 + "'", int15 == 70);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test0297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0297");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(31, 31);
        int int13 = randomNumberGenerator0.getRandomNumber(0, 100);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(69, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=69 max=5");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
    }

    @Test
    public void test0298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0298");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(49, 86);
        int int15 = randomNumberGenerator0.getRandomNumber(69, 97);
        try {
            int int18 = randomNumberGenerator0.getRandomNumber((int) (byte) 100, 36);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=100 max=36");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 18 + "'", int4 == 18);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 77 + "'", int7 == 77);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 54 + "'", int12 == 54);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 94 + "'", int15 == 94);
    }

    @Test
    public void test0299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0299");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber((-1), 51);
        int int10 = randomNumberGenerator0.getRandomNumber((int) (short) 0, 10);
        try {
            int int13 = randomNumberGenerator0.getRandomNumber(95, 70);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=95 max=70");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 28 + "'", int7 == 28);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test0300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0300");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(93, 93);
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(15, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=15 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 67 + "'", int10 == 67);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 93 + "'", int15 == 93);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test0301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0301");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        int int16 = randomNumberGenerator0.getRandomNumber(41, 94);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        int int21 = randomNumberGenerator0.getRandomNumber((-1), 61);
        java.lang.Class<?> wildcardClass22 = randomNumberGenerator0.getClass();
        try {
            int int25 = randomNumberGenerator0.getRandomNumber(68, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=68 max=3");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 80 + "'", int4 == 80);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 27 + "'", int13 == 27);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 56 + "'", int16 == 56);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test0302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0302");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(5, 72);
        int int19 = randomNumberGenerator0.getRandomNumber((-1), 37);
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        int int23 = randomNumberGenerator0.getRandomNumber((int) (short) -1, 60);
        java.lang.Class<?> wildcardClass24 = randomNumberGenerator0.getClass();
        try {
            int int27 = randomNumberGenerator0.getRandomNumber(68, 14);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=68 max=14");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 62 + "'", int4 == 62);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 7 + "'", int8 == 7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 65 + "'", int16 == 65);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 16 + "'", int19 == 16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 31 + "'", int23 == 31);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test0303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0303");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(52, 55);
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        int int20 = randomNumberGenerator0.getRandomNumber(5, 55);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 63 + "'", int4 == 63);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 51 + "'", int10 == 51);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 54 + "'", int15 == 54);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 17 + "'", int20 == 17);
    }

    @Test
    public void test0304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0304");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(40, 52);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(0, 88);
        int int17 = randomNumberGenerator0.getRandomNumber((int) (short) 0, 49);
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(47, 36);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=47 max=36");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 48 + "'", int4 == 48);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 42 + "'", int10 == 42);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 28 + "'", int17 == 28);
    }

    @Test
    public void test0305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0305");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        int int11 = randomNumberGenerator0.getRandomNumber(0, 51);
        int int14 = randomNumberGenerator0.getRandomNumber(34, 43);
        int int17 = randomNumberGenerator0.getRandomNumber(0, 71);
        int int20 = randomNumberGenerator0.getRandomNumber(24, 88);
        int int23 = randomNumberGenerator0.getRandomNumber(77, 81);
        try {
            int int26 = randomNumberGenerator0.getRandomNumber(75, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=75 max=28");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 26 + "'", int4 == 26);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 17 + "'", int11 == 17);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 34 + "'", int14 == 34);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 54 + "'", int17 == 54);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 46 + "'", int20 == 46);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 78 + "'", int23 == 78);
    }

    @Test
    public void test0306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0306");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber((int) ' ', 72);
        int int13 = randomNumberGenerator0.getRandomNumber(55, 92);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(57, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=57 max=18");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 38 + "'", int10 == 38);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 84 + "'", int13 == 84);
    }

    @Test
    public void test0307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0307");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        try {
            int int9 = randomNumberGenerator0.getRandomNumber(68, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=68 max=9");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 78 + "'", int4 == 78);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test0308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0308");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        int int16 = randomNumberGenerator0.getRandomNumber(41, 94);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        int int20 = randomNumberGenerator0.getRandomNumber(0, 24);
        int int23 = randomNumberGenerator0.getRandomNumber(10, 47);
        java.lang.Class<?> wildcardClass24 = randomNumberGenerator0.getClass();
        int int27 = randomNumberGenerator0.getRandomNumber(0, 89);
        java.lang.Class<?> wildcardClass28 = randomNumberGenerator0.getClass();
        try {
            int int31 = randomNumberGenerator0.getRandomNumber(81, 72);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=81 max=72");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 65 + "'", int4 == 65);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 56 + "'", int13 == 56);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 49 + "'", int16 == 49);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 22 + "'", int23 == 22);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 50 + "'", int27 == 50);
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

    @Test
    public void test0309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0309");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, (int) (short) -1);
        try {
            int int18 = randomNumberGenerator0.getRandomNumber((int) '#', 10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=35 max=10");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 18 + "'", int4 == 18);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test0310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0310");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        int int11 = randomNumberGenerator0.getRandomNumber(0, 51);
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(99, 25);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=99 max=25");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test0311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0311");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(19, 82);
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(53, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=53 max=2");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 61 + "'", int11 == 61);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test0312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0312");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(0, 12);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(0, 66);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass19 = randomNumberGenerator0.getClass();
        try {
            int int22 = randomNumberGenerator0.getRandomNumber(86, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=86 max=5");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 26 + "'", int4 == 26);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 58 + "'", int16 == 58);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test0313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0313");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(4, 5);
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        int int19 = randomNumberGenerator0.getRandomNumber(0, 41);
        try {
            int int22 = randomNumberGenerator0.getRandomNumber(91, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=91 max=-1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 54 + "'", int4 == 54);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 36 + "'", int19 == 36);
    }

    @Test
    public void test0314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0314");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        int int17 = randomNumberGenerator0.getRandomNumber(52, 73);
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass19 = randomNumberGenerator0.getClass();
        try {
            int int22 = randomNumberGenerator0.getRandomNumber(70, 29);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=70 max=29");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 42 + "'", int7 == 42);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 58 + "'", int10 == 58);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 69 + "'", int17 == 69);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test0315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0315");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber((-1), (int) (short) 10);
        int int19 = randomNumberGenerator0.getRandomNumber(12, (int) ' ');
        try {
            int int22 = randomNumberGenerator0.getRandomNumber((int) ' ', 21);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=32 max=21");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 79 + "'", int7 == 79);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 34 + "'", int13 == 34);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 9 + "'", int16 == 9);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 22 + "'", int19 == 22);
    }

    @Test
    public void test0316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0316");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        int int3 = randomNumberGenerator0.getRandomNumber(28, 59);
        try {
            int int6 = randomNumberGenerator0.getRandomNumber(76, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=76 max=1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 43 + "'", int3 == 43);
    }

    @Test
    public void test0317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0317");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        int int18 = randomNumberGenerator0.getRandomNumber(39, 72);
        try {
            int int21 = randomNumberGenerator0.getRandomNumber(7, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=7 max=-1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 46 + "'", int10 == 46);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 39 + "'", int13 == 39);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 63 + "'", int18 == 63);
    }

    @Test
    public void test0318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0318");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        int int18 = randomNumberGenerator0.getRandomNumber(39, 72);
        int int21 = randomNumberGenerator0.getRandomNumber(0, 75);
        java.lang.Class<?> wildcardClass22 = randomNumberGenerator0.getClass();
        int int25 = randomNumberGenerator0.getRandomNumber(19, 80);
        java.lang.Class<?> wildcardClass26 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass27 = randomNumberGenerator0.getClass();
        try {
            int int30 = randomNumberGenerator0.getRandomNumber(97, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=97 max=52");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 46 + "'", int7 == 46);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 70 + "'", int10 == 70);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 45 + "'", int18 == 45);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 48 + "'", int21 == 48);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 29 + "'", int25 == 29);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

    @Test
    public void test0319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0319");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(4, 5);
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        int int19 = randomNumberGenerator0.getRandomNumber(0, 41);
        try {
            int int22 = randomNumberGenerator0.getRandomNumber(91, 26);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=91 max=26");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 11 + "'", int10 == 11);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 30 + "'", int19 == 30);
    }

    @Test
    public void test0320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0320");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber(79, (int) (short) 100);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(31, 80);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(50, 88);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        try {
            int int21 = randomNumberGenerator0.getRandomNumber(71, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=71 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 62 + "'", int4 == 62);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 90 + "'", int8 == 90);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 34 + "'", int12 == 34);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 58 + "'", int16 == 58);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test0321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0321");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(72, 93);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(91, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=91 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 18 + "'", int7 == 18);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 85 + "'", int10 == 85);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 77 + "'", int13 == 77);
    }

    @Test
    public void test0322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0322");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber(2, 73);
        int int19 = randomNumberGenerator0.getRandomNumber(80, 83);
        int int22 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, 86);
        try {
            int int25 = randomNumberGenerator0.getRandomNumber(55, 33);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=55 max=33");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 44 + "'", int7 == 44);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 61 + "'", int10 == 61);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 53 + "'", int13 == 53);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 44 + "'", int16 == 44);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 80 + "'", int19 == 80);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 73 + "'", int22 == 73);
    }

    @Test
    public void test0323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0323");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(0, 12);
        int int15 = randomNumberGenerator0.getRandomNumber(36, 93);
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        try {
            int int21 = randomNumberGenerator0.getRandomNumber(42, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=42 max=32");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 11 + "'", int8 == 11);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 41 + "'", int15 == 41);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test0324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0324");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(73, 99);
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 85 + "'", int14 == 85);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test0325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0325");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(4, 5);
        int int17 = randomNumberGenerator0.getRandomNumber(21, 37);
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        int int21 = randomNumberGenerator0.getRandomNumber(41, 76);
        java.lang.Class<?> wildcardClass22 = randomNumberGenerator0.getClass();
        try {
            int int25 = randomNumberGenerator0.getRandomNumber(44, 29);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=44 max=29");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 60 + "'", int4 == 60);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 64 + "'", int10 == 64);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 29 + "'", int17 == 29);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 75 + "'", int21 == 75);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test0326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0326");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        int int11 = randomNumberGenerator0.getRandomNumber(0, 51);
        int int14 = randomNumberGenerator0.getRandomNumber(18, 86);
        int int17 = randomNumberGenerator0.getRandomNumber(28, (int) (byte) 100);
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(75, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=75 max=10");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 56 + "'", int4 == 56);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 14 + "'", int8 == 14);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 22 + "'", int14 == 22);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 66 + "'", int17 == 66);
    }

    @Test
    public void test0327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0327");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(49, 86);
        try {
            int int15 = randomNumberGenerator0.getRandomNumber(58, 36);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=58 max=36");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 58 + "'", int4 == 58);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 36 + "'", int7 == 36);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 54 + "'", int12 == 54);
    }

    @Test
    public void test0328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0328");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber(79, (int) (short) 100);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(50, 90);
        try {
            int int15 = randomNumberGenerator0.getRandomNumber(85, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=85 max=2");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 85 + "'", int4 == 85);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 79 + "'", int8 == 79);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
    }

    @Test
    public void test0329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0329");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(76, (int) (byte) 100);
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(0, 0);
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        int int19 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        int int23 = randomNumberGenerator0.getRandomNumber(18, 78);
        try {
            int int26 = randomNumberGenerator0.getRandomNumber(86, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=86 max=21");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 74 + "'", int4 == 74);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 85 + "'", int11 == 85);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 70 + "'", int19 == 70);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 70 + "'", int23 == 70);
    }

    @Test
    public void test0330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0330");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(25, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=25 max=18");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 35 + "'", int7 == 35);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 96 + "'", int10 == 96);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test0331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0331");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        int int13 = randomNumberGenerator0.getRandomNumber(4, 69);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        int int18 = randomNumberGenerator0.getRandomNumber((-1), 26);
        try {
            int int21 = randomNumberGenerator0.getRandomNumber(76, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=76 max=6");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 48 + "'", int4 == 48);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 27 + "'", int13 == 27);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
    }

    @Test
    public void test0332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0332");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber((-1), 51);
        int int10 = randomNumberGenerator0.getRandomNumber((int) (short) 0, 10);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(60, 75);
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(24, 14);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=24 max=14");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 11 + "'", int7 == 11);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 68 + "'", int15 == 68);
    }

    @Test
    public void test0333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0333");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        int int11 = randomNumberGenerator0.getRandomNumber(0, 51);
        int int14 = randomNumberGenerator0.getRandomNumber(18, 86);
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(52, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=52 max=4");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 18 + "'", int4 == 18);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 14 + "'", int11 == 14);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 48 + "'", int14 == 48);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test0334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0334");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(47, 47);
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(54, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=54 max=9");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 47 + "'", int14 == 47);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test0335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0335");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(40, 52);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber((int) '4', 54);
        int int17 = randomNumberGenerator0.getRandomNumber(35, 41);
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(90, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=90 max=4");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 56 + "'", int4 == 56);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 51 + "'", int10 == 51);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 35 + "'", int17 == 35);
    }

    @Test
    public void test0336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0336");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber(2, 73);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass19 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass21 = randomNumberGenerator0.getClass();
        try {
            int int24 = randomNumberGenerator0.getRandomNumber(81, 44);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=81 max=44");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 25 + "'", int7 == 25);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 71 + "'", int10 == 71);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 47 + "'", int16 == 47);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test0337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0337");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        try {
            int int15 = randomNumberGenerator0.getRandomNumber(28, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=28 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 67 + "'", int10 == 67);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test0338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0338");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(35, 56);
        int int14 = randomNumberGenerator0.getRandomNumber(9, (int) (byte) 10);
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(37, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=37 max=15");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 9 + "'", int14 == 9);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test0339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0339");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber((int) ' ', 72);
        int int13 = randomNumberGenerator0.getRandomNumber(55, 92);
        int int16 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 67);
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(69, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=69 max=7");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 18 + "'", int4 == 18);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 72 + "'", int13 == 72);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 48 + "'", int16 == 48);
    }

    @Test
    public void test0340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0340");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        int int16 = randomNumberGenerator0.getRandomNumber(41, 94);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        int int21 = randomNumberGenerator0.getRandomNumber(50, 92);
        java.lang.Class<?> wildcardClass22 = randomNumberGenerator0.getClass();
        try {
            int int25 = randomNumberGenerator0.getRandomNumber(42, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=42 max=3");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 81 + "'", int4 == 81);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 48 + "'", int13 == 48);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 64 + "'", int16 == 64);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 91 + "'", int21 == 91);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test0341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0341");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(4, 5);
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        int int18 = randomNumberGenerator0.getRandomNumber(9, 43);
        int int21 = randomNumberGenerator0.getRandomNumber(46, 74);
        try {
            int int24 = randomNumberGenerator0.getRandomNumber(65, 43);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=65 max=43");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 35 + "'", int10 == 35);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 32 + "'", int18 == 32);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 64 + "'", int21 == 64);
    }

    @Test
    public void test0342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0342");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(0, 14);
        int int14 = randomNumberGenerator0.getRandomNumber(0, 40);
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(30, 23);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=30 max=23");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 28 + "'", int4 == 28);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 30 + "'", int14 == 30);
    }

    @Test
    public void test0343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0343");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(4, 5);
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        int int18 = randomNumberGenerator0.getRandomNumber(9, 43);
        int int21 = randomNumberGenerator0.getRandomNumber((int) (short) 0, 12);
        try {
            int int24 = randomNumberGenerator0.getRandomNumber(43, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=43 max=31");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 23 + "'", int4 == 23);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 18 + "'", int10 == 18);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 21 + "'", int18 == 21);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 8 + "'", int21 == 8);
    }

    @Test
    public void test0344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0344");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber((int) ' ', 72);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        try {
            int int15 = randomNumberGenerator0.getRandomNumber(44, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=44 max=8");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 50 + "'", int4 == 50);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test0345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0345");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(12, 27);
        int int13 = randomNumberGenerator0.getRandomNumber(19, (int) (short) 100);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(57, 47);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=57 max=47");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 58 + "'", int13 == 58);
    }

    @Test
    public void test0346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0346");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(5, 72);
        int int19 = randomNumberGenerator0.getRandomNumber((-1), 37);
        int int22 = randomNumberGenerator0.getRandomNumber(9, 57);
        try {
            int int25 = randomNumberGenerator0.getRandomNumber(70, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=70 max=3");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 70 + "'", int4 == 70);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 25 + "'", int16 == 25);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 7 + "'", int19 == 7);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 20 + "'", int22 == 20);
    }

    @Test
    public void test0347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0347");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber(79, (int) (short) 100);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        try {
            int int12 = randomNumberGenerator0.getRandomNumber((int) (byte) 100, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=100 max=13");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 79 + "'", int8 == 79);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test0348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0348");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(49, 86);
        try {
            int int15 = randomNumberGenerator0.getRandomNumber(14, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=14 max=-1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 66 + "'", int12 == 66);
    }

    @Test
    public void test0349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0349");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(40, 52);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber((int) '4', 54);
        int int17 = randomNumberGenerator0.getRandomNumber(35, 41);
        try {
            int int20 = randomNumberGenerator0.getRandomNumber((int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=32 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 87 + "'", int4 == 87);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 41 + "'", int10 == 41);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53 + "'", int14 == 53);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 35 + "'", int17 == 35);
    }

    @Test
    public void test0350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0350");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        int int13 = randomNumberGenerator0.getRandomNumber(4, 69);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        int int17 = randomNumberGenerator0.getRandomNumber(96, 97);
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        try {
            int int21 = randomNumberGenerator0.getRandomNumber((int) 'a', 22);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=97 max=22");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 54 + "'", int10 == 54);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 33 + "'", int13 == 33);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 96 + "'", int17 == 96);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test0351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0351");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber(79, (int) (short) 100);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (short) 0, 90);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(97, 38);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=97 max=38");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 48 + "'", int4 == 48);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 96 + "'", int8 == 96);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 76 + "'", int13 == 76);
    }

    @Test
    public void test0352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0352");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(12, 27);
        int int13 = randomNumberGenerator0.getRandomNumber(19, (int) (short) 100);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(80, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=80 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 23 + "'", int10 == 23);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 46 + "'", int13 == 46);
    }

    @Test
    public void test0353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0353");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(19, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=19 max=11");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
    }

    @Test
    public void test0354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0354");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(35, 56);
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(98, 84);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=98 max=84");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 55 + "'", int11 == 55);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test0355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0355");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(34, 39);
        int int13 = randomNumberGenerator0.getRandomNumber((int) ' ', 97);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(98, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=98 max=31");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 38 + "'", int10 == 38);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 88 + "'", int13 == 88);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test0356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0356");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(40, 52);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(0, 88);
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(65, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=65 max=13");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 26 + "'", int4 == 26);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 47 + "'", int10 == 47);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 45 + "'", int14 == 45);
    }

    @Test
    public void test0357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0357");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(34, 39);
        int int13 = randomNumberGenerator0.getRandomNumber(37, 43);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        int int17 = randomNumberGenerator0.getRandomNumber((-1), (int) (short) 0);
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        try {
            int int21 = randomNumberGenerator0.getRandomNumber(53, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=53 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 72 + "'", int7 == 72);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 36 + "'", int10 == 36);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 38 + "'", int13 == 38);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test0358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0358");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        try {
            int int9 = randomNumberGenerator0.getRandomNumber(72, 51);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=72 max=51");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 70 + "'", int4 == 70);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test0359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0359");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber((-1), (int) (short) 10);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        try {
            int int21 = randomNumberGenerator0.getRandomNumber(99, 61);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=99 max=61");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 17 + "'", int7 == 17);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 66 + "'", int10 == 66);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 27 + "'", int13 == 27);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test0360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0360");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(49, 86);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(66, 42);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=66 max=42");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 41 + "'", int4 == 41);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 42 + "'", int7 == 42);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 82 + "'", int12 == 82);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test0361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0361");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(49, 86);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(55, 59);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        try {
            int int21 = randomNumberGenerator0.getRandomNumber(22, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=22 max=10");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 93 + "'", int4 == 93);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 73 + "'", int7 == 73);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 82 + "'", int12 == 82);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 58 + "'", int16 == 58);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test0362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0362");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(73, 99);
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(79, 43);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=79 max=43");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 81 + "'", int4 == 81);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 91 + "'", int14 == 91);
    }

    @Test
    public void test0363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0363");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(76, (int) (byte) 100);
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(0, 0);
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        int int19 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        int int23 = randomNumberGenerator0.getRandomNumber(18, 78);
        java.lang.Class<?> wildcardClass24 = randomNumberGenerator0.getClass();
        try {
            int int27 = randomNumberGenerator0.getRandomNumber(80, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=80 max=52");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 38 + "'", int4 == 38);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 79 + "'", int11 == 79);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 50 + "'", int19 == 50);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 58 + "'", int23 == 58);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test0364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0364");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber((-1), 51);
        int int10 = randomNumberGenerator0.getRandomNumber(52, 89);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(46, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=46 max=2");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 48 + "'", int7 == 48);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 82 + "'", int10 == 82);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test0365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0365");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(0, 12);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber((int) (short) -1, 54);
        try {
            int int19 = randomNumberGenerator0.getRandomNumber((int) '#', 2);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=35 max=2");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 60 + "'", int4 == 60);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 23 + "'", int16 == 23);
    }

    @Test
    public void test0366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0366");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        int int11 = randomNumberGenerator0.getRandomNumber(0, 51);
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber((int) '4', 80);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(42, 29);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=42 max=29");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 42 + "'", int4 == 42);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 27 + "'", int11 == 27);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 55 + "'", int16 == 55);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test0367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0367");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, (int) (byte) 1);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        try {
            int int12 = randomNumberGenerator0.getRandomNumber(50, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=50 max=21");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test0368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0368");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        try {
            int int11 = randomNumberGenerator0.getRandomNumber(21, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=21 max=12");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test0369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0369");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        try {
            int int11 = randomNumberGenerator0.getRandomNumber(89, 80);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=89 max=80");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test0370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0370");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        int int11 = randomNumberGenerator0.getRandomNumber(0, 51);
        int int14 = randomNumberGenerator0.getRandomNumber(34, 43);
        int int17 = randomNumberGenerator0.getRandomNumber(0, 79);
        int int20 = randomNumberGenerator0.getRandomNumber(40, 88);
        int int23 = randomNumberGenerator0.getRandomNumber(10, 26);
        int int26 = randomNumberGenerator0.getRandomNumber(36, 78);
        try {
            int int29 = randomNumberGenerator0.getRandomNumber(51, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=51 max=16");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 95 + "'", int4 == 95);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 41 + "'", int14 == 41);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 44 + "'", int20 == 44);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 25 + "'", int23 == 25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 57 + "'", int26 == 57);
    }

    @Test
    public void test0371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0371");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber((int) ' ', 72);
        int int13 = randomNumberGenerator0.getRandomNumber(55, 92);
        int int16 = randomNumberGenerator0.getRandomNumber(9, 26);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(96, 54);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=96 max=54");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 65 + "'", int4 == 65);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 56 + "'", int10 == 56);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 87 + "'", int13 == 87);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 14 + "'", int16 == 14);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test0372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0372");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(4, 5);
        int int17 = randomNumberGenerator0.getRandomNumber(21, 37);
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass19 = randomNumberGenerator0.getClass();
        try {
            int int22 = randomNumberGenerator0.getRandomNumber(100, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=100 max=19");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 23 + "'", int17 == 23);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test0373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0373");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        int int16 = randomNumberGenerator0.getRandomNumber(41, 94);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        int int21 = randomNumberGenerator0.getRandomNumber(50, 92);
        int int24 = randomNumberGenerator0.getRandomNumber(19, 26);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 66 + "'", int4 == 66);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 94 + "'", int16 == 94);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 80 + "'", int21 == 80);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 19 + "'", int24 == 19);
    }

    @Test
    public void test0374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0374");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber(79, (int) (short) 100);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(31, 80);
        try {
            int int15 = randomNumberGenerator0.getRandomNumber(15, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=15 max=9");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 84 + "'", int8 == 84);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 67 + "'", int12 == 67);
    }

    @Test
    public void test0375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0375");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        int int9 = randomNumberGenerator0.getRandomNumber(73, (int) (short) 100);
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(9, (int) ' ');
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(60, 37);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=60 max=37");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 89 + "'", int9 == 89);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 30 + "'", int15 == 30);
    }

    @Test
    public void test0376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0376");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(35, 56);
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(76, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=76 max=4");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 44 + "'", int11 == 44);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test0377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0377");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        int int9 = randomNumberGenerator0.getRandomNumber(73, (int) (short) 100);
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(0, 78);
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(19, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=19 max=13");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 74 + "'", int9 == 74);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
    }

    @Test
    public void test0378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0378");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        int int17 = randomNumberGenerator0.getRandomNumber(52, 73);
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        try {
            int int21 = randomNumberGenerator0.getRandomNumber(92, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=92 max=13");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 71 + "'", int7 == 71);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 82 + "'", int10 == 82);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 67 + "'", int17 == 67);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test0379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0379");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        int int11 = randomNumberGenerator0.getRandomNumber(0, 51);
        int int14 = randomNumberGenerator0.getRandomNumber(93, 94);
        int int17 = randomNumberGenerator0.getRandomNumber(0, 80);
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        try {
            int int21 = randomNumberGenerator0.getRandomNumber(78, 51);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=78 max=51");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 62 + "'", int4 == 62);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 93 + "'", int14 == 93);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 59 + "'", int17 == 59);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test0380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0380");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(4, 5);
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        int int18 = randomNumberGenerator0.getRandomNumber(9, 43);
        try {
            int int21 = randomNumberGenerator0.getRandomNumber(74, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=74 max=52");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 17 + "'", int4 == 17);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 30 + "'", int10 == 30);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 33 + "'", int18 == 33);
    }

    @Test
    public void test0381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0381");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(93, 93);
        int int18 = randomNumberGenerator0.getRandomNumber(11, 20);
        int int21 = randomNumberGenerator0.getRandomNumber(21, 61);
        try {
            int int24 = randomNumberGenerator0.getRandomNumber(66, 26);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=66 max=26");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 43 + "'", int4 == 43);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 47 + "'", int10 == 47);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 93 + "'", int15 == 93);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 16 + "'", int18 == 16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 43 + "'", int21 == 43);
    }

    @Test
    public void test0382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0382");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(4, 5);
        int int17 = randomNumberGenerator0.getRandomNumber(21, 37);
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        int int21 = randomNumberGenerator0.getRandomNumber(41, 76);
        int int24 = randomNumberGenerator0.getRandomNumber((int) '4', 55);
        try {
            int int27 = randomNumberGenerator0.getRandomNumber(45, 40);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=45 max=40");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 18 + "'", int10 == 18);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 29 + "'", int17 == 29);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 76 + "'", int21 == 76);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 55 + "'", int24 == 55);
    }

    @Test
    public void test0383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0383");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(0, 12);
        int int15 = randomNumberGenerator0.getRandomNumber(36, 93);
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        int int19 = randomNumberGenerator0.getRandomNumber(61, 68);
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        int int23 = randomNumberGenerator0.getRandomNumber(67, 72);
        java.lang.Class<?> wildcardClass24 = randomNumberGenerator0.getClass();
        try {
            int int27 = randomNumberGenerator0.getRandomNumber(70, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=70 max=32");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 47 + "'", int4 == 47);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 51 + "'", int15 == 51);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 62 + "'", int19 == 62);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 67 + "'", int23 == 67);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test0384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0384");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        try {
            int int8 = randomNumberGenerator0.getRandomNumber(7, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=7 max=-1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 94 + "'", int4 == 94);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test0385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0385");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        int int18 = randomNumberGenerator0.getRandomNumber(39, 72);
        java.lang.Class<?> wildcardClass19 = randomNumberGenerator0.getClass();
        int int22 = randomNumberGenerator0.getRandomNumber(75, 100);
        java.lang.Class<?> wildcardClass23 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass24 = randomNumberGenerator0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 77 + "'", int7 == 77);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 95 + "'", int10 == 95);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 50 + "'", int18 == 50);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 82 + "'", int22 == 82);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test0386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0386");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        int int3 = randomNumberGenerator0.getRandomNumber(0, 54);
        int int6 = randomNumberGenerator0.getRandomNumber(38, 62);
        try {
            int int9 = randomNumberGenerator0.getRandomNumber(48, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=48 max=16");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 27 + "'", int3 == 27);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 38 + "'", int6 == 38);
    }

    @Test
    public void test0387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0387");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(12, 27);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(71, 27);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=71 max=27");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 25 + "'", int10 == 25);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test0388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0388");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(93, 93);
        int int18 = randomNumberGenerator0.getRandomNumber(11, 20);
        java.lang.Class<?> wildcardClass19 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        try {
            int int23 = randomNumberGenerator0.getRandomNumber(15, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=15 max=7");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 88 + "'", int4 == 88);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 93 + "'", int15 == 93);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 20 + "'", int18 == 20);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test0389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0389");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        int int16 = randomNumberGenerator0.getRandomNumber(41, 94);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        int int21 = randomNumberGenerator0.getRandomNumber(50, 92);
        java.lang.Class<?> wildcardClass22 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass23 = randomNumberGenerator0.getClass();
        int int26 = randomNumberGenerator0.getRandomNumber(40, 86);
        try {
            int int29 = randomNumberGenerator0.getRandomNumber(85, 64);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=85 max=64");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 65 + "'", int4 == 65);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 64 + "'", int13 == 64);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 71 + "'", int21 == 71);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 84 + "'", int26 == 84);
    }

    @Test
    public void test0390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0390");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(5, 72);
        int int19 = randomNumberGenerator0.getRandomNumber((-1), 37);
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        int int23 = randomNumberGenerator0.getRandomNumber((int) (short) -1, 60);
        int int26 = randomNumberGenerator0.getRandomNumber(0, 3);
        try {
            int int29 = randomNumberGenerator0.getRandomNumber(98, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=98 max=1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 48 + "'", int4 == 48);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 23 + "'", int16 == 23);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 36 + "'", int23 == 36);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test0391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0391");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(12, 27);
        int int13 = randomNumberGenerator0.getRandomNumber((int) ' ', 52);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        int int17 = randomNumberGenerator0.getRandomNumber((int) (short) -1, 70);
        int int20 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, 22);
        java.lang.Class<?> wildcardClass21 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass22 = randomNumberGenerator0.getClass();
        try {
            int int25 = randomNumberGenerator0.getRandomNumber(47, 36);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=47 max=36");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 23 + "'", int10 == 23);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 50 + "'", int13 == 50);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 5 + "'", int17 == 5);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 7 + "'", int20 == 7);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test0392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0392");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(40, 52);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber((int) '4', 54);
        int int17 = randomNumberGenerator0.getRandomNumber(35, 41);
        int int20 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 21);
        try {
            int int23 = randomNumberGenerator0.getRandomNumber(64, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=64 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 93 + "'", int4 == 93);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 47 + "'", int10 == 47);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53 + "'", int14 == 53);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 36 + "'", int17 == 36);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 17 + "'", int20 == 17);
    }

    @Test
    public void test0393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0393");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(40, 52);
        int int13 = randomNumberGenerator0.getRandomNumber(38, 61);
        int int16 = randomNumberGenerator0.getRandomNumber((int) (short) 0, 35);
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(65, 43);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=65 max=43");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 70 + "'", int4 == 70);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 51 + "'", int10 == 51);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 43 + "'", int13 == 43);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 34 + "'", int16 == 34);
    }

    @Test
    public void test0394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0394");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        int int9 = randomNumberGenerator0.getRandomNumber(73, (int) (short) 100);
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        int int17 = randomNumberGenerator0.getRandomNumber(1, 64);
        int int20 = randomNumberGenerator0.getRandomNumber(34, 77);
        try {
            int int23 = randomNumberGenerator0.getRandomNumber(44, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=44 max=10");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 80 + "'", int9 == 80);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 35 + "'", int20 == 35);
    }

    @Test
    public void test0395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0395");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(7, 67);
        int int14 = randomNumberGenerator0.getRandomNumber(33, 93);
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(61, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=61 max=31");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 63 + "'", int11 == 63);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 64 + "'", int14 == 64);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test0396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0396");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        int int16 = randomNumberGenerator0.getRandomNumber(55, 79);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        try {
            int int20 = randomNumberGenerator0.getRandomNumber((int) (byte) 100, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=100 max=20");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 79 + "'", int16 == 79);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test0397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0397");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(0, 12);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(75, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=75 max=1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 30 + "'", int4 == 30);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test0398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0398");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber(0, (int) (short) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(19, 40);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        try {
            int int11 = randomNumberGenerator0.getRandomNumber(52, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=52 max=3");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 25 + "'", int7 == 25);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test0399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0399");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(12, 27);
        int int13 = randomNumberGenerator0.getRandomNumber(19, (int) (short) 100);
        int int16 = randomNumberGenerator0.getRandomNumber(18, (int) (byte) 100);
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(98, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=98 max=35");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 25 + "'", int10 == 25);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 27 + "'", int13 == 27);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 71 + "'", int16 == 71);
    }

    @Test
    public void test0400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0400");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber(0, (int) (short) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(19, 40);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        try {
            int int11 = randomNumberGenerator0.getRandomNumber(90, 27);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=90 max=27");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 33 + "'", int7 == 33);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test0401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0401");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber(82, 87);
        try {
            int int10 = randomNumberGenerator0.getRandomNumber(97, 56);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=97 max=56");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 36 + "'", int4 == 36);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 85 + "'", int7 == 85);
    }

    @Test
    public void test0402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0402");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber(2, 73);
        int int19 = randomNumberGenerator0.getRandomNumber(80, 83);
        int int22 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, 86);
        try {
            int int25 = randomNumberGenerator0.getRandomNumber(70, 62);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=70 max=62");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 41 + "'", int7 == 41);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 74 + "'", int10 == 74);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 22 + "'", int13 == 22);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 60 + "'", int16 == 60);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 83 + "'", int19 == 83);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 13 + "'", int22 == 13);
    }

    @Test
    public void test0403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0403");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(93, 93);
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(58, 48);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=58 max=48");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 38 + "'", int4 == 38);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 93 + "'", int15 == 93);
    }

    @Test
    public void test0404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0404");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber(0, (int) (short) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        try {
            int int8 = randomNumberGenerator0.getRandomNumber(98, 87);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=98 max=87");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test0405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0405");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, 16);
        try {
            int int15 = randomNumberGenerator0.getRandomNumber(26, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=26 max=10");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 35 + "'", int4 == 35);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
    }

    @Test
    public void test0406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0406");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        int int9 = randomNumberGenerator0.getRandomNumber(73, (int) (short) 100);
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        int int17 = randomNumberGenerator0.getRandomNumber(18, (int) '4');
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(69, 55);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=69 max=55");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 91 + "'", int9 == 91);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
    }

    @Test
    public void test0407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0407");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber((-1), 51);
        int int10 = randomNumberGenerator0.getRandomNumber((int) (short) 0, 10);
        int int13 = randomNumberGenerator0.getRandomNumber((int) '#', 82);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(14, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=14 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 51 + "'", int13 == 51);
    }

    @Test
    public void test0408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0408");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(40, 52);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber((int) '4', 54);
        int int17 = randomNumberGenerator0.getRandomNumber(35, 41);
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(99, 61);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=99 max=61");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 35 + "'", int4 == 35);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 54 + "'", int14 == 54);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 40 + "'", int17 == 40);
    }

    @Test
    public void test0409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0409");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber(79, (int) (short) 100);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(31, 80);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(50, 88);
        int int19 = randomNumberGenerator0.getRandomNumber(0, 4);
        try {
            int int22 = randomNumberGenerator0.getRandomNumber(99, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=99 max=32");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 67 + "'", int4 == 67);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 94 + "'", int8 == 94);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 55 + "'", int12 == 55);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 61 + "'", int16 == 61);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test0410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0410");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(49, 86);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(55, 59);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass19 = randomNumberGenerator0.getClass();
        try {
            int int22 = randomNumberGenerator0.getRandomNumber(92, 82);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=92 max=82");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 92 + "'", int4 == 92);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 89 + "'", int7 == 89);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 70 + "'", int12 == 70);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 55 + "'", int16 == 55);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test0411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0411");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(49, 86);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(13, (int) ' ');
        int int19 = randomNumberGenerator0.getRandomNumber(5, 71);
        int int22 = randomNumberGenerator0.getRandomNumber(2, 63);
        try {
            int int25 = randomNumberGenerator0.getRandomNumber(77, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=77 max=2");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 25 + "'", int4 == 25);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 36 + "'", int7 == 36);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 53 + "'", int12 == 53);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 29 + "'", int16 == 29);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 54 + "'", int19 == 54);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 40 + "'", int22 == 40);
    }

    @Test
    public void test0412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0412");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (byte) 100);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        int int18 = randomNumberGenerator0.getRandomNumber(9, 34);
        java.lang.Class<?> wildcardClass19 = randomNumberGenerator0.getClass();
        try {
            int int22 = randomNumberGenerator0.getRandomNumber(99, 63);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=99 max=63");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 29 + "'", int4 == 29);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 30 + "'", int18 == 30);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test0413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0413");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        int int11 = randomNumberGenerator0.getRandomNumber(0, 51);
        int int14 = randomNumberGenerator0.getRandomNumber(93, 94);
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(98, 51);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=98 max=51");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 82 + "'", int4 == 82);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 94 + "'", int14 == 94);
    }

    @Test
    public void test0414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0414");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, (int) (byte) 1);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        try {
            int int12 = randomNumberGenerator0.getRandomNumber(92, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=92 max=1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test0415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0415");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber(2, 73);
        int int19 = randomNumberGenerator0.getRandomNumber(80, 83);
        int int22 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, 86);
        try {
            int int25 = randomNumberGenerator0.getRandomNumber(86, 58);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=86 max=58");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 30 + "'", int7 == 30);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 64 + "'", int10 == 64);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 34 + "'", int13 == 34);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 5 + "'", int16 == 5);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 82 + "'", int19 == 82);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 74 + "'", int22 == 74);
    }

    @Test
    public void test0416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0416");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber(69, 78);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber((int) (byte) 100, 17);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=100 max=17");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 76 + "'", int13 == 76);
    }

    @Test
    public void test0417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0417");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber((-1), (int) (short) 10);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        try {
            int int21 = randomNumberGenerator0.getRandomNumber(78, 39);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=78 max=39");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 73 + "'", int10 == 73);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 27 + "'", int13 == 27);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test0418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0418");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(31, 31);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber((int) (byte) 10, 91);
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(90, 68);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=90 max=68");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 60 + "'", int15 == 60);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test0419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0419");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        try {
            int int11 = randomNumberGenerator0.getRandomNumber(51, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=51 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 23 + "'", int7 == 23);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test0420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0420");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber((-1), (int) (short) 10);
        int int19 = randomNumberGenerator0.getRandomNumber(12, (int) ' ');
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        try {
            int int23 = randomNumberGenerator0.getRandomNumber(51, 41);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=51 max=41");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 74 + "'", int7 == 74);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 34 + "'", int10 == 34);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 56 + "'", int13 == 56);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 5 + "'", int16 == 5);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 32 + "'", int19 == 32);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test0421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0421");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        int int16 = randomNumberGenerator0.getRandomNumber(41, 94);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        int int21 = randomNumberGenerator0.getRandomNumber(50, 92);
        java.lang.Class<?> wildcardClass22 = randomNumberGenerator0.getClass();
        int int25 = randomNumberGenerator0.getRandomNumber(0, 7);
        try {
            int int28 = randomNumberGenerator0.getRandomNumber(99, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=99 max=11");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 51 + "'", int13 == 51);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 47 + "'", int16 == 47);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 73 + "'", int21 == 73);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
    }

    @Test
    public void test0422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0422");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        try {
            int int13 = randomNumberGenerator0.getRandomNumber(76, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=76 max=15");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test0423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0423");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(31, 31);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(60, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=60 max=5");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test0424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0424");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        try {
            int int13 = randomNumberGenerator0.getRandomNumber(56, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=56 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 89 + "'", int4 == 89);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 60 + "'", int7 == 60);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test0425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0425");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        int int11 = randomNumberGenerator0.getRandomNumber(0, 51);
        int int14 = randomNumberGenerator0.getRandomNumber(18, 86);
        int int17 = randomNumberGenerator0.getRandomNumber(28, (int) (byte) 100);
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        try {
            int int21 = randomNumberGenerator0.getRandomNumber(37, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=37 max=34");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 95 + "'", int4 == 95);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 14 + "'", int8 == 14);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 47 + "'", int11 == 47);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 19 + "'", int14 == 19);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 73 + "'", int17 == 73);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test0426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0426");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(12, 27);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber((int) (short) 0, (int) (byte) 0);
        int int17 = randomNumberGenerator0.getRandomNumber((int) (short) 1, 60);
        int int20 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 6);
        int int23 = randomNumberGenerator0.getRandomNumber(62, (int) 'a');
        try {
            int int26 = randomNumberGenerator0.getRandomNumber(93, 70);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=93 max=70");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 22 + "'", int10 == 22);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 47 + "'", int17 == 47);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 85 + "'", int23 == 85);
    }

    @Test
    public void test0427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0427");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        int int13 = randomNumberGenerator0.getRandomNumber(4, 69);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        int int17 = randomNumberGenerator0.getRandomNumber(96, 97);
        int int20 = randomNumberGenerator0.getRandomNumber(41, 87);
        try {
            int int23 = randomNumberGenerator0.getRandomNumber(55, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=55 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 26 + "'", int4 == 26);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 22 + "'", int10 == 22);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 44 + "'", int13 == 44);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 96 + "'", int17 == 96);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 58 + "'", int20 == 58);
    }

    @Test
    public void test0428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0428");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (byte) 100);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        int int18 = randomNumberGenerator0.getRandomNumber(9, 34);
        java.lang.Class<?> wildcardClass19 = randomNumberGenerator0.getClass();
        try {
            int int22 = randomNumberGenerator0.getRandomNumber((int) (short) 100, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=100 max=3");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 45 + "'", int7 == 45);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 39 + "'", int12 == 39);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 29 + "'", int18 == 29);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test0429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0429");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber(2, 73);
        int int19 = randomNumberGenerator0.getRandomNumber(80, 83);
        int int22 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, 86);
        java.lang.Class<?> wildcardClass23 = randomNumberGenerator0.getClass();
        try {
            int int26 = randomNumberGenerator0.getRandomNumber(72, 27);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=72 max=27");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 50 + "'", int10 == 50);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 81 + "'", int19 == 81);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 31 + "'", int22 == 31);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test0430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0430");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        int int16 = randomNumberGenerator0.getRandomNumber(41, 94);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        int int21 = randomNumberGenerator0.getRandomNumber(50, 92);
        java.lang.Class<?> wildcardClass22 = randomNumberGenerator0.getClass();
        try {
            int int25 = randomNumberGenerator0.getRandomNumber(3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=3 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 58 + "'", int4 == 58);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 50 + "'", int13 == 50);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 49 + "'", int16 == 49);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 66 + "'", int21 == 66);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test0431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0431");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, 76);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        int int17 = randomNumberGenerator0.getRandomNumber(55, 86);
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(62, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=62 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 67 + "'", int10 == 67);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 62 + "'", int17 == 62);
    }

    @Test
    public void test0432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0432");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(47, 47);
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(20, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=20 max=16");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 47 + "'", int14 == 47);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test0433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0433");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(52, 55);
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(36, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=36 max=10");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 92 + "'", int4 == 92);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 47 + "'", int10 == 47);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
    }

    @Test
    public void test0434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0434");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber(2, 73);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        int int20 = randomNumberGenerator0.getRandomNumber((int) (byte) 10, 97);
        java.lang.Class<?> wildcardClass21 = randomNumberGenerator0.getClass();
        int int24 = randomNumberGenerator0.getRandomNumber(37, 60);
        java.lang.Class<?> wildcardClass25 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass26 = randomNumberGenerator0.getClass();
        try {
            int int29 = randomNumberGenerator0.getRandomNumber(23, 22);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=23 max=22");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 74 + "'", int7 == 74);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 74 + "'", int10 == 74);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 59 + "'", int16 == 59);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 92 + "'", int20 == 92);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 55 + "'", int24 == 55);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test0435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0435");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(7, 67);
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(11, 27);
        int int19 = randomNumberGenerator0.getRandomNumber(19, 37);
        try {
            int int22 = randomNumberGenerator0.getRandomNumber(4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=4 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 50 + "'", int11 == 50);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 26 + "'", int19 == 26);
    }

    @Test
    public void test0436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0436");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(7, 67);
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        try {
            int int15 = randomNumberGenerator0.getRandomNumber(78, 26);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=78 max=26");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 36 + "'", int11 == 36);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test0437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0437");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 10, 65);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(66, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=66 max=5");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 59 + "'", int4 == 59);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 26 + "'", int13 == 26);
    }

    @Test
    public void test0438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0438");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        try {
            int int10 = randomNumberGenerator0.getRandomNumber(89, 77);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=89 max=77");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 48 + "'", int4 == 48);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 93 + "'", int7 == 93);
    }

    @Test
    public void test0439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0439");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        int int18 = randomNumberGenerator0.getRandomNumber(39, 72);
        java.lang.Class<?> wildcardClass19 = randomNumberGenerator0.getClass();
        int int22 = randomNumberGenerator0.getRandomNumber(75, 100);
        try {
            int int25 = randomNumberGenerator0.getRandomNumber(71, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=71 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 86 + "'", int7 == 86);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 79 + "'", int10 == 79);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 44 + "'", int13 == 44);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 39 + "'", int18 == 39);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 84 + "'", int22 == 84);
    }

    @Test
    public void test0440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0440");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber((int) '#', 76);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(91, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=91 max=-1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 46 + "'", int10 == 46);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 65 + "'", int13 == 65);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test0441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0441");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(7, 67);
        int int14 = randomNumberGenerator0.getRandomNumber(33, 93);
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(56, 17);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=56 max=17");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 56 + "'", int11 == 56);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 40 + "'", int14 == 40);
    }

    @Test
    public void test0442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0442");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        int int3 = randomNumberGenerator0.getRandomNumber(28, 59);
        try {
            int int6 = randomNumberGenerator0.getRandomNumber(59, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=59 max=10");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 57 + "'", int3 == 57);
    }

    @Test
    public void test0443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0443");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        int int13 = randomNumberGenerator0.getRandomNumber(61, 94);
        int int16 = randomNumberGenerator0.getRandomNumber(53, 58);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(11, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=11 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 92 + "'", int4 == 92);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 71 + "'", int13 == 71);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test0444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0444");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(0, 12);
        int int15 = randomNumberGenerator0.getRandomNumber(36, 93);
        int int18 = randomNumberGenerator0.getRandomNumber((int) (short) 10, 53);
        try {
            int int21 = randomNumberGenerator0.getRandomNumber(83, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=83 max=6");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 14 + "'", int4 == 14);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 38 + "'", int15 == 38);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 51 + "'", int18 == 51);
    }

    @Test
    public void test0445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0445");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(76, (int) (byte) 100);
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(0, 0);
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(99, 91);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=99 max=91");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 89 + "'", int4 == 89);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 97 + "'", int11 == 97);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test0446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0446");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber((-1), 51);
        int int10 = randomNumberGenerator0.getRandomNumber((int) (short) 0, 10);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(61, 29);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=61 max=29");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 23 + "'", int7 == 23);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test0447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0447");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber(2, 73);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass19 = randomNumberGenerator0.getClass();
        int int22 = randomNumberGenerator0.getRandomNumber(38, 52);
        try {
            int int25 = randomNumberGenerator0.getRandomNumber(68, 50);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=68 max=50");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 68 + "'", int7 == 68);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 42 + "'", int10 == 42);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 19 + "'", int13 == 19);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 59 + "'", int16 == 59);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 40 + "'", int22 == 40);
    }

    @Test
    public void test0448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0448");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber(0, 60);
        int int16 = randomNumberGenerator0.getRandomNumber((int) (byte) 10, 91);
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(89, 44);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=89 max=44");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 37 + "'", int4 == 37);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 7 + "'", int13 == 7);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 82 + "'", int16 == 82);
    }

    @Test
    public void test0449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0449");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber(2, 73);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        int int20 = randomNumberGenerator0.getRandomNumber((int) (byte) 10, 97);
        java.lang.Class<?> wildcardClass21 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass22 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass23 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass24 = randomNumberGenerator0.getClass();
        try {
            int int27 = randomNumberGenerator0.getRandomNumber(68, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=68 max=18");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 50 + "'", int10 == 50);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 22 + "'", int16 == 22);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 78 + "'", int20 == 78);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test0450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0450");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(40, 52);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber((int) '4', 54);
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        try {
            int int18 = randomNumberGenerator0.getRandomNumber(16, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=16 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 95 + "'", int4 == 95);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 51 + "'", int10 == 51);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 54 + "'", int14 == 54);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test0451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0451");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(0, 12);
        int int15 = randomNumberGenerator0.getRandomNumber(36, 93);
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        int int19 = randomNumberGenerator0.getRandomNumber(61, 68);
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        int int23 = randomNumberGenerator0.getRandomNumber(67, 72);
        try {
            int int26 = randomNumberGenerator0.getRandomNumber(20, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=20 max=11");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 47 + "'", int15 == 47);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 63 + "'", int19 == 63);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 72 + "'", int23 == 72);
    }

    @Test
    public void test0452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0452");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(31, 31);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber((int) '4', 55);
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        try {
            int int21 = randomNumberGenerator0.getRandomNumber(38, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=38 max=10");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 53 + "'", int15 == 53);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test0453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0453");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(49, 86);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(33, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=33 max=28");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 42 + "'", int4 == 42);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 51 + "'", int7 == 51);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 61 + "'", int12 == 61);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test0454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0454");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber(2, 73);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass19 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        try {
            int int23 = randomNumberGenerator0.getRandomNumber(17, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=17 max=2");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 47 + "'", int7 == 47);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 61 + "'", int10 == 61);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 50 + "'", int13 == 50);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 30 + "'", int16 == 30);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test0455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0455");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(0, 12);
        int int15 = randomNumberGenerator0.getRandomNumber(36, 93);
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        int int19 = randomNumberGenerator0.getRandomNumber(61, 68);
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        int int23 = randomNumberGenerator0.getRandomNumber(67, 72);
        java.lang.Class<?> wildcardClass24 = randomNumberGenerator0.getClass();
        try {
            int int27 = randomNumberGenerator0.getRandomNumber(92, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=92 max=35");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 17 + "'", int4 == 17);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 45 + "'", int15 == 45);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 62 + "'", int19 == 62);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 69 + "'", int23 == 69);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test0456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0456");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        int int13 = randomNumberGenerator0.getRandomNumber(4, 69);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        int int18 = randomNumberGenerator0.getRandomNumber((-1), 26);
        int int21 = randomNumberGenerator0.getRandomNumber(54, 69);
        try {
            int int24 = randomNumberGenerator0.getRandomNumber(64, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=64 max=16");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 78 + "'", int4 == 78);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 11 + "'", int13 == 11);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 18 + "'", int18 == 18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 68 + "'", int21 == 68);
    }

    @Test
    public void test0457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0457");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        try {
            int int3 = randomNumberGenerator0.getRandomNumber(67, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=67 max=4");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test0458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0458");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(40, 52);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber((int) '4', 54);
        int int17 = randomNumberGenerator0.getRandomNumber(35, 41);
        int int20 = randomNumberGenerator0.getRandomNumber(88, 100);
        java.lang.Class<?> wildcardClass21 = randomNumberGenerator0.getClass();
        try {
            int int24 = randomNumberGenerator0.getRandomNumber(80, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=80 max=12");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 44 + "'", int10 == 44);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53 + "'", int14 == 53);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 39 + "'", int17 == 39);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 90 + "'", int20 == 90);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test0459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0459");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        int int11 = randomNumberGenerator0.getRandomNumber(76, (int) (byte) 100);
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(0, 0);
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(90, 78);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=90 max=78");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 79 + "'", int11 == 79);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test0460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0460");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber(2, 73);
        int int19 = randomNumberGenerator0.getRandomNumber(80, 83);
        try {
            int int22 = randomNumberGenerator0.getRandomNumber(14, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=14 max=10");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 55 + "'", int10 == 55);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 28 + "'", int13 == 28);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 34 + "'", int16 == 34);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 83 + "'", int19 == 83);
    }

    @Test
    public void test0461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0461");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(34, 39);
        int int13 = randomNumberGenerator0.getRandomNumber(37, 43);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        int int17 = randomNumberGenerator0.getRandomNumber((-1), (int) (short) 0);
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass19 = randomNumberGenerator0.getClass();
        int int22 = randomNumberGenerator0.getRandomNumber(52, 77);
        try {
            int int25 = randomNumberGenerator0.getRandomNumber((int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=10 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 59 + "'", int7 == 59);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 36 + "'", int10 == 36);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 41 + "'", int13 == 41);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 75 + "'", int22 == 75);
    }

    @Test
    public void test0462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0462");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(40, 52);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(0, 88);
        int int17 = randomNumberGenerator0.getRandomNumber(1, 87);
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(36, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=36 max=21");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 66 + "'", int4 == 66);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 45 + "'", int10 == 45);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 84 + "'", int14 == 84);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 75 + "'", int17 == 75);
    }

    @Test
    public void test0463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0463");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(4, 5);
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(49, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=49 max=5");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 53 + "'", int10 == 53);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
    }

    @Test
    public void test0464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0464");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(0, 12);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(0, 66);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        int int21 = randomNumberGenerator0.getRandomNumber(39, 74);
        try {
            int int24 = randomNumberGenerator0.getRandomNumber(90, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=90 max=32");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 38 + "'", int4 == 38);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 11 + "'", int8 == 11);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 42 + "'", int21 == 42);
    }

    @Test
    public void test0465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0465");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(12, 27);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber((int) (short) 0, (int) (byte) 0);
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        try {
            int int21 = randomNumberGenerator0.getRandomNumber(91, 61);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=91 max=61");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test0466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0466");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        int int18 = randomNumberGenerator0.getRandomNumber(39, 72);
        int int21 = randomNumberGenerator0.getRandomNumber(0, 75);
        java.lang.Class<?> wildcardClass22 = randomNumberGenerator0.getClass();
        int int25 = randomNumberGenerator0.getRandomNumber(19, 80);
        java.lang.Class<?> wildcardClass26 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass27 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass28 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass29 = randomNumberGenerator0.getClass();
        try {
            int int32 = randomNumberGenerator0.getRandomNumber(89, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=89 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 36 + "'", int10 == 36);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 38 + "'", int13 == 38);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 60 + "'", int18 == 60);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 17 + "'", int21 == 17);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(wildcardClass29);
    }

    @Test
    public void test0467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0467");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(0, 12);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(0, 66);
        int int19 = randomNumberGenerator0.getRandomNumber(38, 71);
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass21 = randomNumberGenerator0.getClass();
        int int24 = randomNumberGenerator0.getRandomNumber(27, 81);
        try {
            int int27 = randomNumberGenerator0.getRandomNumber(42, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=42 max=19");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 92 + "'", int4 == 92);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 60 + "'", int16 == 60);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 40 + "'", int19 == 40);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 47 + "'", int24 == 47);
    }

    @Test
    public void test0468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0468");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber(2, 73);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        int int20 = randomNumberGenerator0.getRandomNumber((int) (byte) 10, 97);
        java.lang.Class<?> wildcardClass21 = randomNumberGenerator0.getClass();
        int int24 = randomNumberGenerator0.getRandomNumber(37, 60);
        java.lang.Class<?> wildcardClass25 = randomNumberGenerator0.getClass();
        try {
            int int28 = randomNumberGenerator0.getRandomNumber(94, 54);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=94 max=54");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 94 + "'", int10 == 94);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 42 + "'", int13 == 42);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 70 + "'", int16 == 70);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 38 + "'", int20 == 38);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 40 + "'", int24 == 40);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test0469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0469");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, 76);
        int int16 = randomNumberGenerator0.getRandomNumber(46, 53);
        int int19 = randomNumberGenerator0.getRandomNumber(65, 74);
        int int22 = randomNumberGenerator0.getRandomNumber(29, (int) (byte) 100);
        try {
            int int25 = randomNumberGenerator0.getRandomNumber(58, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=58 max=4");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 55 + "'", int4 == 55);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 72 + "'", int10 == 72);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 49 + "'", int13 == 49);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 49 + "'", int16 == 49);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 69 + "'", int19 == 69);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 83 + "'", int22 == 83);
    }

    @Test
    public void test0470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0470");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        int int11 = randomNumberGenerator0.getRandomNumber(0, 51);
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber((int) '4', 80);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(20, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=20 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 14 + "'", int4 == 14);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 11 + "'", int8 == 11);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 28 + "'", int11 == 28);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 69 + "'", int16 == 69);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test0471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0471");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(28, 71);
        int int19 = randomNumberGenerator0.getRandomNumber(0, 34);
        try {
            int int22 = randomNumberGenerator0.getRandomNumber(71, 46);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=71 max=46");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 14 + "'", int8 == 14);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 57 + "'", int16 == 57);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 23 + "'", int19 == 23);
    }

    @Test
    public void test0472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0472");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(40, 52);
        int int13 = randomNumberGenerator0.getRandomNumber(38, 61);
        int int16 = randomNumberGenerator0.getRandomNumber((int) (short) 0, 35);
        int int19 = randomNumberGenerator0.getRandomNumber(8, 54);
        try {
            int int22 = randomNumberGenerator0.getRandomNumber(100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=100 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 41 + "'", int10 == 41);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 48 + "'", int13 == 48);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 14 + "'", int16 == 14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 27 + "'", int19 == 27);
    }

    @Test
    public void test0473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0473");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 36 + "'", int7 == 36);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 83 + "'", int10 == 83);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test0474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0474");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        try {
            int int13 = randomNumberGenerator0.getRandomNumber(83, 75);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=83 max=75");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 17 + "'", int10 == 17);
    }

    @Test
    public void test0475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0475");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        int int11 = randomNumberGenerator0.getRandomNumber(0, 51);
        int int14 = randomNumberGenerator0.getRandomNumber(34, 43);
        int int17 = randomNumberGenerator0.getRandomNumber(0, 71);
        int int20 = randomNumberGenerator0.getRandomNumber(24, 88);
        int int23 = randomNumberGenerator0.getRandomNumber(77, 81);
        java.lang.Class<?> wildcardClass24 = randomNumberGenerator0.getClass();
        try {
            int int27 = randomNumberGenerator0.getRandomNumber(99, 96);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=99 max=96");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 75 + "'", int4 == 75);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 39 + "'", int14 == 39);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 27 + "'", int17 == 27);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 67 + "'", int20 == 67);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 78 + "'", int23 == 78);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test0476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0476");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        int int9 = randomNumberGenerator0.getRandomNumber(73, (int) (short) 100);
        try {
            int int12 = randomNumberGenerator0.getRandomNumber(81, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=81 max=35");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 99 + "'", int9 == 99);
    }

    @Test
    public void test0477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0477");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(12, 27);
        int int13 = randomNumberGenerator0.getRandomNumber((int) ' ', 52);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        int int17 = randomNumberGenerator0.getRandomNumber((int) (short) -1, 70);
        int int20 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, 22);
        java.lang.Class<?> wildcardClass21 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass22 = randomNumberGenerator0.getClass();
        int int25 = randomNumberGenerator0.getRandomNumber(0, 93);
        try {
            int int28 = randomNumberGenerator0.getRandomNumber(69, 57);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=69 max=57");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 42 + "'", int13 == 42);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 32 + "'", int17 == 32);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 89 + "'", int25 == 89);
    }

    @Test
    public void test0478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0478");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(0, 12);
        int int15 = randomNumberGenerator0.getRandomNumber(36, 93);
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(57, 54);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=57 max=54");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 66 + "'", int4 == 66);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 14 + "'", int8 == 14);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 53 + "'", int15 == 53);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test0479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0479");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber((-1), 51);
        int int10 = randomNumberGenerator0.getRandomNumber((int) (short) 0, 10);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(97, 93);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=97 max=93");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 43 + "'", int7 == 43);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 7 + "'", int10 == 7);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test0480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0480");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        int int16 = randomNumberGenerator0.getRandomNumber(41, 94);
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        int int21 = randomNumberGenerator0.getRandomNumber(50, 92);
        java.lang.Class<?> wildcardClass22 = randomNumberGenerator0.getClass();
        int int25 = randomNumberGenerator0.getRandomNumber(0, 7);
        int int28 = randomNumberGenerator0.getRandomNumber(55, 57);
        int int31 = randomNumberGenerator0.getRandomNumber(0, 29);
        java.lang.Class<?> wildcardClass32 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass33 = randomNumberGenerator0.getClass();
        try {
            int int36 = randomNumberGenerator0.getRandomNumber(96, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=96 max=1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 82 + "'", int4 == 82);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 57 + "'", int13 == 57);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 86 + "'", int16 == 86);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 67 + "'", int21 == 67);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 55 + "'", int28 == 55);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 20 + "'", int31 == 20);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(wildcardClass33);
    }

    @Test
    public void test0481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0481");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(40, 52);
        int int13 = randomNumberGenerator0.getRandomNumber(38, 61);
        int int16 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 41);
        int int19 = randomNumberGenerator0.getRandomNumber(41, 91);
        int int22 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 31);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 48 + "'", int4 == 48);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 49 + "'", int10 == 49);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 49 + "'", int13 == 49);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 80 + "'", int19 == 80);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 19 + "'", int22 == 19);
    }

    @Test
    public void test0482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0482");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(31, 31);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        try {
            int int15 = randomNumberGenerator0.getRandomNumber((int) (byte) 100, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=100 max=1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test0483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0483");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        try {
            int int11 = randomNumberGenerator0.getRandomNumber(45, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=45 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
    }

    @Test
    public void test0484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0484");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber(2, 73);
        int int19 = randomNumberGenerator0.getRandomNumber(80, 83);
        int int22 = randomNumberGenerator0.getRandomNumber(29, 65);
        try {
            int int25 = randomNumberGenerator0.getRandomNumber(72, 65);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=72 max=65");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 36 + "'", int7 == 36);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 71 + "'", int10 == 71);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 21 + "'", int13 == 21);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 62 + "'", int16 == 62);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 82 + "'", int19 == 82);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 65 + "'", int22 == 65);
    }

    @Test
    public void test0485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0485");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber((int) (byte) 10, 95);
        try {
            int int17 = randomNumberGenerator0.getRandomNumber(87, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=87 max=35");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 73 + "'", int4 == 73);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 11 + "'", int8 == 11);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 22 + "'", int14 == 22);
    }

    @Test
    public void test0486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0486");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        int int17 = randomNumberGenerator0.getRandomNumber((int) (short) 10, 79);
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        int int21 = randomNumberGenerator0.getRandomNumber(9, 88);
        try {
            int int24 = randomNumberGenerator0.getRandomNumber(75, 40);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=75 max=40");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 7 + "'", int7 == 7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 75 + "'", int10 == 75);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 53 + "'", int17 == 53);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 38 + "'", int21 == 38);
    }

    @Test
    public void test0487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0487");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        int int17 = randomNumberGenerator0.getRandomNumber((int) (short) 10, 79);
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass19 = randomNumberGenerator0.getClass();
        int int22 = randomNumberGenerator0.getRandomNumber(44, 63);
        int int25 = randomNumberGenerator0.getRandomNumber(46, 57);
        java.lang.Class<?> wildcardClass26 = randomNumberGenerator0.getClass();
        try {
            int int29 = randomNumberGenerator0.getRandomNumber(71, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=71 max=-1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 43 + "'", int10 == 43);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 55 + "'", int17 == 55);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 62 + "'", int22 == 62);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 46 + "'", int25 == 46);
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test0488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0488");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        int int7 = randomNumberGenerator0.getRandomNumber(0, 100);
        int int10 = randomNumberGenerator0.getRandomNumber(33, (int) 'a');
        int int13 = randomNumberGenerator0.getRandomNumber(0, 56);
        int int16 = randomNumberGenerator0.getRandomNumber((-1), (int) (short) 10);
        int int19 = randomNumberGenerator0.getRandomNumber(9, 32);
        java.lang.Class<?> wildcardClass20 = randomNumberGenerator0.getClass();
        int int23 = randomNumberGenerator0.getRandomNumber(30, 45);
        java.lang.Class<?> wildcardClass24 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass25 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass26 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass27 = randomNumberGenerator0.getClass();
        try {
            int int30 = randomNumberGenerator0.getRandomNumber(94, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=94 max=34");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 43 + "'", int7 == 43);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 64 + "'", int10 == 64);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 13 + "'", int13 == 13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 16 + "'", int19 == 16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 42 + "'", int23 == 42);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

    @Test
    public void test0489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0489");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(67, 90);
        int int17 = randomNumberGenerator0.getRandomNumber(54, 91);
        int int20 = randomNumberGenerator0.getRandomNumber(44, 98);
        try {
            int int23 = randomNumberGenerator0.getRandomNumber(55, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=55 max=1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 27 + "'", int4 == 27);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 40 + "'", int10 == 40);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 84 + "'", int14 == 84);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 86 + "'", int17 == 86);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 82 + "'", int20 == 82);
    }

    @Test
    public void test0490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0490");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(12, 27);
        int int13 = randomNumberGenerator0.getRandomNumber((int) ' ', 52);
        try {
            int int16 = randomNumberGenerator0.getRandomNumber(95, 57);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=95 max=57");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 36 + "'", int13 == 36);
    }

    @Test
    public void test0491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0491");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(28, 27);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=28 max=27");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 55 + "'", int7 == 55);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test0492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0492");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(0, 12);
        int int15 = randomNumberGenerator0.getRandomNumber(36, 93);
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        int int21 = randomNumberGenerator0.getRandomNumber(17, 100);
        try {
            int int24 = randomNumberGenerator0.getRandomNumber(12, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=12 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57 + "'", int4 == 57);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 80 + "'", int15 == 80);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 49 + "'", int21 == 49);
    }

    @Test
    public void test0493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0493");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass10 = randomNumberGenerator0.getClass();
        int int13 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 100);
        java.lang.Class<?> wildcardClass14 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass15 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(99, 49);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=99 max=49");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 49 + "'", int4 == 49);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 35 + "'", int13 == 35);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test0494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0494");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(49, 86);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(55, 59);
        try {
            int int19 = randomNumberGenerator0.getRandomNumber(70, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=70 max=24");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 94 + "'", int4 == 94);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 55 + "'", int12 == 55);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 59 + "'", int16 == 59);
    }

    @Test
    public void test0495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0495");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        int int8 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 14);
        int int11 = randomNumberGenerator0.getRandomNumber(0, 51);
        try {
            int int14 = randomNumberGenerator0.getRandomNumber(71, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=71 max=10");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 25 + "'", int11 == 25);
    }

    @Test
    public void test0496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0496");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass6 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass7 = randomNumberGenerator0.getClass();
        int int10 = randomNumberGenerator0.getRandomNumber(12, 27);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber((int) (short) 0, (int) (byte) 0);
        int int17 = randomNumberGenerator0.getRandomNumber((int) (short) 1, 60);
        int int20 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 6);
        int int23 = randomNumberGenerator0.getRandomNumber(10, 63);
        int int26 = randomNumberGenerator0.getRandomNumber(19, 38);
        try {
            int int29 = randomNumberGenerator0.getRandomNumber(34, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=34 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 16 + "'", int10 == 16);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 59 + "'", int17 == 59);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 27 + "'", int23 == 27);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 33 + "'", int26 == 33);
    }

    @Test
    public void test0497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0497");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass12 = randomNumberGenerator0.getClass();
        int int15 = randomNumberGenerator0.getRandomNumber(52, 55);
        java.lang.Class<?> wildcardClass16 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass17 = randomNumberGenerator0.getClass();
        try {
            int int20 = randomNumberGenerator0.getRandomNumber(75, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=75 max=2");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 95 + "'", int4 == 95);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 54 + "'", int15 == 54);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test0498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0498");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) 0, (int) (short) 1);
        int int10 = randomNumberGenerator0.getRandomNumber(0, 73);
        java.lang.Class<?> wildcardClass11 = randomNumberGenerator0.getClass();
        int int14 = randomNumberGenerator0.getRandomNumber(67, 90);
        int int17 = randomNumberGenerator0.getRandomNumber(54, 91);
        java.lang.Class<?> wildcardClass18 = randomNumberGenerator0.getClass();
        int int21 = randomNumberGenerator0.getRandomNumber(42, 55);
        int int24 = randomNumberGenerator0.getRandomNumber(14, 25);
        try {
            int int27 = randomNumberGenerator0.getRandomNumber(83, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=83 max=1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 18 + "'", int10 == 18);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 82 + "'", int14 == 82);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 88 + "'", int17 == 88);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 50 + "'", int21 == 50);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 25 + "'", int24 == 25);
    }

    @Test
    public void test0499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0499");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(49, 86);
        java.lang.Class<?> wildcardClass13 = randomNumberGenerator0.getClass();
        int int16 = randomNumberGenerator0.getRandomNumber(13, (int) ' ');
        int int19 = randomNumberGenerator0.getRandomNumber(5, 71);
        int int22 = randomNumberGenerator0.getRandomNumber(2, 63);
        int int25 = randomNumberGenerator0.getRandomNumber(11, 96);
        java.lang.Class<?> wildcardClass26 = randomNumberGenerator0.getClass();
        try {
            int int29 = randomNumberGenerator0.getRandomNumber((int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=1 max=0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 34 + "'", int4 == 34);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 64 + "'", int12 == 64);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 26 + "'", int16 == 26);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 63 + "'", int19 == 63);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 60 + "'", int22 == 60);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 37 + "'", int25 == 37);
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test0500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0500");
        uk.co.lrnk.self_esteem_snake.RandomNumberGenerator randomNumberGenerator0 = new uk.co.lrnk.self_esteem_snake.RandomNumberGenerator();
        java.lang.Class<?> wildcardClass1 = randomNumberGenerator0.getClass();
        int int4 = randomNumberGenerator0.getRandomNumber((int) (short) -1, (int) 'a');
        int int7 = randomNumberGenerator0.getRandomNumber((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass8 = randomNumberGenerator0.getClass();
        java.lang.Class<?> wildcardClass9 = randomNumberGenerator0.getClass();
        int int12 = randomNumberGenerator0.getRandomNumber(49, 86);
        int int15 = randomNumberGenerator0.getRandomNumber(69, 97);
        int int18 = randomNumberGenerator0.getRandomNumber(22, 82);
        try {
            int int21 = randomNumberGenerator0.getRandomNumber(96, 81);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Invalid arguments passed to RandomNumberGenerator.getRandomNumber: min=96 max=81");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 79 + "'", int12 == 79);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 81 + "'", int15 == 81);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 26 + "'", int18 == 26);
    }
}

