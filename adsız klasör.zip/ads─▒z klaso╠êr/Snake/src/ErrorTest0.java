import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ErrorTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test001");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Space space2 = snake0.getHeadSpace();
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test002");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        int int1 = snake0.getLength();
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test003");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Space space6 = snake0.getHeadSpace();
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test004");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList5 = snake0.getSnakeSpaces();
        snake0.step();
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test005");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        int int2 = snake0.getLength();
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test006");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction3 = snake0.getCurrentDirection();
        snake0.step();
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test007");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        int int18 = snake0.getLength();
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test008");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Space space18 = snake0.getHeadSpace();
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test009");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList5 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake0.getCurrentDirection();
        int int7 = snake0.getLength();
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test010");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        snake0.tryToHeadDown();
        int int3 = snake0.getLength();
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test011");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        uk.co.lrnk.self_esteem_snake.Direction direction15 = snake0.getCurrentDirection();
        int int16 = snake0.getLength();
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test012");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        uk.co.lrnk.self_esteem_snake.Direction direction15 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Space space16 = snake0.getHeadSpace();
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test013");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        snake0.tryToHeadDown();
        snake0.step();
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test014");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        int int3 = snake0.getStartingLength();
        int int4 = snake0.getLength();
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test015");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Space space2 = snake0.getHeadSpace();
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test016");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getNextStepDirection();
        int int6 = snake0.getLength();
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test017");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getNextStepDirection();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Space space7 = snake0.getHeadSpace();
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test018");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        int int3 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Space space4 = snake0.getHeadSpace();
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test019");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Space space3 = snake0.getHeadSpace();
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test020");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.step();
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test021");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        int int5 = snake0.getStartingLength();
        int int6 = snake0.getLength();
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test022");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        int int3 = snake0.getLength();
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test023");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getNextStepDirection();
        int int18 = snake0.getLength();
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test024");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        int int5 = snake0.getLength();
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test025");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList9 = snake4.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction10 = snake4.getCurrentDirection();
        snake0.setCurrentDirection(direction10);
        int int12 = snake0.getStartingLength();
        int int13 = snake0.getStartingLength();
        int int14 = snake0.getLength();
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test026");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        snake0.tryToHeadDown();
        snake0.tryToHeadUp();
        snake0.step();
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test027");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        int int3 = snake0.getLength();
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test028");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        int int3 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Space space4 = snake0.getHeadSpace();
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test029");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        int int2 = snake0.getLength();
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test030");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake5 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake5.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction7 = snake5.getCurrentDirection();
        snake5.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake9 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake9.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction11 = snake9.getCurrentDirection();
        snake9.tryToHeadDown();
        int int13 = snake9.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList14 = snake9.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction15 = snake9.getCurrentDirection();
        snake5.setCurrentDirection(direction15);
        snake0.setNextStepDirection(direction15);
        snake0.tryToHeadDown();
        java.lang.Class<?> wildcardClass19 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Space space20 = snake0.getHeadSpace();
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test031");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        snake0.tryToHeadRight();
        snake0.tryToHeadUp();
        snake0.tryToHeadUp();
        uk.co.lrnk.self_esteem_snake.Space space6 = snake0.getHeadSpace();
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test032");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Space space7 = snake0.getHeadSpace();
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test033");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList9 = snake4.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction10 = snake4.getCurrentDirection();
        snake0.setCurrentDirection(direction10);
        java.lang.Class<?> wildcardClass12 = snake0.getClass();
        snake0.tryToHeadLeft();
        int int14 = snake0.getLength();
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test034");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        int int15 = snake0.getLength();
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test035");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        uk.co.lrnk.self_esteem_snake.Direction direction15 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction16 = snake0.getCurrentDirection();
        snake0.step();
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test036");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getNextStepDirection();
        java.lang.Class<?> wildcardClass6 = snake0.getClass();
        snake0.step();
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test037");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction3 = snake0.getCurrentDirection();
        int int4 = snake0.getStartingLength();
        snake0.step();
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test038");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        int int3 = snake0.getStartingLength();
        int int4 = snake0.getLength();
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test039");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList9 = snake4.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction10 = snake4.getCurrentDirection();
        snake0.setCurrentDirection(direction10);
        java.lang.Class<?> wildcardClass12 = snake0.getClass();
        snake0.step();
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test040");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        int int3 = snake0.getLength();
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test041");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        snake0.tryToHeadDown();
        snake0.tryToHeadUp();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake0.getNextStepDirection();
        snake0.tryToHeadUp();
        int int6 = snake0.getLength();
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test042");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        int int3 = snake0.getStartingLength();
        snake0.tryToHeadUp();
        snake0.tryToHeadLeft();
        snake0.step();
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test043");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList9 = snake4.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction10 = snake4.getCurrentDirection();
        snake0.setCurrentDirection(direction10);
        java.lang.Class<?> wildcardClass12 = snake0.getClass();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction14 = snake0.getNextStepDirection();
        snake0.step();
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test044");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Space space5 = snake0.getHeadSpace();
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test045");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        int int3 = snake0.getLength();
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test046");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Space space19 = snake0.getHeadSpace();
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test047");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake5 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake5.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction7 = snake5.getCurrentDirection();
        snake5.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake9 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake9.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction11 = snake9.getCurrentDirection();
        snake9.tryToHeadDown();
        int int13 = snake9.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList14 = snake9.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction15 = snake9.getCurrentDirection();
        snake5.setCurrentDirection(direction15);
        snake0.setNextStepDirection(direction15);
        snake0.tryToHeadDown();
        java.lang.Class<?> wildcardClass19 = snake0.getClass();
        snake0.step();
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test048");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass3 = snake2.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake8 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake8.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction10 = snake8.getCurrentDirection();
        snake8.tryToHeadDown();
        int int12 = snake8.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList13 = snake8.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction14 = snake8.getCurrentDirection();
        snake4.setCurrentDirection(direction14);
        snake2.setNextStepDirection(direction14);
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake2.getCurrentDirection();
        snake0.setNextStepDirection(direction17);
        int int19 = snake0.getStartingLength();
        snake0.step();
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test049");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getNextStepDirection();
        java.lang.Class<?> wildcardClass6 = snake0.getClass();
        snake0.tryToHeadLeft();
        int int8 = snake0.getLength();
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test050");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList5 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Space space7 = snake0.getHeadSpace();
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test051");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        int int2 = snake0.getStartingLength();
        int int3 = snake0.getStartingLength();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList5 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Space space6 = snake0.getHeadSpace();
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test052");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getCurrentDirection();
        int int6 = snake0.getLength();
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test053");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction3 = snake0.getCurrentDirection();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Space space6 = snake0.getHeadSpace();
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test054");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList9 = snake4.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction10 = snake4.getCurrentDirection();
        snake0.setCurrentDirection(direction10);
        int int12 = snake0.getStartingLength();
        int int13 = snake0.getStartingLength();
        snake0.tryToHeadLeft();
        snake0.tryToHeadRight();
        snake0.step();
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test055");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getNextStepDirection();
        snake0.tryToHeadLeft();
        snake0.tryToHeadUp();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake0.getNextStepDirection();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList9 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Space space10 = snake0.getHeadSpace();
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test056");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        snake0.tryToHeadDown();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList3 = snake0.getSnakeSpaces();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getCurrentDirection();
        snake0.step();
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test057");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        java.lang.Class<?> wildcardClass3 = snake0.getClass();
        java.lang.Class<?> wildcardClass4 = snake0.getClass();
        int int5 = snake0.getLength();
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test058");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        int int5 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake0.getNextStepDirection();
        snake0.step();
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test059");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList5 = snake0.getSnakeSpaces();
        snake0.step();
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test060");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        snake0.step();
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test061");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        int int2 = snake0.getStartingLength();
        int int3 = snake0.getStartingLength();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList5 = snake0.getSnakeSpaces();
        snake0.tryToHeadLeft();
        snake0.step();
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test062");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        snake0.tryToHeadDown();
        snake0.tryToHeadLeft();
        int int5 = snake0.getLength();
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test063");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake5 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake5.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction7 = snake5.getCurrentDirection();
        snake5.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake9 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake9.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction11 = snake9.getCurrentDirection();
        snake9.tryToHeadDown();
        int int13 = snake9.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList14 = snake9.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction15 = snake9.getCurrentDirection();
        snake5.setCurrentDirection(direction15);
        snake0.setNextStepDirection(direction15);
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getCurrentDirection();
        java.lang.Class<?> wildcardClass19 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Space space20 = snake0.getHeadSpace();
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test064");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        int int6 = snake2.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake7 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake7.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction9 = snake7.getCurrentDirection();
        snake7.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake11 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake11.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction13 = snake11.getCurrentDirection();
        snake11.tryToHeadDown();
        int int15 = snake11.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList16 = snake11.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake11.getCurrentDirection();
        snake7.setCurrentDirection(direction17);
        snake2.setNextStepDirection(direction17);
        snake0.setCurrentDirection(direction17);
        snake0.step();
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test065");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        int int3 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction9 = snake4.getCurrentDirection();
        snake0.setNextStepDirection(direction9);
        int int11 = snake0.getLength();
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test066");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Space space18 = snake0.getHeadSpace();
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test067");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList9 = snake4.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction10 = snake4.getCurrentDirection();
        snake0.setCurrentDirection(direction10);
        int int12 = snake0.getStartingLength();
        int int13 = snake0.getStartingLength();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Space space15 = snake0.getHeadSpace();
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test068");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        int int2 = snake0.getStartingLength();
        int int3 = snake0.getStartingLength();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList5 = snake0.getSnakeSpaces();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Space space7 = snake0.getHeadSpace();
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test069");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList9 = snake4.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction10 = snake4.getCurrentDirection();
        snake0.setCurrentDirection(direction10);
        int int12 = snake0.getStartingLength();
        int int13 = snake0.getStartingLength();
        snake0.tryToHeadLeft();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Space space16 = snake0.getHeadSpace();
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test070");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getNextStepDirection();
        int int19 = snake0.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList20 = snake0.getSnakeSpaces();
        snake0.step();
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test071");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getNextStepDirection();
        snake0.tryToHeadLeft();
        snake0.step();
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test072");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList5 = snake0.getSnakeSpaces();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList6 = snake0.getSnakeSpaces();
        int int7 = snake0.getLength();
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test073");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        java.lang.Class<?> wildcardClass17 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getCurrentDirection();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Space space20 = snake0.getHeadSpace();
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test074");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        java.lang.Class<?> wildcardClass16 = snake0.getClass();
        snake0.step();
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test075");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction3 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        snake0.tryToHeadUp();
        int int6 = snake0.getLength();
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test076");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        java.lang.Class<?> wildcardClass3 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake0.getNextStepDirection();
        java.lang.Class<?> wildcardClass5 = snake0.getClass();
        snake0.step();
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test077");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        int int2 = snake0.getLength();
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test078");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getNextStepDirection();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction19 = snake0.getNextStepDirection();
        int int20 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction21 = snake0.getNextStepDirection();
        int int22 = snake0.getLength();
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test079");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getNextStepDirection();
        snake0.tryToHeadLeft();
        snake0.tryToHeadUp();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake0.getNextStepDirection();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList9 = snake0.getSnakeSpaces();
        snake0.step();
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test080");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction3 = snake0.getNextStepDirection();
        snake0.tryToHeadUp();
        int int5 = snake0.getLength();
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test081");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        int int6 = snake2.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake7 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake7.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction9 = snake7.getCurrentDirection();
        snake7.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake11 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake11.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction13 = snake11.getCurrentDirection();
        snake11.tryToHeadDown();
        int int15 = snake11.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList16 = snake11.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake11.getCurrentDirection();
        snake7.setCurrentDirection(direction17);
        snake2.setNextStepDirection(direction17);
        snake0.setCurrentDirection(direction17);
        snake0.tryToHeadRight();
        int int22 = snake0.getLength();
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test082");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        int int3 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Space space4 = snake0.getHeadSpace();
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test083");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList9 = snake4.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction10 = snake4.getCurrentDirection();
        snake0.setCurrentDirection(direction10);
        int int12 = snake0.getStartingLength();
        int int13 = snake0.getStartingLength();
        snake0.tryToHeadLeft();
        snake0.tryToHeadRight();
        int int16 = snake0.getLength();
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test084");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction3 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake0.getCurrentDirection();
        snake0.tryToHeadRight();
        snake0.step();
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test085");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction3 = snake0.getCurrentDirection();
        int int4 = snake0.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList5 = snake0.getSnakeSpaces();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Space space7 = snake0.getHeadSpace();
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test086");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        java.lang.Class<?> wildcardClass17 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Space space22 = snake0.getHeadSpace();
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test087");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake5 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake5.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction7 = snake5.getCurrentDirection();
        snake5.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake9 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake9.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction11 = snake9.getCurrentDirection();
        snake9.tryToHeadDown();
        int int13 = snake9.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList14 = snake9.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction15 = snake9.getCurrentDirection();
        snake5.setCurrentDirection(direction15);
        snake0.setNextStepDirection(direction15);
        uk.co.lrnk.self_esteem_snake.Space space18 = snake0.getHeadSpace();
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test088");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        java.lang.Class<?> wildcardClass3 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake0.getNextStepDirection();
        java.lang.Class<?> wildcardClass5 = snake0.getClass();
        int int6 = snake0.getStartingLength();
        snake0.step();
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test089");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getCurrentDirection();
        snake0.tryToHeadUp();
        snake0.step();
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test090");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass3 = snake2.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake8 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake8.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction10 = snake8.getCurrentDirection();
        snake8.tryToHeadDown();
        int int12 = snake8.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList13 = snake8.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction14 = snake8.getCurrentDirection();
        snake4.setCurrentDirection(direction14);
        snake2.setNextStepDirection(direction14);
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake2.getCurrentDirection();
        snake0.setNextStepDirection(direction17);
        uk.co.lrnk.self_esteem_snake.Space space19 = snake0.getHeadSpace();
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test091");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        snake0.tryToHeadDown();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList3 = snake0.getSnakeSpaces();
        int int4 = snake0.getLength();
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test092");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList9 = snake4.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction10 = snake4.getCurrentDirection();
        snake0.setCurrentDirection(direction10);
        java.lang.Class<?> wildcardClass12 = snake0.getClass();
        int int13 = snake0.getLength();
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test093");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList5 = snake0.getSnakeSpaces();
        snake0.tryToHeadLeft();
        int int7 = snake0.getLength();
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test094");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake5 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake5.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction7 = snake5.getCurrentDirection();
        snake5.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake9 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake9.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction11 = snake9.getCurrentDirection();
        snake9.tryToHeadDown();
        int int13 = snake9.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList14 = snake9.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction15 = snake9.getCurrentDirection();
        snake5.setCurrentDirection(direction15);
        snake0.setNextStepDirection(direction15);
        snake0.tryToHeadDown();
        int int19 = snake0.getLength();
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test095");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction3 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        snake0.step();
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test096");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake5 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake5.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction7 = snake5.getCurrentDirection();
        snake5.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake9 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake9.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction11 = snake9.getCurrentDirection();
        snake9.tryToHeadDown();
        int int13 = snake9.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList14 = snake9.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction15 = snake9.getCurrentDirection();
        snake5.setCurrentDirection(direction15);
        snake0.setNextStepDirection(direction15);
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getCurrentDirection();
        java.lang.Class<?> wildcardClass19 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Direction direction20 = snake0.getNextStepDirection();
        snake0.step();
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test097");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction3 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int5 = snake0.getLength();
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test098");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        int int2 = snake0.getStartingLength();
        int int3 = snake0.getStartingLength();
        snake0.tryToHeadLeft();
        snake0.tryToHeadDown();
        snake0.step();
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test099");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getCurrentDirection();
        snake0.tryToHeadUp();
        uk.co.lrnk.self_esteem_snake.Space space20 = snake0.getHeadSpace();
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test100");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        int int3 = snake0.getStartingLength();
        snake0.tryToHeadUp();
        snake0.tryToHeadLeft();
        int int6 = snake0.getLength();
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test101");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList9 = snake4.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction10 = snake4.getCurrentDirection();
        snake0.setCurrentDirection(direction10);
        java.lang.Class<?> wildcardClass12 = snake0.getClass();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Space space14 = snake0.getHeadSpace();
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test102");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getNextStepDirection();
        java.lang.Class<?> wildcardClass19 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Space space20 = snake0.getHeadSpace();
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test103");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        snake0.tryToHeadDown();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList3 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake0.getCurrentDirection();
        snake0.step();
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test104");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        snake0.tryToHeadRight();
        snake0.step();
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test105");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake5 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass6 = snake5.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake7 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake7.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction9 = snake7.getCurrentDirection();
        snake7.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake11 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake11.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction13 = snake11.getCurrentDirection();
        snake11.tryToHeadDown();
        int int15 = snake11.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList16 = snake11.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake11.getCurrentDirection();
        snake7.setCurrentDirection(direction17);
        snake5.setNextStepDirection(direction17);
        snake5.tryToHeadRight();
        snake5.tryToHeadRight();
        java.lang.Class<?> wildcardClass22 = snake5.getClass();
        uk.co.lrnk.self_esteem_snake.Direction direction23 = snake5.getCurrentDirection();
        snake0.setCurrentDirection(direction23);
        uk.co.lrnk.self_esteem_snake.Direction direction25 = snake0.getCurrentDirection();
        snake0.tryToHeadRight();
        int int27 = snake0.getLength();
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test106");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getNextStepDirection();
        snake0.step();
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test107");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        snake0.tryToHeadDown();
        snake0.tryToHeadRight();
        int int5 = snake0.getLength();
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test108");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        snake0.tryToHeadRight();
        int int6 = snake0.getLength();
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test109");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake5 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake5.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction7 = snake5.getCurrentDirection();
        snake5.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake9 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake9.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction11 = snake9.getCurrentDirection();
        snake9.tryToHeadDown();
        int int13 = snake9.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList14 = snake9.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction15 = snake9.getCurrentDirection();
        snake5.setCurrentDirection(direction15);
        snake0.setNextStepDirection(direction15);
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getCurrentDirection();
        java.lang.Class<?> wildcardClass19 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Direction direction20 = snake0.getNextStepDirection();
        int int21 = snake0.getLength();
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test110");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList9 = snake4.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction10 = snake4.getCurrentDirection();
        snake0.setCurrentDirection(direction10);
        java.lang.Class<?> wildcardClass12 = snake0.getClass();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction14 = snake0.getNextStepDirection();
        snake0.tryToHeadUp();
        uk.co.lrnk.self_esteem_snake.Space space16 = snake0.getHeadSpace();
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test111");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getNextStepDirection();
        java.lang.Class<?> wildcardClass6 = snake0.getClass();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Space space8 = snake0.getHeadSpace();
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test112");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        int int2 = snake0.getStartingLength();
        int int3 = snake0.getStartingLength();
        snake0.step();
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test113");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getNextStepDirection();
        snake0.tryToHeadRight();
        snake0.step();
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test114");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        int int7 = snake0.getLength();
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test115");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Space space6 = snake0.getHeadSpace();
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test116");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        snake0.tryToHeadUp();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Direction direction20 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Space space21 = snake0.getHeadSpace();
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test117");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction3 = snake0.getCurrentDirection();
        int int4 = snake0.getStartingLength();
        snake0.tryToHeadDown();
        snake0.step();
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test118");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getNextStepDirection();
        snake0.step();
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test119");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        snake0.tryToHeadDown();
        snake0.tryToHeadUp();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList4 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Space space5 = snake0.getHeadSpace();
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test120");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getCurrentDirection();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList6 = snake0.getSnakeSpaces();
        snake0.tryToHeadDown();
        snake0.step();
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test121");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        int int3 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction9 = snake4.getCurrentDirection();
        snake0.setNextStepDirection(direction9);
        snake0.tryToHeadRight();
        snake0.tryToHeadLeft();
        int int13 = snake0.getLength();
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test122");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        snake0.step();
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test123");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        int int3 = snake0.getStartingLength();
        snake0.tryToHeadLeft();
        int int5 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Space space6 = snake0.getHeadSpace();
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test124");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        int int2 = snake0.getStartingLength();
        int int3 = snake0.getLength();
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test125");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        int int3 = snake0.getStartingLength();
        snake0.tryToHeadDown();
        snake0.tryToHeadRight();
        snake0.step();
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test126");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        snake0.tryToHeadRight();
        int int19 = snake0.getLength();
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test127");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getNextStepDirection();
        snake0.tryToHeadLeft();
        snake0.tryToHeadUp();
        uk.co.lrnk.self_esteem_snake.Space space21 = snake0.getHeadSpace();
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test128");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass3 = snake2.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake8 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake8.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction10 = snake8.getCurrentDirection();
        snake8.tryToHeadDown();
        int int12 = snake8.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList13 = snake8.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction14 = snake8.getCurrentDirection();
        snake4.setCurrentDirection(direction14);
        snake2.setNextStepDirection(direction14);
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake2.getCurrentDirection();
        snake0.setNextStepDirection(direction17);
        java.lang.Class<?> wildcardClass19 = snake0.getClass();
        snake0.tryToHeadLeft();
        int int21 = snake0.getLength();
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test129");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction16 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Space space17 = snake0.getHeadSpace();
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test130");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        java.lang.Class<?> wildcardClass17 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        snake0.step();
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test131");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        java.lang.Class<?> wildcardClass16 = snake0.getClass();
        java.lang.Class<?> wildcardClass17 = snake0.getClass();
        java.lang.Class<?> wildcardClass18 = snake0.getClass();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction20 = snake0.getCurrentDirection();
        snake0.step();
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test132");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        uk.co.lrnk.self_esteem_snake.Direction direction15 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction16 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Space space17 = snake0.getHeadSpace();
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test133");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getNextStepDirection();
        java.lang.Class<?> wildcardClass19 = snake0.getClass();
        snake0.tryToHeadUp();
        snake0.step();
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test134");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList9 = snake4.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction10 = snake4.getCurrentDirection();
        snake0.setCurrentDirection(direction10);
        int int12 = snake0.getStartingLength();
        snake0.tryToHeadLeft();
        int int14 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Space space15 = snake0.getHeadSpace();
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test135");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getCurrentDirection();
        snake0.tryToHeadRight();
        int int20 = snake0.getLength();
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test136");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass7 = snake6.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake8 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake8.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction10 = snake8.getCurrentDirection();
        snake8.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake12 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake12.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction14 = snake12.getCurrentDirection();
        snake12.tryToHeadDown();
        int int16 = snake12.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList17 = snake12.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake12.getCurrentDirection();
        snake8.setCurrentDirection(direction18);
        snake6.setNextStepDirection(direction18);
        snake6.tryToHeadRight();
        snake6.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction23 = snake6.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction24 = snake6.getNextStepDirection();
        snake0.setNextStepDirection(direction24);
        int int26 = snake0.getLength();
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test137");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake5 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake5.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction7 = snake5.getCurrentDirection();
        snake5.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake9 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake9.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction11 = snake9.getCurrentDirection();
        snake9.tryToHeadDown();
        int int13 = snake9.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList14 = snake9.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction15 = snake9.getCurrentDirection();
        snake5.setCurrentDirection(direction15);
        snake0.setNextStepDirection(direction15);
        snake0.tryToHeadDown();
        java.lang.Class<?> wildcardClass19 = snake0.getClass();
        snake0.tryToHeadLeft();
        snake0.tryToHeadLeft();
        int int22 = snake0.getLength();
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test138");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        int int2 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction3 = snake0.getCurrentDirection();
        java.lang.Class<?> wildcardClass4 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Space space6 = snake0.getHeadSpace();
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test139");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        snake0.step();
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test140");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        snake0.tryToHeadUp();
        snake0.tryToHeadLeft();
        int int20 = snake0.getLength();
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test141");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction3 = snake0.getCurrentDirection();
        int int4 = snake0.getLength();
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test142");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getNextStepDirection();
        int int19 = snake0.getStartingLength();
        java.lang.Class<?> wildcardClass20 = snake0.getClass();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList21 = snake0.getSnakeSpaces();
        snake0.step();
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test143");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        int int3 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        snake0.tryToHeadRight();
        int int7 = snake0.getStartingLength();
        int int8 = snake0.getLength();
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test144");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        snake0.tryToHeadUp();
        int int5 = snake0.getStartingLength();
        int int6 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Space space7 = snake0.getHeadSpace();
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test145");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        snake0.tryToHeadUp();
        int int4 = snake0.getLength();
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test146");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        java.lang.Class<?> wildcardClass3 = snake0.getClass();
        int int4 = snake0.getLength();
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test147");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getNextStepDirection();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction19 = snake0.getNextStepDirection();
        int int20 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Space space21 = snake0.getHeadSpace();
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test148");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake5 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass6 = snake5.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake7 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake7.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction9 = snake7.getCurrentDirection();
        snake7.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake11 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake11.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction13 = snake11.getCurrentDirection();
        snake11.tryToHeadDown();
        int int15 = snake11.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList16 = snake11.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake11.getCurrentDirection();
        snake7.setCurrentDirection(direction17);
        snake5.setNextStepDirection(direction17);
        snake5.tryToHeadRight();
        snake5.tryToHeadRight();
        java.lang.Class<?> wildcardClass22 = snake5.getClass();
        uk.co.lrnk.self_esteem_snake.Direction direction23 = snake5.getCurrentDirection();
        snake0.setCurrentDirection(direction23);
        uk.co.lrnk.self_esteem_snake.Direction direction25 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction26 = snake0.getNextStepDirection();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList27 = snake0.getSnakeSpaces();
        snake0.step();
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test149");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake0.getCurrentDirection();
        int int5 = snake0.getLength();
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test150");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        int int3 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction9 = snake4.getCurrentDirection();
        snake0.setNextStepDirection(direction9);
        uk.co.lrnk.self_esteem_snake.Direction direction11 = snake0.getNextStepDirection();
        int int12 = snake0.getStartingLength();
        int int13 = snake0.getLength();
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test151");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        snake0.tryToHeadLeft();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Space space19 = snake0.getHeadSpace();
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test152");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction3 = snake0.getCurrentDirection();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList4 = snake0.getSnakeSpaces();
        snake0.step();
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test153");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction3 = snake0.getCurrentDirection();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getNextStepDirection();
        snake0.tryToHeadRight();
        int int7 = snake0.getStartingLength();
        snake0.step();
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test154");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        snake0.tryToHeadRight();
        snake0.tryToHeadUp();
        int int5 = snake0.getLength();
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test155");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Space space5 = snake0.getHeadSpace();
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test156");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        snake0.tryToHeadLeft();
        snake0.tryToHeadLeft();
        snake0.tryToHeadUp();
        snake0.tryToHeadUp();
        uk.co.lrnk.self_esteem_snake.Space space7 = snake0.getHeadSpace();
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test157");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        int int3 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction9 = snake4.getCurrentDirection();
        snake0.setNextStepDirection(direction9);
        int int11 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Space space12 = snake0.getHeadSpace();
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test158");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getCurrentDirection();
        int int18 = snake0.getLength();
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test159");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake5 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake5.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction7 = snake5.getCurrentDirection();
        snake5.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake9 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake9.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction11 = snake9.getCurrentDirection();
        snake9.tryToHeadDown();
        int int13 = snake9.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList14 = snake9.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction15 = snake9.getCurrentDirection();
        snake5.setCurrentDirection(direction15);
        snake0.setNextStepDirection(direction15);
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getNextStepDirection();
        int int19 = snake0.getLength();
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test160");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        snake0.tryToHeadDown();
        snake0.tryToHeadUp();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake0.getNextStepDirection();
        snake0.tryToHeadRight();
        snake0.step();
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test161");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        int int6 = snake2.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake7 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake7.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction9 = snake7.getCurrentDirection();
        snake7.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake11 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake11.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction13 = snake11.getCurrentDirection();
        snake11.tryToHeadDown();
        int int15 = snake11.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList16 = snake11.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake11.getCurrentDirection();
        snake7.setCurrentDirection(direction17);
        snake2.setNextStepDirection(direction17);
        snake0.setCurrentDirection(direction17);
        snake0.tryToHeadRight();
        snake0.step();
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test162");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake5 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass6 = snake5.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake7 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake7.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction9 = snake7.getCurrentDirection();
        snake7.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake11 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake11.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction13 = snake11.getCurrentDirection();
        snake11.tryToHeadDown();
        int int15 = snake11.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList16 = snake11.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake11.getCurrentDirection();
        snake7.setCurrentDirection(direction17);
        snake5.setNextStepDirection(direction17);
        snake5.tryToHeadRight();
        snake5.tryToHeadRight();
        java.lang.Class<?> wildcardClass22 = snake5.getClass();
        uk.co.lrnk.self_esteem_snake.Direction direction23 = snake5.getCurrentDirection();
        snake0.setCurrentDirection(direction23);
        uk.co.lrnk.self_esteem_snake.Space space25 = snake0.getHeadSpace();
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test163");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList5 = snake0.getSnakeSpaces();
        snake0.tryToHeadLeft();
        snake0.tryToHeadLeft();
        snake0.tryToHeadUp();
        uk.co.lrnk.self_esteem_snake.Space space9 = snake0.getHeadSpace();
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test164");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        snake0.tryToHeadDown();
        snake0.tryToHeadUp();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake0.getNextStepDirection();
        snake0.tryToHeadRight();
        int int6 = snake0.getLength();
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test165");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction3 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake0.getCurrentDirection();
        snake0.tryToHeadRight();
        int int6 = snake0.getLength();
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test166");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getCurrentDirection();
        snake0.tryToHeadUp();
        uk.co.lrnk.self_esteem_snake.Direction direction19 = snake0.getNextStepDirection();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList20 = snake0.getSnakeSpaces();
        int int21 = snake0.getLength();
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test167");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        int int2 = snake0.getStartingLength();
        snake0.tryToHeadLeft();
        snake0.step();
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test168");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getNextStepDirection();
        int int19 = snake0.getStartingLength();
        java.lang.Class<?> wildcardClass20 = snake0.getClass();
        snake0.tryToHeadLeft();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Space space23 = snake0.getHeadSpace();
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test169");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList9 = snake4.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction10 = snake4.getCurrentDirection();
        snake0.setCurrentDirection(direction10);
        uk.co.lrnk.self_esteem_snake.Space space12 = snake0.getHeadSpace();
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test170");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getNextStepDirection();
        snake0.tryToHeadLeft();
        snake0.tryToHeadUp();
        int int21 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Space space22 = snake0.getHeadSpace();
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test171");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadRight();
        int int4 = snake0.getLength();
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test172");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction3 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake0.getCurrentDirection();
        int int5 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake0.getCurrentDirection();
        int int7 = snake0.getLength();
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test173");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList9 = snake4.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction10 = snake4.getCurrentDirection();
        snake0.setCurrentDirection(direction10);
        int int12 = snake0.getStartingLength();
        int int13 = snake0.getStartingLength();
        snake0.tryToHeadDown();
        snake0.tryToHeadRight();
        int int16 = snake0.getLength();
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test174");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getNextStepDirection();
        int int19 = snake0.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList20 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction21 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Space space22 = snake0.getHeadSpace();
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test175");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList9 = snake4.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction10 = snake4.getCurrentDirection();
        snake0.setCurrentDirection(direction10);
        java.lang.Class<?> wildcardClass12 = snake0.getClass();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction14 = snake0.getNextStepDirection();
        snake0.tryToHeadLeft();
        snake0.step();
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test176");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getNextStepDirection();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction19 = snake0.getNextStepDirection();
        int int20 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction21 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Space space22 = snake0.getHeadSpace();
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test177");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList5 = snake0.getSnakeSpaces();
        int int6 = snake0.getLength();
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test178");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake5 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake5.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction7 = snake5.getCurrentDirection();
        snake5.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake9 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake9.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction11 = snake9.getCurrentDirection();
        snake9.tryToHeadDown();
        int int13 = snake9.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList14 = snake9.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction15 = snake9.getCurrentDirection();
        snake5.setCurrentDirection(direction15);
        snake0.setNextStepDirection(direction15);
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getCurrentDirection();
        java.lang.Class<?> wildcardClass19 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Direction direction20 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction21 = snake0.getCurrentDirection();
        snake0.tryToHeadUp();
        snake0.step();
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test179");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList3 = snake0.getSnakeSpaces();
        int int4 = snake0.getLength();
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test180");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getNextStepDirection();
        java.lang.Class<?> wildcardClass6 = snake0.getClass();
        snake0.tryToHeadLeft();
        java.lang.Class<?> wildcardClass8 = snake0.getClass();
        java.lang.Class<?> wildcardClass9 = snake0.getClass();
        snake0.step();
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test181");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction3 = snake0.getCurrentDirection();
        int int4 = snake0.getStartingLength();
        java.lang.Class<?> wildcardClass5 = snake0.getClass();
        snake0.tryToHeadRight();
        snake0.tryToHeadUp();
        snake0.step();
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test182");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        snake0.tryToHeadUp();
        uk.co.lrnk.self_esteem_snake.Space space4 = snake0.getHeadSpace();
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test183");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Space space5 = snake0.getHeadSpace();
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test184");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction3 = snake0.getCurrentDirection();
        int int4 = snake0.getStartingLength();
        java.lang.Class<?> wildcardClass5 = snake0.getClass();
        int int6 = snake0.getStartingLength();
        snake0.tryToHeadUp();
        int int8 = snake0.getLength();
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test185");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getNextStepDirection();
        snake0.tryToHeadLeft();
        snake0.tryToHeadUp();
        int int21 = snake0.getStartingLength();
        snake0.step();
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test186");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        snake0.tryToHeadDown();
        snake0.tryToHeadUp();
        int int4 = snake0.getStartingLength();
        java.lang.Class<?> wildcardClass5 = snake0.getClass();
        snake0.step();
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test187");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction3 = snake0.getCurrentDirection();
        java.lang.Class<?> wildcardClass4 = snake0.getClass();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList5 = snake0.getSnakeSpaces();
        int int6 = snake0.getLength();
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test188");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake0.getCurrentDirection();
        int int5 = snake0.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList6 = snake0.getSnakeSpaces();
        int int7 = snake0.getLength();
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test189");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getNextStepDirection();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction20 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Space space21 = snake0.getHeadSpace();
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test190");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList9 = snake4.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction10 = snake4.getCurrentDirection();
        snake0.setCurrentDirection(direction10);
        java.lang.Class<?> wildcardClass12 = snake0.getClass();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction14 = snake0.getNextStepDirection();
        snake0.tryToHeadUp();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Space space17 = snake0.getHeadSpace();
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test191");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        java.lang.Class<?> wildcardClass17 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getNextStepDirection();
        snake0.tryToHeadLeft();
        int int20 = snake0.getLength();
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test192");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake5 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake5.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction7 = snake5.getCurrentDirection();
        snake5.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake9 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake9.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction11 = snake9.getCurrentDirection();
        snake9.tryToHeadDown();
        int int13 = snake9.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList14 = snake9.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction15 = snake9.getCurrentDirection();
        snake5.setCurrentDirection(direction15);
        snake0.setNextStepDirection(direction15);
        snake0.tryToHeadDown();
        java.lang.Class<?> wildcardClass19 = snake0.getClass();
        snake0.tryToHeadLeft();
        snake0.tryToHeadLeft();
        snake0.tryToHeadDown();
        snake0.step();
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test193");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        int int2 = snake0.getStartingLength();
        int int3 = snake0.getStartingLength();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getCurrentDirection();
        snake0.step();
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test194");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake5 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake5.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction7 = snake5.getCurrentDirection();
        snake5.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake9 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake9.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction11 = snake9.getCurrentDirection();
        snake9.tryToHeadDown();
        int int13 = snake9.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList14 = snake9.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction15 = snake9.getCurrentDirection();
        snake5.setCurrentDirection(direction15);
        snake0.setNextStepDirection(direction15);
        snake0.tryToHeadDown();
        java.lang.Class<?> wildcardClass19 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Direction direction20 = snake0.getNextStepDirection();
        snake0.step();
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test195");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        snake0.tryToHeadUp();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList19 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Space space20 = snake0.getHeadSpace();
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test196");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        int int3 = snake0.getStartingLength();
        snake0.tryToHeadLeft();
        int int5 = snake0.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList6 = snake0.getSnakeSpaces();
        snake0.step();
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test197");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        snake0.tryToHeadDown();
        snake0.step();
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test198");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake5 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake5.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction7 = snake5.getCurrentDirection();
        snake5.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake9 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake9.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction11 = snake9.getCurrentDirection();
        snake9.tryToHeadDown();
        int int13 = snake9.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList14 = snake9.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction15 = snake9.getCurrentDirection();
        snake5.setCurrentDirection(direction15);
        snake0.setNextStepDirection(direction15);
        snake0.tryToHeadDown();
        java.lang.Class<?> wildcardClass19 = snake0.getClass();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Direction direction21 = snake0.getNextStepDirection();
        int int22 = snake0.getLength();
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test199");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getNextStepDirection();
        int int19 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction20 = snake0.getCurrentDirection();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList21 = snake0.getSnakeSpaces();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Space space23 = snake0.getHeadSpace();
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test200");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        snake0.tryToHeadDown();
        snake0.tryToHeadUp();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList4 = snake0.getSnakeSpaces();
        snake0.step();
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test201");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getNextStepDirection();
        snake0.tryToHeadLeft();
        snake0.tryToHeadUp();
        snake0.tryToHeadRight();
        snake0.step();
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test202");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList9 = snake4.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction10 = snake4.getCurrentDirection();
        snake0.setCurrentDirection(direction10);
        java.lang.Class<?> wildcardClass12 = snake0.getClass();
        int int13 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Space space14 = snake0.getHeadSpace();
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test203");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        snake0.tryToHeadDown();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList3 = snake0.getSnakeSpaces();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Space space6 = snake0.getHeadSpace();
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test204");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        int int3 = snake0.getStartingLength();
        snake0.step();
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test205");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake5 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass6 = snake5.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake7 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake7.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction9 = snake7.getCurrentDirection();
        snake7.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake11 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake11.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction13 = snake11.getCurrentDirection();
        snake11.tryToHeadDown();
        int int15 = snake11.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList16 = snake11.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake11.getCurrentDirection();
        snake7.setCurrentDirection(direction17);
        snake5.setNextStepDirection(direction17);
        snake5.tryToHeadRight();
        snake5.tryToHeadRight();
        java.lang.Class<?> wildcardClass22 = snake5.getClass();
        uk.co.lrnk.self_esteem_snake.Direction direction23 = snake5.getCurrentDirection();
        snake0.setCurrentDirection(direction23);
        uk.co.lrnk.self_esteem_snake.Direction direction25 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction26 = snake0.getNextStepDirection();
        snake0.step();
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test206");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction3 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        snake0.step();
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test207");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getNextStepDirection();
        int int19 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction20 = snake0.getCurrentDirection();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList21 = snake0.getSnakeSpaces();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Direction direction23 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Space space24 = snake0.getHeadSpace();
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test208");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake0.getCurrentDirection();
        java.lang.Class<?> wildcardClass7 = snake0.getClass();
        snake0.tryToHeadLeft();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Space space10 = snake0.getHeadSpace();
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test209");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        snake0.tryToHeadDown();
        snake0.tryToHeadDown();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Space space5 = snake0.getHeadSpace();
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test210");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        java.lang.Class<?> wildcardClass3 = snake0.getClass();
        snake0.tryToHeadDown();
        snake0.step();
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test211");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        snake0.tryToHeadDown();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass5 = snake4.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake10 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake10.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake10.getCurrentDirection();
        snake10.tryToHeadDown();
        int int14 = snake10.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList15 = snake10.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction16 = snake10.getCurrentDirection();
        snake6.setCurrentDirection(direction16);
        snake4.setNextStepDirection(direction16);
        snake4.tryToHeadRight();
        snake4.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction21 = snake4.getCurrentDirection();
        snake0.setNextStepDirection(direction21);
        uk.co.lrnk.self_esteem_snake.Space space23 = snake0.getHeadSpace();
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test212");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        java.lang.Class<?> wildcardClass17 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Snake snake21 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake21.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction23 = snake21.getCurrentDirection();
        snake21.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake25 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake25.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction27 = snake25.getCurrentDirection();
        snake25.tryToHeadDown();
        int int29 = snake25.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList30 = snake25.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction31 = snake25.getCurrentDirection();
        snake21.setCurrentDirection(direction31);
        java.lang.Class<?> wildcardClass33 = snake21.getClass();
        snake21.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction35 = snake21.getNextStepDirection();
        snake0.setCurrentDirection(direction35);
        snake0.step();
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test213");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList9 = snake4.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction10 = snake4.getCurrentDirection();
        snake0.setCurrentDirection(direction10);
        int int12 = snake0.getStartingLength();
        int int13 = snake0.getStartingLength();
        snake0.tryToHeadLeft();
        snake0.tryToHeadRight();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList16 = snake0.getSnakeSpaces();
        snake0.step();
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test214");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        int int3 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Space space5 = snake0.getHeadSpace();
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test215");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        snake0.tryToHeadUp();
        int int5 = snake0.getLength();
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test216");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList9 = snake4.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction10 = snake4.getCurrentDirection();
        snake0.setCurrentDirection(direction10);
        java.lang.Class<?> wildcardClass12 = snake0.getClass();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction14 = snake0.getNextStepDirection();
        snake0.tryToHeadUp();
        snake0.tryToHeadDown();
        snake0.tryToHeadLeft();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Space space19 = snake0.getHeadSpace();
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test217");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        int int2 = snake0.getStartingLength();
        int int3 = snake0.getStartingLength();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList5 = snake0.getSnakeSpaces();
        snake0.step();
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test218");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake0.getCurrentDirection();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Space space8 = snake0.getHeadSpace();
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test219");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        int int5 = snake0.getStartingLength();
        java.lang.Class<?> wildcardClass6 = snake0.getClass();
        snake0.tryToHeadDown();
        snake0.step();
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test220");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        int int3 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction9 = snake4.getCurrentDirection();
        snake0.setNextStepDirection(direction9);
        snake0.tryToHeadRight();
        snake0.tryToHeadUp();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Space space14 = snake0.getHeadSpace();
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test221");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList5 = snake0.getSnakeSpaces();
        snake0.tryToHeadLeft();
        snake0.tryToHeadLeft();
        snake0.tryToHeadDown();
        snake0.tryToHeadRight();
        int int10 = snake0.getLength();
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test222");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getNextStepDirection();
        java.lang.Class<?> wildcardClass19 = snake0.getClass();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList21 = snake0.getSnakeSpaces();
        snake0.tryToHeadUp();
        java.lang.Class<?> wildcardClass23 = snake0.getClass();
        snake0.step();
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test223");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadUp();
        snake0.step();
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test224");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getNextStepDirection();
        java.lang.Class<?> wildcardClass19 = snake0.getClass();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList21 = snake0.getSnakeSpaces();
        snake0.tryToHeadUp();
        uk.co.lrnk.self_esteem_snake.Space space23 = snake0.getHeadSpace();
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test225");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        snake0.tryToHeadRight();
        snake0.tryToHeadUp();
        snake0.tryToHeadRight();
        snake0.tryToHeadUp();
        int int7 = snake0.getLength();
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test226");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getNextStepDirection();
        snake0.tryToHeadLeft();
        snake0.tryToHeadRight();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList8 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction9 = snake0.getCurrentDirection();
        snake0.step();
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test227");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        snake0.tryToHeadRight();
        snake0.step();
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test228");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        int int2 = snake0.getStartingLength();
        java.lang.Class<?> wildcardClass3 = snake0.getClass();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList4 = snake0.getSnakeSpaces();
        int int5 = snake0.getLength();
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test229");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        java.lang.Class<?> wildcardClass16 = snake0.getClass();
        java.lang.Class<?> wildcardClass17 = snake0.getClass();
        int int18 = snake0.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList19 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Space space20 = snake0.getHeadSpace();
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test230");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        java.lang.Class<?> wildcardClass16 = snake0.getClass();
        java.lang.Class<?> wildcardClass17 = snake0.getClass();
        java.lang.Class<?> wildcardClass18 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Direction direction19 = snake0.getNextStepDirection();
        snake0.tryToHeadUp();
        snake0.step();
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test231");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        int int2 = snake0.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList3 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake0.getNextStepDirection();
        java.lang.Class<?> wildcardClass5 = snake0.getClass();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList6 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Space space7 = snake0.getHeadSpace();
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test232");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction19 = snake0.getCurrentDirection();
        int int20 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Space space21 = snake0.getHeadSpace();
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test233");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        java.lang.Class<?> wildcardClass3 = snake0.getClass();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Space space5 = snake0.getHeadSpace();
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test234");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        java.lang.Class<?> wildcardClass3 = snake0.getClass();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList5 = snake0.getSnakeSpaces();
        snake0.step();
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test235");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass3 = snake2.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake8 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake8.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction10 = snake8.getCurrentDirection();
        snake8.tryToHeadDown();
        int int12 = snake8.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList13 = snake8.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction14 = snake8.getCurrentDirection();
        snake4.setCurrentDirection(direction14);
        snake2.setNextStepDirection(direction14);
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake2.getCurrentDirection();
        snake0.setNextStepDirection(direction17);
        java.lang.Class<?> wildcardClass19 = snake0.getClass();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction21 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction22 = snake0.getNextStepDirection();
        int int23 = snake0.getLength();
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test236");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList5 = snake0.getSnakeSpaces();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Space space7 = snake0.getHeadSpace();
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test237");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList9 = snake4.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction10 = snake4.getCurrentDirection();
        snake0.setCurrentDirection(direction10);
        int int12 = snake0.getStartingLength();
        snake0.tryToHeadDown();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList14 = snake0.getSnakeSpaces();
        snake0.step();
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test238");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        snake0.tryToHeadDown();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList3 = snake0.getSnakeSpaces();
        snake0.step();
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test239");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake0.getCurrentDirection();
        java.lang.Class<?> wildcardClass7 = snake0.getClass();
        snake0.tryToHeadLeft();
        int int9 = snake0.getLength();
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test240");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction3 = snake0.getCurrentDirection();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getNextStepDirection();
        snake0.tryToHeadRight();
        snake0.step();
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test241");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getCurrentDirection();
        snake0.tryToHeadRight();
        snake0.step();
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test242");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction3 = snake0.getCurrentDirection();
        int int4 = snake0.getStartingLength();
        java.lang.Class<?> wildcardClass5 = snake0.getClass();
        int int6 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Space space7 = snake0.getHeadSpace();
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test243");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList9 = snake4.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction10 = snake4.getCurrentDirection();
        snake0.setCurrentDirection(direction10);
        int int12 = snake0.getStartingLength();
        snake0.tryToHeadDown();
        int int14 = snake0.getStartingLength();
        snake0.tryToHeadUp();
        int int16 = snake0.getLength();
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test244");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        int int3 = snake0.getStartingLength();
        snake0.tryToHeadLeft();
        int int5 = snake0.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList6 = snake0.getSnakeSpaces();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList7 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Space space8 = snake0.getHeadSpace();
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test245");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction3 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        snake0.tryToHeadUp();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction7 = snake0.getNextStepDirection();
        snake0.step();
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test246");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getNextStepDirection();
        java.lang.Class<?> wildcardClass6 = snake0.getClass();
        snake0.tryToHeadLeft();
        java.lang.Class<?> wildcardClass8 = snake0.getClass();
        java.lang.Class<?> wildcardClass9 = snake0.getClass();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList10 = snake0.getSnakeSpaces();
        snake0.step();
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test247");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        snake0.tryToHeadRight();
        snake0.tryToHeadUp();
        snake0.tryToHeadUp();
        snake0.step();
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test248");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getCurrentDirection();
        snake0.tryToHeadRight();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList20 = snake0.getSnakeSpaces();
        int int21 = snake0.getLength();
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test249");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake5 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake5.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction7 = snake5.getCurrentDirection();
        snake5.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake9 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake9.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction11 = snake9.getCurrentDirection();
        snake9.tryToHeadDown();
        int int13 = snake9.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList14 = snake9.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction15 = snake9.getCurrentDirection();
        snake5.setCurrentDirection(direction15);
        snake0.setNextStepDirection(direction15);
        snake0.tryToHeadDown();
        int int19 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Space space20 = snake0.getHeadSpace();
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test250");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction3 = snake0.getCurrentDirection();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getNextStepDirection();
        int int6 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Space space7 = snake0.getHeadSpace();
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test251");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        snake0.tryToHeadDown();
        snake0.tryToHeadUp();
        snake0.tryToHeadLeft();
        snake0.tryToHeadRight();
        int int6 = snake0.getLength();
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test252");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getNextStepDirection();
        int int19 = snake0.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList20 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Snake snake21 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake21.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList23 = snake21.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction24 = snake21.getCurrentDirection();
        int int25 = snake21.getStartingLength();
        java.lang.Class<?> wildcardClass26 = snake21.getClass();
        int int27 = snake21.getStartingLength();
        snake21.tryToHeadUp();
        uk.co.lrnk.self_esteem_snake.Direction direction29 = snake21.getNextStepDirection();
        snake0.setCurrentDirection(direction29);
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Space space32 = snake0.getHeadSpace();
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test253");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction18 = snake0.getNextStepDirection();
        int int19 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction20 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction21 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Space space22 = snake0.getHeadSpace();
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test254");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getNextStepDirection();
        int int6 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction7 = snake0.getCurrentDirection();
        snake0.tryToHeadUp();
        uk.co.lrnk.self_esteem_snake.Space space9 = snake0.getHeadSpace();
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test255");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        java.lang.Class<?> wildcardClass3 = snake0.getClass();
        java.lang.Class<?> wildcardClass4 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getCurrentDirection();
        snake0.step();
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test256");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        snake0.tryToHeadLeft();
        int int3 = snake0.getLength();
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test257");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        java.lang.Class<?> wildcardClass16 = snake0.getClass();
        java.lang.Class<?> wildcardClass17 = snake0.getClass();
        java.lang.Class<?> wildcardClass18 = snake0.getClass();
        snake0.tryToHeadLeft();
        int int20 = snake0.getLength();
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test258");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake5 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake5.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction7 = snake5.getCurrentDirection();
        snake5.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake9 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake9.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction11 = snake9.getCurrentDirection();
        snake9.tryToHeadDown();
        int int13 = snake9.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList14 = snake9.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction15 = snake9.getCurrentDirection();
        snake5.setCurrentDirection(direction15);
        snake0.setNextStepDirection(direction15);
        snake0.tryToHeadDown();
        java.lang.Class<?> wildcardClass19 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Direction direction20 = snake0.getNextStepDirection();
        int int21 = snake0.getLength();
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test259");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        snake0.tryToHeadDown();
        int int4 = snake0.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList5 = snake0.getSnakeSpaces();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList6 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Space space7 = snake0.getHeadSpace();
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test260");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadRight();
        snake0.tryToHeadDown();
        int int3 = snake0.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Snake snake4 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake4.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction6 = snake4.getCurrentDirection();
        snake4.tryToHeadDown();
        int int8 = snake4.getStartingLength();
        uk.co.lrnk.self_esteem_snake.Direction direction9 = snake4.getCurrentDirection();
        snake0.setNextStepDirection(direction9);
        snake0.tryToHeadRight();
        snake0.tryToHeadUp();
        uk.co.lrnk.self_esteem_snake.Space space13 = snake0.getHeadSpace();
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test261");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction2 = snake0.getCurrentDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction3 = snake0.getCurrentDirection();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList4 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction5 = snake0.getNextStepDirection();
        snake0.tryToHeadRight();
        int int7 = snake0.getLength();
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test262");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        snake0.tryToHeadDown();
        snake0.tryToHeadUp();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList4 = snake0.getSnakeSpaces();
        snake0.tryToHeadUp();
        snake0.tryToHeadDown();
        int int7 = snake0.getLength();
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test263");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getCurrentDirection();
        snake0.tryToHeadUp();
        uk.co.lrnk.self_esteem_snake.Space space19 = snake0.getHeadSpace();
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test264");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake0.tryToHeadLeft();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList2 = snake0.getSnakeSpaces();
        int int3 = snake0.getStartingLength();
        snake0.tryToHeadLeft();
        int int5 = snake0.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList6 = snake0.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Snake snake7 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake7.tryToHeadLeft();
        int int9 = snake7.getStartingLength();
        int int10 = snake7.getStartingLength();
        snake7.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake7.getNextStepDirection();
        snake0.setNextStepDirection(direction12);
        uk.co.lrnk.self_esteem_snake.Space space14 = snake0.getHeadSpace();
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test265");
        uk.co.lrnk.self_esteem_snake.Snake snake0 = new uk.co.lrnk.self_esteem_snake.Snake();
        java.lang.Class<?> wildcardClass1 = snake0.getClass();
        uk.co.lrnk.self_esteem_snake.Snake snake2 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake2.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction4 = snake2.getCurrentDirection();
        snake2.tryToHeadDown();
        uk.co.lrnk.self_esteem_snake.Snake snake6 = new uk.co.lrnk.self_esteem_snake.Snake();
        snake6.tryToHeadLeft();
        uk.co.lrnk.self_esteem_snake.Direction direction8 = snake6.getCurrentDirection();
        snake6.tryToHeadDown();
        int int10 = snake6.getStartingLength();
        java.util.List<uk.co.lrnk.self_esteem_snake.Space> spaceList11 = snake6.getSnakeSpaces();
        uk.co.lrnk.self_esteem_snake.Direction direction12 = snake6.getCurrentDirection();
        snake2.setCurrentDirection(direction12);
        snake0.setNextStepDirection(direction12);
        snake0.tryToHeadRight();
        snake0.tryToHeadRight();
        uk.co.lrnk.self_esteem_snake.Direction direction17 = snake0.getCurrentDirection();
        snake0.tryToHeadUp();
        uk.co.lrnk.self_esteem_snake.Direction direction19 = snake0.getNextStepDirection();
        uk.co.lrnk.self_esteem_snake.Direction direction20 = snake0.getNextStepDirection();
        snake0.step();
    }
}

