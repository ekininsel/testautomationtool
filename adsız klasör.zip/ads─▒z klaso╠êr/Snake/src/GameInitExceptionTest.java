import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ GameInitExceptionTest0.class, GameInitExceptionTest1.class, GameInitExceptionTest2.class, GameInitExceptionTest3.class, GameInitExceptionTest4.class, GameInitExceptionTest5.class, GameInitExceptionTest6.class })
public class GameInitExceptionTest {
}

