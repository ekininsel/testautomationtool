package uk.co.lrnk.self_esteem_snake;

public class GameOverException extends RuntimeException {
}