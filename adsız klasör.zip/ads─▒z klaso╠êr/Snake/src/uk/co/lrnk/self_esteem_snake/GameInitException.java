package uk.co.lrnk.self_esteem_snake;

public class GameInitException extends RuntimeException {
    public GameInitException(String message) {
        super(message);
    }
}