package uk.co.lrnk.self_esteem_snake;

public enum Direction {
    UP,DOWN,LEFT,RIGHT
}