package uk.co.lrnk.self_esteem_snake;

public class NoNextSpaceException extends RuntimeException {
}