import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class DirectionTest0 {

    public static boolean debug = false;

    @Test
    public void test1() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test1");
        uk.co.lrnk.self_esteem_snake.Direction direction0 = uk.co.lrnk.self_esteem_snake.Direction.UP;
        org.junit.Assert.assertTrue("'" + direction0 + "' != '" + uk.co.lrnk.self_esteem_snake.Direction.UP + "'", direction0.equals(uk.co.lrnk.self_esteem_snake.Direction.UP));
    }

    @Test
    public void test2() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test2");
        uk.co.lrnk.self_esteem_snake.Direction direction0 = uk.co.lrnk.self_esteem_snake.Direction.LEFT;
        org.junit.Assert.assertTrue("'" + direction0 + "' != '" + uk.co.lrnk.self_esteem_snake.Direction.LEFT + "'", direction0.equals(uk.co.lrnk.self_esteem_snake.Direction.LEFT));
    }

    @Test
    public void test3() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test3");
        uk.co.lrnk.self_esteem_snake.Direction direction0 = uk.co.lrnk.self_esteem_snake.Direction.RIGHT;
        org.junit.Assert.assertTrue("'" + direction0 + "' != '" + uk.co.lrnk.self_esteem_snake.Direction.RIGHT + "'", direction0.equals(uk.co.lrnk.self_esteem_snake.Direction.RIGHT));
    }

    @Test
    public void test4() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test4");
        uk.co.lrnk.self_esteem_snake.Direction direction0 = uk.co.lrnk.self_esteem_snake.Direction.DOWN;
        org.junit.Assert.assertTrue("'" + direction0 + "' != '" + uk.co.lrnk.self_esteem_snake.Direction.DOWN + "'", direction0.equals(uk.co.lrnk.self_esteem_snake.Direction.DOWN));
    }
}

