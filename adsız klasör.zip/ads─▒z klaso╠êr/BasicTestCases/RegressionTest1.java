import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test0501() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0501");
        int int2 = sum.Toplama.sum(1476, 96);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1572 + "'", int2 == 1572);
    }

    @Test
    public void test0502() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0502");
        int int2 = sum.Toplama.sum(980, 2125);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3105 + "'", int2 == 3105);
    }

    @Test
    public void test0503() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0503");
        int int2 = sum.Toplama.sum(0, 107);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 107 + "'", int2 == 107);
    }

    @Test
    public void test0504() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0504");
        int int2 = sum.Toplama.sum(1772, 347);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2119 + "'", int2 == 2119);
    }

    @Test
    public void test0505() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0505");
        int int2 = sum.Toplama.sum(4521, 88);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4609 + "'", int2 == 4609);
    }

    @Test
    public void test0506() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0506");
        int int2 = sum.Toplama.sum(497, 515);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1012 + "'", int2 == 1012);
    }

    @Test
    public void test0507() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0507");
        int int2 = sum.Toplama.sum(0, 1840);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1840 + "'", int2 == 1840);
    }

    @Test
    public void test0508() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0508");
        int int2 = sum.Toplama.sum(1735, 1000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2735 + "'", int2 == 2735);
    }

    @Test
    public void test0509() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0509");
        int int2 = sum.Toplama.sum(110, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 110 + "'", int2 == 110);
    }

    @Test
    public void test0510() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0510");
        int int2 = sum.Toplama.sum((int) (byte) 10, 374);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 384 + "'", int2 == 384);
    }

    @Test
    public void test0511() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0511");
        int int2 = sum.Toplama.sum(891, 374);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1265 + "'", int2 == 1265);
    }

    @Test
    public void test0512() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0512");
        int int2 = sum.Toplama.sum(1446, 519);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1965 + "'", int2 == 1965);
    }

    @Test
    public void test0513() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0513");
        int int2 = sum.Toplama.sum(1955, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1955 + "'", int2 == 1955);
    }

    @Test
    public void test0514() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0514");
        int int2 = sum.Toplama.sum(1478, 61);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1539 + "'", int2 == 1539);
    }

    @Test
    public void test0515() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0515");
        int int2 = sum.Toplama.sum(1895, 1877);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3772 + "'", int2 == 3772);
    }

    @Test
    public void test0516() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0516");
        int int2 = sum.Toplama.sum(1083, 358);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1441 + "'", int2 == 1441);
    }

    @Test
    public void test0517() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0517");
        int int2 = sum.Toplama.sum(1095, 1719);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2814 + "'", int2 == 2814);
    }

    @Test
    public void test0518() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0518");
        int int2 = sum.Toplama.sum(411, 2150);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2561 + "'", int2 == 2561);
    }

    @Test
    public void test0519() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0519");
        int int2 = sum.Toplama.sum(2723, 2810);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5533 + "'", int2 == 5533);
    }

    @Test
    public void test0520() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0520");
        int int2 = sum.Toplama.sum(4410, 1522);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5932 + "'", int2 == 5932);
    }

    @Test
    public void test0521() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0521");
        int int2 = sum.Toplama.sum(4246, 199);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4445 + "'", int2 == 4445);
    }

    @Test
    public void test0522() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0522");
        int int2 = sum.Toplama.sum(2214, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2249 + "'", int2 == 2249);
    }

    @Test
    public void test0523() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0523");
        int int2 = sum.Toplama.sum(190, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 190 + "'", int2 == 190);
    }

    @Test
    public void test0524() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0524");
        int int2 = sum.Toplama.sum(520, 891);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1411 + "'", int2 == 1411);
    }

    @Test
    public void test0525() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0525");
        int int2 = sum.Toplama.sum(408, 1193);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1601 + "'", int2 == 1601);
    }

    @Test
    public void test0526() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0526");
        int int2 = sum.Toplama.sum(1408, 2821);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4229 + "'", int2 == 4229);
    }

    @Test
    public void test0527() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0527");
        int int2 = sum.Toplama.sum(2572, 939);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3511 + "'", int2 == 3511);
    }

    @Test
    public void test0528() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0528");
        int int2 = sum.Toplama.sum(802, 4768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5570 + "'", int2 == 5570);
    }

    @Test
    public void test0529() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0529");
        int int2 = sum.Toplama.sum(3791, 110);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3901 + "'", int2 == 3901);
    }

    @Test
    public void test0530() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0530");
        int int2 = sum.Toplama.sum(508, 809);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1317 + "'", int2 == 1317);
    }

    @Test
    public void test0531() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0531");
        int int2 = sum.Toplama.sum(1428, 9644);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11072 + "'", int2 == 11072);
    }

    @Test
    public void test0532() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0532");
        int int2 = sum.Toplama.sum(806, 1982);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2788 + "'", int2 == 2788);
    }

    @Test
    public void test0533() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0533");
        int int2 = sum.Toplama.sum(3176, 917);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4093 + "'", int2 == 4093);
    }

    @Test
    public void test0534() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0534");
        int int2 = sum.Toplama.sum(1441, 1491);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2932 + "'", int2 == 2932);
    }

    @Test
    public void test0535() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0535");
        int int2 = sum.Toplama.sum(792, 4246);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5038 + "'", int2 == 5038);
    }

    @Test
    public void test0536() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0536");
        int int2 = sum.Toplama.sum(814, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 814 + "'", int2 == 814);
    }

    @Test
    public void test0537() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0537");
        int int2 = sum.Toplama.sum(488, 2146);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2634 + "'", int2 == 2634);
    }

    @Test
    public void test0538() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0538");
        int int2 = sum.Toplama.sum(584, 96);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 680 + "'", int2 == 680);
    }

    @Test
    public void test0539() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0539");
        int int2 = sum.Toplama.sum(854, 210);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1064 + "'", int2 == 1064);
    }

    @Test
    public void test0540() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0540");
        int int2 = sum.Toplama.sum(1867, 1177);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3044 + "'", int2 == 3044);
    }

    @Test
    public void test0541() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0541");
        int int2 = sum.Toplama.sum(1648, 269);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1917 + "'", int2 == 1917);
    }

    @Test
    public void test0542() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0542");
        int int2 = sum.Toplama.sum(3527, 1255);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4782 + "'", int2 == 4782);
    }

    @Test
    public void test0543() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0543");
        int int2 = sum.Toplama.sum(1249, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1301 + "'", int2 == 1301);
    }

    @Test
    public void test0544() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0544");
        int int2 = sum.Toplama.sum(3113, 5946);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9059 + "'", int2 == 9059);
    }

    @Test
    public void test0545() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0545");
        int int2 = sum.Toplama.sum(547, 9059);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9606 + "'", int2 == 9606);
    }

    @Test
    public void test0546() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0546");
        int int2 = sum.Toplama.sum(853, 1917);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2770 + "'", int2 == 2770);
    }

    @Test
    public void test0547() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0547");
        int int2 = sum.Toplama.sum(197, 888);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1085 + "'", int2 == 1085);
    }

    @Test
    public void test0548() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0548");
        int int2 = sum.Toplama.sum(0, 261);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 261 + "'", int2 == 261);
    }

    @Test
    public void test0549() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0549");
        int int2 = sum.Toplama.sum(305, 972);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1277 + "'", int2 == 1277);
    }

    @Test
    public void test0550() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0550");
        int int2 = sum.Toplama.sum(1460, 2202);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3662 + "'", int2 == 3662);
    }

    @Test
    public void test0551() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0551");
        int int2 = sum.Toplama.sum(509, 295);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 804 + "'", int2 == 804);
    }

    @Test
    public void test0552() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0552");
        int int2 = sum.Toplama.sum(3012, 2835);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5847 + "'", int2 == 5847);
    }

    @Test
    public void test0553() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0553");
        int int2 = sum.Toplama.sum(520, 4782);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5302 + "'", int2 == 5302);
    }

    @Test
    public void test0554() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0554");
        int int2 = sum.Toplama.sum(1643, 3310);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4953 + "'", int2 == 4953);
    }

    @Test
    public void test0555() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0555");
        int int2 = sum.Toplama.sum(5284, 51);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5335 + "'", int2 == 5335);
    }

    @Test
    public void test0556() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0556");
        int int2 = sum.Toplama.sum(3012, 1287);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4299 + "'", int2 == 4299);
    }

    @Test
    public void test0557() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0557");
        int int2 = sum.Toplama.sum(5533, 110);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5643 + "'", int2 == 5643);
    }

    @Test
    public void test0558() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0558");
        int int2 = sum.Toplama.sum(1408, 509);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1917 + "'", int2 == 1917);
    }

    @Test
    public void test0559() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0559");
        int int2 = sum.Toplama.sum(1348, 875);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2223 + "'", int2 == 2223);
    }

    @Test
    public void test0560() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0560");
        int int2 = sum.Toplama.sum(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0561() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0561");
        int int2 = sum.Toplama.sum(624, 1735);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2359 + "'", int2 == 2359);
    }

    @Test
    public void test0562() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0562");
        int int2 = sum.Toplama.sum(1464, 280);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1744 + "'", int2 == 1744);
    }

    @Test
    public void test0563() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0563");
        int int2 = sum.Toplama.sum(737, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 737 + "'", int2 == 737);
    }

    @Test
    public void test0564() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0564");
        int int2 = sum.Toplama.sum(707, 299);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1006 + "'", int2 == 1006);
    }

    @Test
    public void test0565() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0565");
        int int2 = sum.Toplama.sum(0, 395);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 395 + "'", int2 == 395);
    }

    @Test
    public void test0566() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0566");
        int int2 = sum.Toplama.sum(282, 405);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 687 + "'", int2 == 687);
    }

    @Test
    public void test0567() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0567");
        int int2 = sum.Toplama.sum(488, 854);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1342 + "'", int2 == 1342);
    }

    @Test
    public void test0568() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0568");
        int int2 = sum.Toplama.sum(3901, 411);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4312 + "'", int2 == 4312);
    }

    @Test
    public void test0569() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0569");
        int int2 = sum.Toplama.sum(393, 344);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 737 + "'", int2 == 737);
    }

    @Test
    public void test0570() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0570");
        int int2 = sum.Toplama.sum((int) 'a', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test0571() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0571");
        int int2 = sum.Toplama.sum(2223, 3026);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5249 + "'", int2 == 5249);
    }

    @Test
    public void test0572() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0572");
        int int2 = sum.Toplama.sum(6876, 1481);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8357 + "'", int2 == 8357);
    }

    @Test
    public void test0573() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0573");
        int int2 = sum.Toplama.sum(351, 4246);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4597 + "'", int2 == 4597);
    }

    @Test
    public void test0574() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0574");
        int int2 = sum.Toplama.sum(1482, 544);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2026 + "'", int2 == 2026);
    }

    @Test
    public void test0575() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0575");
        int int2 = sum.Toplama.sum(621, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 621 + "'", int2 == 621);
    }

    @Test
    public void test0576() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0576");
        int int2 = sum.Toplama.sum(151, 2973);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3124 + "'", int2 == 3124);
    }

    @Test
    public void test0577() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0577");
        int int2 = sum.Toplama.sum(1680, 296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1976 + "'", int2 == 1976);
    }

    @Test
    public void test0578() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0578");
        int int2 = sum.Toplama.sum(2340, 164);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2504 + "'", int2 == 2504);
    }

    @Test
    public void test0579() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0579");
        int int2 = sum.Toplama.sum(1481, 229);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1710 + "'", int2 == 1710);
    }

    @Test
    public void test0580() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0580");
        int int2 = sum.Toplama.sum(2282, 305);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2587 + "'", int2 == 2587);
    }

    @Test
    public void test0581() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0581");
        int int2 = sum.Toplama.sum(2536, 676);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3212 + "'", int2 == 3212);
    }

    @Test
    public void test0582() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0582");
        int int2 = sum.Toplama.sum(10, 475);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 485 + "'", int2 == 485);
    }

    @Test
    public void test0583() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0583");
        int int2 = sum.Toplama.sum((int) (byte) 1, 2102);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2103 + "'", int2 == 2103);
    }

    @Test
    public void test0584() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0584");
        int int2 = sum.Toplama.sum(732, 2316);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3048 + "'", int2 == 3048);
    }

    @Test
    public void test0585() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0585");
        int int2 = sum.Toplama.sum(2223, 2249);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4472 + "'", int2 == 4472);
    }

    @Test
    public void test0586() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0586");
        int int2 = sum.Toplama.sum(2150, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2150 + "'", int2 == 2150);
    }

    @Test
    public void test0587() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0587");
        int int2 = sum.Toplama.sum(3113, 2214);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5327 + "'", int2 == 5327);
    }

    @Test
    public void test0588() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0588");
        int int2 = sum.Toplama.sum(396, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 396 + "'", int2 == 396);
    }

    @Test
    public void test0589() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0589");
        int int2 = sum.Toplama.sum(3212, 1478);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4690 + "'", int2 == 4690);
    }

    @Test
    public void test0590() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0590");
        int int2 = sum.Toplama.sum(1584, 1060);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2644 + "'", int2 == 2644);
    }

    @Test
    public void test0591() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0591");
        int int2 = sum.Toplama.sum(3460, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3460 + "'", int2 == 3460);
    }

    @Test
    public void test0592() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0592");
        int int2 = sum.Toplama.sum(4953, 260);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5213 + "'", int2 == 5213);
    }

    @Test
    public void test0593() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0593");
        int int2 = sum.Toplama.sum(1719, 4609);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6328 + "'", int2 == 6328);
    }

    @Test
    public void test0594() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0594");
        int int2 = sum.Toplama.sum(423, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 423 + "'", int2 == 423);
    }

    @Test
    public void test0595() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0595");
        int int2 = sum.Toplama.sum(315, 824);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1139 + "'", int2 == 1139);
    }

    @Test
    public void test0596() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0596");
        int int2 = sum.Toplama.sum(1713, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1723 + "'", int2 == 1723);
    }

    @Test
    public void test0597() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0597");
        int int2 = sum.Toplama.sum(1976, 308);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2284 + "'", int2 == 2284);
    }

    @Test
    public void test0598() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0598");
        int int2 = sum.Toplama.sum(5041, 2085);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7126 + "'", int2 == 7126);
    }

    @Test
    public void test0599() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0599");
        int int2 = sum.Toplama.sum((int) '#', 595);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 630 + "'", int2 == 630);
    }

    @Test
    public void test0600() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0600");
        int int2 = sum.Toplama.sum(739, 6876);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7615 + "'", int2 == 7615);
    }

    @Test
    public void test0601() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0601");
        int int2 = sum.Toplama.sum(859, 3509);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4368 + "'", int2 == 4368);
    }

    @Test
    public void test0602() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0602");
        int int2 = sum.Toplama.sum(100, 4782);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4882 + "'", int2 == 4882);
    }

    @Test
    public void test0603() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0603");
        int int2 = sum.Toplama.sum(1867, 4768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6635 + "'", int2 == 6635);
    }

    @Test
    public void test0604() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0604");
        int int2 = sum.Toplama.sum(1385, 1260);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2645 + "'", int2 == 2645);
    }

    @Test
    public void test0605() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0605");
        int int2 = sum.Toplama.sum((int) 'a', 792);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 889 + "'", int2 == 889);
    }

    @Test
    public void test0606() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0606");
        int int2 = sum.Toplama.sum(5847, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5847 + "'", int2 == 5847);
    }

    @Test
    public void test0607() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0607");
        int int2 = sum.Toplama.sum(2284, 3038);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5322 + "'", int2 == 5322);
    }

    @Test
    public void test0608() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0608");
        int int2 = sum.Toplama.sum(630, 6138);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6768 + "'", int2 == 6768);
    }

    @Test
    public void test0609() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0609");
        int int2 = sum.Toplama.sum(2788, 1460);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4248 + "'", int2 == 4248);
    }

    @Test
    public void test0610() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0610");
        int int2 = sum.Toplama.sum(519, 1249);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1768 + "'", int2 == 1768);
    }

    @Test
    public void test0611() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0611");
        int int2 = sum.Toplama.sum(3431, 1522);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4953 + "'", int2 == 4953);
    }

    @Test
    public void test0612() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0612");
        int int2 = sum.Toplama.sum(824, 1428);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2252 + "'", int2 == 2252);
    }

    @Test
    public void test0613() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0613");
        int int2 = sum.Toplama.sum(1203, 3012);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4215 + "'", int2 == 4215);
    }

    @Test
    public void test0614() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0614");
        int int2 = sum.Toplama.sum(181, 1491);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1672 + "'", int2 == 1672);
    }

    @Test
    public void test0615() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0615");
        int int2 = sum.Toplama.sum(1041, 1422);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2463 + "'", int2 == 2463);
    }

    @Test
    public void test0616() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0616");
        int int2 = sum.Toplama.sum(5302, 1255);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6557 + "'", int2 == 6557);
    }

    @Test
    public void test0617() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0617");
        int int2 = sum.Toplama.sum(1270, 396);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1666 + "'", int2 == 1666);
    }

    @Test
    public void test0618() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0618");
        int int2 = sum.Toplama.sum(0, 931);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 931 + "'", int2 == 931);
    }

    @Test
    public void test0619() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0619");
        int int2 = sum.Toplama.sum(381, 405);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 786 + "'", int2 == 786);
    }

    @Test
    public void test0620() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0620");
        int int2 = sum.Toplama.sum(909, 51);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 960 + "'", int2 == 960);
    }

    @Test
    public void test0621() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0621");
        int int2 = sum.Toplama.sum(2645, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2742 + "'", int2 == 2742);
    }

    @Test
    public void test0622() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0622");
        int int2 = sum.Toplama.sum(308, 485);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 793 + "'", int2 == 793);
    }

    @Test
    public void test0623() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0623");
        int int2 = sum.Toplama.sum(0, 1539);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1539 + "'", int2 == 1539);
    }

    @Test
    public void test0624() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0624");
        int int2 = sum.Toplama.sum(109, 2085);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2194 + "'", int2 == 2194);
    }

    @Test
    public void test0625() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0625");
        int int2 = sum.Toplama.sum(0, 547);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 547 + "'", int2 == 547);
    }

    @Test
    public void test0626() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0626");
        int int2 = sum.Toplama.sum(1648, 1488);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3136 + "'", int2 == 3136);
    }

    @Test
    public void test0627() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0627");
        int int2 = sum.Toplama.sum(3791, 995);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4786 + "'", int2 == 4786);
    }

    @Test
    public void test0628() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0628");
        int int2 = sum.Toplama.sum(4229, 1482);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5711 + "'", int2 == 5711);
    }

    @Test
    public void test0629() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0629");
        int int2 = sum.Toplama.sum(5932, 1147);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7079 + "'", int2 == 7079);
    }

    @Test
    public void test0630() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0630");
        int int2 = sum.Toplama.sum(3113, 2102);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5215 + "'", int2 == 5215);
    }

    @Test
    public void test0631() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0631");
        int int2 = sum.Toplama.sum(1965, 4093);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6058 + "'", int2 == 6058);
    }

    @Test
    public void test0632() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0632");
        int int2 = sum.Toplama.sum(295, 3442);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3737 + "'", int2 == 3737);
    }

    @Test
    public void test0633() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0633");
        int int2 = sum.Toplama.sum(897, 806);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1703 + "'", int2 == 1703);
    }

    @Test
    public void test0634() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0634");
        int int2 = sum.Toplama.sum(1233, 1735);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2968 + "'", int2 == 2968);
    }

    @Test
    public void test0635() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0635");
        int int2 = sum.Toplama.sum(5533, 1716);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7249 + "'", int2 == 7249);
    }

    @Test
    public void test0636() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0636");
        int int2 = sum.Toplama.sum(2355, 5055);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7410 + "'", int2 == 7410);
    }

    @Test
    public void test0637() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0637");
        int int2 = sum.Toplama.sum(1982, 623);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2605 + "'", int2 == 2605);
    }

    @Test
    public void test0638() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0638");
        int int2 = sum.Toplama.sum(1584, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1584 + "'", int2 == 1584);
    }

    @Test
    public void test0639() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0639");
        int int2 = sum.Toplama.sum(2252, 2605);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4857 + "'", int2 == 4857);
    }

    @Test
    public void test0640() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0640");
        int int2 = sum.Toplama.sum(1175, 1083);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2258 + "'", int2 == 2258);
    }

    @Test
    public void test0641() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0641");
        int int2 = sum.Toplama.sum(164, 5249);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5413 + "'", int2 == 5413);
    }

    @Test
    public void test0642() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0642");
        int int2 = sum.Toplama.sum(2359, 1995);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4354 + "'", int2 == 4354);
    }

    @Test
    public void test0643() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0643");
        int int2 = sum.Toplama.sum(2103, 1064);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3167 + "'", int2 == 3167);
    }

    @Test
    public void test0644() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0644");
        int int2 = sum.Toplama.sum(1301, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1311 + "'", int2 == 1311);
    }

    @Test
    public void test0645() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0645");
        int int2 = sum.Toplama.sum(939, 3169);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4108 + "'", int2 == 4108);
    }

    @Test
    public void test0646() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0646");
        int int2 = sum.Toplama.sum((int) (short) 1, 2252);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2253 + "'", int2 == 2253);
    }

    @Test
    public void test0647() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0647");
        int int2 = sum.Toplama.sum(7249, 1424);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8673 + "'", int2 == 8673);
    }

    @Test
    public void test0648() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0648");
        int int2 = sum.Toplama.sum(422, 1867);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2289 + "'", int2 == 2289);
    }

    @Test
    public void test0649() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0649");
        int int2 = sum.Toplama.sum(1204, 2223);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3427 + "'", int2 == 3427);
    }

    @Test
    public void test0650() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0650");
        int int2 = sum.Toplama.sum(909, 3460);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4369 + "'", int2 == 4369);
    }

    @Test
    public void test0651() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0651");
        int int2 = sum.Toplama.sum(5284, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5284 + "'", int2 == 5284);
    }

    @Test
    public void test0652() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0652");
        int int2 = sum.Toplama.sum(9644, 3791);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13435 + "'", int2 == 13435);
    }

    @Test
    public void test0653() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0653");
        int int2 = sum.Toplama.sum(2561, 1005);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3566 + "'", int2 == 3566);
    }

    @Test
    public void test0654() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0654");
        int int2 = sum.Toplama.sum(392, 300);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 692 + "'", int2 == 692);
    }

    @Test
    public void test0655() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0655");
        int int2 = sum.Toplama.sum(1601, 1296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2897 + "'", int2 == 2897);
    }

    @Test
    public void test0656() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0656");
        int int2 = sum.Toplama.sum(786, 551);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1337 + "'", int2 == 1337);
    }

    @Test
    public void test0657() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0657");
        int int2 = sum.Toplama.sum(2792, 1041);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3833 + "'", int2 == 3833);
    }

    @Test
    public void test0658() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0658");
        int int2 = sum.Toplama.sum(464, 2405);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2869 + "'", int2 == 2869);
    }

    @Test
    public void test0659() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0659");
        int int2 = sum.Toplama.sum((int) (byte) 10, 384);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 394 + "'", int2 == 394);
    }

    @Test
    public void test0660() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0660");
        int int2 = sum.Toplama.sum((int) ' ', 4137);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4169 + "'", int2 == 4169);
    }

    @Test
    public void test0661() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0661");
        int int2 = sum.Toplama.sum((int) (short) 0, 5530);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5530 + "'", int2 == 5530);
    }

    @Test
    public void test0662() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0662");
        int int2 = sum.Toplama.sum(1476, 487);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1963 + "'", int2 == 1963);
    }

    @Test
    public void test0663() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0663");
        int int2 = sum.Toplama.sum(543, 1520);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2063 + "'", int2 == 2063);
    }

    @Test
    public void test0664() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0664");
        int int2 = sum.Toplama.sum(2661, 4369);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7030 + "'", int2 == 7030);
    }

    @Test
    public void test0665() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0665");
        int int2 = sum.Toplama.sum(1680, 5847);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7527 + "'", int2 == 7527);
    }

    @Test
    public void test0666() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0666");
        int int2 = sum.Toplama.sum(2835, 300);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3135 + "'", int2 == 3135);
    }

    @Test
    public void test0667() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0667");
        int int2 = sum.Toplama.sum(948, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 948 + "'", int2 == 948);
    }

    @Test
    public void test0668() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0668");
        int int2 = sum.Toplama.sum(2634, 2282);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4916 + "'", int2 == 4916);
    }

    @Test
    public void test0669() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0669");
        int int2 = sum.Toplama.sum(9059, 3124);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12183 + "'", int2 == 12183);
    }

    @Test
    public void test0670() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0670");
        int int2 = sum.Toplama.sum(344, 64);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 408 + "'", int2 == 408);
    }

    @Test
    public void test0671() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0671");
        int int2 = sum.Toplama.sum(2359, 732);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3091 + "'", int2 == 3091);
    }

    @Test
    public void test0672() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0672");
        int int2 = sum.Toplama.sum(315, 1255);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1570 + "'", int2 == 1570);
    }

    @Test
    public void test0673() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0673");
        int int2 = sum.Toplama.sum(393, 2488);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2881 + "'", int2 == 2881);
    }

    @Test
    public void test0674() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0674");
        int int2 = sum.Toplama.sum(888, 622);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1510 + "'", int2 == 1510);
    }

    @Test
    public void test0675() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0675");
        int int2 = sum.Toplama.sum(522, 3135);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3657 + "'", int2 == 3657);
    }

    @Test
    public void test0676() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0676");
        int int2 = sum.Toplama.sum(995, 2445);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3440 + "'", int2 == 3440);
    }

    @Test
    public void test0677() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0677");
        int int2 = sum.Toplama.sum(0, 936);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 936 + "'", int2 == 936);
    }

    @Test
    public void test0678() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0678");
        int int2 = sum.Toplama.sum(1970, 557);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2527 + "'", int2 == 2527);
    }

    @Test
    public void test0679() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0679");
        int int2 = sum.Toplama.sum(680, 1446);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2126 + "'", int2 == 2126);
    }

    @Test
    public void test0680() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0680");
        int int2 = sum.Toplama.sum(0, 2436);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2436 + "'", int2 == 2436);
    }

    @Test
    public void test0681() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0681");
        int int2 = sum.Toplama.sum(5533, 8673);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14206 + "'", int2 == 14206);
    }

    @Test
    public void test0682() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0682");
        int int2 = sum.Toplama.sum(9, 2634);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2643 + "'", int2 == 2643);
    }

    @Test
    public void test0683() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0683");
        int int2 = sum.Toplama.sum(2735, 3105);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5840 + "'", int2 == 5840);
    }

    @Test
    public void test0684() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0684");
        int int2 = sum.Toplama.sum(3048, 7615);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10663 + "'", int2 == 10663);
    }

    @Test
    public void test0685() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0685");
        int int2 = sum.Toplama.sum(1161, 110);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1271 + "'", int2 == 1271);
    }

    @Test
    public void test0686() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0686");
        int int2 = sum.Toplama.sum(5533, 551);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6084 + "'", int2 == 6084);
    }

    @Test
    public void test0687() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0687");
        int int2 = sum.Toplama.sum(2723, 746);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3469 + "'", int2 == 3469);
    }

    @Test
    public void test0688() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0688");
        int int2 = sum.Toplama.sum(307, 552);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 859 + "'", int2 == 859);
    }

    @Test
    public void test0689() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0689");
        int int2 = sum.Toplama.sum(3048, 2869);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5917 + "'", int2 == 5917);
    }

    @Test
    public void test0690() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0690");
        int int2 = sum.Toplama.sum(1579, 2536);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4115 + "'", int2 == 4115);
    }

    @Test
    public void test0691() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0691");
        int int2 = sum.Toplama.sum(351, 2814);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3165 + "'", int2 == 3165);
    }

    @Test
    public void test0692() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0692");
        int int2 = sum.Toplama.sum(261, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 293 + "'", int2 == 293);
    }

    @Test
    public void test0693() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0693");
        int int2 = sum.Toplama.sum(805, 296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1101 + "'", int2 == 1101);
    }

    @Test
    public void test0694() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0694");
        int int2 = sum.Toplama.sum(2194, 3105);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5299 + "'", int2 == 5299);
    }

    @Test
    public void test0695() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0695");
        int int2 = sum.Toplama.sum(3469, 621);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4090 + "'", int2 == 4090);
    }

    @Test
    public void test0696() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0696");
        int int2 = sum.Toplama.sum(3101, 4215);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7316 + "'", int2 == 7316);
    }

    @Test
    public void test0697() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0697");
        int int2 = sum.Toplama.sum(152, 2014);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2166 + "'", int2 == 2166);
    }

    @Test
    public void test0698() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0698");
        int int2 = sum.Toplama.sum(3038, 7410);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10448 + "'", int2 == 10448);
    }

    @Test
    public void test0699() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0699");
        int int2 = sum.Toplama.sum(0, 948);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 948 + "'", int2 == 948);
    }

    @Test
    public void test0700() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0700");
        int int2 = sum.Toplama.sum(1735, 2962);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4697 + "'", int2 == 4697);
    }

    @Test
    public void test0701() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0701");
        int int2 = sum.Toplama.sum(1803, 1139);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2942 + "'", int2 == 2942);
    }

    @Test
    public void test0702() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0702");
        int int2 = sum.Toplama.sum(3165, 1311);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4476 + "'", int2 == 4476);
    }

    @Test
    public void test0703() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0703");
        int int2 = sum.Toplama.sum(3040, 7030);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10070 + "'", int2 == 10070);
    }

    @Test
    public void test0704() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0704");
        int int2 = sum.Toplama.sum(514, 640);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1154 + "'", int2 == 1154);
    }

    @Test
    public void test0705() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0705");
        int int2 = sum.Toplama.sum(304, 806);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1110 + "'", int2 == 1110);
    }

    @Test
    public void test0706() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0706");
        int int2 = sum.Toplama.sum(7030, 5284);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12314 + "'", int2 == 12314);
    }

    @Test
    public void test0707() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0707");
        int int2 = sum.Toplama.sum(2536, 3418);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5954 + "'", int2 == 5954);
    }

    @Test
    public void test0708() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0708");
        int int2 = sum.Toplama.sum(64, 3135);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3199 + "'", int2 == 3199);
    }

    @Test
    public void test0709() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0709");
        int int2 = sum.Toplama.sum(393, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 394 + "'", int2 == 394);
    }

    @Test
    public void test0710() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0710");
        int int2 = sum.Toplama.sum(995, 3498);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4493 + "'", int2 == 4493);
    }

    @Test
    public void test0711() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0711");
        int int2 = sum.Toplama.sum(3105, 2103);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5208 + "'", int2 == 5208);
    }

    @Test
    public void test0712() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0712");
        int int2 = sum.Toplama.sum(452, 3662);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4114 + "'", int2 == 4114);
    }

    @Test
    public void test0713() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0713");
        int int2 = sum.Toplama.sum(3427, 1955);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5382 + "'", int2 == 5382);
    }

    @Test
    public void test0714() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0714");
        int int2 = sum.Toplama.sum(1520, 1006);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2526 + "'", int2 == 2526);
    }

    @Test
    public void test0715() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0715");
        int int2 = sum.Toplama.sum(6635, 687);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7322 + "'", int2 == 7322);
    }

    @Test
    public void test0716() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0716");
        int int2 = sum.Toplama.sum(2526, 3113);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5639 + "'", int2 == 5639);
    }

    @Test
    public void test0717() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0717");
        int int2 = sum.Toplama.sum(1539, 1970);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3509 + "'", int2 == 3509);
    }

    @Test
    public void test0718() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0718");
        int int2 = sum.Toplama.sum(459, 394);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 853 + "'", int2 == 853);
    }

    @Test
    public void test0719() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0719");
        int int2 = sum.Toplama.sum(5847, 1177);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7024 + "'", int2 == 7024);
    }

    @Test
    public void test0720() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0720");
        int int2 = sum.Toplama.sum(452, 486);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 938 + "'", int2 == 938);
    }

    @Test
    public void test0721() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0721");
        int int2 = sum.Toplama.sum(2065, 551);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2616 + "'", int2 == 2616);
    }

    @Test
    public void test0722() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0722");
        int int2 = sum.Toplama.sum(1105, 5533);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6638 + "'", int2 == 6638);
    }

    @Test
    public void test0723() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0723");
        int int2 = sum.Toplama.sum(315, 547);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 862 + "'", int2 == 862);
    }

    @Test
    public void test0724() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0724");
        int int2 = sum.Toplama.sum(259, 2561);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2820 + "'", int2 == 2820);
    }

    @Test
    public void test0725() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0725");
        int int2 = sum.Toplama.sum(3305, 960);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4265 + "'", int2 == 4265);
    }

    @Test
    public void test0726() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0726");
        int int2 = sum.Toplama.sum(6084, 936);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7020 + "'", int2 == 7020);
    }

    @Test
    public void test0727() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0727");
        int int2 = sum.Toplama.sum(6557, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6557 + "'", int2 == 6557);
    }

    @Test
    public void test0728() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0728");
        int int2 = sum.Toplama.sum(2742, 515);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3257 + "'", int2 == 3257);
    }

    @Test
    public void test0729() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0729");
        int int2 = sum.Toplama.sum(622, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 632 + "'", int2 == 632);
    }

    @Test
    public void test0730() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0730");
        int int2 = sum.Toplama.sum(1095, 7249);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8344 + "'", int2 == 8344);
    }

    @Test
    public void test0731() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0731");
        int int2 = sum.Toplama.sum(6574, 1510);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8084 + "'", int2 == 8084);
    }

    @Test
    public void test0732() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0732");
        int int2 = sum.Toplama.sum(1723, 299);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2022 + "'", int2 == 2022);
    }

    @Test
    public void test0733() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0733");
        int int2 = sum.Toplama.sum(1193, 1012);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2205 + "'", int2 == 2205);
    }

    @Test
    public void test0734() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0734");
        int int2 = sum.Toplama.sum(5840, 753);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6593 + "'", int2 == 6593);
    }

    @Test
    public void test0735() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0735");
        int int2 = sum.Toplama.sum(0, 296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 296 + "'", int2 == 296);
    }

    @Test
    public void test0736() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0736");
        int int2 = sum.Toplama.sum(960, 7322);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8282 + "'", int2 == 8282);
    }

    @Test
    public void test0737() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0737");
        int int2 = sum.Toplama.sum(1540, 1365);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2905 + "'", int2 == 2905);
    }

    @Test
    public void test0738() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0738");
        int int2 = sum.Toplama.sum(261, 230);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 491 + "'", int2 == 491);
    }

    @Test
    public void test0739() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0739");
        int int2 = sum.Toplama.sum(64, 730);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 794 + "'", int2 == 794);
    }

    @Test
    public void test0740() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0740");
        int int2 = sum.Toplama.sum(2616, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2651 + "'", int2 == 2651);
    }

    @Test
    public void test0741() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0741");
        int int2 = sum.Toplama.sum(999, 168);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1167 + "'", int2 == 1167);
    }

    @Test
    public void test0742() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0742");
        int int2 = sum.Toplama.sum(0, 5711);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5711 + "'", int2 == 5711);
    }

    @Test
    public void test0743() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0743");
        int int2 = sum.Toplama.sum(1087, 964);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2051 + "'", int2 == 2051);
    }

    @Test
    public void test0744() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0744");
        int int2 = sum.Toplama.sum((int) (byte) 0, 216);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 216 + "'", int2 == 216);
    }

    @Test
    public void test0745() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0745");
        int int2 = sum.Toplama.sum(543, 1867);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2410 + "'", int2 == 2410);
    }

    @Test
    public void test0746() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0746");
        int int2 = sum.Toplama.sum(3212, 381);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3593 + "'", int2 == 3593);
    }

    @Test
    public void test0747() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0747");
        int int2 = sum.Toplama.sum(2051, 1270);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3321 + "'", int2 == 3321);
    }

    @Test
    public void test0748() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0748");
        int int2 = sum.Toplama.sum(1572, 1087);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2659 + "'", int2 == 2659);
    }

    @Test
    public void test0749() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0749");
        int int2 = sum.Toplama.sum(3101, 1539);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4640 + "'", int2 == 4640);
    }

    @Test
    public void test0750() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0750");
        int int2 = sum.Toplama.sum(5917, 585);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6502 + "'", int2 == 6502);
    }

    @Test
    public void test0751() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0751");
        int int2 = sum.Toplama.sum(1481, 351);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1832 + "'", int2 == 1832);
    }

    @Test
    public void test0752() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0752");
        int int2 = sum.Toplama.sum(96, 2088);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2184 + "'", int2 == 2184);
    }

    @Test
    public void test0753() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0753");
        int int2 = sum.Toplama.sum(724, 197);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 921 + "'", int2 == 921);
    }

    @Test
    public void test0754() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0754");
        int int2 = sum.Toplama.sum(1955, 3105);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5060 + "'", int2 == 5060);
    }

    @Test
    public void test0755() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0755");
        int int2 = sum.Toplama.sum(405, 1867);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2272 + "'", int2 == 2272);
    }

    @Test
    public void test0756() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0756");
        int int2 = sum.Toplama.sum(1203, 3169);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4372 + "'", int2 == 4372);
    }

    @Test
    public void test0757() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0757");
        int int2 = sum.Toplama.sum(2184, 2223);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4407 + "'", int2 == 4407);
    }

    @Test
    public void test0758() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0758");
        int int2 = sum.Toplama.sum(260, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 270 + "'", int2 == 270);
    }

    @Test
    public void test0759() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0759");
        int int2 = sum.Toplama.sum(7527, 2536);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10063 + "'", int2 == 10063);
    }

    @Test
    public void test0760() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0760");
        int int2 = sum.Toplama.sum(995, 1000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1995 + "'", int2 == 1995);
    }

    @Test
    public void test0761() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0761");
        int int2 = sum.Toplama.sum(2, 7410);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7412 + "'", int2 == 7412);
    }

    @Test
    public void test0762() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0762");
        int int2 = sum.Toplama.sum((int) (byte) 10, 538);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 548 + "'", int2 == 548);
    }

    @Test
    public void test0763() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0763");
        int int2 = sum.Toplama.sum((int) (short) 0, 4080);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4080 + "'", int2 == 4080);
    }

    @Test
    public void test0764() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0764");
        int int2 = sum.Toplama.sum(4229, 7412);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11641 + "'", int2 == 11641);
    }

    @Test
    public void test0765() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0765");
        int int2 = sum.Toplama.sum(5382, 4697);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10079 + "'", int2 == 10079);
    }

    @Test
    public void test0766() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0766");
        int int2 = sum.Toplama.sum(411, 626);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1037 + "'", int2 == 1037);
    }

    @Test
    public void test0767() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0767");
        int int2 = sum.Toplama.sum(948, 737);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1685 + "'", int2 == 1685);
    }

    @Test
    public void test0768() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0768");
        int int2 = sum.Toplama.sum(1666, 1177);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2843 + "'", int2 == 2843);
    }

    @Test
    public void test0769() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0769");
        int int2 = sum.Toplama.sum(129, 2223);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2352 + "'", int2 == 2352);
    }

    @Test
    public void test0770() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0770");
        int int2 = sum.Toplama.sum(109, 131);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 240 + "'", int2 == 240);
    }

    @Test
    public void test0771() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0771");
        int int2 = sum.Toplama.sum((int) '#', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test0772() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0772");
        int int2 = sum.Toplama.sum(1482, 2214);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3696 + "'", int2 == 3696);
    }

    @Test
    public void test0773() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0773");
        int int2 = sum.Toplama.sum(2045, 3814);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5859 + "'", int2 == 5859);
    }

    @Test
    public void test0774() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0774");
        int int2 = sum.Toplama.sum(1545, 2770);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4315 + "'", int2 == 4315);
    }

    @Test
    public void test0775() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0775");
        int int2 = sum.Toplama.sum(2150, 10663);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12813 + "'", int2 == 12813);
    }

    @Test
    public void test0776() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0776");
        int int2 = sum.Toplama.sum(0, 1223);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1223 + "'", int2 == 1223);
    }

    @Test
    public void test0777() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0777");
        int int2 = sum.Toplama.sum(486, 1570);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2056 + "'", int2 == 2056);
    }

    @Test
    public void test0778() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0778");
        int int2 = sum.Toplama.sum(440, 4368);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4808 + "'", int2 == 4808);
    }

    @Test
    public void test0779() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0779");
        int int2 = sum.Toplama.sum(1433, 2526);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3959 + "'", int2 == 3959);
    }

    @Test
    public void test0780() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0780");
        int int2 = sum.Toplama.sum(2051, 753);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2804 + "'", int2 == 2804);
    }

    @Test
    public void test0781() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0781");
        int int2 = sum.Toplama.sum(3469, 5382);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8851 + "'", int2 == 8851);
    }

    @Test
    public void test0782() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0782");
        int int2 = sum.Toplama.sum(440, 4407);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4847 + "'", int2 == 4847);
    }

    @Test
    public void test0783() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0783");
        int int2 = sum.Toplama.sum(1238, 1422);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2660 + "'", int2 == 2660);
    }

    @Test
    public void test0784() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0784");
        int int2 = sum.Toplama.sum(50, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test0785() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0785");
        int int2 = sum.Toplama.sum(35, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test0786() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0786");
        int int2 = sum.Toplama.sum(293, 3657);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3950 + "'", int2 == 3950);
    }

    @Test
    public void test0787() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0787");
        int int2 = sum.Toplama.sum(3460, 2368);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5828 + "'", int2 == 5828);
    }

    @Test
    public void test0788() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0788");
        int int2 = sum.Toplama.sum(0, 4697);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4697 + "'", int2 == 4697);
    }

    @Test
    public void test0789() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0789");
        int int2 = sum.Toplama.sum(4857, 269);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5126 + "'", int2 == 5126);
    }

    @Test
    public void test0790() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0790");
        int int2 = sum.Toplama.sum(809, 3418);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4227 + "'", int2 == 4227);
    }

    @Test
    public void test0791() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0791");
        int int2 = sum.Toplama.sum(2126, 2527);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4653 + "'", int2 == 4653);
    }

    @Test
    public void test0792() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0792");
        int int2 = sum.Toplama.sum(1536, 1520);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3056 + "'", int2 == 3056);
    }

    @Test
    public void test0793() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0793");
        int int2 = sum.Toplama.sum(4697, 1427);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6124 + "'", int2 == 6124);
    }

    @Test
    public void test0794() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0794");
        int int2 = sum.Toplama.sum((int) '#', 3772);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3807 + "'", int2 == 3807);
    }

    @Test
    public void test0795() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0795");
        int int2 = sum.Toplama.sum(1441, 4786);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6227 + "'", int2 == 6227);
    }

    @Test
    public void test0796() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0796");
        int int2 = sum.Toplama.sum(1723, 4369);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6092 + "'", int2 == 6092);
    }

    @Test
    public void test0797() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0797");
        int int2 = sum.Toplama.sum(1491, 1249);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2740 + "'", int2 == 2740);
    }

    @Test
    public void test0798() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0798");
        int int2 = sum.Toplama.sum(1337, 786);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2123 + "'", int2 == 2123);
    }

    @Test
    public void test0799() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0799");
        int int2 = sum.Toplama.sum(650, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 650 + "'", int2 == 650);
    }

    @Test
    public void test0800() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0800");
        int int2 = sum.Toplama.sum(2814, 6138);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8952 + "'", int2 == 8952);
    }

    @Test
    public void test0801() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0801");
        int int2 = sum.Toplama.sum(4229, 6557);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10786 + "'", int2 == 10786);
    }

    @Test
    public void test0802() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0802");
        int int2 = sum.Toplama.sum(809, 4169);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4978 + "'", int2 == 4978);
    }

    @Test
    public void test0803() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0803");
        int int2 = sum.Toplama.sum(5041, 3814);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8855 + "'", int2 == 8855);
    }

    @Test
    public void test0804() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0804");
        int int2 = sum.Toplama.sum(2289, 3950);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6239 + "'", int2 == 6239);
    }

    @Test
    public void test0805() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0805");
        int int2 = sum.Toplama.sum(1428, 2249);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3677 + "'", int2 == 3677);
    }

    @Test
    public void test0806() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0806");
        int int2 = sum.Toplama.sum(1343, 3199);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4542 + "'", int2 == 4542);
    }

    @Test
    public void test0807() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0807");
        int int2 = sum.Toplama.sum(1840, 623);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2463 + "'", int2 == 2463);
    }

    @Test
    public void test0808() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0808");
        int int2 = sum.Toplama.sum(1895, 2184);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4079 + "'", int2 == 4079);
    }

    @Test
    public void test0809() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0809");
        int int2 = sum.Toplama.sum(1488, 3469);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4957 + "'", int2 == 4957);
    }

    @Test
    public void test0810() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0810");
        int int2 = sum.Toplama.sum(412, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 447 + "'", int2 == 447);
    }

    @Test
    public void test0811() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0811");
        int int2 = sum.Toplama.sum(910, 622);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1532 + "'", int2 == 1532);
    }

    @Test
    public void test0812() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0812");
        int int2 = sum.Toplama.sum(240, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 240 + "'", int2 == 240);
    }

    @Test
    public void test0813() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0813");
        int int2 = sum.Toplama.sum(151, 2526);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2677 + "'", int2 == 2677);
    }

    @Test
    public void test0814() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0814");
        int int2 = sum.Toplama.sum(4882, 1584);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6466 + "'", int2 == 6466);
    }

    @Test
    public void test0815() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0815");
        int int2 = sum.Toplama.sum(4653, 746);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5399 + "'", int2 == 5399);
    }

    @Test
    public void test0816() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0816");
        int int2 = sum.Toplama.sum(1260, 854);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2114 + "'", int2 == 2114);
    }

    @Test
    public void test0817() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0817");
        int int2 = sum.Toplama.sum(1539, 4539);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6078 + "'", int2 == 6078);
    }

    @Test
    public void test0818() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0818");
        int int2 = sum.Toplama.sum(61, 129);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 190 + "'", int2 == 190);
    }

    @Test
    public void test0819() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0819");
        int int2 = sum.Toplama.sum(5284, 575);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5859 + "'", int2 == 5859);
    }

    @Test
    public void test0820() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0820");
        int int2 = sum.Toplama.sum(575, 2636);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3211 + "'", int2 == 3211);
    }

    @Test
    public void test0821() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0821");
        int int2 = sum.Toplama.sum(3012, 3959);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6971 + "'", int2 == 6971);
    }

    @Test
    public void test0822() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0822");
        int int2 = sum.Toplama.sum(1976, 547);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2523 + "'", int2 == 2523);
    }

    @Test
    public void test0823() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0823");
        int int2 = sum.Toplama.sum(746, 650);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1396 + "'", int2 == 1396);
    }

    @Test
    public void test0824() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0824");
        int int2 = sum.Toplama.sum(2735, 4115);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6850 + "'", int2 == 6850);
    }

    @Test
    public void test0825() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0825");
        int int2 = sum.Toplama.sum(4493, 4476);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8969 + "'", int2 == 8969);
    }

    @Test
    public void test0826() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0826");
        int int2 = sum.Toplama.sum(1396, 1239);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2635 + "'", int2 == 2635);
    }

    @Test
    public void test0827() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0827");
        int int2 = sum.Toplama.sum(4697, 3257);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7954 + "'", int2 == 7954);
    }

    @Test
    public void test0828() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0828");
        int int2 = sum.Toplama.sum(1238, 485);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1723 + "'", int2 == 1723);
    }

    @Test
    public void test0829() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0829");
        int int2 = sum.Toplama.sum(13435, 131);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13566 + "'", int2 == 13566);
    }

    @Test
    public void test0830() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0830");
        int int2 = sum.Toplama.sum(0, 1965);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1965 + "'", int2 == 1965);
    }

    @Test
    public void test0831() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0831");
        int int2 = sum.Toplama.sum(4690, 259);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4949 + "'", int2 == 4949);
    }

    @Test
    public void test0832() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0832");
        int int2 = sum.Toplama.sum(6328, 3772);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10100 + "'", int2 == 10100);
    }

    @Test
    public void test0833() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0833");
        int int2 = sum.Toplama.sum(3566, 2677);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6243 + "'", int2 == 6243);
    }

    @Test
    public void test0834() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0834");
        int int2 = sum.Toplama.sum(1064, 1428);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2492 + "'", int2 == 2492);
    }

    @Test
    public void test0835() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0835");
        int int2 = sum.Toplama.sum(855, 8357);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9212 + "'", int2 == 9212);
    }

    @Test
    public void test0836() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0836");
        int int2 = sum.Toplama.sum(4327, 812);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5139 + "'", int2 == 5139);
    }

    @Test
    public void test0837() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0837");
        int int2 = sum.Toplama.sum(1064, 2123);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3187 + "'", int2 == 3187);
    }

    @Test
    public void test0838() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0838");
        int int2 = sum.Toplama.sum(676, 392);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1068 + "'", int2 == 1068);
    }

    @Test
    public void test0839() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0839");
        int int2 = sum.Toplama.sum(2103, 6635);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8738 + "'", int2 == 8738);
    }

    @Test
    public void test0840() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0840");
        int int2 = sum.Toplama.sum(1896, 2253);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4149 + "'", int2 == 4149);
    }

    @Test
    public void test0841() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0841");
        int int2 = sum.Toplama.sum(3566, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3663 + "'", int2 == 3663);
    }

    @Test
    public void test0842() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0842");
        int int2 = sum.Toplama.sum(824, 8851);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9675 + "'", int2 == 9675);
    }

    @Test
    public void test0843() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0843");
        int int2 = sum.Toplama.sum(1154, 980);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2134 + "'", int2 == 2134);
    }

    @Test
    public void test0844() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0844");
        int int2 = sum.Toplama.sum(2605, 948);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3553 + "'", int2 == 3553);
    }

    @Test
    public void test0845() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0845");
        int int2 = sum.Toplama.sum(487, 2405);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2892 + "'", int2 == 2892);
    }

    @Test
    public void test0846() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0846");
        int int2 = sum.Toplama.sum(2014, 304);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2318 + "'", int2 == 2318);
    }

    @Test
    public void test0847() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0847");
        int int2 = sum.Toplama.sum(4312, 5055);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9367 + "'", int2 == 9367);
    }

    @Test
    public void test0848() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0848");
        int int2 = sum.Toplama.sum(1963, 5639);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7602 + "'", int2 == 7602);
    }

    @Test
    public void test0849() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0849");
        int int2 = sum.Toplama.sum(2347, 3460);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5807 + "'", int2 == 5807);
    }

    @Test
    public void test0850() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0850");
        int int2 = sum.Toplama.sum(7602, 3814);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11416 + "'", int2 == 11416);
    }

    @Test
    public void test0851() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0851");
        int int2 = sum.Toplama.sum(227, 1315);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1542 + "'", int2 == 1542);
    }

    @Test
    public void test0852() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0852");
        int int2 = sum.Toplama.sum(6971, 358);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7329 + "'", int2 == 7329);
    }

    @Test
    public void test0853() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0853");
        int int2 = sum.Toplama.sum(730, 2897);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3627 + "'", int2 == 3627);
    }

    @Test
    public void test0854() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0854");
        int int2 = sum.Toplama.sum(3427, 2085);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5512 + "'", int2 == 5512);
    }

    @Test
    public void test0855() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0855");
        int int2 = sum.Toplama.sum(469, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 468 + "'", int2 == 468);
    }

    @Test
    public void test0856() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0856");
        int int2 = sum.Toplama.sum(468, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 468 + "'", int2 == 468);
    }

    @Test
    public void test0857() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0857");
        int int2 = sum.Toplama.sum(8673, 252);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8925 + "'", int2 == 8925);
    }

    @Test
    public void test0858() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0858");
        int int2 = sum.Toplama.sum(2536, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2535 + "'", int2 == 2535);
    }

    @Test
    public void test0859() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0859");
        int int2 = sum.Toplama.sum(4248, 315);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4563 + "'", int2 == 4563);
    }

    @Test
    public void test0860() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0860");
        int int2 = sum.Toplama.sum(574, 2788);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3362 + "'", int2 == 3362);
    }

    @Test
    public void test0861() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0861");
        int int2 = sum.Toplama.sum(109, 2814);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2923 + "'", int2 == 2923);
    }

    @Test
    public void test0862() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0862");
        int int2 = sum.Toplama.sum(195, 5208);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5403 + "'", int2 == 5403);
    }

    @Test
    public void test0863() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0863");
        int int2 = sum.Toplama.sum(131, 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 140 + "'", int2 == 140);
    }

    @Test
    public void test0864() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0864");
        int int2 = sum.Toplama.sum(2, 552);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 554 + "'", int2 == 554);
    }

    @Test
    public void test0865() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0865");
        int int2 = sum.Toplama.sum(558, 857);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1415 + "'", int2 == 1415);
    }

    @Test
    public void test0866() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0866");
        int int2 = sum.Toplama.sum(4782, 519);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5301 + "'", int2 == 5301);
    }

    @Test
    public void test0867() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0867");
        int int2 = sum.Toplama.sum(954, 1041);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1995 + "'", int2 == 1995);
    }

    @Test
    public void test0868() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0868");
        int int2 = sum.Toplama.sum(1006, 359);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1365 + "'", int2 == 1365);
    }

    @Test
    public void test0869() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0869");
        int int2 = sum.Toplama.sum(3012, 3124);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6136 + "'", int2 == 6136);
    }

    @Test
    public void test0870() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0870");
        int int2 = sum.Toplama.sum(3663, 280);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3943 + "'", int2 == 3943);
    }

    @Test
    public void test0871() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0871");
        int int2 = sum.Toplama.sum(4653, 1147);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5800 + "'", int2 == 5800);
    }

    @Test
    public void test0872() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0872");
        int int2 = sum.Toplama.sum(0, 2192);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2192 + "'", int2 == 2192);
    }

    @Test
    public void test0873() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0873");
        int int2 = sum.Toplama.sum(4315, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4315 + "'", int2 == 4315);
    }

    @Test
    public void test0874() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0874");
        int int2 = sum.Toplama.sum(1087, 519);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1606 + "'", int2 == 1606);
    }

    @Test
    public void test0875() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0875");
        int int2 = sum.Toplama.sum(2311, 3833);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6144 + "'", int2 == 6144);
    }

    @Test
    public void test0876() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0876");
        int int2 = sum.Toplama.sum(5643, 1121);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6764 + "'", int2 == 6764);
    }

    @Test
    public void test0877() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0877");
        int int2 = sum.Toplama.sum(3135, 352);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3487 + "'", int2 == 3487);
    }

    @Test
    public void test0878() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0878");
        int int2 = sum.Toplama.sum(6054, 9059);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15113 + "'", int2 == 15113);
    }

    @Test
    public void test0879() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0879");
        int int2 = sum.Toplama.sum(1433, 4597);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6030 + "'", int2 == 6030);
    }

    @Test
    public void test0880() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0880");
        int int2 = sum.Toplama.sum(4149, 931);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5080 + "'", int2 == 5080);
    }

    @Test
    public void test0881() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0881");
        int int2 = sum.Toplama.sum(3662, 188);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3850 + "'", int2 == 3850);
    }

    @Test
    public void test0882() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0882");
        int int2 = sum.Toplama.sum(3036, 730);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3766 + "'", int2 == 3766);
    }

    @Test
    public void test0883() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0883");
        int int2 = sum.Toplama.sum(1175, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1185 + "'", int2 == 1185);
    }

    @Test
    public void test0884() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0884");
        int int2 = sum.Toplama.sum(4354, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4451 + "'", int2 == 4451);
    }

    @Test
    public void test0885() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0885");
        int int2 = sum.Toplama.sum(1301, 3036);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4337 + "'", int2 == 4337);
    }

    @Test
    public void test0886() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0886");
        int int2 = sum.Toplama.sum(0, 7412);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7412 + "'", int2 == 7412);
    }

    @Test
    public void test0887() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0887");
        int int2 = sum.Toplama.sum(421, 369);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 790 + "'", int2 == 790);
    }

    @Test
    public void test0888() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0888");
        int int2 = sum.Toplama.sum((int) (byte) 100, 2311);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2411 + "'", int2 == 2411);
    }

    @Test
    public void test0889() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0889");
        int int2 = sum.Toplama.sum(3105, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3106 + "'", int2 == 3106);
    }

    @Test
    public void test0890() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0890");
        int int2 = sum.Toplama.sum(2644, 897);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3541 + "'", int2 == 3541);
    }

    @Test
    public void test0891() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0891");
        int int2 = sum.Toplama.sum(875, 512);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1387 + "'", int2 == 1387);
    }

    @Test
    public void test0892() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0892");
        int int2 = sum.Toplama.sum(0, 2742);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2742 + "'", int2 == 2742);
    }

    @Test
    public void test0893() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0893");
        int int2 = sum.Toplama.sum(3850, 4847);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8697 + "'", int2 == 8697);
    }

    @Test
    public void test0894() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0894");
        int int2 = sum.Toplama.sum(381, 4521);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4902 + "'", int2 == 4902);
    }

    @Test
    public void test0895() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0895");
        int int2 = sum.Toplama.sum(1277, 2463);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3740 + "'", int2 == 3740);
    }

    @Test
    public void test0896() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0896");
        int int2 = sum.Toplama.sum(5639, 3169);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8808 + "'", int2 == 8808);
    }

    @Test
    public void test0897() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0897");
        int int2 = sum.Toplama.sum(3167, 2318);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5485 + "'", int2 == 5485);
    }

    @Test
    public void test0898() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0898");
        int int2 = sum.Toplama.sum(2411, 4227);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6638 + "'", int2 == 6638);
    }

    @Test
    public void test0899() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0899");
        int int2 = sum.Toplama.sum(896, 421);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1317 + "'", int2 == 1317);
    }

    @Test
    public void test0900() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0900");
        int int2 = sum.Toplama.sum(7126, 936);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8062 + "'", int2 == 8062);
    }

    @Test
    public void test0901() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0901");
        int int2 = sum.Toplama.sum(3113, 6078);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9191 + "'", int2 == 9191);
    }

    @Test
    public void test0902() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0902");
        int int2 = sum.Toplama.sum(5335, 1643);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6978 + "'", int2 == 6978);
    }

    @Test
    public void test0903() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0903");
        int int2 = sum.Toplama.sum(746, 131);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 877 + "'", int2 == 877);
    }

    @Test
    public void test0904() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0904");
        int int2 = sum.Toplama.sum(2881, 3833);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6714 + "'", int2 == 6714);
    }

    @Test
    public void test0905() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0905");
        int int2 = sum.Toplama.sum(1185, 3125);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4310 + "'", int2 == 4310);
    }

    @Test
    public void test0906() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0906");
        int int2 = sum.Toplama.sum(520, 4093);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4613 + "'", int2 == 4613);
    }

    @Test
    public void test0907() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0907");
        int int2 = sum.Toplama.sum(6328, 2660);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8988 + "'", int2 == 8988);
    }

    @Test
    public void test0908() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0908");
        int int2 = sum.Toplama.sum(0, 623);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 623 + "'", int2 == 623);
    }

    @Test
    public void test0909() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0909");
        int int2 = sum.Toplama.sum(13566, 4472);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18038 + "'", int2 == 18038);
    }

    @Test
    public void test0910() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0910");
        int int2 = sum.Toplama.sum(8697, 88);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8785 + "'", int2 == 8785);
    }

    @Test
    public void test0911() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0911");
        int int2 = sum.Toplama.sum(1317, 1744);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3061 + "'", int2 == 3061);
    }

    @Test
    public void test0912() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0912");
        int int2 = sum.Toplama.sum(1343, 229);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1572 + "'", int2 == 1572);
    }

    @Test
    public void test0913() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0913");
        int int2 = sum.Toplama.sum(6971, 3850);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10821 + "'", int2 == 10821);
    }

    @Test
    public void test0914() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0914");
        int int2 = sum.Toplama.sum(802, 2184);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2986 + "'", int2 == 2986);
    }

    @Test
    public void test0915() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0915");
        int int2 = sum.Toplama.sum(1154, 6078);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7232 + "'", int2 == 7232);
    }

    @Test
    public void test0916() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0916");
        int int2 = sum.Toplama.sum(4567, 230);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4797 + "'", int2 == 4797);
    }

    @Test
    public void test0917() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0917");
        int int2 = sum.Toplama.sum(4931, 2677);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7608 + "'", int2 == 7608);
    }

    @Test
    public void test0918() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0918");
        int int2 = sum.Toplama.sum(9367, 624);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9991 + "'", int2 == 9991);
    }

    @Test
    public void test0919() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0919");
        int int2 = sum.Toplama.sum(8785, 2065);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10850 + "'", int2 == 10850);
    }

    @Test
    public void test0920() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0920");
        int int2 = sum.Toplama.sum(140, 421);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 561 + "'", int2 == 561);
    }

    @Test
    public void test0921() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0921");
        int int2 = sum.Toplama.sum(1491, 2820);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4311 + "'", int2 == 4311);
    }

    @Test
    public void test0922() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0922");
        int int2 = sum.Toplama.sum(2677, 10100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12777 + "'", int2 == 12777);
    }

    @Test
    public void test0923() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0923");
        int int2 = sum.Toplama.sum(3593, 794);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4387 + "'", int2 == 4387);
    }

    @Test
    public void test0924() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0924");
        int int2 = sum.Toplama.sum(543, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 544 + "'", int2 == 544);
    }

    @Test
    public void test0925() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0925");
        int int2 = sum.Toplama.sum(2223, 1685);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3908 + "'", int2 == 3908);
    }

    @Test
    public void test0926() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0926");
        int int2 = sum.Toplama.sum(241, 960);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1201 + "'", int2 == 1201);
    }

    @Test
    public void test0927() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0927");
        int int2 = sum.Toplama.sum(3135, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3135 + "'", int2 == 3135);
    }

    @Test
    public void test0928() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0928");
        int int2 = sum.Toplama.sum((int) (short) 1, 547);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 548 + "'", int2 == 548);
    }

    @Test
    public void test0929() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0929");
        int int2 = sum.Toplama.sum(1199, 4407);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5606 + "'", int2 == 5606);
    }

    @Test
    public void test0930() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0930");
        int int2 = sum.Toplama.sum(307, 1536);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1843 + "'", int2 == 1843);
    }

    @Test
    public void test0931() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0931");
        int int2 = sum.Toplama.sum(870, 305);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1175 + "'", int2 == 1175);
    }

    @Test
    public void test0932() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0932");
        int int2 = sum.Toplama.sum(1315, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1415 + "'", int2 == 1415);
    }

    @Test
    public void test0933() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0933");
        int int2 = sum.Toplama.sum(1895, 2352);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4247 + "'", int2 == 4247);
    }

    @Test
    public void test0934() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0934");
        int int2 = sum.Toplama.sum(8855, 5954);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14809 + "'", int2 == 14809);
    }

    @Test
    public void test0935() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0935");
        int int2 = sum.Toplama.sum(4169, 8282);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12451 + "'", int2 == 12451);
    }

    @Test
    public void test0936() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0936");
        int int2 = sum.Toplama.sum(921, 1037);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1958 + "'", int2 == 1958);
    }

    @Test
    public void test0937() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0937");
        int int2 = sum.Toplama.sum(468, 3101);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3569 + "'", int2 == 3569);
    }

    @Test
    public void test0938() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0938");
        int int2 = sum.Toplama.sum(11072, 939);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12011 + "'", int2 == 12011);
    }

    @Test
    public void test0939() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0939");
        int int2 = sum.Toplama.sum(2659, 1396);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4055 + "'", int2 == 4055);
    }

    @Test
    public void test0940() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0940");
        int int2 = sum.Toplama.sum(1424, 4539);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5963 + "'", int2 == 5963);
    }

    @Test
    public void test0941() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0941");
        int int2 = sum.Toplama.sum(9606, 2184);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11790 + "'", int2 == 11790);
    }

    @Test
    public void test0942() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0942");
        int int2 = sum.Toplama.sum(809, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 809 + "'", int2 == 809);
    }

    @Test
    public void test0943() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0943");
        int int2 = sum.Toplama.sum(2465, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2466 + "'", int2 == 2466);
    }

    @Test
    public void test0944() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0944");
        int int2 = sum.Toplama.sum(5335, 3044);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8379 + "'", int2 == 8379);
    }

    @Test
    public void test0945() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0945");
        int int2 = sum.Toplama.sum(2651, 1190);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3841 + "'", int2 == 3841);
    }

    @Test
    public void test0946() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0946");
        int int2 = sum.Toplama.sum(1881, 621);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2502 + "'", int2 == 2502);
    }

    @Test
    public void test0947() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0947");
        int int2 = sum.Toplama.sum(756, 4265);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5021 + "'", int2 == 5021);
    }

    @Test
    public void test0948() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0948");
        int int2 = sum.Toplama.sum(802, 216);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1018 + "'", int2 == 1018);
    }

    @Test
    public void test0949() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0949");
        int int2 = sum.Toplama.sum(1955, 997);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2952 + "'", int2 == 2952);
    }

    @Test
    public void test0950() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0950");
        int int2 = sum.Toplama.sum(3403, 3511);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6914 + "'", int2 == 6914);
    }

    @Test
    public void test0951() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0951");
        int int2 = sum.Toplama.sum(889, 293);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1182 + "'", int2 == 1182);
    }

    @Test
    public void test0952() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0952");
        int int2 = sum.Toplama.sum(10663, 972);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11635 + "'", int2 == 11635);
    }

    @Test
    public void test0953() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0953");
        int int2 = sum.Toplama.sum(2536, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2536 + "'", int2 == 2536);
    }

    @Test
    public void test0954() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0954");
        int int2 = sum.Toplama.sum(1182, 2249);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3431 + "'", int2 == 3431);
    }

    @Test
    public void test0955() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0955");
        int int2 = sum.Toplama.sum(61, 2253);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2314 + "'", int2 == 2314);
    }

    @Test
    public void test0956() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0956");
        int int2 = sum.Toplama.sum((int) '4', 786);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 838 + "'", int2 == 838);
    }

    @Test
    public void test0957() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0957");
        int int2 = sum.Toplama.sum(746, 13435);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14181 + "'", int2 == 14181);
    }

    @Test
    public void test0958() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0958");
        int int2 = sum.Toplama.sum(1570, 61);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1631 + "'", int2 == 1631);
    }

    @Test
    public void test0959() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0959");
        int int2 = sum.Toplama.sum(6328, 8084);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14412 + "'", int2 == 14412);
    }

    @Test
    public void test0960() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0960");
        int int2 = sum.Toplama.sum(1606, 10079);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11685 + "'", int2 == 11685);
    }

    @Test
    public void test0961() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0961");
        int int2 = sum.Toplama.sum(3663, 948);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4611 + "'", int2 == 4611);
    }

    @Test
    public void test0962() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0962");
        int int2 = sum.Toplama.sum(449, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 449 + "'", int2 == 449);
    }

    @Test
    public void test0963() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0963");
        int int2 = sum.Toplama.sum(1895, 909);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2804 + "'", int2 == 2804);
    }

    @Test
    public void test0964() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0964");
        int int2 = sum.Toplama.sum(1903, 6574);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8477 + "'", int2 == 8477);
    }

    @Test
    public void test0965() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0965");
        int int2 = sum.Toplama.sum(1478, 4563);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6041 + "'", int2 == 6041);
    }

    @Test
    public void test0966() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0966");
        int int2 = sum.Toplama.sum(5302, 1446);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6748 + "'", int2 == 6748);
    }

    @Test
    public void test0967() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0967");
        int int2 = sum.Toplama.sum(806, 2272);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3078 + "'", int2 == 3078);
    }

    @Test
    public void test0968() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0968");
        int int2 = sum.Toplama.sum(5327, 2463);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7790 + "'", int2 == 7790);
    }

    @Test
    public void test0969() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0969");
        int int2 = sum.Toplama.sum(514, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 514 + "'", int2 == 514);
    }

    @Test
    public void test0970() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0970");
        int int2 = sum.Toplama.sum(6322, 299);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6621 + "'", int2 == 6621);
    }

    @Test
    public void test0971() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0971");
        int int2 = sum.Toplama.sum(1478, 1970);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3448 + "'", int2 == 3448);
    }

    @Test
    public void test0972() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0972");
        int int2 = sum.Toplama.sum(2504, 5249);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7753 + "'", int2 == 7753);
    }

    @Test
    public void test0973() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0973");
        int int2 = sum.Toplama.sum(1710, 1087);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2797 + "'", int2 == 2797);
    }

    @Test
    public void test0974() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0974");
        int int2 = sum.Toplama.sum((int) ' ', 455);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 487 + "'", int2 == 487);
    }

    @Test
    public void test0975() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0975");
        int int2 = sum.Toplama.sum(1448, 2055);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3503 + "'", int2 == 3503);
    }

    @Test
    public void test0976() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0976");
        int int2 = sum.Toplama.sum(1118, 814);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1932 + "'", int2 == 1932);
    }

    @Test
    public void test0977() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0977");
        int int2 = sum.Toplama.sum(2634, 261);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2895 + "'", int2 == 2895);
    }

    @Test
    public void test0978() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0978");
        int int2 = sum.Toplama.sum(110, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 207 + "'", int2 == 207);
    }

    @Test
    public void test0979() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0979");
        int int2 = sum.Toplama.sum(6239, 96);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6335 + "'", int2 == 6335);
    }

    @Test
    public void test0980() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0980");
        int int2 = sum.Toplama.sum(6574, 140);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6714 + "'", int2 == 6714);
    }

    @Test
    public void test0981() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0981");
        int int2 = sum.Toplama.sum(1540, 2502);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4042 + "'", int2 == 4042);
    }

    @Test
    public void test0982() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0982");
        int int2 = sum.Toplama.sum(890, 1719);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2609 + "'", int2 == 2609);
    }

    @Test
    public void test0983() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0983");
        int int2 = sum.Toplama.sum(6030, 3106);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9136 + "'", int2 == 9136);
    }

    @Test
    public void test0984() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0984");
        int int2 = sum.Toplama.sum(1713, 2869);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4582 + "'", int2 == 4582);
    }

    @Test
    public void test0985() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0985");
        int int2 = sum.Toplama.sum(477, 6144);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6621 + "'", int2 == 6621);
    }

    @Test
    public void test0986() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0986");
        int int2 = sum.Toplama.sum(190, 2788);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2978 + "'", int2 == 2978);
    }

    @Test
    public void test0987() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0987");
        int int2 = sum.Toplama.sum(459, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 459 + "'", int2 == 459);
    }

    @Test
    public void test0988() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0988");
        int int2 = sum.Toplama.sum(921, 3211);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4132 + "'", int2 == 4132);
    }

    @Test
    public void test0989() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0989");
        int int2 = sum.Toplama.sum(2986, 5322);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8308 + "'", int2 == 8308);
    }

    @Test
    public void test0990() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0990");
        int int2 = sum.Toplama.sum(1000, 1446);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2446 + "'", int2 == 2446);
    }

    @Test
    public void test0991() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0991");
        int int2 = sum.Toplama.sum(4609, 4315);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8924 + "'", int2 == 8924);
    }

    @Test
    public void test0992() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0992");
        int int2 = sum.Toplama.sum(2311, 622);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2933 + "'", int2 == 2933);
    }

    @Test
    public void test0993() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0993");
        int int2 = sum.Toplama.sum(5299, 2352);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7651 + "'", int2 == 7651);
    }

    @Test
    public void test0994() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0994");
        int int2 = sum.Toplama.sum(2770, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2770 + "'", int2 == 2770);
    }

    @Test
    public void test0995() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0995");
        int int2 = sum.Toplama.sum(15113, 1542);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16655 + "'", int2 == 16655);
    }

    @Test
    public void test0996() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0996");
        int int2 = sum.Toplama.sum(9059, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9156 + "'", int2 == 9156);
    }

    @Test
    public void test0997() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0997");
        int int2 = sum.Toplama.sum(6328, 10786);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17114 + "'", int2 == 17114);
    }

    @Test
    public void test0998() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0998");
        int int2 = sum.Toplama.sum(2051, 1041);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3092 + "'", int2 == 3092);
    }

    @Test
    public void test0999() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0999");
        int int2 = sum.Toplama.sum(0, 3696);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3696 + "'", int2 == 3696);
    }

    @Test
    public void test1000() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test1000");
        int int2 = sum.Toplama.sum(561, 2740);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3301 + "'", int2 == 3301);
    }
}

