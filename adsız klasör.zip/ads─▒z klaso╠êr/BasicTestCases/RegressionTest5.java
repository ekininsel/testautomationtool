import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test2501() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2501");
        int int2 = sum.Toplama.sum(17384, 88);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17472 + "'", int2 == 17472);
    }

    @Test
    public void test2502() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2502");
        int int2 = sum.Toplama.sum(1270, 1584);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2854 + "'", int2 == 2854);
    }

    @Test
    public void test2503() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2503");
        int int2 = sum.Toplama.sum(28642, 7410);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36052 + "'", int2 == 36052);
    }

    @Test
    public void test2504() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2504");
        int int2 = sum.Toplama.sum(20178, 1723);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21901 + "'", int2 == 21901);
    }

    @Test
    public void test2505() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2505");
        int int2 = sum.Toplama.sum(40362, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40362 + "'", int2 == 40362);
    }

    @Test
    public void test2506() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2506");
        int int2 = sum.Toplama.sum(2314, 20351);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22665 + "'", int2 == 22665);
    }

    @Test
    public void test2507() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2507");
        int int2 = sum.Toplama.sum(2797, 2328);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5125 + "'", int2 == 5125);
    }

    @Test
    public void test2508() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2508");
        int int2 = sum.Toplama.sum(859, 4945);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5804 + "'", int2 == 5804);
    }

    @Test
    public void test2509() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2509");
        int int2 = sum.Toplama.sum(2698, 4332);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7030 + "'", int2 == 7030);
    }

    @Test
    public void test2510() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2510");
        int int2 = sum.Toplama.sum(6748, 11682);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18430 + "'", int2 == 18430);
    }

    @Test
    public void test2511() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2511");
        int int2 = sum.Toplama.sum(7459, 11225);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18684 + "'", int2 == 18684);
    }

    @Test
    public void test2512() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2512");
        int int2 = sum.Toplama.sum(3772, 11235);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15007 + "'", int2 == 15007);
    }

    @Test
    public void test2513() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2513");
        int int2 = sum.Toplama.sum(4310, 18445);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22755 + "'", int2 == 22755);
    }

    @Test
    public void test2514() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2514");
        int int2 = sum.Toplama.sum(3566, 616);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4182 + "'", int2 == 4182);
    }

    @Test
    public void test2515() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2515");
        int int2 = sum.Toplama.sum(2417, 9367);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11784 + "'", int2 == 11784);
    }

    @Test
    public void test2516() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2516");
        int int2 = sum.Toplama.sum(20625, 5021);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25646 + "'", int2 == 25646);
    }

    @Test
    public void test2517() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2517");
        int int2 = sum.Toplama.sum(16213, 11685);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27898 + "'", int2 == 27898);
    }

    @Test
    public void test2518() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2518");
        int int2 = sum.Toplama.sum(2126, 824);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2950 + "'", int2 == 2950);
    }

    @Test
    public void test2519() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2519");
        int int2 = sum.Toplama.sum(4521, 5224);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9745 + "'", int2 == 9745);
    }

    @Test
    public void test2520() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2520");
        int int2 = sum.Toplama.sum(3136, 10468);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13604 + "'", int2 == 13604);
    }

    @Test
    public void test2521() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2521");
        int int2 = sum.Toplama.sum(7457, 14486);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21943 + "'", int2 == 21943);
    }

    @Test
    public void test2522() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2522");
        int int2 = sum.Toplama.sum(474, 2882);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3356 + "'", int2 == 3356);
    }

    @Test
    public void test2523() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2523");
        int int2 = sum.Toplama.sum(5126, 477);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5603 + "'", int2 == 5603);
    }

    @Test
    public void test2524() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2524");
        int int2 = sum.Toplama.sum(6119, 6808);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12927 + "'", int2 == 12927);
    }

    @Test
    public void test2525() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2525");
        int int2 = sum.Toplama.sum(17443, 16442);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33885 + "'", int2 == 33885);
    }

    @Test
    public void test2526() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2526");
        int int2 = sum.Toplama.sum(6542, 11784);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18326 + "'", int2 == 18326);
    }

    @Test
    public void test2527() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2527");
        int int2 = sum.Toplama.sum(809, 9950);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10759 + "'", int2 == 10759);
    }

    @Test
    public void test2528() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2528");
        int int2 = sum.Toplama.sum(15817, 4407);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20224 + "'", int2 == 20224);
    }

    @Test
    public void test2529() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2529");
        int int2 = sum.Toplama.sum(7932, 21913);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29845 + "'", int2 == 29845);
    }

    @Test
    public void test2530() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2530");
        int int2 = sum.Toplama.sum(8599, 10063);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18662 + "'", int2 == 18662);
    }

    @Test
    public void test2531() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2531");
        int int2 = sum.Toplama.sum(17853, 13566);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31419 + "'", int2 == 31419);
    }

    @Test
    public void test2532() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2532");
        int int2 = sum.Toplama.sum(2014, 16212);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18226 + "'", int2 == 18226);
    }

    @Test
    public void test2533() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2533");
        int int2 = sum.Toplama.sum(9689, 511);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10200 + "'", int2 == 10200);
    }

    @Test
    public void test2534() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2534");
        int int2 = sum.Toplama.sum(2214, 15901);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18115 + "'", int2 == 18115);
    }

    @Test
    public void test2535() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2535");
        int int2 = sum.Toplama.sum(4476, 10084);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14560 + "'", int2 == 14560);
    }

    @Test
    public void test2536() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2536");
        int int2 = sum.Toplama.sum(3045, 34846);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37891 + "'", int2 == 37891);
    }

    @Test
    public void test2537() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2537");
        int int2 = sum.Toplama.sum(1570, 1028);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2598 + "'", int2 == 2598);
    }

    @Test
    public void test2538() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2538");
        int int2 = sum.Toplama.sum(0, 4115);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4115 + "'", int2 == 4115);
    }

    @Test
    public void test2539() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2539");
        int int2 = sum.Toplama.sum(1105, 2882);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3987 + "'", int2 == 3987);
    }

    @Test
    public void test2540() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2540");
        int int2 = sum.Toplama.sum(18166, 8785);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26951 + "'", int2 == 26951);
    }

    @Test
    public void test2541() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2541");
        int int2 = sum.Toplama.sum(38024, 10897);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48921 + "'", int2 == 48921);
    }

    @Test
    public void test2542() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2542");
        int int2 = sum.Toplama.sum(19834, 6471);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26305 + "'", int2 == 26305);
    }

    @Test
    public void test2543() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2543");
        int int2 = sum.Toplama.sum(854, 10084);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10938 + "'", int2 == 10938);
    }

    @Test
    public void test2544() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2544");
        int int2 = sum.Toplama.sum(922, 2770);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3692 + "'", int2 == 3692);
    }

    @Test
    public void test2545() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2545");
        int int2 = sum.Toplama.sum(7316, 910);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8226 + "'", int2 == 8226);
    }

    @Test
    public void test2546() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2546");
        int int2 = sum.Toplama.sum(8697, 5305);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14002 + "'", int2 == 14002);
    }

    @Test
    public void test2547() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2547");
        int int2 = sum.Toplama.sum(3418, 2314);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5732 + "'", int2 == 5732);
    }

    @Test
    public void test2548() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2548");
        int int2 = sum.Toplama.sum(1408, 2814);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4222 + "'", int2 == 4222);
    }

    @Test
    public void test2549() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2549");
        int int2 = sum.Toplama.sum(5853, 3908);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9761 + "'", int2 == 9761);
    }

    @Test
    public void test2550() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2550");
        int int2 = sum.Toplama.sum(1374, 7335);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8709 + "'", int2 == 8709);
    }

    @Test
    public void test2551() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2551");
        int int2 = sum.Toplama.sum(12919, 812);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13731 + "'", int2 == 13731);
    }

    @Test
    public void test2552() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2552");
        int int2 = sum.Toplama.sum(5108, 10565);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15673 + "'", int2 == 15673);
    }

    @Test
    public void test2553() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2553");
        int int2 = sum.Toplama.sum(6136, 3282);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9418 + "'", int2 == 9418);
    }

    @Test
    public void test2554() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2554");
        int int2 = sum.Toplama.sum(1165, 38256);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39421 + "'", int2 == 39421);
    }

    @Test
    public void test2555() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2555");
        int int2 = sum.Toplama.sum(8607, 4542);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13149 + "'", int2 == 13149);
    }

    @Test
    public void test2556() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2556");
        int int2 = sum.Toplama.sum(6451, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6451 + "'", int2 == 6451);
    }

    @Test
    public void test2557() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2557");
        int int2 = sum.Toplama.sum(17026, 6345);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23371 + "'", int2 == 23371);
    }

    @Test
    public void test2558() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2558");
        int int2 = sum.Toplama.sum(13204, 1233);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14437 + "'", int2 == 14437);
    }

    @Test
    public void test2559() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2559");
        int int2 = sum.Toplama.sum(1051, 6377);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7428 + "'", int2 == 7428);
    }

    @Test
    public void test2560() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2560");
        int int2 = sum.Toplama.sum(804, 19035);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19839 + "'", int2 == 19839);
    }

    @Test
    public void test2561() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2561");
        int int2 = sum.Toplama.sum(5516, 15704);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21220 + "'", int2 == 21220);
    }

    @Test
    public void test2562() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2562");
        int int2 = sum.Toplama.sum(14770, 13188);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27958 + "'", int2 == 27958);
    }

    @Test
    public void test2563() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2563");
        int int2 = sum.Toplama.sum(23192, 8474);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31666 + "'", int2 == 31666);
    }

    @Test
    public void test2564() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2564");
        int int2 = sum.Toplama.sum(199, 3585);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3784 + "'", int2 == 3784);
    }

    @Test
    public void test2565() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2565");
        int int2 = sum.Toplama.sum(10658, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10658 + "'", int2 == 10658);
    }

    @Test
    public void test2566() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2566");
        int int2 = sum.Toplama.sum(6019, 2657);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8676 + "'", int2 == 8676);
    }

    @Test
    public void test2567() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2567");
        int int2 = sum.Toplama.sum(15901, 15601);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31502 + "'", int2 == 31502);
    }

    @Test
    public void test2568() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2568");
        int int2 = sum.Toplama.sum(12610, 9950);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22560 + "'", int2 == 22560);
    }

    @Test
    public void test2569() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2569");
        int int2 = sum.Toplama.sum(17051, 14631);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31682 + "'", int2 == 31682);
    }

    @Test
    public void test2570() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2570");
        int int2 = sum.Toplama.sum(6626, 20562);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27188 + "'", int2 == 27188);
    }

    @Test
    public void test2571() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2571");
        int int2 = sum.Toplama.sum(7932, 2953);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10885 + "'", int2 == 10885);
    }

    @Test
    public void test2572() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2572");
        int int2 = sum.Toplama.sum(14631, 2814);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17445 + "'", int2 == 17445);
    }

    @Test
    public void test2573() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2573");
        int int2 = sum.Toplama.sum(3578, 19441);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23019 + "'", int2 == 23019);
    }

    @Test
    public void test2574() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2574");
        int int2 = sum.Toplama.sum(547, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 547 + "'", int2 == 547);
    }

    @Test
    public void test2575() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2575");
        int int2 = sum.Toplama.sum(9833, 814);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10647 + "'", int2 == 10647);
    }

    @Test
    public void test2576() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2576");
        int int2 = sum.Toplama.sum(0, 5718);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5718 + "'", int2 == 5718);
    }

    @Test
    public void test2577() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2577");
        int int2 = sum.Toplama.sum(13543, 12993);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26536 + "'", int2 == 26536);
    }

    @Test
    public void test2578() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2578");
        int int2 = sum.Toplama.sum(13376, 10904);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24280 + "'", int2 == 24280);
    }

    @Test
    public void test2579() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2579");
        int int2 = sum.Toplama.sum(10594, 15503);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26097 + "'", int2 == 26097);
    }

    @Test
    public void test2580() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2580");
        int int2 = sum.Toplama.sum(97, 954);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1051 + "'", int2 == 1051);
    }

    @Test
    public void test2581() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2581");
        int int2 = sum.Toplama.sum(0, 6063);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6063 + "'", int2 == 6063);
    }

    @Test
    public void test2582() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2582");
        int int2 = sum.Toplama.sum(25450, 6556);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32006 + "'", int2 == 32006);
    }

    @Test
    public void test2583() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2583");
        int int2 = sum.Toplama.sum(12420, 4611);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17031 + "'", int2 == 17031);
    }

    @Test
    public void test2584() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2584");
        int int2 = sum.Toplama.sum(5626, 917);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6543 + "'", int2 == 6543);
    }

    @Test
    public void test2585() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2585");
        int int2 = sum.Toplama.sum(8370, 15287);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23657 + "'", int2 == 23657);
    }

    @Test
    public void test2586() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2586");
        int int2 = sum.Toplama.sum(2134, 1697);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3831 + "'", int2 == 3831);
    }

    @Test
    public void test2587() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2587");
        int int2 = sum.Toplama.sum(4227, 12813);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17040 + "'", int2 == 17040);
    }

    @Test
    public void test2588() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2588");
        int int2 = sum.Toplama.sum(2698, 9868);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12566 + "'", int2 == 12566);
    }

    @Test
    public void test2589() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2589");
        int int2 = sum.Toplama.sum(6278, 1723);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8001 + "'", int2 == 8001);
    }

    @Test
    public void test2590() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2590");
        int int2 = sum.Toplama.sum(0, 14653);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14653 + "'", int2 == 14653);
    }

    @Test
    public void test2591() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2591");
        int int2 = sum.Toplama.sum(10200, 28560);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38760 + "'", int2 == 38760);
    }

    @Test
    public void test2592() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2592");
        int int2 = sum.Toplama.sum(4069, 7002);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11071 + "'", int2 == 11071);
    }

    @Test
    public void test2593() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2593");
        int int2 = sum.Toplama.sum(3503, 3569);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7072 + "'", int2 == 7072);
    }

    @Test
    public void test2594() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2594");
        int int2 = sum.Toplama.sum(15486, 5368);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20854 + "'", int2 == 20854);
    }

    @Test
    public void test2595() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2595");
        int int2 = sum.Toplama.sum(2636, 10940);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13576 + "'", int2 == 13576);
    }

    @Test
    public void test2596() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2596");
        int int2 = sum.Toplama.sum(802, 3644);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4446 + "'", int2 == 4446);
    }

    @Test
    public void test2597() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2597");
        int int2 = sum.Toplama.sum(10505, 3511);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14016 + "'", int2 == 14016);
    }

    @Test
    public void test2598() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2598");
        int int2 = sum.Toplama.sum(7329, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7329 + "'", int2 == 7329);
    }

    @Test
    public void test2599() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2599");
        int int2 = sum.Toplama.sum(10785, 379);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11164 + "'", int2 == 11164);
    }

    @Test
    public void test2600() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2600");
        int int2 = sum.Toplama.sum(12581, 2328);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14909 + "'", int2 == 14909);
    }

    @Test
    public void test2601() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2601");
        int int2 = sum.Toplama.sum(35479, 8709);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44188 + "'", int2 == 44188);
    }

    @Test
    public void test2602() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2602");
        int int2 = sum.Toplama.sum(14620, 49393);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64013 + "'", int2 == 64013);
    }

    @Test
    public void test2603() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2603");
        int int2 = sum.Toplama.sum(10415, 8855);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19270 + "'", int2 == 19270);
    }

    @Test
    public void test2604() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2604");
        int int2 = sum.Toplama.sum(1177, 18662);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19839 + "'", int2 == 19839);
    }

    @Test
    public void test2605() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2605");
        int int2 = sum.Toplama.sum(855, 12663);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13518 + "'", int2 == 13518);
    }

    @Test
    public void test2606() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2606");
        int int2 = sum.Toplama.sum(18228, 14507);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32735 + "'", int2 == 32735);
    }

    @Test
    public void test2607() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2607");
        int int2 = sum.Toplama.sum(4080, 17856);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21936 + "'", int2 == 21936);
    }

    @Test
    public void test2608() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2608");
        int int2 = sum.Toplama.sum(4552, 6345);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10897 + "'", int2 == 10897);
    }

    @Test
    public void test2609() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2609");
        int int2 = sum.Toplama.sum(1970, 5413);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7383 + "'", int2 == 7383);
    }

    @Test
    public void test2610() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2610");
        int int2 = sum.Toplama.sum(16777, 1772);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18549 + "'", int2 == 18549);
    }

    @Test
    public void test2611() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2611");
        int int2 = sum.Toplama.sum(37891, 19193);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57084 + "'", int2 == 57084);
    }

    @Test
    public void test2612() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2612");
        int int2 = sum.Toplama.sum(8785, 13480);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22265 + "'", int2 == 22265);
    }

    @Test
    public void test2613() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2613");
        int int2 = sum.Toplama.sum(0, 12696);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12696 + "'", int2 == 12696);
    }

    @Test
    public void test2614() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2614");
        int int2 = sum.Toplama.sum(1335, 12075);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13410 + "'", int2 == 13410);
    }

    @Test
    public void test2615() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2615");
        int int2 = sum.Toplama.sum(15901, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15901 + "'", int2 == 15901);
    }

    @Test
    public void test2616() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2616");
        int int2 = sum.Toplama.sum(735, 2109);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2844 + "'", int2 == 2844);
    }

    @Test
    public void test2617() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2617");
        int int2 = sum.Toplama.sum(4281, 8901);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13182 + "'", int2 == 13182);
    }

    @Test
    public void test2618() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2618");
        int int2 = sum.Toplama.sum(7054, 29241);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36295 + "'", int2 == 36295);
    }

    @Test
    public void test2619() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2619");
        int int2 = sum.Toplama.sum(917, 5523);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6440 + "'", int2 == 6440);
    }

    @Test
    public void test2620() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2620");
        int int2 = sum.Toplama.sum(23190, 1697);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24887 + "'", int2 == 24887);
    }

    @Test
    public void test2621() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2621");
        int int2 = sum.Toplama.sum(7970, 3850);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11820 + "'", int2 == 11820);
    }

    @Test
    public void test2622() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2622");
        int int2 = sum.Toplama.sum(12000, 1385);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13385 + "'", int2 == 13385);
    }

    @Test
    public void test2623() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2623");
        int int2 = sum.Toplama.sum(11416, 31666);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43082 + "'", int2 == 43082);
    }

    @Test
    public void test2624() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2624");
        int int2 = sum.Toplama.sum(252, 11928);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12180 + "'", int2 == 12180);
    }

    @Test
    public void test2625() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2625");
        int int2 = sum.Toplama.sum(15475, 22314);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37789 + "'", int2 == 37789);
    }

    @Test
    public void test2626() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2626");
        int int2 = sum.Toplama.sum(2869, 2882);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5751 + "'", int2 == 5751);
    }

    @Test
    public void test2627() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2627");
        int int2 = sum.Toplama.sum(1335, 1274);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2609 + "'", int2 == 2609);
    }

    @Test
    public void test2628() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2628");
        int int2 = sum.Toplama.sum(19425, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19425 + "'", int2 == 19425);
    }

    @Test
    public void test2629() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2629");
        int int2 = sum.Toplama.sum(5008, 16109);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21117 + "'", int2 == 21117);
    }

    @Test
    public void test2630() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2630");
        int int2 = sum.Toplama.sum(13344, 753);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14097 + "'", int2 == 14097);
    }

    @Test
    public void test2631() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2631");
        int int2 = sum.Toplama.sum(4578, 9187);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13765 + "'", int2 == 13765);
    }

    @Test
    public void test2632() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2632");
        int int2 = sum.Toplama.sum(0, 2368);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2368 + "'", int2 == 2368);
    }

    @Test
    public void test2633() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2633");
        int int2 = sum.Toplama.sum(300, 4453);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4753 + "'", int2 == 4753);
    }

    @Test
    public void test2634() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2634");
        int int2 = sum.Toplama.sum(14621, 161);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14782 + "'", int2 == 14782);
    }

    @Test
    public void test2635() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2635");
        int int2 = sum.Toplama.sum(1936, 12314);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14250 + "'", int2 == 14250);
    }

    @Test
    public void test2636() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2636");
        int int2 = sum.Toplama.sum(38024, 13198);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51222 + "'", int2 == 51222);
    }

    @Test
    public void test2637() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2637");
        int int2 = sum.Toplama.sum(0, 2380);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2380 + "'", int2 == 2380);
    }

    @Test
    public void test2638() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2638");
        int int2 = sum.Toplama.sum(5188, 13663);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18851 + "'", int2 == 18851);
    }

    @Test
    public void test2639() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2639");
        int int2 = sum.Toplama.sum(1723, 14719);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16442 + "'", int2 == 16442);
    }

    @Test
    public void test2640() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2640");
        int int2 = sum.Toplama.sum(14135, 11204);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25339 + "'", int2 == 25339);
    }

    @Test
    public void test2641() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2641");
        int int2 = sum.Toplama.sum(6085, 6983);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13068 + "'", int2 == 13068);
    }

    @Test
    public void test2642() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2642");
        int int2 = sum.Toplama.sum(891, 9475);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10366 + "'", int2 == 10366);
    }

    @Test
    public void test2643() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2643");
        int int2 = sum.Toplama.sum(902, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 902 + "'", int2 == 902);
    }

    @Test
    public void test2644() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2644");
        int int2 = sum.Toplama.sum(40630, 5512);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46142 + "'", int2 == 46142);
    }

    @Test
    public void test2645() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2645");
        int int2 = sum.Toplama.sum(1542, 3569);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5111 + "'", int2 == 5111);
    }

    @Test
    public void test2646() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2646");
        int int2 = sum.Toplama.sum(9870, 720);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10590 + "'", int2 == 10590);
    }

    @Test
    public void test2647() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2647");
        int int2 = sum.Toplama.sum(109, 4211);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4320 + "'", int2 == 4320);
    }

    @Test
    public void test2648() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2648");
        int int2 = sum.Toplama.sum(6440, 10897);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17337 + "'", int2 == 17337);
    }

    @Test
    public void test2649() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2649");
        int int2 = sum.Toplama.sum(2109, 3892);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6001 + "'", int2 == 6001);
    }

    @Test
    public void test2650() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2650");
        int int2 = sum.Toplama.sum(9914, 2252);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12166 + "'", int2 == 12166);
    }

    @Test
    public void test2651() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2651");
        int int2 = sum.Toplama.sum(6931, 3257);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10188 + "'", int2 == 10188);
    }

    @Test
    public void test2652() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2652");
        int int2 = sum.Toplama.sum(630, 1177);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1807 + "'", int2 == 1807);
    }

    @Test
    public void test2653() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2653");
        int int2 = sum.Toplama.sum(50, 3469);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3519 + "'", int2 == 3519);
    }

    @Test
    public void test2654() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2654");
        int int2 = sum.Toplama.sum(9670, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9669 + "'", int2 == 9669);
    }

    @Test
    public void test2655() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2655");
        int int2 = sum.Toplama.sum(15890, 25922);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41812 + "'", int2 == 41812);
    }

    @Test
    public void test2656() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2656");
        int int2 = sum.Toplama.sum(4248, 1271);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5519 + "'", int2 == 5519);
    }

    @Test
    public void test2657() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2657");
        int int2 = sum.Toplama.sum(11434, 793);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12227 + "'", int2 == 12227);
    }

    @Test
    public void test2658() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2658");
        int int2 = sum.Toplama.sum(17361, 21060);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38421 + "'", int2 == 38421);
    }

    @Test
    public void test2659() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2659");
        int int2 = sum.Toplama.sum(26669, 3136);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29805 + "'", int2 == 29805);
    }

    @Test
    public void test2660() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2660");
        int int2 = sum.Toplama.sum(622, 5939);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6561 + "'", int2 == 6561);
    }

    @Test
    public void test2661() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2661");
        int int2 = sum.Toplama.sum(8221, 5824);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14045 + "'", int2 == 14045);
    }

    @Test
    public void test2662() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2662");
        int int2 = sum.Toplama.sum(1207, 11186);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12393 + "'", int2 == 12393);
    }

    @Test
    public void test2663() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2663");
        int int2 = sum.Toplama.sum(3644, 5512);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9156 + "'", int2 == 9156);
    }

    @Test
    public void test2664() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2664");
        int int2 = sum.Toplama.sum(12544, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12554 + "'", int2 == 12554);
    }

    @Test
    public void test2665() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2665");
        int int2 = sum.Toplama.sum(6244, 3602);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9846 + "'", int2 == 9846);
    }

    @Test
    public void test2666() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2666");
        int int2 = sum.Toplama.sum(7329, 1028);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8357 + "'", int2 == 8357);
    }

    @Test
    public void test2667() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2667");
        int int2 = sum.Toplama.sum(3772, 16787);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20559 + "'", int2 == 20559);
    }

    @Test
    public void test2668() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2668");
        int int2 = sum.Toplama.sum(0, 24168);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24168 + "'", int2 == 24168);
    }

    @Test
    public void test2669() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2669");
        int int2 = sum.Toplama.sum(16215, 7258);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23473 + "'", int2 == 23473);
    }

    @Test
    public void test2670() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2670");
        int int2 = sum.Toplama.sum(3277, 17306);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20583 + "'", int2 == 20583);
    }

    @Test
    public void test2671() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2671");
        int int2 = sum.Toplama.sum(12581, 17955);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30536 + "'", int2 == 30536);
    }

    @Test
    public void test2672() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2672");
        int int2 = sum.Toplama.sum(1337, 131);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1468 + "'", int2 == 1468);
    }

    @Test
    public void test2673() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2673");
        int int2 = sum.Toplama.sum(3965, 25067);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29032 + "'", int2 == 29032);
    }

    @Test
    public void test2674() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2674");
        int int2 = sum.Toplama.sum(2723, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2723 + "'", int2 == 2723);
    }

    @Test
    public void test2675() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2675");
        int int2 = sum.Toplama.sum(8566, 7410);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15976 + "'", int2 == 15976);
    }

    @Test
    public void test2676() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2676");
        int int2 = sum.Toplama.sum(1411, 3059);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4470 + "'", int2 == 4470);
    }

    @Test
    public void test2677() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2677");
        int int2 = sum.Toplama.sum(642, 1803);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2445 + "'", int2 == 2445);
    }

    @Test
    public void test2678() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2678");
        int int2 = sum.Toplama.sum(921, 18115);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19036 + "'", int2 == 19036);
    }

    @Test
    public void test2679() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2679");
        int int2 = sum.Toplama.sum(7585, 2194);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9779 + "'", int2 == 9779);
    }

    @Test
    public void test2680() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2680");
        int int2 = sum.Toplama.sum(96, 11287);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11383 + "'", int2 == 11383);
    }

    @Test
    public void test2681() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2681");
        int int2 = sum.Toplama.sum(2314, 960);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3274 + "'", int2 == 3274);
    }

    @Test
    public void test2682() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2682");
        int int2 = sum.Toplama.sum(4978, 12136);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17114 + "'", int2 == 17114);
    }

    @Test
    public void test2683() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2683");
        int int2 = sum.Toplama.sum(6502, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6502 + "'", int2 == 6502);
    }

    @Test
    public void test2684() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2684");
        int int2 = sum.Toplama.sum(6635, 21278);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27913 + "'", int2 == 27913);
    }

    @Test
    public void test2685() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2685");
        int int2 = sum.Toplama.sum(2316, 7249);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9565 + "'", int2 == 9565);
    }

    @Test
    public void test2686() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2686");
        int int2 = sum.Toplama.sum(3211, 1903);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5114 + "'", int2 == 5114);
    }

    @Test
    public void test2687() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2687");
        int int2 = sum.Toplama.sum(8139, 9565);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17704 + "'", int2 == 17704);
    }

    @Test
    public void test2688() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2688");
        int int2 = sum.Toplama.sum(22617, 16804);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39421 + "'", int2 == 39421);
    }

    @Test
    public void test2689() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2689");
        int int2 = sum.Toplama.sum(14197, 8671);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22868 + "'", int2 == 22868);
    }

    @Test
    public void test2690() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2690");
        int int2 = sum.Toplama.sum(2788, 5541);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8329 + "'", int2 == 8329);
    }

    @Test
    public void test2691() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2691");
        int int2 = sum.Toplama.sum(5512, 3281);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8793 + "'", int2 == 8793);
    }

    @Test
    public void test2692() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2692");
        int int2 = sum.Toplama.sum(616, 33885);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34501 + "'", int2 == 34501);
    }

    @Test
    public void test2693() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2693");
        int int2 = sum.Toplama.sum((int) (short) -1, 6586);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6585 + "'", int2 == 6585);
    }

    @Test
    public void test2694() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2694");
        int int2 = sum.Toplama.sum(2723, 1584);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4307 + "'", int2 == 4307);
    }

    @Test
    public void test2695() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2695");
        int int2 = sum.Toplama.sum(1917, 7126);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9043 + "'", int2 == 9043);
    }

    @Test
    public void test2696() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2696");
        int int2 = sum.Toplama.sum(0, 25852);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25852 + "'", int2 == 25852);
    }

    @Test
    public void test2697() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2697");
        int int2 = sum.Toplama.sum(5764, 17073);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22837 + "'", int2 == 22837);
    }

    @Test
    public void test2698() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2698");
        int int2 = sum.Toplama.sum(5440, 1069);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6509 + "'", int2 == 6509);
    }

    @Test
    public void test2699() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2699");
        int int2 = sum.Toplama.sum(1287, 10945);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12232 + "'", int2 == 12232);
    }

    @Test
    public void test2700() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2700");
        int int2 = sum.Toplama.sum(300, 10018);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10318 + "'", int2 == 10318);
    }

    @Test
    public void test2701() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2701");
        int int2 = sum.Toplama.sum(16109, 3012);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19121 + "'", int2 == 19121);
    }

    @Test
    public void test2702() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2702");
        int int2 = sum.Toplama.sum(3995, 2282);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6277 + "'", int2 == 6277);
    }

    @Test
    public void test2703() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2703");
        int int2 = sum.Toplama.sum(1639, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1691 + "'", int2 == 1691);
    }

    @Test
    public void test2704() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2704");
        int int2 = sum.Toplama.sum(8883, 3511);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12394 + "'", int2 == 12394);
    }

    @Test
    public void test2705() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2705");
        int int2 = sum.Toplama.sum(6808, 12499);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19307 + "'", int2 == 19307);
    }

    @Test
    public void test2706() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2706");
        int int2 = sum.Toplama.sum(5382, 30709);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36091 + "'", int2 == 36091);
    }

    @Test
    public void test2707() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2707");
        int int2 = sum.Toplama.sum(27430, 3356);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30786 + "'", int2 == 30786);
    }

    @Test
    public void test2708() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2708");
        int int2 = sum.Toplama.sum(4855, 7225);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12080 + "'", int2 == 12080);
    }

    @Test
    public void test2709() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2709");
        int int2 = sum.Toplama.sum(379, 6152);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6531 + "'", int2 == 6531);
    }

    @Test
    public void test2710() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2710");
        int int2 = sum.Toplama.sum(2953, 1010);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3963 + "'", int2 == 3963);
    }

    @Test
    public void test2711() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2711");
        int int2 = sum.Toplama.sum(9745, 12556);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22301 + "'", int2 == 22301);
    }

    @Test
    public void test2712() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2712");
        int int2 = sum.Toplama.sum(19365, 7222);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26587 + "'", int2 == 26587);
    }

    @Test
    public void test2713() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2713");
        int int2 = sum.Toplama.sum(3950, 2000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5950 + "'", int2 == 5950);
    }

    @Test
    public void test2714() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2714");
        int int2 = sum.Toplama.sum(9004, 3918);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12922 + "'", int2 == 12922);
    }

    @Test
    public void test2715() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2715");
        int int2 = sum.Toplama.sum(10154, 2905);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13059 + "'", int2 == 13059);
    }

    @Test
    public void test2716() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2716");
        int int2 = sum.Toplama.sum(5188, 9677);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14865 + "'", int2 == 14865);
    }

    @Test
    public void test2717() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2717");
        int int2 = sum.Toplama.sum(7024, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7024 + "'", int2 == 7024);
    }

    @Test
    public void test2718() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2718");
        int int2 = sum.Toplama.sum(36949, 6594);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43543 + "'", int2 == 43543);
    }

    @Test
    public void test2719() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2719");
        int int2 = sum.Toplama.sum(7840, 3078);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10918 + "'", int2 == 10918);
    }

    @Test
    public void test2720() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2720");
        int int2 = sum.Toplama.sum(6092, 14437);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20529 + "'", int2 == 20529);
    }

    @Test
    public void test2721() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2721");
        int int2 = sum.Toplama.sum(3689, 18820);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22509 + "'", int2 == 22509);
    }

    @Test
    public void test2722() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2722");
        int int2 = sum.Toplama.sum(21362, 12405);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33767 + "'", int2 == 33767);
    }

    @Test
    public void test2723() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2723");
        int int2 = sum.Toplama.sum(307, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 307 + "'", int2 == 307);
    }

    @Test
    public void test2724() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2724");
        int int2 = sum.Toplama.sum(1292, 9971);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11263 + "'", int2 == 11263);
    }

    @Test
    public void test2725() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2725");
        int int2 = sum.Toplama.sum(9916, 18228);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28144 + "'", int2 == 28144);
    }

    @Test
    public void test2726() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2726");
        int int2 = sum.Toplama.sum(1213, 12919);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14132 + "'", int2 == 14132);
    }

    @Test
    public void test2727() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2727");
        int int2 = sum.Toplama.sum(14719, 3106);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17825 + "'", int2 == 17825);
    }

    @Test
    public void test2728() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2728");
        int int2 = sum.Toplama.sum(2258, 10079);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12337 + "'", int2 == 12337);
    }

    @Test
    public void test2729() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2729");
        int int2 = sum.Toplama.sum(1213, 15976);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17189 + "'", int2 == 17189);
    }

    @Test
    public void test2730() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2730");
        int int2 = sum.Toplama.sum(31502, 23031);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54533 + "'", int2 == 54533);
    }

    @Test
    public void test2731() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2731");
        int int2 = sum.Toplama.sum(2166, 199);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2365 + "'", int2 == 2365);
    }

    @Test
    public void test2732() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2732");
        int int2 = sum.Toplama.sum(5855, 7224);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13079 + "'", int2 == 13079);
    }

    @Test
    public void test2733() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2733");
        int int2 = sum.Toplama.sum(27913, 1522);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29435 + "'", int2 == 29435);
    }

    @Test
    public void test2734() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2734");
        int int2 = sum.Toplama.sum(1665, 1666);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3331 + "'", int2 == 3331);
    }

    @Test
    public void test2735() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2735");
        int int2 = sum.Toplama.sum(16878, 5881);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22759 + "'", int2 == 22759);
    }

    @Test
    public void test2736() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2736");
        int int2 = sum.Toplama.sum(3833, 10461);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14294 + "'", int2 == 14294);
    }

    @Test
    public void test2737() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2737");
        int int2 = sum.Toplama.sum(2893, 5224);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8117 + "'", int2 == 8117);
    }

    @Test
    public void test2738() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2738");
        int int2 = sum.Toplama.sum(806, 21060);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21866 + "'", int2 == 21866);
    }

    @Test
    public void test2739() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2739");
        int int2 = sum.Toplama.sum(12180, 57084);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69264 + "'", int2 == 69264);
    }

    @Test
    public void test2740() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2740");
        int int2 = sum.Toplama.sum(16902, 200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17102 + "'", int2 == 17102);
    }

    @Test
    public void test2741() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2741");
        int int2 = sum.Toplama.sum(0, 36052);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36052 + "'", int2 == 36052);
    }

    @Test
    public void test2742() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2742");
        int int2 = sum.Toplama.sum(4597, 2282);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6879 + "'", int2 == 6879);
    }

    @Test
    public void test2743() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2743");
        int int2 = sum.Toplama.sum(4215, 3460);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7675 + "'", int2 == 7675);
    }

    @Test
    public void test2744() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2744");
        int int2 = sum.Toplama.sum(10867, 2386);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13253 + "'", int2 == 13253);
    }

    @Test
    public void test2745() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2745");
        int int2 = sum.Toplama.sum(1422, 12363);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13785 + "'", int2 == 13785);
    }

    @Test
    public void test2746() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2746");
        int int2 = sum.Toplama.sum(25067, 29032);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54099 + "'", int2 == 54099);
    }

    @Test
    public void test2747() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2747");
        int int2 = sum.Toplama.sum(4539, 6214);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10753 + "'", int2 == 10753);
    }

    @Test
    public void test2748() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2748");
        int int2 = sum.Toplama.sum(23276, 1068);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24344 + "'", int2 == 24344);
    }

    @Test
    public void test2749() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2749");
        int int2 = sum.Toplama.sum(4808, 610);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5418 + "'", int2 == 5418);
    }

    @Test
    public void test2750() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2750");
        int int2 = sum.Toplama.sum(11603, 8898);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20501 + "'", int2 == 20501);
    }

    @Test
    public void test2751() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2751");
        int int2 = sum.Toplama.sum(37864, 34445);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72309 + "'", int2 == 72309);
    }

    @Test
    public void test2752() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2752");
        int int2 = sum.Toplama.sum(1579, 1747);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3326 + "'", int2 == 3326);
    }

    @Test
    public void test2753() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2753");
        int int2 = sum.Toplama.sum(0, 3943);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3943 + "'", int2 == 3943);
    }

    @Test
    public void test2754() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2754");
        int int2 = sum.Toplama.sum(6850, 20924);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27774 + "'", int2 == 27774);
    }

    @Test
    public void test2755() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2755");
        int int2 = sum.Toplama.sum(838, 5783);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6621 + "'", int2 == 6621);
    }

    @Test
    public void test2756() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2756");
        int int2 = sum.Toplama.sum(10990, 5335);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16325 + "'", int2 == 16325);
    }

    @Test
    public void test2757() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2757");
        int int2 = sum.Toplama.sum(2797, 10023);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12820 + "'", int2 == 12820);
    }

    @Test
    public void test2758() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2758");
        int int2 = sum.Toplama.sum(1966, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1966 + "'", int2 == 1966);
    }

    @Test
    public void test2759() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2759");
        int int2 = sum.Toplama.sum(7488, 1562);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9050 + "'", int2 == 9050);
    }

    @Test
    public void test2760() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2760");
        int int2 = sum.Toplama.sum(29853, 9689);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39542 + "'", int2 == 39542);
    }

    @Test
    public void test2761() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2761");
        int int2 = sum.Toplama.sum(7840, 8219);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16059 + "'", int2 == 16059);
    }

    @Test
    public void test2762() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2762");
        int int2 = sum.Toplama.sum(5703, 6610);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12313 + "'", int2 == 12313);
    }

    @Test
    public void test2763() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2763");
        int int2 = sum.Toplama.sum(10045, 1139);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11184 + "'", int2 == 11184);
    }

    @Test
    public void test2764() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2764");
        int int2 = sum.Toplama.sum(7002, 23031);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30033 + "'", int2 == 30033);
    }

    @Test
    public void test2765() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2765");
        int int2 = sum.Toplama.sum(1694, 5125);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6819 + "'", int2 == 6819);
    }

    @Test
    public void test2766() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2766");
        int int2 = sum.Toplama.sum(30366, 20088);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50454 + "'", int2 == 50454);
    }

    @Test
    public void test2767() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2767");
        int int2 = sum.Toplama.sum(8607, 24301);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32908 + "'", int2 == 32908);
    }

    @Test
    public void test2768() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2768");
        int int2 = sum.Toplama.sum(0, 4211);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4211 + "'", int2 == 4211);
    }

    @Test
    public void test2769() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2769");
        int int2 = sum.Toplama.sum(8506, 3044);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11550 + "'", int2 == 11550);
    }

    @Test
    public void test2770() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2770");
        int int2 = sum.Toplama.sum(32908, 45623);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78531 + "'", int2 == 78531);
    }

    @Test
    public void test2771() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2771");
        int int2 = sum.Toplama.sum(9045, 38760);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47805 + "'", int2 == 47805);
    }

    @Test
    public void test2772() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2772");
        int int2 = sum.Toplama.sum(5354, 13496);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18850 + "'", int2 == 18850);
    }

    @Test
    public void test2773() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2773");
        int int2 = sum.Toplama.sum(13710, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13710 + "'", int2 == 13710);
    }

    @Test
    public void test2774() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2774");
        int int2 = sum.Toplama.sum(14002, 2643);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16645 + "'", int2 == 16645);
    }

    @Test
    public void test2775() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2775");
        int int2 = sum.Toplama.sum(49393, 51222);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100615 + "'", int2 == 100615);
    }

    @Test
    public void test2776() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2776");
        int int2 = sum.Toplama.sum(2352, 3503);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5855 + "'", int2 == 5855);
    }

    @Test
    public void test2777() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2777");
        int int2 = sum.Toplama.sum(10018, 3911);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13929 + "'", int2 == 13929);
    }

    @Test
    public void test2778() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2778");
        int int2 = sum.Toplama.sum(1337, 4582);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5919 + "'", int2 == 5919);
    }

    @Test
    public void test2779() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2779");
        int int2 = sum.Toplama.sum(13027, 13390);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26417 + "'", int2 == 26417);
    }

    @Test
    public void test2780() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2780");
        int int2 = sum.Toplama.sum(7917, 2215);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10132 + "'", int2 == 10132);
    }

    @Test
    public void test2781() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2781");
        int int2 = sum.Toplama.sum(13566, 11258);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24824 + "'", int2 == 24824);
    }

    @Test
    public void test2782() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2782");
        int int2 = sum.Toplama.sum(7053, 8414);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15467 + "'", int2 == 15467);
    }

    @Test
    public void test2783() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2783");
        int int2 = sum.Toplama.sum(15251, 4986);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20237 + "'", int2 == 20237);
    }

    @Test
    public void test2784() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2784");
        int int2 = sum.Toplama.sum(21936, 6144);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28080 + "'", int2 == 28080);
    }

    @Test
    public void test2785() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2785");
        int int2 = sum.Toplama.sum(24887, 25339);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50226 + "'", int2 == 50226);
    }

    @Test
    public void test2786() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2786");
        int int2 = sum.Toplama.sum(7736, 13686);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21422 + "'", int2 == 21422);
    }

    @Test
    public void test2787() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2787");
        int int2 = sum.Toplama.sum(999, 13731);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14730 + "'", int2 == 14730);
    }

    @Test
    public void test2788() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2788");
        int int2 = sum.Toplama.sum(5919, 25922);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31841 + "'", int2 == 31841);
    }

    @Test
    public void test2789() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2789");
        int int2 = sum.Toplama.sum(4567, 1213);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5780 + "'", int2 == 5780);
    }

    @Test
    public void test2790() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2790");
        int int2 = sum.Toplama.sum(18053, 7651);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25704 + "'", int2 == 25704);
    }

    @Test
    public void test2791() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2791");
        int int2 = sum.Toplama.sum(8692, 17012);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25704 + "'", int2 == 25704);
    }

    @Test
    public void test2792() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2792");
        int int2 = sum.Toplama.sum(19130, 11651);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30781 + "'", int2 == 30781);
    }

    @Test
    public void test2793() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2793");
        int int2 = sum.Toplama.sum(6978, 8139);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15117 + "'", int2 == 15117);
    }

    @Test
    public void test2794() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2794");
        int int2 = sum.Toplama.sum(23546, 8370);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31916 + "'", int2 == 31916);
    }

    @Test
    public void test2795() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2795");
        int int2 = sum.Toplama.sum(11167, 10953);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22120 + "'", int2 == 22120);
    }

    @Test
    public void test2796() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2796");
        int int2 = sum.Toplama.sum(3987, 11434);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15421 + "'", int2 == 15421);
    }

    @Test
    public void test2797() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2797");
        int int2 = sum.Toplama.sum(3040, 5783);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8823 + "'", int2 == 8823);
    }

    @Test
    public void test2798() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2798");
        int int2 = sum.Toplama.sum(595, 2598);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3193 + "'", int2 == 3193);
    }

    @Test
    public void test2799() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2799");
        int int2 = sum.Toplama.sum(8963, 4563);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13526 + "'", int2 == 13526);
    }

    @Test
    public void test2800() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2800");
        int int2 = sum.Toplama.sum(632, 1232);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1864 + "'", int2 == 1864);
    }

    @Test
    public void test2801() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2801");
        int int2 = sum.Toplama.sum(1572, 2410);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3982 + "'", int2 == 3982);
    }

    @Test
    public void test2802() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2802");
        int int2 = sum.Toplama.sum(11713, 6199);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17912 + "'", int2 == 17912);
    }

    @Test
    public void test2803() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2803");
        int int2 = sum.Toplama.sum(1005, 1365);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2370 + "'", int2 == 2370);
    }

    @Test
    public void test2804() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2804");
        int int2 = sum.Toplama.sum(1085, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1085 + "'", int2 == 1085);
    }

    @Test
    public void test2805() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2805");
        int int2 = sum.Toplama.sum(15673, 4332);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20005 + "'", int2 == 20005);
    }

    @Test
    public void test2806() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2806");
        int int2 = sum.Toplama.sum(2272, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2272 + "'", int2 == 2272);
    }

    @Test
    public void test2807() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2807");
        int int2 = sum.Toplama.sum(1531, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1531 + "'", int2 == 1531);
    }

    @Test
    public void test2808() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2808");
        int int2 = sum.Toplama.sum(552, 6716);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7268 + "'", int2 == 7268);
    }

    @Test
    public void test2809() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2809");
        int int2 = sum.Toplama.sum(2950, 20755);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23705 + "'", int2 == 23705);
    }

    @Test
    public void test2810() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2810");
        int int2 = sum.Toplama.sum(20005, 1060);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21065 + "'", int2 == 21065);
    }

    @Test
    public void test2811() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2811");
        int int2 = sum.Toplama.sum(7917, 5621);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13538 + "'", int2 == 13538);
    }

    @Test
    public void test2812() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2812");
        int int2 = sum.Toplama.sum(43082, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43179 + "'", int2 == 43179);
    }

    @Test
    public void test2813() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2813");
        int int2 = sum.Toplama.sum(17856, 293);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18149 + "'", int2 == 18149);
    }

    @Test
    public void test2814() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2814");
        int int2 = sum.Toplama.sum(20351, 4434);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24785 + "'", int2 == 24785);
    }

    @Test
    public void test2815() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2815");
        int int2 = sum.Toplama.sum(15421, 2045);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17466 + "'", int2 == 17466);
    }

    @Test
    public void test2816() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2816");
        int int2 = sum.Toplama.sum(4582, 8963);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13545 + "'", int2 == 13545);
    }

    @Test
    public void test2817() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2817");
        int int2 = sum.Toplama.sum(2414, 1724);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4138 + "'", int2 == 4138);
    }

    @Test
    public void test2818() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2818");
        int int2 = sum.Toplama.sum(6557, 2792);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9349 + "'", int2 == 9349);
    }

    @Test
    public void test2819() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2819");
        int int2 = sum.Toplama.sum(12514, 2284);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14798 + "'", int2 == 14798);
    }

    @Test
    public void test2820() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2820");
        int int2 = sum.Toplama.sum(1735, 43543);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45278 + "'", int2 == 45278);
    }

    @Test
    public void test2821() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2821");
        int int2 = sum.Toplama.sum(11284, 7780);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19064 + "'", int2 == 19064);
    }

    @Test
    public void test2822() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2822");
        int int2 = sum.Toplama.sum(1204, 1037);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2241 + "'", int2 == 2241);
    }

    @Test
    public void test2823() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2823");
        int int2 = sum.Toplama.sum(6914, 4902);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11816 + "'", int2 == 11816);
    }

    @Test
    public void test2824() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2824");
        int int2 = sum.Toplama.sum(4597, 10951);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15548 + "'", int2 == 15548);
    }

    @Test
    public void test2825() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2825");
        int int2 = sum.Toplama.sum(20351, 2768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23119 + "'", int2 == 23119);
    }

    @Test
    public void test2826() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2826");
        int int2 = sum.Toplama.sum(3695, 1867);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5562 + "'", int2 == 5562);
    }

    @Test
    public void test2827() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2827");
        int int2 = sum.Toplama.sum(2635, 341);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2976 + "'", int2 == 2976);
    }

    @Test
    public void test2828() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2828");
        int int2 = sum.Toplama.sum(1768, 1622);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3390 + "'", int2 == 3390);
    }

    @Test
    public void test2829() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2829");
        int int2 = sum.Toplama.sum(307, 12345);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12652 + "'", int2 == 12652);
    }

    @Test
    public void test2830() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2830");
        int int2 = sum.Toplama.sum(1041, 10900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11941 + "'", int2 == 11941);
    }

    @Test
    public void test2831() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2831");
        int int2 = sum.Toplama.sum(423, 20005);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20428 + "'", int2 == 20428);
    }

    @Test
    public void test2832() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2832");
        int int2 = sum.Toplama.sum(45278, 3814);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49092 + "'", int2 == 49092);
    }

    @Test
    public void test2833() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2833");
        int int2 = sum.Toplama.sum(1028, 48921);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49949 + "'", int2 == 49949);
    }

    @Test
    public void test2834() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2834");
        int int2 = sum.Toplama.sum(3418, 724);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4142 + "'", int2 == 4142);
    }

    @Test
    public void test2835() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2835");
        int int2 = sum.Toplama.sum(190, 19130);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19320 + "'", int2 == 19320);
    }

    @Test
    public void test2836() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2836");
        int int2 = sum.Toplama.sum(25609, 1877);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27486 + "'", int2 == 27486);
    }

    @Test
    public void test2837() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2837");
        int int2 = sum.Toplama.sum(5166, 11715);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16881 + "'", int2 == 16881);
    }

    @Test
    public void test2838() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2838");
        int int2 = sum.Toplama.sum(10953, 10396);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21349 + "'", int2 == 21349);
    }

    @Test
    public void test2839() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2839");
        int int2 = sum.Toplama.sum(4222, 817);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5039 + "'", int2 == 5039);
    }

    @Test
    public void test2840() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2840");
        int int2 = sum.Toplama.sum(6322, 1510);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7832 + "'", int2 == 7832);
    }

    @Test
    public void test2841() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2841");
        int int2 = sum.Toplama.sum(809, 17407);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18216 + "'", int2 == 18216);
    }

    @Test
    public void test2842() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2842");
        int int2 = sum.Toplama.sum(4902, 9677);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14579 + "'", int2 == 14579);
    }

    @Test
    public void test2843() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2843");
        int int2 = sum.Toplama.sum(2004, 1255);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3259 + "'", int2 == 3259);
    }

    @Test
    public void test2844() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2844");
        int int2 = sum.Toplama.sum(730, 6078);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6808 + "'", int2 == 6808);
    }

    @Test
    public void test2845() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2845");
        int int2 = sum.Toplama.sum(26085, 22098);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48183 + "'", int2 == 48183);
    }

    @Test
    public void test2846() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2846");
        int int2 = sum.Toplama.sum(64013, 20428);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 84441 + "'", int2 == 84441);
    }

    @Test
    public void test2847() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2847");
        int int2 = sum.Toplama.sum(2841, 8693);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11534 + "'", int2 == 11534);
    }

    @Test
    public void test2848() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2848");
        int int2 = sum.Toplama.sum(15362, 721);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16083 + "'", int2 == 16083);
    }

    @Test
    public void test2849() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2849");
        int int2 = sum.Toplama.sum(1839, 4916);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6755 + "'", int2 == 6755);
    }

    @Test
    public void test2850() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2850");
        int int2 = sum.Toplama.sum(9212, 3208);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12420 + "'", int2 == 12420);
    }

    @Test
    public void test2851() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2851");
        int int2 = sum.Toplama.sum(2146, 14709);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16855 + "'", int2 == 16855);
    }

    @Test
    public void test2852() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2852");
        int int2 = sum.Toplama.sum(21736, 917);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22653 + "'", int2 == 22653);
    }

    @Test
    public void test2853() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2853");
        int int2 = sum.Toplama.sum(2950, 2340);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5290 + "'", int2 == 5290);
    }

    @Test
    public void test2854() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2854");
        int int2 = sum.Toplama.sum(35929, 15704);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51633 + "'", int2 == 51633);
    }

    @Test
    public void test2855() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2855");
        int int2 = sum.Toplama.sum(2698, 369);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3067 + "'", int2 == 3067);
    }

    @Test
    public void test2856() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2856");
        int int2 = sum.Toplama.sum(5673, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5673 + "'", int2 == 5673);
    }

    @Test
    public void test2857() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2857");
        int int2 = sum.Toplama.sum(4387, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4387 + "'", int2 == 4387);
    }

    @Test
    public void test2858() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2858");
        int int2 = sum.Toplama.sum(18820, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18820 + "'", int2 == 18820);
    }

    @Test
    public void test2859() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2859");
        int int2 = sum.Toplama.sum(16774, 4730);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21504 + "'", int2 == 21504);
    }

    @Test
    public void test2860() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2860");
        int int2 = sum.Toplama.sum(8493, 5659);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14152 + "'", int2 == 14152);
    }

    @Test
    public void test2861() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2861");
        int int2 = sum.Toplama.sum(2932, 12420);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15352 + "'", int2 == 15352);
    }

    @Test
    public void test2862() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2862");
        int int2 = sum.Toplama.sum(4797, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4797 + "'", int2 == 4797);
    }

    @Test
    public void test2863() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2863");
        int int2 = sum.Toplama.sum(2905, 22665);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25570 + "'", int2 == 25570);
    }

    @Test
    public void test2864() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2864");
        int int2 = sum.Toplama.sum(9526, 25646);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35172 + "'", int2 == 35172);
    }

    @Test
    public void test2865() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2865");
        int int2 = sum.Toplama.sum(6277, 4281);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10558 + "'", int2 == 10558);
    }

    @Test
    public void test2866() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2866");
        int int2 = sum.Toplama.sum(20351, 3415);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23766 + "'", int2 == 23766);
    }

    @Test
    public void test2867() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2867");
        int int2 = sum.Toplama.sum(17306, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17306 + "'", int2 == 17306);
    }

    @Test
    public void test2868() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2868");
        int int2 = sum.Toplama.sum(12313, 10100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22413 + "'", int2 == 22413);
    }

    @Test
    public void test2869() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2869");
        int int2 = sum.Toplama.sum(12053, 12166);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24219 + "'", int2 == 24219);
    }

    @Test
    public void test2870() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2870");
        int int2 = sum.Toplama.sum(2148, 954);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3102 + "'", int2 == 3102);
    }

    @Test
    public void test2871() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2871");
        int int2 = sum.Toplama.sum(1260, 20154);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21414 + "'", int2 == 21414);
    }

    @Test
    public void test2872() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2872");
        int int2 = sum.Toplama.sum(9024, 30536);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39560 + "'", int2 == 39560);
    }

    @Test
    public void test2873() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2873");
        int int2 = sum.Toplama.sum(10753, 8837);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19590 + "'", int2 == 19590);
    }

    @Test
    public void test2874() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2874");
        int int2 = sum.Toplama.sum(5188, 6235);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11423 + "'", int2 == 11423);
    }

    @Test
    public void test2875() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2875");
        int int2 = sum.Toplama.sum(12696, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12696 + "'", int2 == 12696);
    }

    @Test
    public void test2876() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2876");
        int int2 = sum.Toplama.sum(6235, 870);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7105 + "'", int2 == 7105);
    }

    @Test
    public void test2877() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2877");
        int int2 = sum.Toplama.sum(10931, 13538);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24469 + "'", int2 == 24469);
    }

    @Test
    public void test2878() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2878");
        int int2 = sum.Toplama.sum(11174, 10100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21274 + "'", int2 == 21274);
    }

    @Test
    public void test2879() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2879");
        int int2 = sum.Toplama.sum(393, 50454);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50847 + "'", int2 == 50847);
    }

    @Test
    public void test2880() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2880");
        int int2 = sum.Toplama.sum(2088, 12183);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14271 + "'", int2 == 14271);
    }

    @Test
    public void test2881() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2881");
        int int2 = sum.Toplama.sum(13532, 1648);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15180 + "'", int2 == 15180);
    }

    @Test
    public void test2882() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2882");
        int int2 = sum.Toplama.sum(6199, 1521);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7720 + "'", int2 == 7720);
    }

    @Test
    public void test2883() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2883");
        int int2 = sum.Toplama.sum(7224, 19176);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26400 + "'", int2 == 26400);
    }

    @Test
    public void test2884() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2884");
        int int2 = sum.Toplama.sum(3602, 10285);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13887 + "'", int2 == 13887);
    }

    @Test
    public void test2885() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2885");
        int int2 = sum.Toplama.sum(1232, 16787);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18019 + "'", int2 == 18019);
    }

    @Test
    public void test2886() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2886");
        int int2 = sum.Toplama.sum(2820, 6983);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9803 + "'", int2 == 9803);
    }

    @Test
    public void test2887() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2887");
        int int2 = sum.Toplama.sum(21274, 46754);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68028 + "'", int2 == 68028);
    }

    @Test
    public void test2888() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2888");
        int int2 = sum.Toplama.sum(0, 5897);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5897 + "'", int2 == 5897);
    }

    @Test
    public void test2889() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2889");
        int int2 = sum.Toplama.sum(0, 36949);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36949 + "'", int2 == 36949);
    }

    @Test
    public void test2890() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2890");
        int int2 = sum.Toplama.sum(8451, 720);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9171 + "'", int2 == 9171);
    }

    @Test
    public void test2891() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2891");
        int int2 = sum.Toplama.sum(11001, 3326);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14327 + "'", int2 == 14327);
    }

    @Test
    public void test2892() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2892");
        int int2 = sum.Toplama.sum(17331, 15475);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32806 + "'", int2 == 32806);
    }

    @Test
    public void test2893() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2893");
        int int2 = sum.Toplama.sum(4493, 14815);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19308 + "'", int2 == 19308);
    }

    @Test
    public void test2894() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2894");
        int int2 = sum.Toplama.sum(8506, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8506 + "'", int2 == 8506);
    }

    @Test
    public void test2895() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2895");
        int int2 = sum.Toplama.sum(2146, 1101);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3247 + "'", int2 == 3247);
    }

    @Test
    public void test2896() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2896");
        int int2 = sum.Toplama.sum(33885, 9902);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43787 + "'", int2 == 43787);
    }

    @Test
    public void test2897() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2897");
        int int2 = sum.Toplama.sum(3965, 17040);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21005 + "'", int2 == 21005);
    }

    @Test
    public void test2898() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2898");
        int int2 = sum.Toplama.sum(20428, 12345);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32773 + "'", int2 == 32773);
    }

    @Test
    public void test2899() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2899");
        int int2 = sum.Toplama.sum(10154, 1060);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11214 + "'", int2 == 11214);
    }

    @Test
    public void test2900() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2900");
        int int2 = sum.Toplama.sum(13741, 6078);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19819 + "'", int2 == 19819);
    }

    @Test
    public void test2901() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2901");
        int int2 = sum.Toplama.sum(140, 2698);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2838 + "'", int2 == 2838);
    }

    @Test
    public void test2902() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2902");
        int int2 = sum.Toplama.sum(52, 468);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 520 + "'", int2 == 520);
    }

    @Test
    public void test2903() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2903");
        int int2 = sum.Toplama.sum(870, 6152);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7022 + "'", int2 == 7022);
    }

    @Test
    public void test2904() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2904");
        int int2 = sum.Toplama.sum(17985, 6594);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24579 + "'", int2 == 24579);
    }

    @Test
    public void test2905() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2905");
        int int2 = sum.Toplama.sum(17856, 17114);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34970 + "'", int2 == 34970);
    }

    @Test
    public void test2906() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2906");
        int int2 = sum.Toplama.sum(1877, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1877 + "'", int2 == 1877);
    }

    @Test
    public void test2907() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2907");
        int int2 = sum.Toplama.sum(10321, 29044);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39365 + "'", int2 == 39365);
    }

    @Test
    public void test2908() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2908");
        int int2 = sum.Toplama.sum(8168, 9846);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18014 + "'", int2 == 18014);
    }

    @Test
    public void test2909() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2909");
        int int2 = sum.Toplama.sum(5541, 29305);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34846 + "'", int2 == 34846);
    }

    @Test
    public void test2910() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2910");
        int int2 = sum.Toplama.sum(10023, 1239);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11262 + "'", int2 == 11262);
    }

    @Test
    public void test2911() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2911");
        int int2 = sum.Toplama.sum(1005, 8084);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9089 + "'", int2 == 9089);
    }

    @Test
    public void test2912() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2912");
        int int2 = sum.Toplama.sum(1265, 7745);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9010 + "'", int2 == 9010);
    }

    @Test
    public void test2913() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2913");
        int int2 = sum.Toplama.sum(24785, 468);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25253 + "'", int2 == 25253);
    }

    @Test
    public void test2914() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2914");
        int int2 = sum.Toplama.sum(14631, 6119);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20750 + "'", int2 == 20750);
    }

    @Test
    public void test2915() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2915");
        int int2 = sum.Toplama.sum(1000, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1000 + "'", int2 == 1000);
    }

    @Test
    public void test2916() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2916");
        int int2 = sum.Toplama.sum(17253, 6159);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23412 + "'", int2 == 23412);
    }

    @Test
    public void test2917() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2917");
        int int2 = sum.Toplama.sum(5268, 384);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5652 + "'", int2 == 5652);
    }

    @Test
    public void test2918() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2918");
        int int2 = sum.Toplama.sum(4827, 640);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5467 + "'", int2 == 5467);
    }

    @Test
    public void test2919() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2919");
        int int2 = sum.Toplama.sum(24579, 5420);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29999 + "'", int2 == 29999);
    }

    @Test
    public void test2920() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2920");
        int int2 = sum.Toplama.sum(1840, 5208);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7048 + "'", int2 == 7048);
    }

    @Test
    public void test2921() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2921");
        int int2 = sum.Toplama.sum(46754, 6326);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53080 + "'", int2 == 53080);
    }

    @Test
    public void test2922() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2922");
        int int2 = sum.Toplama.sum(14467, 13765);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28232 + "'", int2 == 28232);
    }

    @Test
    public void test2923() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2923");
        int int2 = sum.Toplama.sum(35479, 19442);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54921 + "'", int2 == 54921);
    }

    @Test
    public void test2924() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2924");
        int int2 = sum.Toplama.sum(2258, 6692);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8950 + "'", int2 == 8950);
    }

    @Test
    public void test2925() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2925");
        int int2 = sum.Toplama.sum(9618, 4931);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14549 + "'", int2 == 14549);
    }

    @Test
    public void test2926() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2926");
        int int2 = sum.Toplama.sum(72309, 10877);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 83186 + "'", int2 == 83186);
    }

    @Test
    public void test2927() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2927");
        int int2 = sum.Toplama.sum(25570, 6593);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32163 + "'", int2 == 32163);
    }

    @Test
    public void test2928() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2928");
        int int2 = sum.Toplama.sum(45623, 548);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46171 + "'", int2 == 46171);
    }

    @Test
    public void test2929() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2929");
        int int2 = sum.Toplama.sum(1672, 6382);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8054 + "'", int2 == 8054);
    }

    @Test
    public void test2930() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2930");
        int int2 = sum.Toplama.sum(753, 261);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1014 + "'", int2 == 1014);
    }

    @Test
    public void test2931() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2931");
        int int2 = sum.Toplama.sum(7306, 230);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7536 + "'", int2 == 7536);
    }

    @Test
    public void test2932() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2932");
        int int2 = sum.Toplama.sum(3410, 13079);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16489 + "'", int2 == 16489);
    }

    @Test
    public void test2933() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2933");
        int int2 = sum.Toplama.sum(0, 12309);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12309 + "'", int2 == 12309);
    }

    @Test
    public void test2934() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2934");
        int int2 = sum.Toplama.sum(2329, 1955);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4284 + "'", int2 == 4284);
    }

    @Test
    public void test2935() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2935");
        int int2 = sum.Toplama.sum(10246, 21065);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31311 + "'", int2 == 31311);
    }

    @Test
    public void test2936() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2936");
        int int2 = sum.Toplama.sum(34758, 5922);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40680 + "'", int2 == 40680);
    }

    @Test
    public void test2937() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2937");
        int int2 = sum.Toplama.sum(19425, 5859);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25284 + "'", int2 == 25284);
    }

    @Test
    public void test2938() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2938");
        int int2 = sum.Toplama.sum(640, 3924);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4564 + "'", int2 == 4564);
    }

    @Test
    public void test2939() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2939");
        int int2 = sum.Toplama.sum(508, 149);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 657 + "'", int2 == 657);
    }

    @Test
    public void test2940() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2940");
        int int2 = sum.Toplama.sum(6503, 20755);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27258 + "'", int2 == 27258);
    }

    @Test
    public void test2941() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2941");
        int int2 = sum.Toplama.sum(9310, 7963);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17273 + "'", int2 == 17273);
    }

    @Test
    public void test2942() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2942");
        int int2 = sum.Toplama.sum(1531, 2572);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4103 + "'", int2 == 4103);
    }

    @Test
    public void test2943() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2943");
        int int2 = sum.Toplama.sum(8901, 13423);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22324 + "'", int2 == 22324);
    }

    @Test
    public void test2944() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2944");
        int int2 = sum.Toplama.sum(9010, 2292);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11302 + "'", int2 == 11302);
    }

    @Test
    public void test2945() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2945");
        int int2 = sum.Toplama.sum(11284, 11820);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23104 + "'", int2 == 23104);
    }

    @Test
    public void test2946() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2946");
        int int2 = sum.Toplama.sum(11436, 7180);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18616 + "'", int2 == 18616);
    }

    @Test
    public void test2947() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2947");
        int int2 = sum.Toplama.sum(5901, 3716);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9617 + "'", int2 == 9617);
    }

    @Test
    public void test2948() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2948");
        int int2 = sum.Toplama.sum(15812, 2814);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18626 + "'", int2 == 18626);
    }

    @Test
    public void test2949() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2949");
        int int2 = sum.Toplama.sum(5519, 2835);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8354 + "'", int2 == 8354);
    }

    @Test
    public void test2950() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2950");
        int int2 = sum.Toplama.sum(14431, 270);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14701 + "'", int2 == 14701);
    }

    @Test
    public void test2951() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2951");
        int int2 = sum.Toplama.sum(1877, 1570);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3447 + "'", int2 == 3447);
    }

    @Test
    public void test2952() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2952");
        int int2 = sum.Toplama.sum(22956, 1023);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23979 + "'", int2 == 23979);
    }

    @Test
    public void test2953() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2953");
        int int2 = sum.Toplama.sum(7368, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7368 + "'", int2 == 7368);
    }

    @Test
    public void test2954() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2954");
        int int2 = sum.Toplama.sum(10904, 4025);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14929 + "'", int2 == 14929);
    }

    @Test
    public void test2955() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2955");
        int int2 = sum.Toplama.sum(2535, 1694);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4229 + "'", int2 == 4229);
    }

    @Test
    public void test2956() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2956");
        int int2 = sum.Toplama.sum(5652, 4368);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10020 + "'", int2 == 10020);
    }

    @Test
    public void test2957() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2957");
        int int2 = sum.Toplama.sum(110, 8948);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9058 + "'", int2 == 9058);
    }

    @Test
    public void test2958() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2958");
        int int2 = sum.Toplama.sum((int) '4', 30786);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30838 + "'", int2 == 30838);
    }

    @Test
    public void test2959() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2959");
        int int2 = sum.Toplama.sum(21275, 13149);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34424 + "'", int2 == 34424);
    }

    @Test
    public void test2960() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2960");
        int int2 = sum.Toplama.sum(7608, 1060);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8668 + "'", int2 == 8668);
    }

    @Test
    public void test2961() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2961");
        int int2 = sum.Toplama.sum(2582, 24824);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27406 + "'", int2 == 27406);
    }

    @Test
    public void test2962() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2962");
        int int2 = sum.Toplama.sum(2952, 11184);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14136 + "'", int2 == 14136);
    }

    @Test
    public void test2963() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2963");
        int int2 = sum.Toplama.sum(23356, 8041);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31397 + "'", int2 == 31397);
    }

    @Test
    public void test2964() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2964");
        int int2 = sum.Toplama.sum(18983, 7666);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26649 + "'", int2 == 26649);
    }

    @Test
    public void test2965() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2965");
        int int2 = sum.Toplama.sum(1832, 6819);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8651 + "'", int2 == 8651);
    }

    @Test
    public void test2966() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2966");
        int int2 = sum.Toplama.sum(20755, 30536);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51291 + "'", int2 == 51291);
    }

    @Test
    public void test2967() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2967");
        int int2 = sum.Toplama.sum(18195, 1139);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19334 + "'", int2 == 19334);
    }

    @Test
    public void test2968() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2968");
        int int2 = sum.Toplama.sum(15812, 6062);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21874 + "'", int2 == 21874);
    }

    @Test
    public void test2969() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2969");
        int int2 = sum.Toplama.sum(10883, 2933);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13816 + "'", int2 == 13816);
    }

    @Test
    public void test2970() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2970");
        int int2 = sum.Toplama.sum(2838, 14045);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16883 + "'", int2 == 16883);
    }

    @Test
    public void test2971() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2971");
        int int2 = sum.Toplama.sum(7258, 1522);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8780 + "'", int2 == 8780);
    }

    @Test
    public void test2972() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2972");
        int int2 = sum.Toplama.sum(12610, 9473);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22083 + "'", int2 == 22083);
    }

    @Test
    public void test2973() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2973");
        int int2 = sum.Toplama.sum(2851, 1917);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4768 + "'", int2 == 4768);
    }

    @Test
    public void test2974() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2974");
        int int2 = sum.Toplama.sum(4730, 25704);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30434 + "'", int2 == 30434);
    }

    @Test
    public void test2975() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2975");
        int int2 = sum.Toplama.sum(7428, 11592);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19020 + "'", int2 == 19020);
    }

    @Test
    public void test2976() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2976");
        int int2 = sum.Toplama.sum(0, 29853);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29853 + "'", int2 == 29853);
    }

    @Test
    public void test2977() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2977");
        int int2 = sum.Toplama.sum(12313, 2103);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14416 + "'", int2 == 14416);
    }

    @Test
    public void test2978() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2978");
        int int2 = sum.Toplama.sum(921, 2055);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2976 + "'", int2 == 2976);
    }

    @Test
    public void test2979() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2979");
        int int2 = sum.Toplama.sum(624, 6330);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6954 + "'", int2 == 6954);
    }

    @Test
    public void test2980() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2980");
        int int2 = sum.Toplama.sum(6843, 630);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7473 + "'", int2 == 7473);
    }

    @Test
    public void test2981() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2981");
        int int2 = sum.Toplama.sum(20178, 5635);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25813 + "'", int2 == 25813);
    }

    @Test
    public void test2982() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2982");
        int int2 = sum.Toplama.sum(6465, 4222);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10687 + "'", int2 == 10687);
    }

    @Test
    public void test2983() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2983");
        int int2 = sum.Toplama.sum(7582, 28232);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35814 + "'", int2 == 35814);
    }

    @Test
    public void test2984() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2984");
        int int2 = sum.Toplama.sum(30496, 31311);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61807 + "'", int2 == 61807);
    }

    @Test
    public void test2985() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2985");
        int int2 = sum.Toplama.sum(18850, 5881);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24731 + "'", int2 == 24731);
    }

    @Test
    public void test2986() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2986");
        int int2 = sum.Toplama.sum(2249, 2437);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4686 + "'", int2 == 4686);
    }

    @Test
    public void test2987() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2987");
        int int2 = sum.Toplama.sum(11790, 6714);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18504 + "'", int2 == 18504);
    }

    @Test
    public void test2988() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2988");
        int int2 = sum.Toplama.sum(117, 12461);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12578 + "'", int2 == 12578);
    }

    @Test
    public void test2989() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2989");
        int int2 = sum.Toplama.sum(0, 16787);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16787 + "'", int2 == 16787);
    }

    @Test
    public void test2990() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2990");
        int int2 = sum.Toplama.sum(15007, 3892);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18899 + "'", int2 == 18899);
    }

    @Test
    public void test2991() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2991");
        int int2 = sum.Toplama.sum(8113, 4552);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12665 + "'", int2 == 12665);
    }

    @Test
    public void test2992() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2992");
        int int2 = sum.Toplama.sum(7459, 12136);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19595 + "'", int2 == 19595);
    }

    @Test
    public void test2993() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2993");
        int int2 = sum.Toplama.sum(7180, 10753);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17933 + "'", int2 == 17933);
    }

    @Test
    public void test2994() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2994");
        int int2 = sum.Toplama.sum(19406, 14709);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34115 + "'", int2 == 34115);
    }

    @Test
    public void test2995() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2995");
        int int2 = sum.Toplama.sum(11746, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11746 + "'", int2 == 11746);
    }

    @Test
    public void test2996() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2996");
        int int2 = sum.Toplama.sum(1683, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1780 + "'", int2 == 1780);
    }

    @Test
    public void test2997() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2997");
        int int2 = sum.Toplama.sum(1041, 10552);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11593 + "'", int2 == 11593);
    }

    @Test
    public void test2998() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2998");
        int int2 = sum.Toplama.sum(2347, 27430);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29777 + "'", int2 == 29777);
    }

    @Test
    public void test2999() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2999");
        int int2 = sum.Toplama.sum(9059, 2742);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11801 + "'", int2 == 11801);
    }

    @Test
    public void test3000() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test3000");
        int int2 = sum.Toplama.sum(3257, 24579);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27836 + "'", int2 == 27836);
    }
}

