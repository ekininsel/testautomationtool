import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test0001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0001");
        int int2 = sum.Toplama.sum((int) (short) -1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0002");
        int int2 = sum.Toplama.sum((int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test0003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0003");
        int int2 = sum.Toplama.sum((int) 'a', (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96 + "'", int2 == 96);
    }

    @Test
    public void test0004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0004");
        int int2 = sum.Toplama.sum(0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test0005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0005");
        int int2 = sum.Toplama.sum((int) '4', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test0006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0006");
        int int2 = sum.Toplama.sum((int) '4', (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51 + "'", int2 == 51);
    }

    @Test
    public void test0007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0007");
        int int2 = sum.Toplama.sum(100, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test0008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0008");
        int int2 = sum.Toplama.sum((int) (byte) -1, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51 + "'", int2 == 51);
    }

    @Test
    public void test0009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0009");
        int int2 = sum.Toplama.sum(52, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51 + "'", int2 == 51);
    }

    @Test
    public void test0010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0010");
        int int2 = sum.Toplama.sum((int) ' ', (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64 + "'", int2 == 64);
    }

    @Test
    public void test0011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0011");
        int int2 = sum.Toplama.sum((int) '4', (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 152 + "'", int2 == 152);
    }

    @Test
    public void test0012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0012");
        int int2 = sum.Toplama.sum((int) (short) 100, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
    }

    @Test
    public void test0013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0013");
        int int2 = sum.Toplama.sum(0, 96);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96 + "'", int2 == 96);
    }

    @Test
    public void test0014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0014");
        int int2 = sum.Toplama.sum((int) (short) 100, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
    }

    @Test
    public void test0015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0015");
        int int2 = sum.Toplama.sum((-1), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test0016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0016");
        int int2 = sum.Toplama.sum(96, 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 195 + "'", int2 == 195);
    }

    @Test
    public void test0017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0017");
        int int2 = sum.Toplama.sum((int) (short) 100, 195);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 295 + "'", int2 == 295);
    }

    @Test
    public void test0018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0018");
        int int2 = sum.Toplama.sum(51, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
    }

    @Test
    public void test0019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0019");
        int int2 = sum.Toplama.sum((int) (byte) 100, 152);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 252 + "'", int2 == 252);
    }

    @Test
    public void test0020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0020");
        int int2 = sum.Toplama.sum((int) (short) 1, 96);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test0021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0021");
        int int2 = sum.Toplama.sum(99, 295);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 394 + "'", int2 == 394);
    }

    @Test
    public void test0022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0022");
        int int2 = sum.Toplama.sum(96, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 131 + "'", int2 == 131);
    }

    @Test
    public void test0023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0023");
        int int2 = sum.Toplama.sum((int) ' ', 64);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96 + "'", int2 == 96);
    }

    @Test
    public void test0024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0024");
        int int2 = sum.Toplama.sum((int) (short) 1, 295);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 296 + "'", int2 == 296);
    }

    @Test
    public void test0025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0025");
        int int2 = sum.Toplama.sum((int) (byte) 0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0026");
        int int2 = sum.Toplama.sum((int) (byte) 1, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53 + "'", int2 == 53);
    }

    @Test
    public void test0027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0027");
        int int2 = sum.Toplama.sum(51, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test0028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0028");
        int int2 = sum.Toplama.sum((int) (byte) 10, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 107 + "'", int2 == 107);
    }

    @Test
    public void test0029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0029");
        int int2 = sum.Toplama.sum(195, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 227 + "'", int2 == 227);
    }

    @Test
    public void test0030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0030");
        int int2 = sum.Toplama.sum(64, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 164 + "'", int2 == 164);
    }

    @Test
    public void test0031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0031");
        int int2 = sum.Toplama.sum((int) (short) -1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
    }

    @Test
    public void test0032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0032");
        int int2 = sum.Toplama.sum(195, 64);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 259 + "'", int2 == 259);
    }

    @Test
    public void test0033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0033");
        int int2 = sum.Toplama.sum((int) ' ', (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 129 + "'", int2 == 129);
    }

    @Test
    public void test0034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0034");
        int int2 = sum.Toplama.sum((int) (short) -1, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51 + "'", int2 == 51);
    }

    @Test
    public void test0035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0035");
        int int2 = sum.Toplama.sum(1, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test0036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0036");
        int int2 = sum.Toplama.sum((int) (short) 0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0037");
        int int2 = sum.Toplama.sum(296, 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 395 + "'", int2 == 395);
    }

    @Test
    public void test0038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0038");
        int int2 = sum.Toplama.sum(100, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 200 + "'", int2 == 200);
    }

    @Test
    public void test0039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0039");
        int int2 = sum.Toplama.sum(252, 129);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 381 + "'", int2 == 381);
    }

    @Test
    public void test0040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0040");
        int int2 = sum.Toplama.sum(381, 96);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 477 + "'", int2 == 477);
    }

    @Test
    public void test0041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0041");
        int int2 = sum.Toplama.sum(107, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 106 + "'", int2 == 106);
    }

    @Test
    public void test0042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0042");
        int int2 = sum.Toplama.sum(395, 296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 691 + "'", int2 == 691);
    }

    @Test
    public void test0043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0043");
        int int2 = sum.Toplama.sum((-1), (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0044");
        int int2 = sum.Toplama.sum(53, 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64 + "'", int2 == 64);
    }

    @Test
    public void test0045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0045");
        int int2 = sum.Toplama.sum((int) (byte) 10, 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 109 + "'", int2 == 109);
    }

    @Test
    public void test0046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0046");
        int int2 = sum.Toplama.sum(0, 252);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 252 + "'", int2 == 252);
    }

    @Test
    public void test0047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0047");
        int int2 = sum.Toplama.sum(295, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 294 + "'", int2 == 294);
    }

    @Test
    public void test0048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0048");
        int int2 = sum.Toplama.sum(64, 295);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 359 + "'", int2 == 359);
    }

    @Test
    public void test0049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0049");
        int int2 = sum.Toplama.sum(359, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 358 + "'", int2 == 358);
    }

    @Test
    public void test0050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0050");
        int int2 = sum.Toplama.sum((int) (byte) 1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test0051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0051");
        int int2 = sum.Toplama.sum(64, 53);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 117 + "'", int2 == 117);
    }

    @Test
    public void test0052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0052");
        int int2 = sum.Toplama.sum((int) 'a', 477);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 574 + "'", int2 == 574);
    }

    @Test
    public void test0053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0053");
        int int2 = sum.Toplama.sum(2, 50);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test0054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0054");
        int int2 = sum.Toplama.sum(129, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 229 + "'", int2 == 229);
    }

    @Test
    public void test0055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0055");
        int int2 = sum.Toplama.sum((-1), (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test0056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0056");
        int int2 = sum.Toplama.sum((int) (short) 1, 229);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 230 + "'", int2 == 230);
    }

    @Test
    public void test0057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0057");
        int int2 = sum.Toplama.sum((int) (short) 10, 51);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61 + "'", int2 == 61);
    }

    @Test
    public void test0058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0058");
        int int2 = sum.Toplama.sum(117, 296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 413 + "'", int2 == 413);
    }

    @Test
    public void test0059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0059");
        int int2 = sum.Toplama.sum(227, 152);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 379 + "'", int2 == 379);
    }

    @Test
    public void test0060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0060");
        int int2 = sum.Toplama.sum(117, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 149 + "'", int2 == 149);
    }

    @Test
    public void test0061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0061");
        int int2 = sum.Toplama.sum(413, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 413 + "'", int2 == 413);
    }

    @Test
    public void test0062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0062");
        int int2 = sum.Toplama.sum(11, 53);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64 + "'", int2 == 64);
    }

    @Test
    public void test0063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0063");
        int int2 = sum.Toplama.sum(11, 296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 307 + "'", int2 == 307);
    }

    @Test
    public void test0064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0064");
        int int2 = sum.Toplama.sum(381, 259);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 640 + "'", int2 == 640);
    }

    @Test
    public void test0065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0065");
        int int2 = sum.Toplama.sum(0, 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
    }

    @Test
    public void test0066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0066");
        int int2 = sum.Toplama.sum(0, 131);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 131 + "'", int2 == 131);
    }

    @Test
    public void test0067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0067");
        int int2 = sum.Toplama.sum(117, 252);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 369 + "'", int2 == 369);
    }

    @Test
    public void test0068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0068");
        int int2 = sum.Toplama.sum(227, 195);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 422 + "'", int2 == 422);
    }

    @Test
    public void test0069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0069");
        int int2 = sum.Toplama.sum((int) ' ', 395);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 427 + "'", int2 == 427);
    }

    @Test
    public void test0070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0070");
        int int2 = sum.Toplama.sum(394, 149);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 543 + "'", int2 == 543);
    }

    @Test
    public void test0071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0071");
        int int2 = sum.Toplama.sum(50, 574);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 624 + "'", int2 == 624);
    }

    @Test
    public void test0072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0072");
        int int2 = sum.Toplama.sum(296, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 393 + "'", int2 == 393);
    }

    @Test
    public void test0073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0073");
        int int2 = sum.Toplama.sum(640, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 642 + "'", int2 == 642);
    }

    @Test
    public void test0074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0074");
        int int2 = sum.Toplama.sum(230, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 282 + "'", int2 == 282);
    }

    @Test
    public void test0075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0075");
        int int2 = sum.Toplama.sum(149, 359);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 508 + "'", int2 == 508);
    }

    @Test
    public void test0076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0076");
        int int2 = sum.Toplama.sum(358, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 455 + "'", int2 == 455);
    }

    @Test
    public void test0077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0077");
        int int2 = sum.Toplama.sum((int) '4', 624);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 676 + "'", int2 == 676);
    }

    @Test
    public void test0078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0078");
        int int2 = sum.Toplama.sum(230, 117);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 347 + "'", int2 == 347);
    }

    @Test
    public void test0079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0079");
        int int2 = sum.Toplama.sum(477, 107);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 584 + "'", int2 == 584);
    }

    @Test
    public void test0080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0080");
        int int2 = sum.Toplama.sum(229, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 230 + "'", int2 == 230);
    }

    @Test
    public void test0081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0081");
        int int2 = sum.Toplama.sum(99, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 151 + "'", int2 == 151);
    }

    @Test
    public void test0082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0082");
        int int2 = sum.Toplama.sum(0, 227);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 227 + "'", int2 == 227);
    }

    @Test
    public void test0083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0083");
        int int2 = sum.Toplama.sum(422, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 423 + "'", int2 == 423);
    }

    @Test
    public void test0084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0084");
        int int2 = sum.Toplama.sum(422, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 474 + "'", int2 == 474);
    }

    @Test
    public void test0085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0085");
        int int2 = sum.Toplama.sum(295, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 305 + "'", int2 == 305);
    }

    @Test
    public void test0086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0086");
        int int2 = sum.Toplama.sum((int) (byte) 1, 508);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 509 + "'", int2 == 509);
    }

    @Test
    public void test0087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0087");
        int int2 = sum.Toplama.sum(129, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 181 + "'", int2 == 181);
    }

    @Test
    public void test0088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0088");
        int int2 = sum.Toplama.sum(422, 64);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 486 + "'", int2 == 486);
    }

    @Test
    public void test0089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0089");
        int int2 = sum.Toplama.sum((int) (short) 100, 305);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 405 + "'", int2 == 405);
    }

    @Test
    public void test0090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0090");
        int int2 = sum.Toplama.sum(0, 691);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 691 + "'", int2 == 691);
    }

    @Test
    public void test0091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0091");
        int int2 = sum.Toplama.sum((int) '#', 359);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 394 + "'", int2 == 394);
    }

    @Test
    public void test0092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0092");
        int int2 = sum.Toplama.sum((int) (short) 10, 200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 210 + "'", int2 == 210);
    }

    @Test
    public void test0093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0093");
        int int2 = sum.Toplama.sum(474, 422);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 896 + "'", int2 == 896);
    }

    @Test
    public void test0094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0094");
        int int2 = sum.Toplama.sum((int) (short) 100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test0095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0095");
        int int2 = sum.Toplama.sum(107, 61);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 168 + "'", int2 == 168);
    }

    @Test
    public void test0096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0096");
        int int2 = sum.Toplama.sum(97, 422);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 519 + "'", int2 == 519);
    }

    @Test
    public void test0097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0097");
        int int2 = sum.Toplama.sum(455, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 455 + "'", int2 == 455);
    }

    @Test
    public void test0098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0098");
        int int2 = sum.Toplama.sum((int) (byte) 1, 151);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 152 + "'", int2 == 152);
    }

    @Test
    public void test0099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0099");
        int int2 = sum.Toplama.sum(64, 395);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 459 + "'", int2 == 459);
    }

    @Test
    public void test0100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0100");
        int int2 = sum.Toplama.sum((int) (byte) 100, 129);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 229 + "'", int2 == 229);
    }

    @Test
    public void test0101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0101");
        int int2 = sum.Toplama.sum(584, 151);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 735 + "'", int2 == 735);
    }

    @Test
    public void test0102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0102");
        int int2 = sum.Toplama.sum(149, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 149 + "'", int2 == 149);
    }

    @Test
    public void test0103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0103");
        int int2 = sum.Toplama.sum(61, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61 + "'", int2 == 61);
    }

    @Test
    public void test0104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0104");
        int int2 = sum.Toplama.sum(164, 642);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 806 + "'", int2 == 806);
    }

    @Test
    public void test0105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0105");
        int int2 = sum.Toplama.sum(200, 152);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 352 + "'", int2 == 352);
    }

    @Test
    public void test0106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0106");
        int int2 = sum.Toplama.sum(100, 195);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 295 + "'", int2 == 295);
    }

    @Test
    public void test0107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0107");
        int int2 = sum.Toplama.sum(294, 459);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 753 + "'", int2 == 753);
    }

    @Test
    public void test0108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0108");
        int int2 = sum.Toplama.sum(151, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 251 + "'", int2 == 251);
    }

    @Test
    public void test0109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0109");
        int int2 = sum.Toplama.sum(294, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 304 + "'", int2 == 304);
    }

    @Test
    public void test0110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0110");
        int int2 = sum.Toplama.sum(164, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 216 + "'", int2 == 216);
    }

    @Test
    public void test0111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0111");
        int int2 = sum.Toplama.sum(106, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 203 + "'", int2 == 203);
    }

    @Test
    public void test0112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0112");
        int int2 = sum.Toplama.sum(152, 474);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 626 + "'", int2 == 626);
    }

    @Test
    public void test0113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0113");
        int int2 = sum.Toplama.sum(230, 203);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 433 + "'", int2 == 433);
    }

    @Test
    public void test0114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0114");
        int int2 = sum.Toplama.sum(295, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 395 + "'", int2 == 395);
    }

    @Test
    public void test0115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0115");
        int int2 = sum.Toplama.sum(164, 210);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 374 + "'", int2 == 374);
    }

    @Test
    public void test0116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0116");
        int int2 = sum.Toplama.sum(433, 381);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 814 + "'", int2 == 814);
    }

    @Test
    public void test0117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0117");
        int int2 = sum.Toplama.sum(691, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 691 + "'", int2 == 691);
    }

    @Test
    public void test0118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0118");
        int int2 = sum.Toplama.sum(477, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 512 + "'", int2 == 512);
    }

    @Test
    public void test0119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0119");
        int int2 = sum.Toplama.sum(0, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test0120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0120");
        int int2 = sum.Toplama.sum(99, 200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 299 + "'", int2 == 299);
    }

    @Test
    public void test0121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0121");
        int int2 = sum.Toplama.sum((int) (byte) 100, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test0122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0122");
        int int2 = sum.Toplama.sum(455, 509);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 964 + "'", int2 == 964);
    }

    @Test
    public void test0123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0123");
        int int2 = sum.Toplama.sum(200, 352);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 552 + "'", int2 == 552);
    }

    @Test
    public void test0124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0124");
        int int2 = sum.Toplama.sum(203, 543);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 746 + "'", int2 == 746);
    }

    @Test
    public void test0125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0125");
        int int2 = sum.Toplama.sum(433, 477);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 910 + "'", int2 == 910);
    }

    @Test
    public void test0126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0126");
        int int2 = sum.Toplama.sum(423, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 475 + "'", int2 == 475);
    }

    @Test
    public void test0127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0127");
        int int2 = sum.Toplama.sum(509, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 544 + "'", int2 == 544);
    }

    @Test
    public void test0128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0128");
        int int2 = sum.Toplama.sum(216, 299);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 515 + "'", int2 == 515);
    }

    @Test
    public void test0129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0129");
        int int2 = sum.Toplama.sum(296, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 396 + "'", int2 == 396);
    }

    @Test
    public void test0130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0130");
        int int2 = sum.Toplama.sum((int) '#', 129);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 164 + "'", int2 == 164);
    }

    @Test
    public void test0131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0131");
        int int2 = sum.Toplama.sum(347, 395);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 742 + "'", int2 == 742);
    }

    @Test
    public void test0132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0132");
        int int2 = sum.Toplama.sum(181, 259);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 440 + "'", int2 == 440);
    }

    @Test
    public void test0133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0133");
        int int2 = sum.Toplama.sum(152, 64);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 216 + "'", int2 == 216);
    }

    @Test
    public void test0134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0134");
        int int2 = sum.Toplama.sum(395, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 405 + "'", int2 == 405);
    }

    @Test
    public void test0135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0135");
        int int2 = sum.Toplama.sum(519, 509);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1028 + "'", int2 == 1028);
    }

    @Test
    public void test0136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0136");
        int int2 = sum.Toplama.sum(624, 691);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1315 + "'", int2 == 1315);
    }

    @Test
    public void test0137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0137");
        int int2 = sum.Toplama.sum(508, 440);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 948 + "'", int2 == 948);
    }

    @Test
    public void test0138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0138");
        int int2 = sum.Toplama.sum(0, 305);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 305 + "'", int2 == 305);
    }

    @Test
    public void test0139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0139");
        int int2 = sum.Toplama.sum(152, 405);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 557 + "'", int2 == 557);
    }

    @Test
    public void test0140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0140");
        int int2 = sum.Toplama.sum(433, 64);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 497 + "'", int2 == 497);
    }

    @Test
    public void test0141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0141");
        int int2 = sum.Toplama.sum(379, 814);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1193 + "'", int2 == 1193);
    }

    @Test
    public void test0142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0142");
        int int2 = sum.Toplama.sum(181, 508);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 689 + "'", int2 == 689);
    }

    @Test
    public void test0143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0143");
        int int2 = sum.Toplama.sum(497, 544);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1041 + "'", int2 == 1041);
    }

    @Test
    public void test0144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0144");
        int int2 = sum.Toplama.sum((int) (byte) 0, 200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 200 + "'", int2 == 200);
    }

    @Test
    public void test0145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0145");
        int int2 = sum.Toplama.sum(195, 381);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 576 + "'", int2 == 576);
    }

    @Test
    public void test0146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0146");
        int int2 = sum.Toplama.sum(574, 423);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 997 + "'", int2 == 997);
    }

    @Test
    public void test0147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0147");
        int int2 = sum.Toplama.sum((int) (byte) 100, 374);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 474 + "'", int2 == 474);
    }

    @Test
    public void test0148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0148");
        int int2 = sum.Toplama.sum(1028, 149);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1177 + "'", int2 == 1177);
    }

    @Test
    public void test0149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0149");
        int int2 = sum.Toplama.sum(53, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 88 + "'", int2 == 88);
    }

    @Test
    public void test0150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0150");
        int int2 = sum.Toplama.sum(440, 107);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 547 + "'", int2 == 547);
    }

    @Test
    public void test0151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0151");
        int int2 = sum.Toplama.sum((int) '#', 164);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 199 + "'", int2 == 199);
    }

    @Test
    public void test0152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0152");
        int int2 = sum.Toplama.sum(486, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 487 + "'", int2 == 487);
    }

    @Test
    public void test0153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0153");
        int int2 = sum.Toplama.sum(107, 543);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 650 + "'", int2 == 650);
    }

    @Test
    public void test0154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0154");
        int int2 = sum.Toplama.sum(358, 381);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 739 + "'", int2 == 739);
    }

    @Test
    public void test0155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0155");
        int int2 = sum.Toplama.sum(216, 576);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 792 + "'", int2 == 792);
    }

    @Test
    public void test0156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0156");
        int int2 = sum.Toplama.sum(131, 149);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 280 + "'", int2 == 280);
    }

    @Test
    public void test0157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0157");
        int int2 = sum.Toplama.sum(508, 477);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 985 + "'", int2 == 985);
    }

    @Test
    public void test0158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0158");
        int int2 = sum.Toplama.sum(475, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 575 + "'", int2 == 575);
    }

    @Test
    public void test0159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0159");
        int int2 = sum.Toplama.sum(107, 96);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 203 + "'", int2 == 203);
    }

    @Test
    public void test0160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0160");
        int int2 = sum.Toplama.sum(304, 216);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 520 + "'", int2 == 520);
    }

    @Test
    public void test0161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0161");
        int int2 = sum.Toplama.sum(1028, 396);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1424 + "'", int2 == 1424);
    }

    @Test
    public void test0162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0162");
        int int2 = sum.Toplama.sum(985, 497);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1482 + "'", int2 == 1482);
    }

    @Test
    public void test0163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0163");
        int int2 = sum.Toplama.sum(806, 487);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1293 + "'", int2 == 1293);
    }

    @Test
    public void test0164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0164");
        int int2 = sum.Toplama.sum(216, 296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 512 + "'", int2 == 512);
    }

    @Test
    public void test0165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0165");
        int int2 = sum.Toplama.sum(487, 422);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 909 + "'", int2 == 909);
    }

    @Test
    public void test0166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0166");
        int int2 = sum.Toplama.sum(395, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 395 + "'", int2 == 395);
    }

    @Test
    public void test0167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0167");
        int int2 = sum.Toplama.sum(131, 296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 427 + "'", int2 == 427);
    }

    @Test
    public void test0168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0168");
        int int2 = sum.Toplama.sum(1193, 455);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1648 + "'", int2 == 1648);
    }

    @Test
    public void test0169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0169");
        int int2 = sum.Toplama.sum(151, 746);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 897 + "'", int2 == 897);
    }

    @Test
    public void test0170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0170");
        int int2 = sum.Toplama.sum((int) (short) 100, 88);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 188 + "'", int2 == 188);
    }

    @Test
    public void test0171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0171");
        int int2 = sum.Toplama.sum(1482, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1482 + "'", int2 == 1482);
    }

    @Test
    public void test0172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0172");
        int int2 = sum.Toplama.sum(544, 543);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1087 + "'", int2 == 1087);
    }

    @Test
    public void test0173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0173");
        int int2 = sum.Toplama.sum(164, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 164 + "'", int2 == 164);
    }

    @Test
    public void test0174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0174");
        int int2 = sum.Toplama.sum(497, 394);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 891 + "'", int2 == 891);
    }

    @Test
    public void test0175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0175");
        int int2 = sum.Toplama.sum(227, 948);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1175 + "'", int2 == 1175);
    }

    @Test
    public void test0176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0176");
        int int2 = sum.Toplama.sum(107, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 117 + "'", int2 == 117);
    }

    @Test
    public void test0177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0177");
        int int2 = sum.Toplama.sum(107, 304);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 411 + "'", int2 == 411);
    }

    @Test
    public void test0178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0178");
        int int2 = sum.Toplama.sum(296, 584);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 880 + "'", int2 == 880);
    }

    @Test
    public void test0179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0179");
        int int2 = sum.Toplama.sum((int) ' ', 1648);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1680 + "'", int2 == 1680);
    }

    @Test
    public void test0180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0180");
        int int2 = sum.Toplama.sum(411, 210);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 621 + "'", int2 == 621);
    }

    @Test
    public void test0181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0181");
        int int2 = sum.Toplama.sum(259, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 269 + "'", int2 == 269);
    }

    @Test
    public void test0182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0182");
        int int2 = sum.Toplama.sum(109, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 109 + "'", int2 == 109);
    }

    @Test
    public void test0183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0183");
        int int2 = sum.Toplama.sum(96, 1424);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1520 + "'", int2 == 1520);
    }

    @Test
    public void test0184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0184");
        int int2 = sum.Toplama.sum(1520, 1520);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3040 + "'", int2 == 3040);
    }

    @Test
    public void test0185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0185");
        int int2 = sum.Toplama.sum(575, 405);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 980 + "'", int2 == 980);
    }

    @Test
    public void test0186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0186");
        int int2 = sum.Toplama.sum(475, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 527 + "'", int2 == 527);
    }

    @Test
    public void test0187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0187");
        int int2 = sum.Toplama.sum((int) (short) 1, 909);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 910 + "'", int2 == 910);
    }

    @Test
    public void test0188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0188");
        int int2 = sum.Toplama.sum((int) (byte) 1, 259);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 260 + "'", int2 == 260);
    }

    @Test
    public void test0189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0189");
        int int2 = sum.Toplama.sum(280, 574);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 854 + "'", int2 == 854);
    }

    @Test
    public void test0190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0190");
        int int2 = sum.Toplama.sum(168, 896);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1064 + "'", int2 == 1064);
    }

    @Test
    public void test0191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0191");
        int int2 = sum.Toplama.sum(1293, 650);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1943 + "'", int2 == 1943);
    }

    @Test
    public void test0192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0192");
        int int2 = sum.Toplama.sum(997, 985);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1982 + "'", int2 == 1982);
    }

    @Test
    public void test0193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0193");
        int int2 = sum.Toplama.sum(181, 1648);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1829 + "'", int2 == 1829);
    }

    @Test
    public void test0194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0194");
        int int2 = sum.Toplama.sum(100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test0195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0195");
        int int2 = sum.Toplama.sum(735, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 835 + "'", int2 == 835);
    }

    @Test
    public void test0196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0196");
        int int2 = sum.Toplama.sum(347, 508);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 855 + "'", int2 == 855);
    }

    @Test
    public void test0197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0197");
        int int2 = sum.Toplama.sum(624, 854);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1478 + "'", int2 == 1478);
    }

    @Test
    public void test0198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0198");
        int int2 = sum.Toplama.sum(626, 188);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 814 + "'", int2 == 814);
    }

    @Test
    public void test0199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0199");
        int int2 = sum.Toplama.sum(520, 508);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1028 + "'", int2 == 1028);
    }

    @Test
    public void test0200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0200");
        int int2 = sum.Toplama.sum(296, 168);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 464 + "'", int2 == 464);
    }

    @Test
    public void test0201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0201");
        int int2 = sum.Toplama.sum(64, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64 + "'", int2 == 64);
    }

    @Test
    public void test0202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0202");
        int int2 = sum.Toplama.sum(294, 413);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 707 + "'", int2 == 707);
    }

    @Test
    public void test0203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0203");
        int int2 = sum.Toplama.sum(396, 131);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 527 + "'", int2 == 527);
    }

    @Test
    public void test0204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0204");
        int int2 = sum.Toplama.sum(394, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 394 + "'", int2 == 394);
    }

    @Test
    public void test0205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0205");
        int int2 = sum.Toplama.sum(2, 188);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 190 + "'", int2 == 190);
    }

    @Test
    public void test0206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0206");
        int int2 = sum.Toplama.sum(61, 280);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 341 + "'", int2 == 341);
    }

    @Test
    public void test0207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0207");
        int int2 = sum.Toplama.sum(459, 411);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 870 + "'", int2 == 870);
    }

    @Test
    public void test0208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0208");
        int int2 = sum.Toplama.sum(1424, 1064);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2488 + "'", int2 == 2488);
    }

    @Test
    public void test0209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0209");
        int int2 = sum.Toplama.sum(689, 199);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 888 + "'", int2 == 888);
    }

    @Test
    public void test0210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0210");
        int int2 = sum.Toplama.sum(230, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 230 + "'", int2 == 230);
    }

    @Test
    public void test0211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0211");
        int int2 = sum.Toplama.sum((int) ' ', 1982);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2014 + "'", int2 == 2014);
    }

    @Test
    public void test0212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0212");
        int int2 = sum.Toplama.sum((int) (short) 0, 508);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 508 + "'", int2 == 508);
    }

    @Test
    public void test0213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0213");
        int int2 = sum.Toplama.sum(395, 464);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 859 + "'", int2 == 859);
    }

    @Test
    public void test0214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0214");
        int int2 = sum.Toplama.sum(11, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 111 + "'", int2 == 111);
    }

    @Test
    public void test0215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0215");
        int int2 = sum.Toplama.sum(888, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 888 + "'", int2 == 888);
    }

    @Test
    public void test0216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0216");
        int int2 = sum.Toplama.sum(129, 746);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 875 + "'", int2 == 875);
    }

    @Test
    public void test0217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0217");
        int int2 = sum.Toplama.sum(543, 997);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1540 + "'", int2 == 1540);
    }

    @Test
    public void test0218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0218");
        int int2 = sum.Toplama.sum(181, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 181 + "'", int2 == 181);
    }

    @Test
    public void test0219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0219");
        int int2 = sum.Toplama.sum(97, 203);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 300 + "'", int2 == 300);
    }

    @Test
    public void test0220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0220");
        int int2 = sum.Toplama.sum((int) (short) -1, 352);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 351 + "'", int2 == 351);
    }

    @Test
    public void test0221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0221");
        int int2 = sum.Toplama.sum(707, 195);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 902 + "'", int2 == 902);
    }

    @Test
    public void test0222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0222");
        int int2 = sum.Toplama.sum(888, 455);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1343 + "'", int2 == 1343);
    }

    @Test
    public void test0223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0223");
        int int2 = sum.Toplama.sum(891, 1064);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1955 + "'", int2 == 1955);
    }

    @Test
    public void test0224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0224");
        int int2 = sum.Toplama.sum(691, 742);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1433 + "'", int2 == 1433);
    }

    @Test
    public void test0225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0225");
        int int2 = sum.Toplama.sum(347, 374);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 721 + "'", int2 == 721);
    }

    @Test
    public void test0226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0226");
        int int2 = sum.Toplama.sum(307, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 308 + "'", int2 == 308);
    }

    @Test
    public void test0227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0227");
        int int2 = sum.Toplama.sum(422, 117);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 539 + "'", int2 == 539);
    }

    @Test
    public void test0228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0228");
        int int2 = sum.Toplama.sum(109, 896);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1005 + "'", int2 == 1005);
    }

    @Test
    public void test0229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0229");
        int int2 = sum.Toplama.sum(396, 1540);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1936 + "'", int2 == 1936);
    }

    @Test
    public void test0230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0230");
        int int2 = sum.Toplama.sum(149, 1028);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1177 + "'", int2 == 1177);
    }

    @Test
    public void test0231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0231");
        int int2 = sum.Toplama.sum(0, 282);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 282 + "'", int2 == 282);
    }

    @Test
    public void test0232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0232");
        int int2 = sum.Toplama.sum(640, 891);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1531 + "'", int2 == 1531);
    }

    @Test
    public void test0233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0233");
        int int2 = sum.Toplama.sum(997, 210);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1207 + "'", int2 == 1207);
    }

    @Test
    public void test0234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0234");
        int int2 = sum.Toplama.sum(51, 190);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 241 + "'", int2 == 241);
    }

    @Test
    public void test0235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0235");
        int int2 = sum.Toplama.sum(512, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 547 + "'", int2 == 547);
    }

    @Test
    public void test0236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0236");
        int int2 = sum.Toplama.sum(53, 396);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 449 + "'", int2 == 449);
    }

    @Test
    public void test0237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0237");
        int int2 = sum.Toplama.sum(891, 557);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1448 + "'", int2 == 1448);
    }

    @Test
    public void test0238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0238");
        int int2 = sum.Toplama.sum(896, 626);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1522 + "'", int2 == 1522);
    }

    @Test
    public void test0239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0239");
        int int2 = sum.Toplama.sum(1315, 1520);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2835 + "'", int2 == 2835);
    }

    @Test
    public void test0240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0240");
        int int2 = sum.Toplama.sum(1315, 107);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1422 + "'", int2 == 1422);
    }

    @Test
    public void test0241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0241");
        int int2 = sum.Toplama.sum(910, 626);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1536 + "'", int2 == 1536);
    }

    @Test
    public void test0242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0242");
        int int2 = sum.Toplama.sum(910, 691);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1601 + "'", int2 == 1601);
    }

    @Test
    public void test0243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0243");
        int int2 = sum.Toplama.sum(280, 64);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 344 + "'", int2 == 344);
    }

    @Test
    public void test0244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0244");
        int int2 = sum.Toplama.sum(427, 168);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 595 + "'", int2 == 595);
    }

    @Test
    public void test0245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0245");
        int int2 = sum.Toplama.sum(188, 544);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 732 + "'", int2 == 732);
    }

    @Test
    public void test0246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0246");
        int int2 = sum.Toplama.sum(676, 689);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1365 + "'", int2 == 1365);
    }

    @Test
    public void test0247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0247");
        int int2 = sum.Toplama.sum(300, 251);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 551 + "'", int2 == 551);
    }

    @Test
    public void test0248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0248");
        int int2 = sum.Toplama.sum(1207, 1207);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2414 + "'", int2 == 2414);
    }

    @Test
    public void test0249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0249");
        int int2 = sum.Toplama.sum(64, 875);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 939 + "'", int2 == 939);
    }

    @Test
    public void test0250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0250");
        int int2 = sum.Toplama.sum(413, 527);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 940 + "'", int2 == 940);
    }

    @Test
    public void test0251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0251");
        int int2 = sum.Toplama.sum(0, 896);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 896 + "'", int2 == 896);
    }

    @Test
    public void test0252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0252");
        int int2 = sum.Toplama.sum(413, 475);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 888 + "'", int2 == 888);
    }

    @Test
    public void test0253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0253");
        int int2 = sum.Toplama.sum(88, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 88 + "'", int2 == 88);
    }

    @Test
    public void test0254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0254");
        int int2 = sum.Toplama.sum((int) (short) 1, 621);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 622 + "'", int2 == 622);
    }

    @Test
    public void test0255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0255");
        int int2 = sum.Toplama.sum(940, 520);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1460 + "'", int2 == 1460);
    }

    @Test
    public void test0256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0256");
        int int2 = sum.Toplama.sum(269, 543);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 812 + "'", int2 == 812);
    }

    @Test
    public void test0257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0257");
        int int2 = sum.Toplama.sum(508, 1522);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2030 + "'", int2 == 2030);
    }

    @Test
    public void test0258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0258");
        int int2 = sum.Toplama.sum(295, 622);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 917 + "'", int2 == 917);
    }

    @Test
    public void test0259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0259");
        int int2 = sum.Toplama.sum(575, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 574 + "'", int2 == 574);
    }

    @Test
    public void test0260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0260");
        int int2 = sum.Toplama.sum(735, 650);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1385 + "'", int2 == 1385);
    }

    @Test
    public void test0261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0261");
        int int2 = sum.Toplama.sum(870, 251);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1121 + "'", int2 == 1121);
    }

    @Test
    public void test0262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0262");
        int int2 = sum.Toplama.sum(423, 1982);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2405 + "'", int2 == 2405);
    }

    @Test
    public void test0263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0263");
        int int2 = sum.Toplama.sum((int) (byte) -1, 1955);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1954 + "'", int2 == 1954);
    }

    @Test
    public void test0264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0264");
        int int2 = sum.Toplama.sum(269, 200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 469 + "'", int2 == 469);
    }

    @Test
    public void test0265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0265");
        int int2 = sum.Toplama.sum(422, 188);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 610 + "'", int2 == 610);
    }

    @Test
    public void test0266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0266");
        int int2 = sum.Toplama.sum(515, 241);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 756 + "'", int2 == 756);
    }

    @Test
    public void test0267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0267");
        int int2 = sum.Toplama.sum(352, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 452 + "'", int2 == 452);
    }

    @Test
    public void test0268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0268");
        int int2 = sum.Toplama.sum(195, 910);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1105 + "'", int2 == 1105);
    }

    @Test
    public void test0269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0269");
        int int2 = sum.Toplama.sum((int) '4', (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53 + "'", int2 == 53);
    }

    @Test
    public void test0270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0270");
        int int2 = sum.Toplama.sum(1540, 1121);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2661 + "'", int2 == 2661);
    }

    @Test
    public void test0271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0271");
        int int2 = sum.Toplama.sum(0, 676);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 676 + "'", int2 == 676);
    }

    @Test
    public void test0272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0272");
        int int2 = sum.Toplama.sum(980, 351);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1331 + "'", int2 == 1331);
    }

    @Test
    public void test0273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0273");
        int int2 = sum.Toplama.sum(1982, 1460);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3442 + "'", int2 == 3442);
    }

    @Test
    public void test0274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0274");
        int int2 = sum.Toplama.sum(691, 369);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1060 + "'", int2 == 1060);
    }

    @Test
    public void test0275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0275");
        int int2 = sum.Toplama.sum(129, 595);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 724 + "'", int2 == 724);
    }

    @Test
    public void test0276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0276");
        int int2 = sum.Toplama.sum(1121, 111);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1232 + "'", int2 == 1232);
    }

    @Test
    public void test0277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0277");
        int int2 = sum.Toplama.sum(610, 199);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 809 + "'", int2 == 809);
    }

    @Test
    public void test0278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0278");
        int int2 = sum.Toplama.sum(111, 917);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1028 + "'", int2 == 1028);
    }

    @Test
    public void test0279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0279");
        int int2 = sum.Toplama.sum(1087, 341);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1428 + "'", int2 == 1428);
    }

    @Test
    public void test0280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0280");
        int int2 = sum.Toplama.sum(308, 896);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1204 + "'", int2 == 1204);
    }

    @Test
    public void test0281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0281");
        int int2 = sum.Toplama.sum(106, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 106 + "'", int2 == 106);
    }

    @Test
    public void test0282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0282");
        int int2 = sum.Toplama.sum(724, 252);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 976 + "'", int2 == 976);
    }

    @Test
    public void test0283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0283");
        int int2 = sum.Toplama.sum(411, 812);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1223 + "'", int2 == 1223);
    }

    @Test
    public void test0284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0284");
        int int2 = sum.Toplama.sum(1087, 610);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1697 + "'", int2 == 1697);
    }

    @Test
    public void test0285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0285");
        int int2 = sum.Toplama.sum(1954, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1954 + "'", int2 == 1954);
    }

    @Test
    public void test0286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0286");
        int int2 = sum.Toplama.sum(1982, 1060);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3042 + "'", int2 == 3042);
    }

    @Test
    public void test0287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0287");
        int int2 = sum.Toplama.sum(0, 746);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 746 + "'", int2 == 746);
    }

    @Test
    public void test0288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0288");
        int int2 = sum.Toplama.sum(487, 1601);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2088 + "'", int2 == 2088);
    }

    @Test
    public void test0289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0289");
        int int2 = sum.Toplama.sum(381, 1522);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1903 + "'", int2 == 1903);
    }

    @Test
    public void test0290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0290");
        int int2 = sum.Toplama.sum((int) (byte) 100, 753);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 853 + "'", int2 == 853);
    }

    @Test
    public void test0291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0291");
        int int2 = sum.Toplama.sum(195, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 195 + "'", int2 == 195);
    }

    @Test
    public void test0292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0292");
        int int2 = sum.Toplama.sum(2405, 621);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3026 + "'", int2 == 3026);
    }

    @Test
    public void test0293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0293");
        int int2 = sum.Toplama.sum((int) (byte) 10, 3026);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3036 + "'", int2 == 3036);
    }

    @Test
    public void test0294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0294");
        int int2 = sum.Toplama.sum(0, 753);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 753 + "'", int2 == 753);
    }

    @Test
    public void test0295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0295");
        int int2 = sum.Toplama.sum(411, 792);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1203 + "'", int2 == 1203);
    }

    @Test
    public void test0296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0296");
        int int2 = sum.Toplama.sum(2405, 405);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2810 + "'", int2 == 2810);
    }

    @Test
    public void test0297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0297");
        int int2 = sum.Toplama.sum(181, 341);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 522 + "'", int2 == 522);
    }

    @Test
    public void test0298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0298");
        int int2 = sum.Toplama.sum(99, 459);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 558 + "'", int2 == 558);
    }

    @Test
    public void test0299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0299");
        int int2 = sum.Toplama.sum(650, 152);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 802 + "'", int2 == 802);
    }

    @Test
    public void test0300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0300");
        int int2 = sum.Toplama.sum(423, 452);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 875 + "'", int2 == 875);
    }

    @Test
    public void test0301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0301");
        int int2 = sum.Toplama.sum(1087, 1105);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2192 + "'", int2 == 2192);
    }

    @Test
    public void test0302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0302");
        int int2 = sum.Toplama.sum((int) (byte) 100, 1955);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2055 + "'", int2 == 2055);
    }

    @Test
    public void test0303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0303");
        int int2 = sum.Toplama.sum(469, 3026);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3495 + "'", int2 == 3495);
    }

    @Test
    public void test0304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0304");
        int int2 = sum.Toplama.sum(814, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 824 + "'", int2 == 824);
    }

    @Test
    public void test0305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0305");
        int int2 = sum.Toplama.sum(3040, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3040 + "'", int2 == 3040);
    }

    @Test
    public void test0306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0306");
        int int2 = sum.Toplama.sum(3026, 405);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3431 + "'", int2 == 3431);
    }

    @Test
    public void test0307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0307");
        int int2 = sum.Toplama.sum((int) (short) 10, 2055);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2065 + "'", int2 == 2065);
    }

    @Test
    public void test0308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0308");
        int int2 = sum.Toplama.sum(824, 1531);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2355 + "'", int2 == 2355);
    }

    @Test
    public void test0309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0309");
        int int2 = sum.Toplama.sum(1982, 1478);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3460 + "'", int2 == 3460);
    }

    @Test
    public void test0310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0310");
        int int2 = sum.Toplama.sum(642, 280);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 922 + "'", int2 == 922);
    }

    @Test
    public void test0311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0311");
        int int2 = sum.Toplama.sum(0, 2810);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2810 + "'", int2 == 2810);
    }

    @Test
    public void test0312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0312");
        int int2 = sum.Toplama.sum(440, 1203);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1643 + "'", int2 == 1643);
    }

    @Test
    public void test0313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0313");
        int int2 = sum.Toplama.sum(53, 1207);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1260 + "'", int2 == 1260);
    }

    @Test
    public void test0314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0314");
        int int2 = sum.Toplama.sum(624, 1522);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2146 + "'", int2 == 2146);
    }

    @Test
    public void test0315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0315");
        int int2 = sum.Toplama.sum(433, 152);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 585 + "'", int2 == 585);
    }

    @Test
    public void test0316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0316");
        int int2 = sum.Toplama.sum(809, 539);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1348 + "'", int2 == 1348);
    }

    @Test
    public void test0317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0317");
        int int2 = sum.Toplama.sum(358, 642);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1000 + "'", int2 == 1000);
    }

    @Test
    public void test0318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0318");
        int int2 = sum.Toplama.sum(109, 405);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 514 + "'", int2 == 514);
    }

    @Test
    public void test0319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0319");
        int int2 = sum.Toplama.sum(459, 1536);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1995 + "'", int2 == 1995);
    }

    @Test
    public void test0320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0320");
        int int2 = sum.Toplama.sum(190, 2661);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2851 + "'", int2 == 2851);
    }

    @Test
    public void test0321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0321");
        int int2 = sum.Toplama.sum(0, 742);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 742 + "'", int2 == 742);
    }

    @Test
    public void test0322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0322");
        int int2 = sum.Toplama.sum(985, 307);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1292 + "'", int2 == 1292);
    }

    @Test
    public void test0323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0323");
        int int2 = sum.Toplama.sum(227, 1995);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2222 + "'", int2 == 2222);
    }

    @Test
    public void test0324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0324");
        int int2 = sum.Toplama.sum(210, 164);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 374 + "'", int2 == 374);
    }

    @Test
    public void test0325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0325");
        int int2 = sum.Toplama.sum(1331, 96);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1427 + "'", int2 == 1427);
    }

    @Test
    public void test0326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0326");
        int int2 = sum.Toplama.sum((int) (byte) 100, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 197 + "'", int2 == 197);
    }

    @Test
    public void test0327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0327");
        int int2 = sum.Toplama.sum(1540, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1540 + "'", int2 == 1540);
    }

    @Test
    public void test0328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0328");
        int int2 = sum.Toplama.sum(304, 117);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 421 + "'", int2 == 421);
    }

    @Test
    public void test0329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0329");
        int int2 = sum.Toplama.sum(746, 735);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1481 + "'", int2 == 1481);
    }

    @Test
    public void test0330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0330");
        int int2 = sum.Toplama.sum(379, 1424);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1803 + "'", int2 == 1803);
    }

    @Test
    public void test0331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0331");
        int int2 = sum.Toplama.sum(909, 199);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1108 + "'", int2 == 1108);
    }

    @Test
    public void test0332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0332");
        int int2 = sum.Toplama.sum(1293, 584);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1877 + "'", int2 == 1877);
    }

    @Test
    public void test0333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0333");
        int int2 = sum.Toplama.sum(1903, 413);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2316 + "'", int2 == 2316);
    }

    @Test
    public void test0334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0334");
        int int2 = sum.Toplama.sum(421, 2835);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3256 + "'", int2 == 3256);
    }

    @Test
    public void test0335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0335");
        int int2 = sum.Toplama.sum(621, 497);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1118 + "'", int2 == 1118);
    }

    @Test
    public void test0336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0336");
        int int2 = sum.Toplama.sum(552, 305);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 857 + "'", int2 == 857);
    }

    @Test
    public void test0337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0337");
        int int2 = sum.Toplama.sum(732, 508);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1240 + "'", int2 == 1240);
    }

    @Test
    public void test0338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0338");
        int int2 = sum.Toplama.sum(575, 164);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 739 + "'", int2 == 739);
    }

    @Test
    public void test0339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0339");
        int int2 = sum.Toplama.sum(1540, 341);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1881 + "'", int2 == 1881);
    }

    @Test
    public void test0340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0340");
        int int2 = sum.Toplama.sum(1175, 721);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1896 + "'", int2 == 1896);
    }

    @Test
    public void test0341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0341");
        int int2 = sum.Toplama.sum((int) (byte) 1, 411);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 412 + "'", int2 == 412);
    }

    @Test
    public void test0342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0342");
        int int2 = sum.Toplama.sum(1223, 64);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1287 + "'", int2 == 1287);
    }

    @Test
    public void test0343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0343");
        int int2 = sum.Toplama.sum(421, 896);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1317 + "'", int2 == 1317);
    }

    @Test
    public void test0344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0344");
        int int2 = sum.Toplama.sum(295, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 392 + "'", int2 == 392);
    }

    @Test
    public void test0345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0345");
        int int2 = sum.Toplama.sum(422, 308);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 730 + "'", int2 == 730);
    }

    @Test
    public void test0346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0346");
        int int2 = sum.Toplama.sum(2661, 742);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3403 + "'", int2 == 3403);
    }

    @Test
    public void test0347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0347");
        int int2 = sum.Toplama.sum(1896, 229);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2125 + "'", int2 == 2125);
    }

    @Test
    public void test0348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0348");
        int int2 = sum.Toplama.sum(152, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 152 + "'", int2 == 152);
    }

    @Test
    public void test0349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0349");
        int int2 = sum.Toplama.sum(477, 299);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 776 + "'", int2 == 776);
    }

    @Test
    public void test0350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0350");
        int int2 = sum.Toplama.sum(195, 1955);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2150 + "'", int2 == 2150);
    }

    @Test
    public void test0351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0351");
        int int2 = sum.Toplama.sum(0, 735);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 735 + "'", int2 == 735);
    }

    @Test
    public void test0352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0352");
        int int2 = sum.Toplama.sum(280, 910);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1190 + "'", int2 == 1190);
    }

    @Test
    public void test0353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0353");
        int int2 = sum.Toplama.sum(109, 379);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 488 + "'", int2 == 488);
    }

    @Test
    public void test0354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0354");
        int int2 = sum.Toplama.sum(2661, 131);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2792 + "'", int2 == 2792);
    }

    @Test
    public void test0355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0355");
        int int2 = sum.Toplama.sum(1005, 1460);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2465 + "'", int2 == 2465);
    }

    @Test
    public void test0356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0356");
        int int2 = sum.Toplama.sum(1190, 106);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1296 + "'", int2 == 1296);
    }

    @Test
    public void test0357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0357");
        int int2 = sum.Toplama.sum(520, 1193);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1713 + "'", int2 == 1713);
    }

    @Test
    public void test0358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0358");
        int int2 = sum.Toplama.sum(854, 379);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1233 + "'", int2 == 1233);
    }

    @Test
    public void test0359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0359");
        int int2 = sum.Toplama.sum(188, 1531);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1719 + "'", int2 == 1719);
    }

    @Test
    public void test0360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0360");
        int int2 = sum.Toplama.sum(732, 1482);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2214 + "'", int2 == 2214);
    }

    @Test
    public void test0361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0361");
        int int2 = sum.Toplama.sum(259, 888);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1147 + "'", int2 == 1147);
    }

    @Test
    public void test0362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0362");
        int int2 = sum.Toplama.sum(241, 997);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1238 + "'", int2 == 1238);
    }

    @Test
    public void test0363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0363");
        int int2 = sum.Toplama.sum((int) (byte) 100, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 110 + "'", int2 == 110);
    }

    @Test
    public void test0364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0364");
        int int2 = sum.Toplama.sum(2661, 464);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3125 + "'", int2 == 3125);
    }

    @Test
    public void test0365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0365");
        int int2 = sum.Toplama.sum(421, 574);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 995 + "'", int2 == 995);
    }

    @Test
    public void test0366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0366");
        int int2 = sum.Toplama.sum(1982, 455);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2437 + "'", int2 == 2437);
    }

    @Test
    public void test0367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0367");
        int int2 = sum.Toplama.sum(1121, 3125);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4246 + "'", int2 == 4246);
    }

    @Test
    public void test0368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0368");
        int int2 = sum.Toplama.sum(1713, 859);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2572 + "'", int2 == 2572);
    }

    @Test
    public void test0369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0369");
        int int2 = sum.Toplama.sum(896, 164);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1060 + "'", int2 == 1060);
    }

    @Test
    public void test0370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0370");
        int int2 = sum.Toplama.sum(1427, 543);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1970 + "'", int2 == 1970);
    }

    @Test
    public void test0371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0371");
        int int2 = sum.Toplama.sum(0, 585);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 585 + "'", int2 == 585);
    }

    @Test
    public void test0372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0372");
        int int2 = sum.Toplama.sum(1193, 642);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1835 + "'", int2 == 1835);
    }

    @Test
    public void test0373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0373");
        int int2 = sum.Toplama.sum(515, 976);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1491 + "'", int2 == 1491);
    }

    @Test
    public void test0374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0374");
        int int2 = sum.Toplama.sum(427, 1118);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1545 + "'", int2 == 1545);
    }

    @Test
    public void test0375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0375");
        int int2 = sum.Toplama.sum(746, 730);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1476 + "'", int2 == 1476);
    }

    @Test
    public void test0376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0376");
        int int2 = sum.Toplama.sum(2316, 1193);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3509 + "'", int2 == 3509);
    }

    @Test
    public void test0377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0377");
        int int2 = sum.Toplama.sum((int) (byte) 0, 551);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 551 + "'", int2 == 551);
    }

    @Test
    public void test0378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0378");
        int int2 = sum.Toplama.sum(1343, 1293);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2636 + "'", int2 == 2636);
    }

    @Test
    public void test0379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0379");
        int int2 = sum.Toplama.sum(305, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 315 + "'", int2 == 315);
    }

    @Test
    public void test0380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0380");
        int int2 = sum.Toplama.sum(543, 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 642 + "'", int2 == 642);
    }

    @Test
    public void test0381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0381");
        int int2 = sum.Toplama.sum(2150, 1348);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3498 + "'", int2 == 3498);
    }

    @Test
    public void test0382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0382");
        int int2 = sum.Toplama.sum(2125, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2125 + "'", int2 == 2125);
    }

    @Test
    public void test0383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0383");
        int int2 = sum.Toplama.sum(1260, 512);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1772 + "'", int2 == 1772);
    }

    @Test
    public void test0384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0384");
        int int2 = sum.Toplama.sum(508, 980);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1488 + "'", int2 == 1488);
    }

    @Test
    public void test0385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0385");
        int int2 = sum.Toplama.sum(2065, 897);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2962 + "'", int2 == 2962);
    }

    @Test
    public void test0386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0386");
        int int2 = sum.Toplama.sum(10, 251);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 261 + "'", int2 == 261);
    }

    @Test
    public void test0387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0387");
        int int2 = sum.Toplama.sum(413, 422);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 835 + "'", int2 == 835);
    }

    @Test
    public void test0388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0388");
        int int2 = sum.Toplama.sum(413, 1482);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1895 + "'", int2 == 1895);
    }

    @Test
    public void test0389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0389");
        int int2 = sum.Toplama.sum((int) (short) 1, 308);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 309 + "'", int2 == 309);
    }

    @Test
    public void test0390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0390");
        int int2 = sum.Toplama.sum(1108, 1428);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2536 + "'", int2 == 2536);
    }

    @Test
    public void test0391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0391");
        int int2 = sum.Toplama.sum(1803, 544);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2347 + "'", int2 == 2347);
    }

    @Test
    public void test0392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0392");
        int int2 = sum.Toplama.sum(0, 440);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 440 + "'", int2 == 440);
    }

    @Test
    public void test0393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0393");
        int int2 = sum.Toplama.sum(423, 853);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1276 + "'", int2 == 1276);
    }

    @Test
    public void test0394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0394");
        int int2 = sum.Toplama.sum(1895, 1803);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3698 + "'", int2 == 3698);
    }

    @Test
    public void test0395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0395");
        int int2 = sum.Toplama.sum(2437, 3509);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5946 + "'", int2 == 5946);
    }

    @Test
    public void test0396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0396");
        int int2 = sum.Toplama.sum(721, 251);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 972 + "'", int2 == 972);
    }

    @Test
    public void test0397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0397");
        int int2 = sum.Toplama.sum((int) (short) -1, 423);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 422 + "'", int2 == 422);
    }

    @Test
    public void test0398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0398");
        int int2 = sum.Toplama.sum(455, 640);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1095 + "'", int2 == 1095);
    }

    @Test
    public void test0399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0399");
        int int2 = sum.Toplama.sum(691, 392);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1083 + "'", int2 == 1083);
    }

    @Test
    public void test0400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0400");
        int int2 = sum.Toplama.sum(1315, 149);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1464 + "'", int2 == 1464);
    }

    @Test
    public void test0401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0401");
        int int2 = sum.Toplama.sum(3431, 1108);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4539 + "'", int2 == 4539);
    }

    @Test
    public void test0402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0402");
        int int2 = sum.Toplama.sum(626, 2792);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3418 + "'", int2 == 3418);
    }

    @Test
    public void test0403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0403");
        int int2 = sum.Toplama.sum(3698, 5946);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9644 + "'", int2 == 9644);
    }

    @Test
    public void test0404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0404");
        int int2 = sum.Toplama.sum(1520, 547);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2067 + "'", int2 == 2067);
    }

    @Test
    public void test0405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0405");
        int int2 = sum.Toplama.sum(469, 939);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1408 + "'", int2 == 1408);
    }

    @Test
    public void test0406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0406");
        int int2 = sum.Toplama.sum(940, 1881);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2821 + "'", int2 == 2821);
    }

    @Test
    public void test0407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0407");
        int int2 = sum.Toplama.sum(99, 309);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 408 + "'", int2 == 408);
    }

    @Test
    public void test0408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0408");
        int int2 = sum.Toplama.sum(1105, 230);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1335 + "'", int2 == 1335);
    }

    @Test
    public void test0409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0409");
        int int2 = sum.Toplama.sum((int) (short) 10, 151);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 161 + "'", int2 == 161);
    }

    @Test
    public void test0410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0410");
        int int2 = sum.Toplama.sum(539, 392);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 931 + "'", int2 == 931);
    }

    @Test
    public void test0411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0411");
        int int2 = sum.Toplama.sum(1896, 1881);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3777 + "'", int2 == 3777);
    }

    @Test
    public void test0412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0412");
        int int2 = sum.Toplama.sum(227, 396);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 623 + "'", int2 == 623);
    }

    @Test
    public void test0413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0413");
        int int2 = sum.Toplama.sum(413, 857);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1270 + "'", int2 == 1270);
    }

    @Test
    public void test0414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0414");
        int int2 = sum.Toplama.sum((int) (short) 10, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test0415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0415");
        int int2 = sum.Toplama.sum(2055, 2355);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4410 + "'", int2 == 4410);
    }

    @Test
    public void test0416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0416");
        int int2 = sum.Toplama.sum(0, 3036);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3036 + "'", int2 == 3036);
    }

    @Test
    public void test0417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0417");
        int int2 = sum.Toplama.sum(689, 514);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1203 + "'", int2 == 1203);
    }

    @Test
    public void test0418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0418");
        int int2 = sum.Toplama.sum(0, 3040);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3040 + "'", int2 == 3040);
    }

    @Test
    public void test0419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0419");
        int int2 = sum.Toplama.sum(997, 1448);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2445 + "'", int2 == 2445);
    }

    @Test
    public void test0420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0420");
        int int2 = sum.Toplama.sum(1545, 1276);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2821 + "'", int2 == 2821);
    }

    @Test
    public void test0421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0421");
        int int2 = sum.Toplama.sum(486, 753);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1239 + "'", int2 == 1239);
    }

    @Test
    public void test0422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0422");
        int int2 = sum.Toplama.sum(199, 1385);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1584 + "'", int2 == 1584);
    }

    @Test
    public void test0423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0423");
        int int2 = sum.Toplama.sum(891, 1545);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2436 + "'", int2 == 2436);
    }

    @Test
    public void test0424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0424");
        int int2 = sum.Toplama.sum(4410, 111);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4521 + "'", int2 == 4521);
    }

    @Test
    public void test0425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0425");
        int int2 = sum.Toplama.sum(940, 315);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1255 + "'", int2 == 1255);
    }

    @Test
    public void test0426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0426");
        int int2 = sum.Toplama.sum(1190, 1121);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2311 + "'", int2 == 2311);
    }

    @Test
    public void test0427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0427");
        int int2 = sum.Toplama.sum(341, 1238);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1579 + "'", int2 == 1579);
    }

    @Test
    public void test0428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0428");
        int int2 = sum.Toplama.sum(50, 488);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 538 + "'", int2 == 538);
    }

    @Test
    public void test0429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0429");
        int int2 = sum.Toplama.sum(1064, 351);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1415 + "'", int2 == 1415);
    }

    @Test
    public void test0430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0430");
        int int2 = sum.Toplama.sum(1680, 522);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2202 + "'", int2 == 2202);
    }

    @Test
    public void test0431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0431");
        int int2 = sum.Toplama.sum(299, 1803);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2102 + "'", int2 == 2102);
    }

    @Test
    public void test0432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0432");
        int int2 = sum.Toplama.sum(164, 835);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 999 + "'", int2 == 999);
    }

    @Test
    public void test0433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0433");
        int int2 = sum.Toplama.sum(1903, 110);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2013 + "'", int2 == 2013);
    }

    @Test
    public void test0434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0434");
        int int2 = sum.Toplama.sum(1476, 1829);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3305 + "'", int2 == 3305);
    }

    @Test
    public void test0435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0435");
        int int2 = sum.Toplama.sum(0, 2202);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2202 + "'", int2 == 2202);
    }

    @Test
    public void test0436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0436");
        int int2 = sum.Toplama.sum((int) ' ', 707);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 739 + "'", int2 == 739);
    }

    @Test
    public void test0437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0437");
        int int2 = sum.Toplama.sum(1296, 1427);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2723 + "'", int2 == 2723);
    }

    @Test
    public void test0438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0438");
        int int2 = sum.Toplama.sum(854, 229);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1083 + "'", int2 == 1083);
    }

    @Test
    public void test0439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0439");
        int int2 = sum.Toplama.sum(2405, 3125);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5530 + "'", int2 == 5530);
    }

    @Test
    public void test0440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0440");
        int int2 = sum.Toplama.sum(1877, 405);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2282 + "'", int2 == 2282);
    }

    @Test
    public void test0441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0441");
        int int2 = sum.Toplama.sum(610, 551);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1161 + "'", int2 == 1161);
    }

    @Test
    public void test0442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0442");
        int int2 = sum.Toplama.sum(792, 5530);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6322 + "'", int2 == 6322);
    }

    @Test
    public void test0443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0443");
        int int2 = sum.Toplama.sum(585, 351);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 936 + "'", int2 == 936);
    }

    @Test
    public void test0444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0444");
        int int2 = sum.Toplama.sum(3305, 509);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3814 + "'", int2 == 3814);
    }

    @Test
    public void test0445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0445");
        int int2 = sum.Toplama.sum(1680, 1293);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2973 + "'", int2 == 2973);
    }

    @Test
    public void test0446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0446");
        int int2 = sum.Toplama.sum(1293, 1719);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3012 + "'", int2 == 3012);
    }

    @Test
    public void test0447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0447");
        int int2 = sum.Toplama.sum(855, 1190);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2045 + "'", int2 == 2045);
    }

    @Test
    public void test0448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0448");
        int int2 = sum.Toplama.sum(888, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 890 + "'", int2 == 890);
    }

    @Test
    public void test0449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0449");
        int int2 = sum.Toplama.sum(2013, 1041);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3054 + "'", int2 == 3054);
    }

    @Test
    public void test0450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0450");
        int int2 = sum.Toplama.sum(980, 1105);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2085 + "'", int2 == 2085);
    }

    @Test
    public void test0451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0451");
        int int2 = sum.Toplama.sum(241, 1719);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1960 + "'", int2 == 1960);
    }

    @Test
    public void test0452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0452");
        int int2 = sum.Toplama.sum(2835, 940);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3775 + "'", int2 == 3775);
    }

    @Test
    public void test0453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0453");
        int int2 = sum.Toplama.sum(4539, 392);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4931 + "'", int2 == 4931);
    }

    @Test
    public void test0454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0454");
        int int2 = sum.Toplama.sum(413, 1427);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1840 + "'", int2 == 1840);
    }

    @Test
    public void test0455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0455");
        int int2 = sum.Toplama.sum(1536, 199);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1735 + "'", int2 == 1735);
    }

    @Test
    public void test0456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0456");
        int int2 = sum.Toplama.sum(1315, 3012);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4327 + "'", int2 == 4327);
    }

    @Test
    public void test0457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0457");
        int int2 = sum.Toplama.sum(433, 304);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 737 + "'", int2 == 737);
    }

    @Test
    public void test0458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0458");
        int int2 = sum.Toplama.sum(0, 1680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1680 + "'", int2 == 1680);
    }

    @Test
    public void test0459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0459");
        int int2 = sum.Toplama.sum(1385, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1417 + "'", int2 == 1417);
    }

    @Test
    public void test0460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0460");
        int int2 = sum.Toplama.sum(3125, 707);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3832 + "'", int2 == 3832);
    }

    @Test
    public void test0461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0461");
        int int2 = sum.Toplama.sum(595, 210);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 805 + "'", int2 == 805);
    }

    @Test
    public void test0462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0462");
        int int2 = sum.Toplama.sum(890, 64);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 954 + "'", int2 == 954);
    }

    @Test
    public void test0463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0463");
        int int2 = sum.Toplama.sum(477, 1903);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2380 + "'", int2 == 2380);
    }

    @Test
    public void test0464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0464");
        int int2 = sum.Toplama.sum(2973, 2311);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5284 + "'", int2 == 5284);
    }

    @Test
    public void test0465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0465");
        int int2 = sum.Toplama.sum(691, 2347);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3038 + "'", int2 == 3038);
    }

    @Test
    public void test0466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0466");
        int int2 = sum.Toplama.sum(2013, 2067);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4080 + "'", int2 == 4080);
    }

    @Test
    public void test0467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0467");
        int int2 = sum.Toplama.sum(2661, 3509);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6170 + "'", int2 == 6170);
    }

    @Test
    public void test0468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0468");
        int int2 = sum.Toplama.sum(2045, 1482);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3527 + "'", int2 == 3527);
    }

    @Test
    public void test0469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0469");
        int int2 = sum.Toplama.sum(624, 181);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 805 + "'", int2 == 805);
    }

    @Test
    public void test0470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0470");
        int int2 = sum.Toplama.sum(4246, 1601);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5847 + "'", int2 == 5847);
    }

    @Test
    public void test0471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0471");
        int int2 = sum.Toplama.sum(2102, 2465);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4567 + "'", int2 == 4567);
    }

    @Test
    public void test0472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0472");
        int int2 = sum.Toplama.sum(1735, 2436);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4171 + "'", int2 == 4171);
    }

    @Test
    public void test0473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0473");
        int int2 = sum.Toplama.sum((int) (short) 10, 1203);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1213 + "'", int2 == 1213);
    }

    @Test
    public void test0474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0474");
        int int2 = sum.Toplama.sum(1829, 1481);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3310 + "'", int2 == 3310);
    }

    @Test
    public void test0475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0475");
        int int2 = sum.Toplama.sum(488, 4567);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5055 + "'", int2 == 5055);
    }

    @Test
    public void test0476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0476");
        int int2 = sum.Toplama.sum(4931, 1643);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6574 + "'", int2 == 6574);
    }

    @Test
    public void test0477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0477");
        int int2 = sum.Toplama.sum(824, 622);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1446 + "'", int2 == 1446);
    }

    @Test
    public void test0478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0478");
        int int2 = sum.Toplama.sum(1232, 1108);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2340 + "'", int2 == 2340);
    }

    @Test
    public void test0479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0479");
        int int2 = sum.Toplama.sum(1161, 88);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1249 + "'", int2 == 1249);
    }

    @Test
    public void test0480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0480");
        int int2 = sum.Toplama.sum(1428, 940);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2368 + "'", int2 == 2368);
    }

    @Test
    public void test0481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0481");
        int int2 = sum.Toplama.sum(3125, 1643);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4768 + "'", int2 == 4768);
    }

    @Test
    public void test0482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0482");
        int int2 = sum.Toplama.sum(2355, 746);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3101 + "'", int2 == 3101);
    }

    @Test
    public void test0483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0483");
        int int2 = sum.Toplama.sum(2405, 792);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3197 + "'", int2 == 3197);
    }

    @Test
    public void test0484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0484");
        int int2 = sum.Toplama.sum(1000, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1000 + "'", int2 == 1000);
    }

    @Test
    public void test0485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0485");
        int int2 = sum.Toplama.sum(1601, 2536);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4137 + "'", int2 == 4137);
    }

    @Test
    public void test0486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0486");
        int int2 = sum.Toplama.sum(5055, 1083);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6138 + "'", int2 == 6138);
    }

    @Test
    public void test0487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0487");
        int int2 = sum.Toplama.sum(1697, 422);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2119 + "'", int2 == 2119);
    }

    @Test
    public void test0488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0488");
        int int2 = sum.Toplama.sum(1478, 902);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2380 + "'", int2 == 2380);
    }

    @Test
    public void test0489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0489");
        int int2 = sum.Toplama.sum(2222, 3832);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6054 + "'", int2 == 6054);
    }

    @Test
    public void test0490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0490");
        int int2 = sum.Toplama.sum(359, 2810);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3169 + "'", int2 == 3169);
    }

    @Test
    public void test0491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0491");
        int int2 = sum.Toplama.sum(3775, 3101);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6876 + "'", int2 == 6876);
    }

    @Test
    public void test0492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0492");
        int int2 = sum.Toplama.sum(282, 3509);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3791 + "'", int2 == 3791);
    }

    @Test
    public void test0493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0493");
        int int2 = sum.Toplama.sum(2222, 891);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3113 + "'", int2 == 3113);
    }

    @Test
    public void test0494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0494");
        int int2 = sum.Toplama.sum(351, 1365);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1716 + "'", int2 == 1716);
    }

    @Test
    public void test0495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0495");
        int int2 = sum.Toplama.sum(352, 809);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1161 + "'", int2 == 1161);
    }

    @Test
    public void test0496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0496");
        int int2 = sum.Toplama.sum(3698, 1343);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5041 + "'", int2 == 5041);
    }

    @Test
    public void test0497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0497");
        int int2 = sum.Toplama.sum(3125, 51);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3176 + "'", int2 == 3176);
    }

    @Test
    public void test0498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0498");
        int int2 = sum.Toplama.sum(0, 168);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 168 + "'", int2 == 168);
    }

    @Test
    public void test0499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0499");
        int int2 = sum.Toplama.sum(1292, 575);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1867 + "'", int2 == 1867);
    }

    @Test
    public void test0500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0500");
        int int2 = sum.Toplama.sum(576, 623);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1199 + "'", int2 == 1199);
    }
}

