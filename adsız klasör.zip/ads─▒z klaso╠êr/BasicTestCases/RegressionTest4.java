import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test2001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2001");
        int int2 = sum.Toplama.sum(732, 8477);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9209 + "'", int2 == 9209);
    }

    @Test
    public void test2002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2002");
        int int2 = sum.Toplama.sum(1970, 11258);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13228 + "'", int2 == 13228);
    }

    @Test
    public void test2003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2003");
        int int2 = sum.Toplama.sum(3075, 11578);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14653 + "'", int2 == 14653);
    }

    @Test
    public void test2004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2004");
        int int2 = sum.Toplama.sum(3272, 13532);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16804 + "'", int2 == 16804);
    }

    @Test
    public void test2005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2005");
        int int2 = sum.Toplama.sum(3124, 9689);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12813 + "'", int2 == 12813);
    }

    @Test
    public void test2006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2006");
        int int2 = sum.Toplama.sum(3627, 2587);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6214 + "'", int2 == 6214);
    }

    @Test
    public void test2007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2007");
        int int2 = sum.Toplama.sum(27283, 1958);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29241 + "'", int2 == 29241);
    }

    @Test
    public void test2008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2008");
        int int2 = sum.Toplama.sum(8047, 4553);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12600 + "'", int2 == 12600);
    }

    @Test
    public void test2009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2009");
        int int2 = sum.Toplama.sum(9986, 897);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10883 + "'", int2 == 10883);
    }

    @Test
    public void test2010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2010");
        int int2 = sum.Toplama.sum(29241, 29044);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58285 + "'", int2 == 58285);
    }

    @Test
    public void test2011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2011");
        int int2 = sum.Toplama.sum(544, 2325);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2869 + "'", int2 == 2869);
    }

    @Test
    public void test2012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2012");
        int int2 = sum.Toplama.sum(4158, 939);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5097 + "'", int2 == 5097);
    }

    @Test
    public void test2013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2013");
        int int2 = sum.Toplama.sum(866, 11790);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12656 + "'", int2 == 12656);
    }

    @Test
    public void test2014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2014");
        int int2 = sum.Toplama.sum(1095, 1357);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2452 + "'", int2 == 2452);
    }

    @Test
    public void test2015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2015");
        int int2 = sum.Toplama.sum(11962, 14197);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26159 + "'", int2 == 26159);
    }

    @Test
    public void test2016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2016");
        int int2 = sum.Toplama.sum(6330, 8785);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15115 + "'", int2 == 15115);
    }

    @Test
    public void test2017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2017");
        int int2 = sum.Toplama.sum(25476, 1954);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27430 + "'", int2 == 27430);
    }

    @Test
    public void test2018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2018");
        int int2 = sum.Toplama.sum(1260, 487);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1747 + "'", int2 == 1747);
    }

    @Test
    public void test2019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2019");
        int int2 = sum.Toplama.sum(5570, 26159);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31729 + "'", int2 == 31729);
    }

    @Test
    public void test2020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2020");
        int int2 = sum.Toplama.sum(11022, 5420);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16442 + "'", int2 == 16442);
    }

    @Test
    public void test2021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2021");
        int int2 = sum.Toplama.sum(7126, 45733);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52859 + "'", int2 == 52859);
    }

    @Test
    public void test2022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2022");
        int int2 = sum.Toplama.sum(15500, 1378);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16878 + "'", int2 == 16878);
    }

    @Test
    public void test2023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2023");
        int int2 = sum.Toplama.sum(11385, 207);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11592 + "'", int2 == 11592);
    }

    @Test
    public void test2024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2024");
        int int2 = sum.Toplama.sum(7602, 2482);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10084 + "'", int2 == 10084);
    }

    @Test
    public void test2025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2025");
        int int2 = sum.Toplama.sum(2436, 1408);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3844 + "'", int2 == 3844);
    }

    @Test
    public void test2026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2026");
        int int2 = sum.Toplama.sum(300, 10867);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11167 + "'", int2 == 11167);
    }

    @Test
    public void test2027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2027");
        int int2 = sum.Toplama.sum(4857, 7488);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12345 + "'", int2 == 12345);
    }

    @Test
    public void test2028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2028");
        int int2 = sum.Toplama.sum(1301, 6666);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7967 + "'", int2 == 7967);
    }

    @Test
    public void test2029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2029");
        int int2 = sum.Toplama.sum(8245, 4299);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12544 + "'", int2 == 12544);
    }

    @Test
    public void test2030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2030");
        int int2 = sum.Toplama.sum(6141, 9563);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15704 + "'", int2 == 15704);
    }

    @Test
    public void test2031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2031");
        int int2 = sum.Toplama.sum(5901, 1182);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7083 + "'", int2 == 7083);
    }

    @Test
    public void test2032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2032");
        int int2 = sum.Toplama.sum(11824, 5188);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17012 + "'", int2 == 17012);
    }

    @Test
    public void test2033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2033");
        int int2 = sum.Toplama.sum(1579, 2982);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4561 + "'", int2 == 4561);
    }

    @Test
    public void test2034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2034");
        int int2 = sum.Toplama.sum(1867, 252);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2119 + "'", int2 == 2119);
    }

    @Test
    public void test2035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2035");
        int int2 = sum.Toplama.sum(5922, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5922 + "'", int2 == 5922);
    }

    @Test
    public void test2036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2036");
        int int2 = sum.Toplama.sum(3323, 12800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16123 + "'", int2 == 16123);
    }

    @Test
    public void test2037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2037");
        int int2 = sum.Toplama.sum(6465, 5248);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11713 + "'", int2 == 11713);
    }

    @Test
    public void test2038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2038");
        int int2 = sum.Toplama.sum(29044, 7731);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36775 + "'", int2 == 36775);
    }

    @Test
    public void test2039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2039");
        int int2 = sum.Toplama.sum(1727, 4149);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5876 + "'", int2 == 5876);
    }

    @Test
    public void test2040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2040");
        int int2 = sum.Toplama.sum(4030, 7650);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11680 + "'", int2 == 11680);
    }

    @Test
    public void test2041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2041");
        int int2 = sum.Toplama.sum(23356, 190);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23546 + "'", int2 == 23546);
    }

    @Test
    public void test2042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2042");
        int int2 = sum.Toplama.sum(10018, 3974);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13992 + "'", int2 == 13992);
    }

    @Test
    public void test2043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2043");
        int int2 = sum.Toplama.sum(10053, 2352);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12405 + "'", int2 == 12405);
    }

    @Test
    public void test2044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2044");
        int int2 = sum.Toplama.sum(15503, 3627);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19130 + "'", int2 == 19130);
    }

    @Test
    public void test2045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2045");
        int int2 = sum.Toplama.sum(1167, 3075);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4242 + "'", int2 == 4242);
    }

    @Test
    public void test2046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2046");
        int int2 = sum.Toplama.sum(24802, 12361);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37163 + "'", int2 == 37163);
    }

    @Test
    public void test2047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2047");
        int int2 = sum.Toplama.sum(6485, 1747);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8232 + "'", int2 == 8232);
    }

    @Test
    public void test2048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2048");
        int int2 = sum.Toplama.sum(1118, 10023);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11141 + "'", int2 == 11141);
    }

    @Test
    public void test2049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2049");
        int int2 = sum.Toplama.sum(12461, 2318);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14779 + "'", int2 == 14779);
    }

    @Test
    public void test2050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2050");
        int int2 = sum.Toplama.sum(1747, 20351);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22098 + "'", int2 == 22098);
    }

    @Test
    public void test2051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2051");
        int int2 = sum.Toplama.sum(917, 7222);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8139 + "'", int2 == 8139);
    }

    @Test
    public void test2052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2052");
        int int2 = sum.Toplama.sum(1843, 8851);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10694 + "'", int2 == 10694);
    }

    @Test
    public void test2053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2053");
        int int2 = sum.Toplama.sum(2810, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2810 + "'", int2 == 2810);
    }

    @Test
    public void test2054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2054");
        int int2 = sum.Toplama.sum(3944, 2797);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6741 + "'", int2 == 6741);
    }

    @Test
    public void test2055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2055");
        int int2 = sum.Toplama.sum(3211, 131);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3342 + "'", int2 == 3342);
    }

    @Test
    public void test2056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2056");
        int int2 = sum.Toplama.sum(4744, 1531);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6275 + "'", int2 == 6275);
    }

    @Test
    public void test2057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2057");
        int int2 = sum.Toplama.sum(1716, 10170);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11886 + "'", int2 == 11886);
    }

    @Test
    public void test2058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2058");
        int int2 = sum.Toplama.sum(9473, 477);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9950 + "'", int2 == 9950);
    }

    @Test
    public void test2059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2059");
        int int2 = sum.Toplama.sum(721, 39909);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40630 + "'", int2 == 40630);
    }

    @Test
    public void test2060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2060");
        int int2 = sum.Toplama.sum(3301, 8752);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12053 + "'", int2 == 12053);
    }

    @Test
    public void test2061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2061");
        int int2 = sum.Toplama.sum(0, 12324);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12324 + "'", int2 == 12324);
    }

    @Test
    public void test2062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2062");
        int int2 = sum.Toplama.sum(4211, 2982);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7193 + "'", int2 == 7193);
    }

    @Test
    public void test2063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2063");
        int int2 = sum.Toplama.sum(6078, 304);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6382 + "'", int2 == 6382);
    }

    @Test
    public void test2064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2064");
        int int2 = sum.Toplama.sum(5139, 96);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5235 + "'", int2 == 5235);
    }

    @Test
    public void test2065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2065");
        int int2 = sum.Toplama.sum(9991, 6768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16759 + "'", int2 == 16759);
    }

    @Test
    public void test2066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2066");
        int int2 = sum.Toplama.sum(2467, 9136);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11603 + "'", int2 == 11603);
    }

    @Test
    public void test2067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2067");
        int int2 = sum.Toplama.sum(25473, 2065);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27538 + "'", int2 == 27538);
    }

    @Test
    public void test2068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2068");
        int int2 = sum.Toplama.sum(8866, 2359);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11225 + "'", int2 == 11225);
    }

    @Test
    public void test2069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2069");
        int int2 = sum.Toplama.sum(11164, 1662);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12826 + "'", int2 == 12826);
    }

    @Test
    public void test2070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2070");
        int int2 = sum.Toplama.sum(2677, 4996);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7673 + "'", int2 == 7673);
    }

    @Test
    public void test2071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2071");
        int int2 = sum.Toplama.sum(1829, 509);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2338 + "'", int2 == 2338);
    }

    @Test
    public void test2072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2072");
        int int2 = sum.Toplama.sum(9473, 1472);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10945 + "'", int2 == 10945);
    }

    @Test
    public void test2073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2073");
        int int2 = sum.Toplama.sum(12461, 18445);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30906 + "'", int2 == 30906);
    }

    @Test
    public void test2074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2074");
        int int2 = sum.Toplama.sum(475, 8673);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9148 + "'", int2 == 9148);
    }

    @Test
    public void test2075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2075");
        int int2 = sum.Toplama.sum(14709, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14709 + "'", int2 == 14709);
    }

    @Test
    public void test2076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2076");
        int int2 = sum.Toplama.sum(11682, 2804);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14486 + "'", int2 == 14486);
    }

    @Test
    public void test2077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2077");
        int int2 = sum.Toplama.sum(6999, 8515);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15514 + "'", int2 == 15514);
    }

    @Test
    public void test2078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2078");
        int int2 = sum.Toplama.sum(739, 3833);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4572 + "'", int2 == 4572);
    }

    @Test
    public void test2079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2079");
        int int2 = sum.Toplama.sum(140, 1969);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2109 + "'", int2 == 2109);
    }

    @Test
    public void test2080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2080");
        int int2 = sum.Toplama.sum(12279, 17026);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29305 + "'", int2 == 29305);
    }

    @Test
    public void test2081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2081");
        int int2 = sum.Toplama.sum(1, 21736);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21737 + "'", int2 == 21737);
    }

    @Test
    public void test2082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2082");
        int int2 = sum.Toplama.sum(4782, 7672);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12454 + "'", int2 == 12454);
    }

    @Test
    public void test2083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2083");
        int int2 = sum.Toplama.sum(5881, 2338);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8219 + "'", int2 == 8219);
    }

    @Test
    public void test2084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2084");
        int int2 = sum.Toplama.sum(938, 4410);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5348 + "'", int2 == 5348);
    }

    @Test
    public void test2085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2085");
        int int2 = sum.Toplama.sum(3530, 6931);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10461 + "'", int2 == 10461);
    }

    @Test
    public void test2086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2086");
        int int2 = sum.Toplama.sum(5800, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5800 + "'", int2 == 5800);
    }

    @Test
    public void test2087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2087");
        int int2 = sum.Toplama.sum(351, 1697);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2048 + "'", int2 == 2048);
    }

    @Test
    public void test2088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2088");
        int int2 = sum.Toplama.sum(1271, 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1370 + "'", int2 == 1370);
    }

    @Test
    public void test2089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2089");
        int int2 = sum.Toplama.sum(20191, 4567);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24758 + "'", int2 == 24758);
    }

    @Test
    public void test2090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2090");
        int int2 = sum.Toplama.sum(14536, 17856);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32392 + "'", int2 == 32392);
    }

    @Test
    public void test2091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2091");
        int int2 = sum.Toplama.sum(6330, 17224);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23554 + "'", int2 == 23554);
    }

    @Test
    public void test2092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2092");
        int int2 = sum.Toplama.sum(1415, 5881);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7296 + "'", int2 == 7296);
    }

    @Test
    public void test2093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2093");
        int int2 = sum.Toplama.sum((int) (byte) 1, 4368);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4369 + "'", int2 == 4369);
    }

    @Test
    public void test2094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2094");
        int int2 = sum.Toplama.sum(4782, 2289);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7071 + "'", int2 == 7071);
    }

    @Test
    public void test2095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2095");
        int int2 = sum.Toplama.sum(3208, 308);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3516 + "'", int2 == 3516);
    }

    @Test
    public void test2096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2096");
        int int2 = sum.Toplama.sum(168, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 168 + "'", int2 == 168);
    }

    @Test
    public void test2097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2097");
        int int2 = sum.Toplama.sum(3509, 4939);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8448 + "'", int2 == 8448);
    }

    @Test
    public void test2098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2098");
        int int2 = sum.Toplama.sum(7642, 5917);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13559 + "'", int2 == 13559);
    }

    @Test
    public void test2099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2099");
        int int2 = sum.Toplama.sum(0, 8966);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8966 + "'", int2 == 8966);
    }

    @Test
    public void test2100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2100");
        int int2 = sum.Toplama.sum(18195, 6187);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24382 + "'", int2 == 24382);
    }

    @Test
    public void test2101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2101");
        int int2 = sum.Toplama.sum((int) (short) 0, 1278);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1278 + "'", int2 == 1278);
    }

    @Test
    public void test2102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2102");
        int int2 = sum.Toplama.sum(39330, 11715);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51045 + "'", int2 == 51045);
    }

    @Test
    public void test2103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2103");
        int int2 = sum.Toplama.sum(1540, 5012);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6552 + "'", int2 == 6552);
    }

    @Test
    public void test2104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2104");
        int int2 = sum.Toplama.sum(721, 34758);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35479 + "'", int2 == 35479);
    }

    @Test
    public void test2105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2105");
        int int2 = sum.Toplama.sum(0, 23554);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23554 + "'", int2 == 23554);
    }

    @Test
    public void test2106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2106");
        int int2 = sum.Toplama.sum(1293, 12461);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13754 + "'", int2 == 13754);
    }

    @Test
    public void test2107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2107");
        int int2 = sum.Toplama.sum(2026, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2026 + "'", int2 == 2026);
    }

    @Test
    public void test2108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2108");
        int int2 = sum.Toplama.sum(13869, 20625);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34494 + "'", int2 == 34494);
    }

    @Test
    public void test2109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2109");
        int int2 = sum.Toplama.sum(8221, 199);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8420 + "'", int2 == 8420);
    }

    @Test
    public void test2110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2110");
        int int2 = sum.Toplama.sum(5840, 5334);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11174 + "'", int2 == 11174);
    }

    @Test
    public void test2111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2111");
        int int2 = sum.Toplama.sum(227, 5922);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6149 + "'", int2 == 6149);
    }

    @Test
    public void test2112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2112");
        int int2 = sum.Toplama.sum(7713, 2258);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9971 + "'", int2 == 9971);
    }

    @Test
    public void test2113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2113");
        int int2 = sum.Toplama.sum(23031, 12898);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35929 + "'", int2 == 35929);
    }

    @Test
    public void test2114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2114");
        int int2 = sum.Toplama.sum(3101, 469);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3570 + "'", int2 == 3570);
    }

    @Test
    public void test2115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2115");
        int int2 = sum.Toplama.sum(15901, 4857);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20758 + "'", int2 == 20758);
    }

    @Test
    public void test2116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2116");
        int int2 = sum.Toplama.sum(1064, 2223);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3287 + "'", int2 == 3287);
    }

    @Test
    public void test2117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2117");
        int int2 = sum.Toplama.sum(910, 8565);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9475 + "'", int2 == 9475);
    }

    @Test
    public void test2118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2118");
        int int2 = sum.Toplama.sum(38024, 8730);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46754 + "'", int2 == 46754);
    }

    @Test
    public void test2119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2119");
        int int2 = sum.Toplama.sum(2284, 3044);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5328 + "'", int2 == 5328);
    }

    @Test
    public void test2120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2120");
        int int2 = sum.Toplama.sum(3287, 3566);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6853 + "'", int2 == 6853);
    }

    @Test
    public void test2121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2121");
        int int2 = sum.Toplama.sum(9991, 1207);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11198 + "'", int2 == 11198);
    }

    @Test
    public void test2122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2122");
        int int2 = sum.Toplama.sum(3277, 2761);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6038 + "'", int2 == 6038);
    }

    @Test
    public void test2123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2123");
        int int2 = sum.Toplama.sum(746, 1963);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2709 + "'", int2 == 2709);
    }

    @Test
    public void test2124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2124");
        int int2 = sum.Toplama.sum(3670, 1408);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5078 + "'", int2 == 5078);
    }

    @Test
    public void test2125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2125");
        int int2 = sum.Toplama.sum(17646, 1448);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19094 + "'", int2 == 19094);
    }

    @Test
    public void test2126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2126");
        int int2 = sum.Toplama.sum(2205, 4521);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6726 + "'", int2 == 6726);
    }

    @Test
    public void test2127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2127");
        int int2 = sum.Toplama.sum(3716, 7488);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11204 + "'", int2 == 11204);
    }

    @Test
    public void test2128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2128");
        int int2 = sum.Toplama.sum(10201, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10201 + "'", int2 == 10201);
    }

    @Test
    public void test2129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2129");
        int int2 = sum.Toplama.sum(199, 2569);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2768 + "'", int2 == 2768);
    }

    @Test
    public void test2130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2130");
        int int2 = sum.Toplama.sum(4434, 6853);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11287 + "'", int2 == 11287);
    }

    @Test
    public void test2131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2131");
        int int2 = sum.Toplama.sum(2814, 8870);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11684 + "'", int2 == 11684);
    }

    @Test
    public void test2132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2132");
        int int2 = sum.Toplama.sum(7007, 341);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7348 + "'", int2 == 7348);
    }

    @Test
    public void test2133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2133");
        int int2 = sum.Toplama.sum(1203, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1203 + "'", int2 == 1203);
    }

    @Test
    public void test2134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2134");
        int int2 = sum.Toplama.sum(5859, 22098);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27957 + "'", int2 == 27957);
    }

    @Test
    public void test2135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2135");
        int int2 = sum.Toplama.sum(8607, 8759);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17366 + "'", int2 == 17366);
    }

    @Test
    public void test2136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2136");
        int int2 = sum.Toplama.sum(3657, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3657 + "'", int2 == 3657);
    }

    @Test
    public void test2137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2137");
        int int2 = sum.Toplama.sum(1343, 3110);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4453 + "'", int2 == 4453);
    }

    @Test
    public void test2138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2138");
        int int2 = sum.Toplama.sum(12786, 6557);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19343 + "'", int2 == 19343);
    }

    @Test
    public void test2139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2139");
        int int2 = sum.Toplama.sum(3257, 42366);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45623 + "'", int2 == 45623);
    }

    @Test
    public void test2140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2140");
        int int2 = sum.Toplama.sum(0, 5963);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5963 + "'", int2 == 5963);
    }

    @Test
    public void test2141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2141");
        int int2 = sum.Toplama.sum(0, 3197);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3197 + "'", int2 == 3197);
    }

    @Test
    public void test2142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2142");
        int int2 = sum.Toplama.sum(11388, 17623);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29011 + "'", int2 == 29011);
    }

    @Test
    public void test2143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2143");
        int int2 = sum.Toplama.sum(10468, 7065);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17533 + "'", int2 == 17533);
    }

    @Test
    public void test2144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2144");
        int int2 = sum.Toplama.sum(12499, 1932);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14431 + "'", int2 == 14431);
    }

    @Test
    public void test2145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2145");
        int int2 = sum.Toplama.sum(181, 35283);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35464 + "'", int2 == 35464);
    }

    @Test
    public void test2146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2146");
        int int2 = sum.Toplama.sum(10754, 6159);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16913 + "'", int2 == 16913);
    }

    @Test
    public void test2147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2147");
        int int2 = sum.Toplama.sum(9991, 10170);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20161 + "'", int2 == 20161);
    }

    @Test
    public void test2148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2148");
        int int2 = sum.Toplama.sum(8912, 1287);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10199 + "'", int2 == 10199);
    }

    @Test
    public void test2149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2149");
        int int2 = sum.Toplama.sum(3458, 13376);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16834 + "'", int2 == 16834);
    }

    @Test
    public void test2150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2150");
        int int2 = sum.Toplama.sum(4171, 1171);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5342 + "'", int2 == 5342);
    }

    @Test
    public void test2151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2151");
        int int2 = sum.Toplama.sum(106, 7967);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8073 + "'", int2 == 8073);
    }

    @Test
    public void test2152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2152");
        int int2 = sum.Toplama.sum(216, 17583);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17799 + "'", int2 == 17799);
    }

    @Test
    public void test2153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2153");
        int int2 = sum.Toplama.sum(1005, 7970);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8975 + "'", int2 == 8975);
    }

    @Test
    public void test2154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2154");
        int int2 = sum.Toplama.sum(890, 1083);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1973 + "'", int2 == 1973);
    }

    @Test
    public void test2155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2155");
        int int2 = sum.Toplama.sum(2282, 5558);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7840 + "'", int2 == 7840);
    }

    @Test
    public void test2156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2156");
        int int2 = sum.Toplama.sum(10444, 10834);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21278 + "'", int2 == 21278);
    }

    @Test
    public void test2157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2157");
        int int2 = sum.Toplama.sum(3814, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3814 + "'", int2 == 3814);
    }

    @Test
    public void test2158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2158");
        int int2 = sum.Toplama.sum(5571, 9664);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15235 + "'", int2 == 15235);
    }

    @Test
    public void test2159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2159");
        int int2 = sum.Toplama.sum(5078, 2871);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7949 + "'", int2 == 7949);
    }

    @Test
    public void test2160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2160");
        int int2 = sum.Toplama.sum(7672, 2482);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10154 + "'", int2 == 10154);
    }

    @Test
    public void test2161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2161");
        int int2 = sum.Toplama.sum(21736, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21736 + "'", int2 == 21736);
    }

    @Test
    public void test2162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2162");
        int int2 = sum.Toplama.sum(8912, 2742);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11654 + "'", int2 == 11654);
    }

    @Test
    public void test2163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2163");
        int int2 = sum.Toplama.sum(3256, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3256 + "'", int2 == 3256);
    }

    @Test
    public void test2164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2164");
        int int2 = sum.Toplama.sum(3460, 2659);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6119 + "'", int2 == 6119);
    }

    @Test
    public void test2165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2165");
        int int2 = sum.Toplama.sum(24758, 1998);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26756 + "'", int2 == 26756);
    }

    @Test
    public void test2166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2166");
        int int2 = sum.Toplama.sum(23038, 5335);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28373 + "'", int2 == 28373);
    }

    @Test
    public void test2167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2167");
        int int2 = sum.Toplama.sum(6716, 10774);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17490 + "'", int2 == 17490);
    }

    @Test
    public void test2168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2168");
        int int2 = sum.Toplama.sum(16510, 1343);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17853 + "'", int2 == 17853);
    }

    @Test
    public void test2169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2169");
        int int2 = sum.Toplama.sum(51, 16510);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16561 + "'", int2 == 16561);
    }

    @Test
    public void test2170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2170");
        int int2 = sum.Toplama.sum(7459, 3913);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11372 + "'", int2 == 11372);
    }

    @Test
    public void test2171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2171");
        int int2 = sum.Toplama.sum(1662, 449);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2111 + "'", int2 == 2111);
    }

    @Test
    public void test2172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2172");
        int int2 = sum.Toplama.sum(6063, 408);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6471 + "'", int2 == 6471);
    }

    @Test
    public void test2173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2173");
        int int2 = sum.Toplama.sum(10774, 14963);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25737 + "'", int2 == 25737);
    }

    @Test
    public void test2174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2174");
        int int2 = sum.Toplama.sum(0, 2332);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2332 + "'", int2 == 2332);
    }

    @Test
    public void test2175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2175");
        int int2 = sum.Toplama.sum(4711, 6723);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11434 + "'", int2 == 11434);
    }

    @Test
    public void test2176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2176");
        int int2 = sum.Toplama.sum(805, 8785);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9590 + "'", int2 == 9590);
    }

    @Test
    public void test2177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2177");
        int int2 = sum.Toplama.sum(447, 10950);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11397 + "'", int2 == 11397);
    }

    @Test
    public void test2178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2178");
        int int2 = sum.Toplama.sum(8448, 640);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9088 + "'", int2 == 9088);
    }

    @Test
    public void test2179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2179");
        int int2 = sum.Toplama.sum(11685, 2119);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13804 + "'", int2 == 13804);
    }

    @Test
    public void test2180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2180");
        int int2 = sum.Toplama.sum(3091, 11416);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14507 + "'", int2 == 14507);
    }

    @Test
    public void test2181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2181");
        int int2 = sum.Toplama.sum((int) (byte) 1, 1976);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1977 + "'", int2 == 1977);
    }

    @Test
    public void test2182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2182");
        int int2 = sum.Toplama.sum(8263, 4169);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12432 + "'", int2 == 12432);
    }

    @Test
    public void test2183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2183");
        int int2 = sum.Toplama.sum(17152, 12701);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29853 + "'", int2 == 29853);
    }

    @Test
    public void test2184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2184");
        int int2 = sum.Toplama.sum(4578, 408);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4986 + "'", int2 == 4986);
    }

    @Test
    public void test2185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2185");
        int int2 = sum.Toplama.sum(1698, 29011);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30709 + "'", int2 == 30709);
    }

    @Test
    public void test2186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2186");
        int int2 = sum.Toplama.sum(7071, 6382);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13453 + "'", int2 == 13453);
    }

    @Test
    public void test2187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2187");
        int int2 = sum.Toplama.sum(3469, 7484);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10953 + "'", int2 == 10953);
    }

    @Test
    public void test2188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2188");
        int int2 = sum.Toplama.sum(3257, 3422);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6679 + "'", int2 == 6679);
    }

    @Test
    public void test2189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2189");
        int int2 = sum.Toplama.sum(9006, 12777);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21783 + "'", int2 == 21783);
    }

    @Test
    public void test2190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2190");
        int int2 = sum.Toplama.sum(11684, 1343);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13027 + "'", int2 == 13027);
    }

    @Test
    public void test2191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2191");
        int int2 = sum.Toplama.sum(5952, 7285);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13237 + "'", int2 == 13237);
    }

    @Test
    public void test2192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2192");
        int int2 = sum.Toplama.sum(296, 992);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1288 + "'", int2 == 1288);
    }

    @Test
    public void test2193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2193");
        int int2 = sum.Toplama.sum(13566, 2102);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15668 + "'", int2 == 15668);
    }

    @Test
    public void test2194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2194");
        int int2 = sum.Toplama.sum(3208, 7669);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10877 + "'", int2 == 10877);
    }

    @Test
    public void test2195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2195");
        int int2 = sum.Toplama.sum(1518, 5224);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6742 + "'", int2 == 6742);
    }

    @Test
    public void test2196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2196");
        int int2 = sum.Toplama.sum(888, 3023);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3911 + "'", int2 == 3911);
    }

    @Test
    public void test2197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2197");
        int int2 = sum.Toplama.sum(21783, 574);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22357 + "'", int2 == 22357);
    }

    @Test
    public void test2198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2198");
        int int2 = sum.Toplama.sum(804, 19294);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20098 + "'", int2 == 20098);
    }

    @Test
    public void test2199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2199");
        int int2 = sum.Toplama.sum(14486, 12993);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27479 + "'", int2 == 27479);
    }

    @Test
    public void test2200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2200");
        int int2 = sum.Toplama.sum(4808, 7322);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12130 + "'", int2 == 12130);
    }

    @Test
    public void test2201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2201");
        int int2 = sum.Toplama.sum(16448, 12689);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29137 + "'", int2 == 29137);
    }

    @Test
    public void test2202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2202");
        int int2 = sum.Toplama.sum(4782, 747);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5529 + "'", int2 == 5529);
    }

    @Test
    public void test2203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2203");
        int int2 = sum.Toplama.sum(11928, 16834);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28762 + "'", int2 == 28762);
    }

    @Test
    public void test2204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2204");
        int int2 = sum.Toplama.sum(12884, 2602);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15486 + "'", int2 == 15486);
    }

    @Test
    public void test2205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2205");
        int int2 = sum.Toplama.sum(1857, 4768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6625 + "'", int2 == 6625);
    }

    @Test
    public void test2206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2206");
        int int2 = sum.Toplama.sum(3106, 34758);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37864 + "'", int2 == 37864);
    }

    @Test
    public void test2207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2207");
        int int2 = sum.Toplama.sum(344, 1339);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1683 + "'", int2 == 1683);
    }

    @Test
    public void test2208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2208");
        int int2 = sum.Toplama.sum(12968, 15362);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28330 + "'", int2 == 28330);
    }

    @Test
    public void test2209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2209");
        int int2 = sum.Toplama.sum(168, 3663);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3831 + "'", int2 == 3831);
    }

    @Test
    public void test2210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2210");
        int int2 = sum.Toplama.sum(3516, 4247);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7763 + "'", int2 == 7763);
    }

    @Test
    public void test2211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2211");
        int int2 = sum.Toplama.sum(1095, 4434);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5529 + "'", int2 == 5529);
    }

    @Test
    public void test2212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2212");
        int int2 = sum.Toplama.sum(20161, 8752);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28913 + "'", int2 == 28913);
    }

    @Test
    public void test2213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2213");
        int int2 = sum.Toplama.sum(1536, 464);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
    }

    @Test
    public void test2214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2214");
        int int2 = sum.Toplama.sum(0, 8870);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8870 + "'", int2 == 8870);
    }

    @Test
    public void test2215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2215");
        int int2 = sum.Toplama.sum(15500, 5301);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20801 + "'", int2 == 20801);
    }

    @Test
    public void test2216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2216");
        int int2 = sum.Toplama.sum(2319, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2319 + "'", int2 == 2319);
    }

    @Test
    public void test2217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2217");
        int int2 = sum.Toplama.sum(7751, 11442);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19193 + "'", int2 == 19193);
    }

    @Test
    public void test2218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2218");
        int int2 = sum.Toplama.sum(11258, 393);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11651 + "'", int2 == 11651);
    }

    @Test
    public void test2219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2219");
        int int2 = sum.Toplama.sum(8975, 16878);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25853 + "'", int2 == 25853);
    }

    @Test
    public void test2220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2220");
        int int2 = sum.Toplama.sum(3044, 10154);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13198 + "'", int2 == 13198);
    }

    @Test
    public void test2221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2221");
        int int2 = sum.Toplama.sum(14653, 7065);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21718 + "'", int2 == 21718);
    }

    @Test
    public void test2222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2222");
        int int2 = sum.Toplama.sum(39330, 10063);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49393 + "'", int2 == 49393);
    }

    @Test
    public void test2223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2223");
        int int2 = sum.Toplama.sum(4768, 5334);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10102 + "'", int2 == 10102);
    }

    @Test
    public void test2224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2224");
        int int2 = sum.Toplama.sum(6626, 5166);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11792 + "'", int2 == 11792);
    }

    @Test
    public void test2225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2225");
        int int2 = sum.Toplama.sum(13754, 21808);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35562 + "'", int2 == 35562);
    }

    @Test
    public void test2226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2226");
        int int2 = sum.Toplama.sum(7329, 10022);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17351 + "'", int2 == 17351);
    }

    @Test
    public void test2227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2227");
        int int2 = sum.Toplama.sum(4626, 1147);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5773 + "'", int2 == 5773);
    }

    @Test
    public void test2228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2228");
        int int2 = sum.Toplama.sum(3095, 9004);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12099 + "'", int2 == 12099);
    }

    @Test
    public void test2229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2229");
        int int2 = sum.Toplama.sum(880, 3085);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3965 + "'", int2 == 3965);
    }

    @Test
    public void test2230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2230");
        int int2 = sum.Toplama.sum(27538, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27635 + "'", int2 == 27635);
    }

    @Test
    public void test2231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2231");
        int int2 = sum.Toplama.sum(2004, 10883);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12887 + "'", int2 == 12887);
    }

    @Test
    public void test2232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2232");
        int int2 = sum.Toplama.sum(5653, 6030);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11683 + "'", int2 == 11683);
    }

    @Test
    public void test2233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2233");
        int int2 = sum.Toplama.sum(6471, 3775);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10246 + "'", int2 == 10246);
    }

    @Test
    public void test2234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2234");
        int int2 = sum.Toplama.sum(1958, 5570);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7528 + "'", int2 == 7528);
    }

    @Test
    public void test2235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2235");
        int int2 = sum.Toplama.sum(14621, 5284);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19905 + "'", int2 == 19905);
    }

    @Test
    public void test2236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2236");
        int int2 = sum.Toplama.sum(7472, 28373);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35845 + "'", int2 == 35845);
    }

    @Test
    public void test2237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2237");
        int int2 = sum.Toplama.sum(3623, 6377);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10000 + "'", int2 == 10000);
    }

    @Test
    public void test2238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2238");
        int int2 = sum.Toplama.sum(1622, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1622 + "'", int2 == 1622);
    }

    @Test
    public void test2239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2239");
        int int2 = sum.Toplama.sum(4797, 2579);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7376 + "'", int2 == 7376);
    }

    @Test
    public void test2240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2240");
        int int2 = sum.Toplama.sum(7431, 1239);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8670 + "'", int2 == 8670);
    }

    @Test
    public void test2241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2241");
        int int2 = sum.Toplama.sum(4577, 4542);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9119 + "'", int2 == 9119);
    }

    @Test
    public void test2242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2242");
        int int2 = sum.Toplama.sum(5403, 11651);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17054 + "'", int2 == 17054);
    }

    @Test
    public void test2243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2243");
        int int2 = sum.Toplama.sum(282, 1342);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1624 + "'", int2 == 1624);
    }

    @Test
    public void test2244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2244");
        int int2 = sum.Toplama.sum(26562, 8870);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35432 + "'", int2 == 35432);
    }

    @Test
    public void test2245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2245");
        int int2 = sum.Toplama.sum(12576, 17920);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30496 + "'", int2 == 30496);
    }

    @Test
    public void test2246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2246");
        int int2 = sum.Toplama.sum(8474, 13123);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21597 + "'", int2 == 21597);
    }

    @Test
    public void test2247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2247");
        int int2 = sum.Toplama.sum(151, 13804);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13955 + "'", int2 == 13955);
    }

    @Test
    public void test2248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2248");
        int int2 = sum.Toplama.sum(22098, 88);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22186 + "'", int2 == 22186);
    }

    @Test
    public void test2249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2249");
        int int2 = sum.Toplama.sum(9991, 34758);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44749 + "'", int2 == 44749);
    }

    @Test
    public void test2250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2250");
        int int2 = sum.Toplama.sum(997, 6227);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7224 + "'", int2 == 7224);
    }

    @Test
    public void test2251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2251");
        int int2 = sum.Toplama.sum(19703, 6062);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25765 + "'", int2 == 25765);
    }

    @Test
    public void test2252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2252");
        int int2 = sum.Toplama.sum(8282, 4567);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12849 + "'", int2 == 12849);
    }

    @Test
    public void test2253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2253");
        int int2 = sum.Toplama.sum(2368, 8532);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10900 + "'", int2 == 10900);
    }

    @Test
    public void test2254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2254");
        int int2 = sum.Toplama.sum(11685, 3130);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14815 + "'", int2 == 14815);
    }

    @Test
    public void test2255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2255");
        int int2 = sum.Toplama.sum(2698, 21893);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24591 + "'", int2 == 24591);
    }

    @Test
    public void test2256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2256");
        int int2 = sum.Toplama.sum(2942, 1339);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4281 + "'", int2 == 4281);
    }

    @Test
    public void test2257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2257");
        int int2 = sum.Toplama.sum(25473, 5639);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31112 + "'", int2 == 31112);
    }

    @Test
    public void test2258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2258");
        int int2 = sum.Toplama.sum(8344, 4953);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13297 + "'", int2 == 13297);
    }

    @Test
    public void test2259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2259");
        int int2 = sum.Toplama.sum(7232, 3598);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10830 + "'", int2 == 10830);
    }

    @Test
    public void test2260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2260");
        int int2 = sum.Toplama.sum(110, 9868);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9978 + "'", int2 == 9978);
    }

    @Test
    public void test2261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2261");
        int int2 = sum.Toplama.sum(4613, 5855);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10468 + "'", int2 == 10468);
    }

    @Test
    public void test2262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2262");
        int int2 = sum.Toplama.sum(2013, 8308);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10321 + "'", int2 == 10321);
    }

    @Test
    public void test2263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2263");
        int int2 = sum.Toplama.sum(16109, 3772);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19881 + "'", int2 == 19881);
    }

    @Test
    public void test2264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2264");
        int int2 = sum.Toplama.sum(17452, 2325);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19777 + "'", int2 == 19777);
    }

    @Test
    public void test2265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2265");
        int int2 = sum.Toplama.sum(13199, 18166);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31365 + "'", int2 == 31365);
    }

    @Test
    public void test2266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2266");
        int int2 = sum.Toplama.sum(515, 6378);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6893 + "'", int2 == 6893);
    }

    @Test
    public void test2267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2267");
        int int2 = sum.Toplama.sum(6377, 11007);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17384 + "'", int2 == 17384);
    }

    @Test
    public void test2268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2268");
        int int2 = sum.Toplama.sum(970, 19808);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20778 + "'", int2 == 20778);
    }

    @Test
    public void test2269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2269");
        int int2 = sum.Toplama.sum(3323, 13453);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16776 + "'", int2 == 16776);
    }

    @Test
    public void test2270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2270");
        int int2 = sum.Toplama.sum(5718, 27957);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33675 + "'", int2 == 33675);
    }

    @Test
    public void test2271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2271");
        int int2 = sum.Toplama.sum(1240, 4902);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6142 + "'", int2 == 6142);
    }

    @Test
    public void test2272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2272");
        int int2 = sum.Toplama.sum(6466, 10321);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16787 + "'", int2 == 16787);
    }

    @Test
    public void test2273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2273");
        int int2 = sum.Toplama.sum(2109, 4169);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6278 + "'", int2 == 6278);
    }

    @Test
    public void test2274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2274");
        int int2 = sum.Toplama.sum(1337, 5997);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7334 + "'", int2 == 7334);
    }

    @Test
    public void test2275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2275");
        int int2 = sum.Toplama.sum(12849, 7713);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20562 + "'", int2 == 20562);
    }

    @Test
    public void test2276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2276");
        int int2 = sum.Toplama.sum(7625, 1965);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9590 + "'", int2 == 9590);
    }

    @Test
    public void test2277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2277");
        int int2 = sum.Toplama.sum(2644, 28762);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31406 + "'", int2 == 31406);
    }

    @Test
    public void test2278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2278");
        int int2 = sum.Toplama.sum(2741, 3959);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6700 + "'", int2 == 6700);
    }

    @Test
    public void test2279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2279");
        int int2 = sum.Toplama.sum(0, 4797);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4797 + "'", int2 == 4797);
    }

    @Test
    public void test2280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2280");
        int int2 = sum.Toplama.sum(39909, 8831);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48740 + "'", int2 == 48740);
    }

    @Test
    public void test2281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2281");
        int int2 = sum.Toplama.sum(13062, 10201);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23263 + "'", int2 == 23263);
    }

    @Test
    public void test2282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2282");
        int int2 = sum.Toplama.sum(3059, 9590);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12649 + "'", int2 == 12649);
    }

    @Test
    public void test2283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2283");
        int int2 = sum.Toplama.sum(527, 8219);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8746 + "'", int2 == 8746);
    }

    @Test
    public void test2284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2284");
        int int2 = sum.Toplama.sum(4609, 3662);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8271 + "'", int2 == 8271);
    }

    @Test
    public void test2285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2285");
        int int2 = sum.Toplama.sum(440, 640);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1080 + "'", int2 == 1080);
    }

    @Test
    public void test2286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2286");
        int int2 = sum.Toplama.sum(3586, 4310);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7896 + "'", int2 == 7896);
    }

    @Test
    public void test2287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2287");
        int int2 = sum.Toplama.sum(4369, 486);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4855 + "'", int2 == 4855);
    }

    @Test
    public void test2288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2288");
        int int2 = sum.Toplama.sum(0, 7296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7296 + "'", int2 == 7296);
    }

    @Test
    public void test2289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2289");
        int int2 = sum.Toplama.sum(433, 6080);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6513 + "'", int2 == 6513);
    }

    @Test
    public void test2290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2290");
        int int2 = sum.Toplama.sum(3825, 7459);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11284 + "'", int2 == 11284);
    }

    @Test
    public void test2291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2291");
        int int2 = sum.Toplama.sum(8041, 4957);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12998 + "'", int2 == 12998);
    }

    @Test
    public void test2292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2292");
        int int2 = sum.Toplama.sum(2747, 3272);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6019 + "'", int2 == 6019);
    }

    @Test
    public void test2293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2293");
        int int2 = sum.Toplama.sum(3824, 51210);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55034 + "'", int2 == 55034);
    }

    @Test
    public void test2294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2294");
        int int2 = sum.Toplama.sum(11284, 16442);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27726 + "'", int2 == 27726);
    }

    @Test
    public void test2295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2295");
        int int2 = sum.Toplama.sum(12499, 12968);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25467 + "'", int2 == 25467);
    }

    @Test
    public void test2296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2296");
        int int2 = sum.Toplama.sum(10108, 6107);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16215 + "'", int2 == 16215);
    }

    @Test
    public void test2297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2297");
        int int2 = sum.Toplama.sum(421, 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 520 + "'", int2 == 520);
    }

    @Test
    public void test2298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2298");
        int int2 = sum.Toplama.sum(1772, 2253);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4025 + "'", int2 == 4025);
    }

    @Test
    public void test2299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2299");
        int int2 = sum.Toplama.sum(6692, 16109);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22801 + "'", int2 == 22801);
    }

    @Test
    public void test2300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2300");
        int int2 = sum.Toplama.sum(2125, 7079);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9204 + "'", int2 == 9204);
    }

    @Test
    public void test2301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2301");
        int int2 = sum.Toplama.sum(3208, 23180);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26388 + "'", int2 == 26388);
    }

    @Test
    public void test2302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2302");
        int int2 = sum.Toplama.sum(3105, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3105 + "'", int2 == 3105);
    }

    @Test
    public void test2303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2303");
        int int2 = sum.Toplama.sum(0, 1465);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1465 + "'", int2 == 1465);
    }

    @Test
    public void test2304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2304");
        int int2 = sum.Toplama.sum(8474, 2761);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11235 + "'", int2 == 11235);
    }

    @Test
    public void test2305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2305");
        int int2 = sum.Toplama.sum(29011, 11069);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40080 + "'", int2 == 40080);
    }

    @Test
    public void test2306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2306");
        int int2 = sum.Toplama.sum(11162, 4410);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15572 + "'", int2 == 15572);
    }

    @Test
    public void test2307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2307");
        int int2 = sum.Toplama.sum(19777, 3257);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23034 + "'", int2 == 23034);
    }

    @Test
    public void test2308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2308");
        int int2 = sum.Toplama.sum(2249, 3160);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5409 + "'", int2 == 5409);
    }

    @Test
    public void test2309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2309");
        int int2 = sum.Toplama.sum(1472, 5800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7272 + "'", int2 == 7272);
    }

    @Test
    public void test2310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2310");
        int int2 = sum.Toplama.sum(421, 3911);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4332 + "'", int2 == 4332);
    }

    @Test
    public void test2311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2311");
        int int2 = sum.Toplama.sum(24499, 1276);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25775 + "'", int2 == 25775);
    }

    @Test
    public void test2312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2312");
        int int2 = sum.Toplama.sum(7963, 543);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8506 + "'", int2 == 8506);
    }

    @Test
    public void test2313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2313");
        int int2 = sum.Toplama.sum(9148, 7673);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16821 + "'", int2 == 16821);
    }

    @Test
    public void test2314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2314");
        int int2 = sum.Toplama.sum(739, 19130);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19869 + "'", int2 == 19869);
    }

    @Test
    public void test2315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2315");
        int int2 = sum.Toplama.sum(23263, 8515);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31778 + "'", int2 == 31778);
    }

    @Test
    public void test2316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2316");
        int int2 = sum.Toplama.sum(21736, 8924);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30660 + "'", int2 == 30660);
    }

    @Test
    public void test2317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2317");
        int int2 = sum.Toplama.sum(11650, 5252);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16902 + "'", int2 == 16902);
    }

    @Test
    public void test2318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2318");
        int int2 = sum.Toplama.sum(948, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 948 + "'", int2 == 948);
    }

    @Test
    public void test2319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2319");
        int int2 = sum.Toplama.sum(6092, 7331);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13423 + "'", int2 == 13423);
    }

    @Test
    public void test2320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2320");
        int int2 = sum.Toplama.sum(0, 2055);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2055 + "'", int2 == 2055);
    }

    @Test
    public void test2321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2321");
        int int2 = sum.Toplama.sum(691, 10198);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10889 + "'", int2 == 10889);
    }

    @Test
    public void test2322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2322");
        int int2 = sum.Toplama.sum(23190, 897);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24087 + "'", int2 == 24087);
    }

    @Test
    public void test2323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2323");
        int int2 = sum.Toplama.sum(10448, 6326);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16774 + "'", int2 == 16774);
    }

    @Test
    public void test2324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2324");
        int int2 = sum.Toplama.sum(4232, 835);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5067 + "'", int2 == 5067);
    }

    @Test
    public void test2325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2325");
        int int2 = sum.Toplama.sum(1685, 433);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2118 + "'", int2 == 2118);
    }

    @Test
    public void test2326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2326");
        int int2 = sum.Toplama.sum(14809, 16834);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31643 + "'", int2 == 31643);
    }

    @Test
    public void test2327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2327");
        int int2 = sum.Toplama.sum(35845, 10663);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46508 + "'", int2 == 46508);
    }

    @Test
    public void test2328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2328");
        int int2 = sum.Toplama.sum(6105, 7083);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13188 + "'", int2 == 13188);
    }

    @Test
    public void test2329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2329");
        int int2 = sum.Toplama.sum(554, 8012);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8566 + "'", int2 == 8566);
    }

    @Test
    public void test2330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2330");
        int int2 = sum.Toplama.sum(11174, 23180);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34354 + "'", int2 == 34354);
    }

    @Test
    public void test2331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2331");
        int int2 = sum.Toplama.sum(21593, 721);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22314 + "'", int2 == 22314);
    }

    @Test
    public void test2332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2332");
        int int2 = sum.Toplama.sum(26388, 21280);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47668 + "'", int2 == 47668);
    }

    @Test
    public void test2333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2333");
        int int2 = sum.Toplama.sum(2123, 13777);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15900 + "'", int2 == 15900);
    }

    @Test
    public void test2334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2334");
        int int2 = sum.Toplama.sum(2651, 9059);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11710 + "'", int2 == 11710);
    }

    @Test
    public void test2335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2335");
        int int2 = sum.Toplama.sum(3036, 7954);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10990 + "'", int2 == 10990);
    }

    @Test
    public void test2336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2336");
        int int2 = sum.Toplama.sum(9978, 3169);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13147 + "'", int2 == 13147);
    }

    @Test
    public void test2337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2337");
        int int2 = sum.Toplama.sum((int) (short) 1, 216);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 217 + "'", int2 == 217);
    }

    @Test
    public void test2338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2338");
        int int2 = sum.Toplama.sum(11074, 6378);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17452 + "'", int2 == 17452);
    }

    @Test
    public void test2339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2339");
        int int2 = sum.Toplama.sum(2045, 5188);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7233 + "'", int2 == 7233);
    }

    @Test
    public void test2340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2340");
        int int2 = sum.Toplama.sum(980, 8065);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9045 + "'", int2 == 9045);
    }

    @Test
    public void test2341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2341");
        int int2 = sum.Toplama.sum(5626, 2788);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8414 + "'", int2 == 8414);
    }

    @Test
    public void test2342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2342");
        int int2 = sum.Toplama.sum(5978, 21894);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27872 + "'", int2 == 27872);
    }

    @Test
    public void test2343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2343");
        int int2 = sum.Toplama.sum(7576, 6474);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14050 + "'", int2 == 14050);
    }

    @Test
    public void test2344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2344");
        int int2 = sum.Toplama.sum(3211, 21278);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24489 + "'", int2 == 24489);
    }

    @Test
    public void test2345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2345");
        int int2 = sum.Toplama.sum(5800, 2368);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8168 + "'", int2 == 8168);
    }

    @Test
    public void test2346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2346");
        int int2 = sum.Toplama.sum(11792, 8851);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20643 + "'", int2 == 20643);
    }

    @Test
    public void test2347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2347");
        int int2 = sum.Toplama.sum(3663, 5235);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8898 + "'", int2 == 8898);
    }

    @Test
    public void test2348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2348");
        int int2 = sum.Toplama.sum(1639, 1223);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2862 + "'", int2 == 2862);
    }

    @Test
    public void test2349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2349");
        int int2 = sum.Toplama.sum(11385, 4582);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15967 + "'", int2 == 15967);
    }

    @Test
    public void test2350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2350");
        int int2 = sum.Toplama.sum(2582, 10594);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13176 + "'", int2 == 13176);
    }

    @Test
    public void test2351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2351");
        int int2 = sum.Toplama.sum(14620, 10830);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25450 + "'", int2 == 25450);
    }

    @Test
    public void test2352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2352");
        int int2 = sum.Toplama.sum(2982, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2982 + "'", int2 == 2982);
    }

    @Test
    public void test2353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2353");
        int int2 = sum.Toplama.sum(720, 1249);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
    }

    @Test
    public void test2354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2354");
        int int2 = sum.Toplama.sum(4137, 4369);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8506 + "'", int2 == 8506);
    }

    @Test
    public void test2355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2355");
        int int2 = sum.Toplama.sum(1023, 307);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1330 + "'", int2 == 1330);
    }

    @Test
    public void test2356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2356");
        int int2 = sum.Toplama.sum(9367, 6957);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16324 + "'", int2 == 16324);
    }

    @Test
    public void test2357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2357");
        int int2 = sum.Toplama.sum(7233, 23014);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30247 + "'", int2 == 30247);
    }

    @Test
    public void test2358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2358");
        int int2 = sum.Toplama.sum(2056, 5783);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7839 + "'", int2 == 7839);
    }

    @Test
    public void test2359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2359");
        int int2 = sum.Toplama.sum(16448, 3283);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19731 + "'", int2 == 19731);
    }

    @Test
    public void test2360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2360");
        int int2 = sum.Toplama.sum(8851, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8948 + "'", int2 == 8948);
    }

    @Test
    public void test2361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2361");
        int int2 = sum.Toplama.sum(4902, 3458);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8360 + "'", int2 == 8360);
    }

    @Test
    public void test2362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2362");
        int int2 = sum.Toplama.sum(14181, 1631);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15812 + "'", int2 == 15812);
    }

    @Test
    public void test2363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2363");
        int int2 = sum.Toplama.sum(3199, 870);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4069 + "'", int2 == 4069);
    }

    @Test
    public void test2364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2364");
        int int2 = sum.Toplama.sum(1207, 23031);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24238 + "'", int2 == 24238);
    }

    @Test
    public void test2365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2365");
        int int2 = sum.Toplama.sum(5348, 7030);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12378 + "'", int2 == 12378);
    }

    @Test
    public void test2366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2366");
        int int2 = sum.Toplama.sum(109, 44749);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44858 + "'", int2 == 44858);
    }

    @Test
    public void test2367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2367");
        int int2 = sum.Toplama.sum(9156, 3924);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13080 + "'", int2 == 13080);
    }

    @Test
    public void test2368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2368");
        int int2 = sum.Toplama.sum(25476, 8969);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34445 + "'", int2 == 34445);
    }

    @Test
    public void test2369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2369");
        int int2 = sum.Toplama.sum(964, 557);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1521 + "'", int2 == 1521);
    }

    @Test
    public void test2370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2370");
        int int2 = sum.Toplama.sum(877, 5256);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6133 + "'", int2 == 6133);
    }

    @Test
    public void test2371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2371");
        int int2 = sum.Toplama.sum(1584, 2411);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3995 + "'", int2 == 3995);
    }

    @Test
    public void test2372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2372");
        int int2 = sum.Toplama.sum(7672, 3113);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10785 + "'", int2 == 10785);
    }

    @Test
    public void test2373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2373");
        int int2 = sum.Toplama.sum(1579, 1703);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3282 + "'", int2 == 3282);
    }

    @Test
    public void test2374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2374");
        int int2 = sum.Toplama.sum(6158, 19130);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25288 + "'", int2 == 25288);
    }

    @Test
    public void test2375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2375");
        int int2 = sum.Toplama.sum(38024, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38024 + "'", int2 == 38024);
    }

    @Test
    public void test2376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2376");
        int int2 = sum.Toplama.sum(25853, 5078);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30931 + "'", int2 == 30931);
    }

    @Test
    public void test2377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2377");
        int int2 = sum.Toplama.sum(7642, 405);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8047 + "'", int2 == 8047);
    }

    @Test
    public void test2378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2378");
        int int2 = sum.Toplama.sum(1768, 12309);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14077 + "'", int2 == 14077);
    }

    @Test
    public void test2379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2379");
        int int2 = sum.Toplama.sum(9035, 5208);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14243 + "'", int2 == 14243);
    }

    @Test
    public void test2380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2380");
        int int2 = sum.Toplama.sum(1274, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1374 + "'", int2 == 1374);
    }

    @Test
    public void test2381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2381");
        int int2 = sum.Toplama.sum(14467, 4939);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19406 + "'", int2 == 19406);
    }

    @Test
    public void test2382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2382");
        int int2 = sum.Toplama.sum(1207, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1207 + "'", int2 == 1207);
    }

    @Test
    public void test2383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2383");
        int int2 = sum.Toplama.sum(5606, 1976);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7582 + "'", int2 == 7582);
    }

    @Test
    public void test2384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2384");
        int int2 = sum.Toplama.sum(19808, 8752);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28560 + "'", int2 == 28560);
    }

    @Test
    public void test2385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2385");
        int int2 = sum.Toplama.sum(5256, 7224);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12480 + "'", int2 == 12480);
    }

    @Test
    public void test2386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2386");
        int int2 = sum.Toplama.sum(10565, 15115);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25680 + "'", int2 == 25680);
    }

    @Test
    public void test2387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2387");
        int int2 = sum.Toplama.sum((int) (byte) 10, 6621);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6631 + "'", int2 == 6631);
    }

    @Test
    public void test2388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2388");
        int int2 = sum.Toplama.sum(1213, 18228);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19441 + "'", int2 == 19441);
    }

    @Test
    public void test2389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2389");
        int int2 = sum.Toplama.sum(1943, 7020);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8963 + "'", int2 == 8963);
    }

    @Test
    public void test2390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2390");
        int int2 = sum.Toplama.sum(0, 4089);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4089 + "'", int2 == 4089);
    }

    @Test
    public void test2391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2391");
        int int2 = sum.Toplama.sum(896, 10940);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11836 + "'", int2 == 11836);
    }

    @Test
    public void test2392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2392");
        int int2 = sum.Toplama.sum(5996, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5996 + "'", int2 == 5996);
    }

    @Test
    public void test2393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2393");
        int int2 = sum.Toplama.sum(857, 5342);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6199 + "'", int2 == 6199);
    }

    @Test
    public void test2394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2394");
        int int2 = sum.Toplama.sum(0, 13062);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13062 + "'", int2 == 13062);
    }

    @Test
    public void test2395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2395");
        int int2 = sum.Toplama.sum(29137, 10170);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39307 + "'", int2 == 39307);
    }

    @Test
    public void test2396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2396");
        int int2 = sum.Toplama.sum(4486, 2804);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7290 + "'", int2 == 7290);
    }

    @Test
    public void test2397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2397");
        int int2 = sum.Toplama.sum(35283, 1666);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36949 + "'", int2 == 36949);
    }

    @Test
    public void test2398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2398");
        int int2 = sum.Toplama.sum(4957, 12998);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17955 + "'", int2 == 17955);
    }

    @Test
    public void test2399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2399");
        int int2 = sum.Toplama.sum(315, 9953);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10268 + "'", int2 == 10268);
    }

    @Test
    public void test2400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2400");
        int int2 = sum.Toplama.sum(9526, 2913);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12439 + "'", int2 == 12439);
    }

    @Test
    public void test2401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2401");
        int int2 = sum.Toplama.sum(1064, 10940);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12004 + "'", int2 == 12004);
    }

    @Test
    public void test2402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2402");
        int int2 = sum.Toplama.sum(10018, 10694);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20712 + "'", int2 == 20712);
    }

    @Test
    public void test2403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2403");
        int int2 = sum.Toplama.sum(5997, 8827);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14824 + "'", int2 == 14824);
    }

    @Test
    public void test2404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2404");
        int int2 = sum.Toplama.sum(2824, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2824 + "'", int2 == 2824);
    }

    @Test
    public void test2405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2405");
        int int2 = sum.Toplama.sum(7736, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7736 + "'", int2 == 7736);
    }

    @Test
    public void test2406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2406");
        int int2 = sum.Toplama.sum(0, 9677);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9677 + "'", int2 == 9677);
    }

    @Test
    public void test2407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2407");
        int int2 = sum.Toplama.sum(8526, 15917);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24443 + "'", int2 == 24443);
    }

    @Test
    public void test2408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2408");
        int int2 = sum.Toplama.sum(11654, 19808);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31462 + "'", int2 == 31462);
    }

    @Test
    public void test2409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2409");
        int int2 = sum.Toplama.sum(37864, 6235);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44099 + "'", int2 == 44099);
    }

    @Test
    public void test2410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2410");
        int int2 = sum.Toplama.sum(2895, 3944);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6839 + "'", int2 == 6839);
    }

    @Test
    public void test2411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2411");
        int int2 = sum.Toplama.sum(2258, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2258 + "'", int2 == 2258);
    }

    @Test
    public void test2412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2412");
        int int2 = sum.Toplama.sum(2587, 30496);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33083 + "'", int2 == 33083);
    }

    @Test
    public void test2413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2413");
        int int2 = sum.Toplama.sum(11022, 488);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11510 + "'", int2 == 11510);
    }

    @Test
    public void test2414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2414");
        int int2 = sum.Toplama.sum(7753, 2386);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10139 + "'", int2 == 10139);
    }

    @Test
    public void test2415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2415");
        int int2 = sum.Toplama.sum(13208, 9748);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22956 + "'", int2 == 22956);
    }

    @Test
    public void test2416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2416");
        int int2 = sum.Toplama.sum(305, 13566);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13871 + "'", int2 == 13871);
    }

    @Test
    public void test2417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2417");
        int int2 = sum.Toplama.sum(0, 25737);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25737 + "'", int2 == 25737);
    }

    @Test
    public void test2418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2418");
        int int2 = sum.Toplama.sum(20805, 8963);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29768 + "'", int2 == 29768);
    }

    @Test
    public void test2419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2419");
        int int2 = sum.Toplama.sum(12826, 8234);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21060 + "'", int2 == 21060);
    }

    @Test
    public void test2420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2420");
        int int2 = sum.Toplama.sum(5342, 5659);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11001 + "'", int2 == 11001);
    }

    @Test
    public void test2421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2421");
        int int2 = sum.Toplama.sum(1622, 24499);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26121 + "'", int2 == 26121);
    }

    @Test
    public void test2422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2422");
        int int2 = sum.Toplama.sum(2940, 4093);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7033 + "'", int2 == 7033);
    }

    @Test
    public void test2423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2423");
        int int2 = sum.Toplama.sum(13453, 199);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13652 + "'", int2 == 13652);
    }

    @Test
    public void test2424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2424");
        int int2 = sum.Toplama.sum(1522, 2897);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4419 + "'", int2 == 4419);
    }

    @Test
    public void test2425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2425");
        int int2 = sum.Toplama.sum(3241, 2523);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5764 + "'", int2 == 5764);
    }

    @Test
    public void test2426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2426");
        int int2 = sum.Toplama.sum(4312, 6874);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11186 + "'", int2 == 11186);
    }

    @Test
    public void test2427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2427");
        int int2 = sum.Toplama.sum(3176, 4690);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7866 + "'", int2 == 7866);
    }

    @Test
    public void test2428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2428");
        int int2 = sum.Toplama.sum(6638, 21280);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27918 + "'", int2 == 27918);
    }

    @Test
    public void test2429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2429");
        int int2 = sum.Toplama.sum(10216, 8837);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19053 + "'", int2 == 19053);
    }

    @Test
    public void test2430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2430");
        int int2 = sum.Toplama.sum(1570, 3593);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5163 + "'", int2 == 5163);
    }

    @Test
    public void test2431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2431");
        int int2 = sum.Toplama.sum(3012, 4744);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7756 + "'", int2 == 7756);
    }

    @Test
    public void test2432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2432");
        int int2 = sum.Toplama.sum(11654, 23192);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34846 + "'", int2 == 34846);
    }

    @Test
    public void test2433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2433");
        int int2 = sum.Toplama.sum(3220, 2609);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5829 + "'", int2 == 5829);
    }

    @Test
    public void test2434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2434");
        int int2 = sum.Toplama.sum(29853, 4827);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34680 + "'", int2 == 34680);
    }

    @Test
    public void test2435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2435");
        int int2 = sum.Toplama.sum(948, 23276);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24224 + "'", int2 == 24224);
    }

    @Test
    public void test2436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2436");
        int int2 = sum.Toplama.sum(2932, 3220);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6152 + "'", int2 == 6152);
    }

    @Test
    public void test2437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2437");
        int int2 = sum.Toplama.sum(15999, 16123);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32122 + "'", int2 == 32122);
    }

    @Test
    public void test2438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2438");
        int int2 = sum.Toplama.sum(24224, 1698);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25922 + "'", int2 == 25922);
    }

    @Test
    public void test2439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2439");
        int int2 = sum.Toplama.sum(11654, 2723);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14377 + "'", int2 == 14377);
    }

    @Test
    public void test2440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2440");
        int int2 = sum.Toplama.sum(3991, 21082);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25073 + "'", int2 == 25073);
    }

    @Test
    public void test2441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2441");
        int int2 = sum.Toplama.sum(5529, 1839);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7368 + "'", int2 == 7368);
    }

    @Test
    public void test2442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2442");
        int int2 = sum.Toplama.sum(11164, 1965);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13129 + "'", int2 == 13129);
    }

    @Test
    public void test2443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2443");
        int int2 = sum.Toplama.sum(294, 7329);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7623 + "'", int2 == 7623);
    }

    @Test
    public void test2444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2444");
        int int2 = sum.Toplama.sum(11162, 23034);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34196 + "'", int2 == 34196);
    }

    @Test
    public void test2445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2445");
        int int2 = sum.Toplama.sum(1385, 5455);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6840 + "'", int2 == 6840);
    }

    @Test
    public void test2446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2446");
        int int2 = sum.Toplama.sum(9187, 2249);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11436 + "'", int2 == 11436);
    }

    @Test
    public void test2447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2447");
        int int2 = sum.Toplama.sum(16522, 3566);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20088 + "'", int2 == 20088);
    }

    @Test
    public void test2448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2448");
        int int2 = sum.Toplama.sum(381, 427);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 808 + "'", int2 == 808);
    }

    @Test
    public void test2449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2449");
        int int2 = sum.Toplama.sum(6019, 4682);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10701 + "'", int2 == 10701);
    }

    @Test
    public void test2450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2450");
        int int2 = sum.Toplama.sum(8113, 7488);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15601 + "'", int2 == 15601);
    }

    @Test
    public void test2451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2451");
        int int2 = sum.Toplama.sum(18820, 33112);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51932 + "'", int2 == 51932);
    }

    @Test
    public void test2452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2452");
        int int2 = sum.Toplama.sum(9916, 1797);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11713 + "'", int2 == 11713);
    }

    @Test
    public void test2453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2453");
        int int2 = sum.Toplama.sum(0, 3422);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3422 + "'", int2 == 3422);
    }

    @Test
    public void test2454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2454");
        int int2 = sum.Toplama.sum(522, 3257);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3779 + "'", int2 == 3779);
    }

    @Test
    public void test2455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2455");
        int int2 = sum.Toplama.sum(1037, 17016);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18053 + "'", int2 == 18053);
    }

    @Test
    public void test2456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2456");
        int int2 = sum.Toplama.sum(3900, 3569);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7469 + "'", int2 == 7469);
    }

    @Test
    public void test2457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2457");
        int int2 = sum.Toplama.sum(1839, 12887);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14726 + "'", int2 == 14726);
    }

    @Test
    public void test2458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2458");
        int int2 = sum.Toplama.sum(1095, 1233);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2328 + "'", int2 == 2328);
    }

    @Test
    public void test2459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2459");
        int int2 = sum.Toplama.sum(6078, 508);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6586 + "'", int2 == 6586);
    }

    @Test
    public void test2460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2460");
        int int2 = sum.Toplama.sum(2319, 6978);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9297 + "'", int2 == 9297);
    }

    @Test
    public void test2461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2461");
        int int2 = sum.Toplama.sum(16213, 393);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16606 + "'", int2 == 16606);
    }

    @Test
    public void test2462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2462");
        int int2 = sum.Toplama.sum(2561, 9870);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12431 + "'", int2 == 12431);
    }

    @Test
    public void test2463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2463");
        int int2 = sum.Toplama.sum(0, 5021);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5021 + "'", int2 == 5021);
    }

    @Test
    public void test2464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2464");
        int int2 = sum.Toplama.sum(1840, 5643);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7483 + "'", int2 == 7483);
    }

    @Test
    public void test2465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2465");
        int int2 = sum.Toplama.sum(1238, 6330);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7568 + "'", int2 == 7568);
    }

    @Test
    public void test2466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2466");
        int int2 = sum.Toplama.sum(7949, 3125);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11074 + "'", int2 == 11074);
    }

    @Test
    public void test2467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2467");
        int int2 = sum.Toplama.sum(0, 8837);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8837 + "'", int2 == 8837);
    }

    @Test
    public void test2468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2468");
        int int2 = sum.Toplama.sum(0, 3578);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3578 + "'", int2 == 3578);
    }

    @Test
    public void test2469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2469");
        int int2 = sum.Toplama.sum(1411, 2968);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4379 + "'", int2 == 4379);
    }

    @Test
    public void test2470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2470");
        int int2 = sum.Toplama.sum(307, 1105);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1412 + "'", int2 == 1412);
    }

    @Test
    public void test2471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2471");
        int int2 = sum.Toplama.sum(508, 24758);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25266 + "'", int2 == 25266);
    }

    @Test
    public void test2472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2472");
        int int2 = sum.Toplama.sum(1784, 8084);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9868 + "'", int2 == 9868);
    }

    @Test
    public void test2473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2473");
        int int2 = sum.Toplama.sum(25067, 13062);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38129 + "'", int2 == 38129);
    }

    @Test
    public void test2474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2474");
        int int2 = sum.Toplama.sum(7745, 10883);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18628 + "'", int2 == 18628);
    }

    @Test
    public void test2475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2475");
        int int2 = sum.Toplama.sum(12813, 3399);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16212 + "'", int2 == 16212);
    }

    @Test
    public void test2476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2476");
        int int2 = sum.Toplama.sum(19442, 1481);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20923 + "'", int2 == 20923);
    }

    @Test
    public void test2477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2477");
        int int2 = sum.Toplama.sum(1385, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1385 + "'", int2 == 1385);
    }

    @Test
    public void test2478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2478");
        int int2 = sum.Toplama.sum(4563, 3901);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8464 + "'", int2 == 8464);
    }

    @Test
    public void test2479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2479");
        int int2 = sum.Toplama.sum(7079, 280);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7359 + "'", int2 == 7359);
    }

    @Test
    public void test2480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2480");
        int int2 = sum.Toplama.sum(16655, 2355);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19010 + "'", int2 == 19010);
    }

    @Test
    public void test2481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2481");
        int int2 = sum.Toplama.sum(3766, 630);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4396 + "'", int2 == 4396);
    }

    @Test
    public void test2482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2482");
        int int2 = sum.Toplama.sum(9914, 18728);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28642 + "'", int2 == 28642);
    }

    @Test
    public void test2483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2483");
        int int2 = sum.Toplama.sum(31778, 1735);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33513 + "'", int2 == 33513);
    }

    @Test
    public void test2484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2484");
        int int2 = sum.Toplama.sum(12968, 1572);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14540 + "'", int2 == 14540);
    }

    @Test
    public void test2485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2485");
        int int2 = sum.Toplama.sum(2923, 4857);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7780 + "'", int2 == 7780);
    }

    @Test
    public void test2486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2486");
        int int2 = sum.Toplama.sum(2134, 19294);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21428 + "'", int2 == 21428);
    }

    @Test
    public void test2487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2487");
        int int2 = sum.Toplama.sum(0, 1606);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1606 + "'", int2 == 1606);
    }

    @Test
    public void test2488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2488");
        int int2 = sum.Toplama.sum(2118, 34680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36798 + "'", int2 == 36798);
    }

    @Test
    public void test2489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2489");
        int int2 = sum.Toplama.sum(4372, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4372 + "'", int2 == 4372);
    }

    @Test
    public void test2490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2490");
        int int2 = sum.Toplama.sum(1239, 10285);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11524 + "'", int2 == 11524);
    }

    @Test
    public void test2491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2491");
        int int2 = sum.Toplama.sum(8113, 809);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8922 + "'", int2 == 8922);
    }

    @Test
    public void test2492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2492");
        int int2 = sum.Toplama.sum(23031, 3453);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26484 + "'", int2 == 26484);
    }

    @Test
    public void test2493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2493");
        int int2 = sum.Toplama.sum(3920, 5653);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9573 + "'", int2 == 9573);
    }

    @Test
    public void test2494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2494");
        int int2 = sum.Toplama.sum(29241, 8493);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37734 + "'", int2 == 37734);
    }

    @Test
    public void test2495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2495");
        int int2 = sum.Toplama.sum(6275, 11186);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17461 + "'", int2 == 17461);
    }

    @Test
    public void test2496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2496");
        int int2 = sum.Toplama.sum(4281, 3824);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8105 + "'", int2 == 8105);
    }

    @Test
    public void test2497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2497");
        int int2 = sum.Toplama.sum(1337, 2405);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3742 + "'", int2 == 3742);
    }

    @Test
    public void test2498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2498");
        int int2 = sum.Toplama.sum(12473, 30931);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43404 + "'", int2 == 43404);
    }

    @Test
    public void test2499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2499");
        int int2 = sum.Toplama.sum(5523, 8666);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14189 + "'", int2 == 14189);
    }

    @Test
    public void test2500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2500");
        int int2 = sum.Toplama.sum(11654, 15901);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27555 + "'", int2 == 27555);
    }
}

