import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest10 {

    public static boolean debug = false;

    @Test
    public void test5001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5001");
        int int2 = sum.Toplama.sum(6127, 21913);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28040 + "'", int2 == 28040);
    }

    @Test
    public void test5002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5002");
        int int2 = sum.Toplama.sum(280, 40389);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40669 + "'", int2 == 40669);
    }

    @Test
    public void test5003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5003");
        int int2 = sum.Toplama.sum(3924, 23855);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27779 + "'", int2 == 27779);
    }

    @Test
    public void test5004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5004");
        int int2 = sum.Toplama.sum(6243, 28232);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34475 + "'", int2 == 34475);
    }

    @Test
    public void test5005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5005");
        int int2 = sum.Toplama.sum(22493, 6335);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28828 + "'", int2 == 28828);
    }

    @Test
    public void test5006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5006");
        int int2 = sum.Toplama.sum(10701, 680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11381 + "'", int2 == 11381);
    }

    @Test
    public void test5007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5007");
        int int2 = sum.Toplama.sum(11875, 127082);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 138957 + "'", int2 == 138957);
    }

    @Test
    public void test5008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5008");
        int int2 = sum.Toplama.sum(5932, 2952);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8884 + "'", int2 == 8884);
    }

    @Test
    public void test5009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5009");
        int int2 = sum.Toplama.sum(2241, 36798);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39039 + "'", int2 == 39039);
    }

    @Test
    public void test5010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5010");
        int int2 = sum.Toplama.sum(21619, 6138);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27757 + "'", int2 == 27757);
    }

    @Test
    public void test5011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5011");
        int int2 = sum.Toplama.sum(17020, 11199);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28219 + "'", int2 == 28219);
    }

    @Test
    public void test5012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5012");
        int int2 = sum.Toplama.sum(2051, 4744);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6795 + "'", int2 == 6795);
    }

    @Test
    public void test5013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5013");
        int int2 = sum.Toplama.sum(21936, 40840);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62776 + "'", int2 == 62776);
    }

    @Test
    public void test5014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5014");
        int int2 = sum.Toplama.sum(20449, 8089);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28538 + "'", int2 == 28538);
    }

    @Test
    public void test5015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5015");
        int int2 = sum.Toplama.sum(6080, 74234);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80314 + "'", int2 == 80314);
    }

    @Test
    public void test5016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5016");
        int int2 = sum.Toplama.sum(8420, 8317);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16737 + "'", int2 == 16737);
    }

    @Test
    public void test5017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5017");
        int int2 = sum.Toplama.sum(0, 1697);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1697 + "'", int2 == 1697);
    }

    @Test
    public void test5018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5018");
        int int2 = sum.Toplama.sum(5621, 12136);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17757 + "'", int2 == 17757);
    }

    @Test
    public void test5019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5019");
        int int2 = sum.Toplama.sum(31137, 2504);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33641 + "'", int2 == 33641);
    }

    @Test
    public void test5020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5020");
        int int2 = sum.Toplama.sum(6030, 29634);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35664 + "'", int2 == 35664);
    }

    @Test
    public void test5021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5021");
        int int2 = sum.Toplama.sum(13129, 25775);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38904 + "'", int2 == 38904);
    }

    @Test
    public void test5022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5022");
        int int2 = sum.Toplama.sum(7193, 14506);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21699 + "'", int2 == 21699);
    }

    @Test
    public void test5023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5023");
        int int2 = sum.Toplama.sum(15218, 6593);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21811 + "'", int2 == 21811);
    }

    @Test
    public void test5024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5024");
        int int2 = sum.Toplama.sum(575, 20806);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21381 + "'", int2 == 21381);
    }

    @Test
    public void test5025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5025");
        int int2 = sum.Toplama.sum(999, 5529);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6528 + "'", int2 == 6528);
    }

    @Test
    public void test5026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5026");
        int int2 = sum.Toplama.sum(7510, 6528);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14038 + "'", int2 == 14038);
    }

    @Test
    public void test5027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5027");
        int int2 = sum.Toplama.sum(39077, 4957);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44034 + "'", int2 == 44034);
    }

    @Test
    public void test5028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5028");
        int int2 = sum.Toplama.sum(2328, 23371);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25699 + "'", int2 == 25699);
    }

    @Test
    public void test5029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5029");
        int int2 = sum.Toplama.sum(12786, 13027);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25813 + "'", int2 == 25813);
    }

    @Test
    public void test5030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5030");
        int int2 = sum.Toplama.sum(3848, 11383);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15231 + "'", int2 == 15231);
    }

    @Test
    public void test5031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5031");
        int int2 = sum.Toplama.sum(3418, 15999);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19417 + "'", int2 == 19417);
    }

    @Test
    public void test5032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5032");
        int int2 = sum.Toplama.sum(23274, 4079);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27353 + "'", int2 == 27353);
    }

    @Test
    public void test5033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5033");
        int int2 = sum.Toplama.sum(18946, 12576);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31522 + "'", int2 == 31522);
    }

    @Test
    public void test5034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5034");
        int int2 = sum.Toplama.sum(35464, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35464 + "'", int2 == 35464);
    }

    @Test
    public void test5035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5035");
        int int2 = sum.Toplama.sum(17306, 3502);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20808 + "'", int2 == 20808);
    }

    @Test
    public void test5036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5036");
        int int2 = sum.Toplama.sum(12588, 16878);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29466 + "'", int2 == 29466);
    }

    @Test
    public void test5037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5037");
        int int2 = sum.Toplama.sum(4247, 23779);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28026 + "'", int2 == 28026);
    }

    @Test
    public void test5038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5038");
        int int2 = sum.Toplama.sum(8793, 5359);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14152 + "'", int2 == 14152);
    }

    @Test
    public void test5039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5039");
        int int2 = sum.Toplama.sum(5721, 1417);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7138 + "'", int2 == 7138);
    }

    @Test
    public void test5040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5040");
        int int2 = sum.Toplama.sum(880, 6084);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6964 + "'", int2 == 6964);
    }

    @Test
    public void test5041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5041");
        int int2 = sum.Toplama.sum(21018, 12034);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33052 + "'", int2 == 33052);
    }

    @Test
    public void test5042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5042");
        int int2 = sum.Toplama.sum(3059, 31587);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34646 + "'", int2 == 34646);
    }

    @Test
    public void test5043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5043");
        int int2 = sum.Toplama.sum(5130, 33902);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39032 + "'", int2 == 39032);
    }

    @Test
    public void test5044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5044");
        int int2 = sum.Toplama.sum(7651, 7866);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15517 + "'", int2 == 15517);
    }

    @Test
    public void test5045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5045");
        int int2 = sum.Toplama.sum(15285, 9156);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24441 + "'", int2 == 24441);
    }

    @Test
    public void test5046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5046");
        int int2 = sum.Toplama.sum(30889, 13693);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44582 + "'", int2 == 44582);
    }

    @Test
    public void test5047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5047");
        int int2 = sum.Toplama.sum(25774, 39038);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64812 + "'", int2 == 64812);
    }

    @Test
    public void test5048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5048");
        int int2 = sum.Toplama.sum(2285, 4476);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6761 + "'", int2 == 6761);
    }

    @Test
    public void test5049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5049");
        int int2 = sum.Toplama.sum(15906, 1832);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17738 + "'", int2 == 17738);
    }

    @Test
    public void test5050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5050");
        int int2 = sum.Toplama.sum(6764, 891);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7655 + "'", int2 == 7655);
    }

    @Test
    public void test5051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5051");
        int int2 = sum.Toplama.sum(22598, 23356);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45954 + "'", int2 == 45954);
    }

    @Test
    public void test5052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5052");
        int int2 = sum.Toplama.sum(10308, 11211);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21519 + "'", int2 == 21519);
    }

    @Test
    public void test5053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5053");
        int int2 = sum.Toplama.sum(344, 25570);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25914 + "'", int2 == 25914);
    }

    @Test
    public void test5054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5054");
        int int2 = sum.Toplama.sum(24620, 16325);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40945 + "'", int2 == 40945);
    }

    @Test
    public void test5055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5055");
        int int2 = sum.Toplama.sum(22140, 4797);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26937 + "'", int2 == 26937);
    }

    @Test
    public void test5056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5056");
        int int2 = sum.Toplama.sum(24466, 15572);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40038 + "'", int2 == 40038);
    }

    @Test
    public void test5057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5057");
        int int2 = sum.Toplama.sum(27297, 23338);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50635 + "'", int2 == 50635);
    }

    @Test
    public void test5058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5058");
        int int2 = sum.Toplama.sum(44034, 11416);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55450 + "'", int2 == 55450);
    }

    @Test
    public void test5059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5059");
        int int2 = sum.Toplama.sum(51795, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51795 + "'", int2 == 51795);
    }

    @Test
    public void test5060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5060");
        int int2 = sum.Toplama.sum(31636, 19136);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50772 + "'", int2 == 50772);
    }

    @Test
    public void test5061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5061");
        int int2 = sum.Toplama.sum(12183, 40840);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53023 + "'", int2 == 53023);
    }

    @Test
    public void test5062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5062");
        int int2 = sum.Toplama.sum(43237, 67627);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 110864 + "'", int2 == 110864);
    }

    @Test
    public void test5063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5063");
        int int2 = sum.Toplama.sum(508, 4232);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4740 + "'", int2 == 4740);
    }

    @Test
    public void test5064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5064");
        int int2 = sum.Toplama.sum(23926, 3287);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27213 + "'", int2 == 27213);
    }

    @Test
    public void test5065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5065");
        int int2 = sum.Toplama.sum(21522, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21522 + "'", int2 == 21522);
    }

    @Test
    public void test5066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5066");
        int int2 = sum.Toplama.sum(4379, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4479 + "'", int2 == 4479);
    }

    @Test
    public void test5067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5067");
        int int2 = sum.Toplama.sum(1932, 6502);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8434 + "'", int2 == 8434);
    }

    @Test
    public void test5068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5068");
        int int2 = sum.Toplama.sum(1464, 15591);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17055 + "'", int2 == 17055);
    }

    @Test
    public void test5069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5069");
        int int2 = sum.Toplama.sum(18926, 30838);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49764 + "'", int2 == 49764);
    }

    @Test
    public void test5070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5070");
        int int2 = sum.Toplama.sum(38986, 4197);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43183 + "'", int2 == 43183);
    }

    @Test
    public void test5071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5071");
        int int2 = sum.Toplama.sum(27060, 42676);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69736 + "'", int2 == 69736);
    }

    @Test
    public void test5072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5072");
        int int2 = sum.Toplama.sum(3987, 3410);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7397 + "'", int2 == 7397);
    }

    @Test
    public void test5073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5073");
        int int2 = sum.Toplama.sum(17613, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17613 + "'", int2 == 17613);
    }

    @Test
    public void test5074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5074");
        int int2 = sum.Toplama.sum(8047, 6511);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14558 + "'", int2 == 14558);
    }

    @Test
    public void test5075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5075");
        int int2 = sum.Toplama.sum(3012, 1396);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4408 + "'", int2 == 4408);
    }

    @Test
    public void test5076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5076");
        int int2 = sum.Toplama.sum(5621, 2535);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8156 + "'", int2 == 8156);
    }

    @Test
    public void test5077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5077");
        int int2 = sum.Toplama.sum(77779, 35337);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 113116 + "'", int2 == 113116);
    }

    @Test
    public void test5078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5078");
        int int2 = sum.Toplama.sum(19136, 13296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32432 + "'", int2 == 32432);
    }

    @Test
    public void test5079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5079");
        int int2 = sum.Toplama.sum(1665, 11801);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13466 + "'", int2 == 13466);
    }

    @Test
    public void test5080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5080");
        int int2 = sum.Toplama.sum(13147, 8245);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21392 + "'", int2 == 21392);
    }

    @Test
    public void test5081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5081");
        int int2 = sum.Toplama.sum(23001, 24675);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47676 + "'", int2 == 47676);
    }

    @Test
    public void test5082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5082");
        int int2 = sum.Toplama.sum(47721, 24466);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72187 + "'", int2 == 72187);
    }

    @Test
    public void test5083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5083");
        int int2 = sum.Toplama.sum(1468, 8785);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10253 + "'", int2 == 10253);
    }

    @Test
    public void test5084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5084");
        int int2 = sum.Toplama.sum(18331, 28330);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46661 + "'", int2 == 46661);
    }

    @Test
    public void test5085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5085");
        int int2 = sum.Toplama.sum(11928, 9418);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21346 + "'", int2 == 21346);
    }

    @Test
    public void test5086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5086");
        int int2 = sum.Toplama.sum(522, 19834);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20356 + "'", int2 == 20356);
    }

    @Test
    public void test5087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5087");
        int int2 = sum.Toplama.sum(32278, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32278 + "'", int2 == 32278);
    }

    @Test
    public void test5088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5088");
        int int2 = sum.Toplama.sum(49950, 58434);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 108384 + "'", int2 == 108384);
    }

    @Test
    public void test5089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5089");
        int int2 = sum.Toplama.sum(33149, 14206);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47355 + "'", int2 == 47355);
    }

    @Test
    public void test5090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5090");
        int int2 = sum.Toplama.sum(77564, 49589);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 127153 + "'", int2 == 127153);
    }

    @Test
    public void test5091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5091");
        int int2 = sum.Toplama.sum(486, 10073);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10559 + "'", int2 == 10559);
    }

    @Test
    public void test5092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5092");
        int int2 = sum.Toplama.sum(2370, 44432);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46802 + "'", int2 == 46802);
    }

    @Test
    public void test5093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5093");
        int int2 = sum.Toplama.sum(12373, 8113);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20486 + "'", int2 == 20486);
    }

    @Test
    public void test5094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5094");
        int int2 = sum.Toplama.sum(11262, 16121);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27383 + "'", int2 == 27383);
    }

    @Test
    public void test5095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5095");
        int int2 = sum.Toplama.sum(4317, 32839);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37156 + "'", int2 == 37156);
    }

    @Test
    public void test5096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5096");
        int int2 = sum.Toplama.sum(4572, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4571 + "'", int2 == 4571);
    }

    @Test
    public void test5097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5097");
        int int2 = sum.Toplama.sum(16540, 9050);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25590 + "'", int2 == 25590);
    }

    @Test
    public void test5098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5098");
        int int2 = sum.Toplama.sum(1068, 9745);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10813 + "'", int2 == 10813);
    }

    @Test
    public void test5099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5099");
        int int2 = sum.Toplama.sum(72187, 57379);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 129566 + "'", int2 == 129566);
    }

    @Test
    public void test5100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5100");
        int int2 = sum.Toplama.sum(1441, 22099);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23540 + "'", int2 == 23540);
    }

    @Test
    public void test5101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5101");
        int int2 = sum.Toplama.sum(38313, 35321);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 73634 + "'", int2 == 73634);
    }

    @Test
    public void test5102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5102");
        int int2 = sum.Toplama.sum(22265, 1446);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23711 + "'", int2 == 23711);
    }

    @Test
    public void test5103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5103");
        int int2 = sum.Toplama.sum(29768, 20237);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50005 + "'", int2 == 50005);
    }

    @Test
    public void test5104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5104");
        int int2 = sum.Toplama.sum(2923, 10071);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12994 + "'", int2 == 12994);
    }

    @Test
    public void test5105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5105");
        int int2 = sum.Toplama.sum(3784, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3784 + "'", int2 == 3784);
    }

    @Test
    public void test5106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5106");
        int int2 = sum.Toplama.sum(40752, 2561);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43313 + "'", int2 == 43313);
    }

    @Test
    public void test5107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5107");
        int int2 = sum.Toplama.sum(1274, 52456);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53730 + "'", int2 == 53730);
    }

    @Test
    public void test5108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5108");
        int int2 = sum.Toplama.sum(7431, 35679);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43110 + "'", int2 == 43110);
    }

    @Test
    public void test5109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5109");
        int int2 = sum.Toplama.sum(21684, 3509);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25193 + "'", int2 == 25193);
    }

    @Test
    public void test5110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5110");
        int int2 = sum.Toplama.sum(17260, 17189);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34449 + "'", int2 == 34449);
    }

    @Test
    public void test5111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5111");
        int int2 = sum.Toplama.sum(24382, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24382 + "'", int2 == 24382);
    }

    @Test
    public void test5112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5112");
        int int2 = sum.Toplama.sum(2067, 8963);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11030 + "'", int2 == 11030);
    }

    @Test
    public void test5113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5113");
        int int2 = sum.Toplama.sum(44581, 11412);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55993 + "'", int2 == 55993);
    }

    @Test
    public void test5114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5114");
        int int2 = sum.Toplama.sum(15421, 7072);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22493 + "'", int2 == 22493);
    }

    @Test
    public void test5115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5115");
        int int2 = sum.Toplama.sum(11460, 4214);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15674 + "'", int2 == 15674);
    }

    @Test
    public void test5116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5116");
        int int2 = sum.Toplama.sum(21060, 5814);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26874 + "'", int2 == 26874);
    }

    @Test
    public void test5117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5117");
        int int2 = sum.Toplama.sum(15721, 13188);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28909 + "'", int2 == 28909);
    }

    @Test
    public void test5118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5118");
        int int2 = sum.Toplama.sum(6219, 18115);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24334 + "'", int2 == 24334);
    }

    @Test
    public void test5119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5119");
        int int2 = sum.Toplama.sum(65220, 23554);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 88774 + "'", int2 == 88774);
    }

    @Test
    public void test5120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5120");
        int int2 = sum.Toplama.sum(2000, 36537);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38537 + "'", int2 == 38537);
    }

    @Test
    public void test5121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5121");
        int int2 = sum.Toplama.sum(8329, 47668);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55997 + "'", int2 == 55997);
    }

    @Test
    public void test5122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5122");
        int int2 = sum.Toplama.sum(10243, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10243 + "'", int2 == 10243);
    }

    @Test
    public void test5123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5123");
        int int2 = sum.Toplama.sum(19162, 27479);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46641 + "'", int2 == 46641);
    }

    @Test
    public void test5124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5124");
        int int2 = sum.Toplama.sum(56970, 70892);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 127862 + "'", int2 == 127862);
    }

    @Test
    public void test5125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5125");
        int int2 = sum.Toplama.sum(6239, 19246);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25485 + "'", int2 == 25485);
    }

    @Test
    public void test5126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5126");
        int int2 = sum.Toplama.sum(5060, 2537);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7597 + "'", int2 == 7597);
    }

    @Test
    public void test5127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5127");
        int int2 = sum.Toplama.sum(0, 21943);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21943 + "'", int2 == 21943);
    }

    @Test
    public void test5128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5128");
        int int2 = sum.Toplama.sum(10938, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10938 + "'", int2 == 10938);
    }

    @Test
    public void test5129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5129");
        int int2 = sum.Toplama.sum(22285, 5780);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28065 + "'", int2 == 28065);
    }

    @Test
    public void test5130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5130");
        int int2 = sum.Toplama.sum(1759, 23370);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25129 + "'", int2 == 25129);
    }

    @Test
    public void test5131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5131");
        int int2 = sum.Toplama.sum(15041, 15184);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30225 + "'", int2 == 30225);
    }

    @Test
    public void test5132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5132");
        int int2 = sum.Toplama.sum(8912, 4825);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13737 + "'", int2 == 13737);
    }

    @Test
    public void test5133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5133");
        int int2 = sum.Toplama.sum(4847, 1562);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6409 + "'", int2 == 6409);
    }

    @Test
    public void test5134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5134");
        int int2 = sum.Toplama.sum(14125, 53499);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67624 + "'", int2 == 67624);
    }

    @Test
    public void test5135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5135");
        int int2 = sum.Toplama.sum(23540, 29435);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52975 + "'", int2 == 52975);
    }

    @Test
    public void test5136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5136");
        int int2 = sum.Toplama.sum(12631, 964);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13595 + "'", int2 == 13595);
    }

    @Test
    public void test5137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5137");
        int int2 = sum.Toplama.sum(11198, 22251);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33449 + "'", int2 == 33449);
    }

    @Test
    public void test5138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5138");
        int int2 = sum.Toplama.sum(9187, 26874);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36061 + "'", int2 == 36061);
    }

    @Test
    public void test5139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5139");
        int int2 = sum.Toplama.sum(7064, 52122);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59186 + "'", int2 == 59186);
    }

    @Test
    public void test5140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5140");
        int int2 = sum.Toplama.sum(6631, 17196);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23827 + "'", int2 == 23827);
    }

    @Test
    public void test5141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5141");
        int int2 = sum.Toplama.sum(15458, 16215);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31673 + "'", int2 == 31673);
    }

    @Test
    public void test5142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5142");
        int int2 = sum.Toplama.sum(3277, 16448);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19725 + "'", int2 == 19725);
    }

    @Test
    public void test5143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5143");
        int int2 = sum.Toplama.sum(1478, 2062);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3540 + "'", int2 == 3540);
    }

    @Test
    public void test5144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5144");
        int int2 = sum.Toplama.sum(21619, 9578);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31197 + "'", int2 == 31197);
    }

    @Test
    public void test5145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5145");
        int int2 = sum.Toplama.sum(4214, 34600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38814 + "'", int2 == 38814);
    }

    @Test
    public void test5146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5146");
        int int2 = sum.Toplama.sum(45954, 10132);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56086 + "'", int2 == 56086);
    }

    @Test
    public void test5147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5147");
        int int2 = sum.Toplama.sum(32370, 29767);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62137 + "'", int2 == 62137);
    }

    @Test
    public void test5148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5148");
        int int2 = sum.Toplama.sum(65089, 909);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 65998 + "'", int2 == 65998);
    }

    @Test
    public void test5149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5149");
        int int2 = sum.Toplama.sum(3901, 78524);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 82425 + "'", int2 == 82425);
    }

    @Test
    public void test5150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5150");
        int int2 = sum.Toplama.sum(29768, 11813);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41581 + "'", int2 == 41581);
    }

    @Test
    public void test5151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5151");
        int int2 = sum.Toplama.sum(36041, 2942);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38983 + "'", int2 == 38983);
    }

    @Test
    public void test5152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5152");
        int int2 = sum.Toplama.sum(14431, 5111);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19542 + "'", int2 == 19542);
    }

    @Test
    public void test5153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5153");
        int int2 = sum.Toplama.sum(52340, 2141);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54481 + "'", int2 == 54481);
    }

    @Test
    public void test5154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5154");
        int int2 = sum.Toplama.sum(26498, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26498 + "'", int2 == 26498);
    }

    @Test
    public void test5155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5155");
        int int2 = sum.Toplama.sum((int) '#', 55997);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56032 + "'", int2 == 56032);
    }

    @Test
    public void test5156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5156");
        int int2 = sum.Toplama.sum(9952, 7457);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17409 + "'", int2 == 17409);
    }

    @Test
    public void test5157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5157");
        int int2 = sum.Toplama.sum(270, 15917);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16187 + "'", int2 == 16187);
    }

    @Test
    public void test5158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5158");
        int int2 = sum.Toplama.sum(3023, 18503);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21526 + "'", int2 == 21526);
    }

    @Test
    public void test5159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5159");
        int int2 = sum.Toplama.sum(1, 48921);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48922 + "'", int2 == 48922);
    }

    @Test
    public void test5160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5160");
        int int2 = sum.Toplama.sum(15828, 17253);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33081 + "'", int2 == 33081);
    }

    @Test
    public void test5161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5161");
        int int2 = sum.Toplama.sum(4094, 11710);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15804 + "'", int2 == 15804);
    }

    @Test
    public void test5162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5162");
        int int2 = sum.Toplama.sum(43591, 2942);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46533 + "'", int2 == 46533);
    }

    @Test
    public void test5163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5163");
        int int2 = sum.Toplama.sum(0, 41739);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41739 + "'", int2 == 41739);
    }

    @Test
    public void test5164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5164");
        int int2 = sum.Toplama.sum(19753, 7131);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26884 + "'", int2 == 26884);
    }

    @Test
    public void test5165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5165");
        int int2 = sum.Toplama.sum(10037, 4996);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15033 + "'", int2 == 15033);
    }

    @Test
    public void test5166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5166");
        int int2 = sum.Toplama.sum(19035, 806);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19841 + "'", int2 == 19841);
    }

    @Test
    public void test5167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5167");
        int int2 = sum.Toplama.sum(10332, 3085);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13417 + "'", int2 == 13417);
    }

    @Test
    public void test5168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5168");
        int int2 = sum.Toplama.sum(28560, 8670);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37230 + "'", int2 == 37230);
    }

    @Test
    public void test5169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5169");
        int int2 = sum.Toplama.sum(1080, 8047);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9127 + "'", int2 == 9127);
    }

    @Test
    public void test5170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5170");
        int int2 = sum.Toplama.sum(4730, 10165);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14895 + "'", int2 == 14895);
    }

    @Test
    public void test5171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5171");
        int int2 = sum.Toplama.sum(11958, 9952);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21910 + "'", int2 == 21910);
    }

    @Test
    public void test5172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5172");
        int int2 = sum.Toplama.sum(15517, 6850);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22367 + "'", int2 == 22367);
    }

    @Test
    public void test5173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5173");
        int int2 = sum.Toplama.sum(64, 547);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 611 + "'", int2 == 611);
    }

    @Test
    public void test5174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5174");
        int int2 = sum.Toplama.sum(0, 14171);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14171 + "'", int2 == 14171);
    }

    @Test
    public void test5175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5175");
        int int2 = sum.Toplama.sum(20463, 25176);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45639 + "'", int2 == 45639);
    }

    @Test
    public void test5176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5176");
        int int2 = sum.Toplama.sum(58080, 7188);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 65268 + "'", int2 == 65268);
    }

    @Test
    public void test5177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5177");
        int int2 = sum.Toplama.sum(5829, 3669);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9498 + "'", int2 == 9498);
    }

    @Test
    public void test5178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5178");
        int int2 = sum.Toplama.sum(6885, 8785);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15670 + "'", int2 == 15670);
    }

    @Test
    public void test5179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5179");
        int int2 = sum.Toplama.sum(25570, 5946);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31516 + "'", int2 == 31516);
    }

    @Test
    public void test5180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5180");
        int int2 = sum.Toplama.sum(7048, 7374);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14422 + "'", int2 == 14422);
    }

    @Test
    public void test5181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5181");
        int int2 = sum.Toplama.sum(8773, 2380);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11153 + "'", int2 == 11153);
    }

    @Test
    public void test5182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5182");
        int int2 = sum.Toplama.sum(1835, 51222);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53057 + "'", int2 == 53057);
    }

    @Test
    public void test5183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5183");
        int int2 = sum.Toplama.sum(37734, 921);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38655 + "'", int2 == 38655);
    }

    @Test
    public void test5184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5184");
        int int2 = sum.Toplama.sum(82154, 16493);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 98647 + "'", int2 == 98647);
    }

    @Test
    public void test5185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5185");
        int int2 = sum.Toplama.sum(17856, 4307);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22163 + "'", int2 == 22163);
    }

    @Test
    public void test5186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5186");
        int int2 = sum.Toplama.sum(23766, 27459);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51225 + "'", int2 == 51225);
    }

    @Test
    public void test5187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5187");
        int int2 = sum.Toplama.sum(48736, 19639);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68375 + "'", int2 == 68375);
    }

    @Test
    public void test5188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5188");
        int int2 = sum.Toplama.sum(4180, 12576);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16756 + "'", int2 == 16756);
    }

    @Test
    public void test5189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5189");
        int int2 = sum.Toplama.sum(0, 17480);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17480 + "'", int2 == 17480);
    }

    @Test
    public void test5190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5190");
        int int2 = sum.Toplama.sum(3662, 33138);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36800 + "'", int2 == 36800);
    }

    @Test
    public void test5191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5191");
        int int2 = sum.Toplama.sum(0, 2085);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2085 + "'", int2 == 2085);
    }

    @Test
    public void test5192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5192");
        int int2 = sum.Toplama.sum(10492, 15917);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26409 + "'", int2 == 26409);
    }

    @Test
    public void test5193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5193");
        int int2 = sum.Toplama.sum(34011, 8329);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42340 + "'", int2 == 42340);
    }

    @Test
    public void test5194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5194");
        int int2 = sum.Toplama.sum(6275, 5252);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11527 + "'", int2 == 11527);
    }

    @Test
    public void test5195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5195");
        int int2 = sum.Toplama.sum(3532, 9652);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13184 + "'", int2 == 13184);
    }

    @Test
    public void test5196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5196");
        int int2 = sum.Toplama.sum(11534, 8465);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19999 + "'", int2 == 19999);
    }

    @Test
    public void test5197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5197");
        int int2 = sum.Toplama.sum(746, 12834);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13580 + "'", int2 == 13580);
    }

    @Test
    public void test5198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5198");
        int int2 = sum.Toplama.sum(10246, 14386);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24632 + "'", int2 == 24632);
    }

    @Test
    public void test5199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5199");
        int int2 = sum.Toplama.sum(39077, 34758);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 73835 + "'", int2 == 73835);
    }

    @Test
    public void test5200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5200");
        int int2 = sum.Toplama.sum(1895, 838);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2733 + "'", int2 == 2733);
    }

    @Test
    public void test5201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5201");
        int int2 = sum.Toplama.sum(0, 1698);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1698 + "'", int2 == 1698);
    }

    @Test
    public void test5202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5202");
        int int2 = sum.Toplama.sum(11141, 34985);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46126 + "'", int2 == 46126);
    }

    @Test
    public void test5203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5203");
        int int2 = sum.Toplama.sum(6417, 1857);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8274 + "'", int2 == 8274);
    }

    @Test
    public void test5204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5204");
        int int2 = sum.Toplama.sum(8898, 9590);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18488 + "'", int2 == 18488);
    }

    @Test
    public void test5205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5205");
        int int2 = sum.Toplama.sum(52456, 58285);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 110741 + "'", int2 == 110741);
    }

    @Test
    public void test5206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5206");
        int int2 = sum.Toplama.sum(11426, 10308);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21734 + "'", int2 == 21734);
    }

    @Test
    public void test5207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5207");
        int int2 = sum.Toplama.sum(24382, 18556);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42938 + "'", int2 == 42938);
    }

    @Test
    public void test5208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5208");
        int int2 = sum.Toplama.sum(1083, 6453);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7536 + "'", int2 == 7536);
    }

    @Test
    public void test5209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5209");
        int int2 = sum.Toplama.sum(19162, 9590);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28752 + "'", int2 == 28752);
    }

    @Test
    public void test5210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5210");
        int int2 = sum.Toplama.sum(21381, 2118);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23499 + "'", int2 == 23499);
    }

    @Test
    public void test5211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5211");
        int int2 = sum.Toplama.sum(13538, 43404);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56942 + "'", int2 == 56942);
    }

    @Test
    public void test5212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5212");
        int int2 = sum.Toplama.sum(13754, 20088);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33842 + "'", int2 == 33842);
    }

    @Test
    public void test5213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5213");
        int int2 = sum.Toplama.sum(8651, 11198);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19849 + "'", int2 == 19849);
    }

    @Test
    public void test5214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5214");
        int int2 = sum.Toplama.sum(7268, 42557);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49825 + "'", int2 == 49825);
    }

    @Test
    public void test5215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5215");
        int int2 = sum.Toplama.sum(17351, 814);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18165 + "'", int2 == 18165);
    }

    @Test
    public void test5216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5216");
        int int2 = sum.Toplama.sum(33149, 4145);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37294 + "'", int2 == 37294);
    }

    @Test
    public void test5217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5217");
        int int2 = sum.Toplama.sum(39528, 2282);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41810 + "'", int2 == 41810);
    }

    @Test
    public void test5218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5218");
        int int2 = sum.Toplama.sum(28792, 34680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63472 + "'", int2 == 63472);
    }

    @Test
    public void test5219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5219");
        int int2 = sum.Toplama.sum(15285, 23127);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38412 + "'", int2 == 38412);
    }

    @Test
    public void test5220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5220");
        int int2 = sum.Toplama.sum(6705, 9815);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16520 + "'", int2 == 16520);
    }

    @Test
    public void test5221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5221");
        int int2 = sum.Toplama.sum(2446, 22098);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24544 + "'", int2 == 24544);
    }

    @Test
    public void test5222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5222");
        int int2 = sum.Toplama.sum(10084, 36052);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46136 + "'", int2 == 46136);
    }

    @Test
    public void test5223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5223");
        int int2 = sum.Toplama.sum(8002, 7790);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15792 + "'", int2 == 15792);
    }

    @Test
    public void test5224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5224");
        int int2 = sum.Toplama.sum(9068, 21117);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30185 + "'", int2 == 30185);
    }

    @Test
    public void test5225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5225");
        int int2 = sum.Toplama.sum(82680, 16366);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99046 + "'", int2 == 99046);
    }

    @Test
    public void test5226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5226");
        int int2 = sum.Toplama.sum(50454, 29284);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 79738 + "'", int2 == 79738);
    }

    @Test
    public void test5227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5227");
        int int2 = sum.Toplama.sum(11684, 5639);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17323 + "'", int2 == 17323);
    }

    @Test
    public void test5228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5228");
        int int2 = sum.Toplama.sum(12916, 25067);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37983 + "'", int2 == 37983);
    }

    @Test
    public void test5229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5229");
        int int2 = sum.Toplama.sum(8011, 19639);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27650 + "'", int2 == 27650);
    }

    @Test
    public void test5230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5230");
        int int2 = sum.Toplama.sum(9846, 34126);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43972 + "'", int2 == 43972);
    }

    @Test
    public void test5231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5231");
        int int2 = sum.Toplama.sum(27650, 23412);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51062 + "'", int2 == 51062);
    }

    @Test
    public void test5232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5232");
        int int2 = sum.Toplama.sum(15279, 17369);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32648 + "'", int2 == 32648);
    }

    @Test
    public void test5233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5233");
        int int2 = sum.Toplama.sum(54173, 6542);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60715 + "'", int2 == 60715);
    }

    @Test
    public void test5234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5234");
        int int2 = sum.Toplama.sum(4882, 8767);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13649 + "'", int2 == 13649);
    }

    @Test
    public void test5235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5235");
        int int2 = sum.Toplama.sum(49825, 37281);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 87106 + "'", int2 == 87106);
    }

    @Test
    public void test5236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5236");
        int int2 = sum.Toplama.sum(151, 24452);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24603 + "'", int2 == 24603);
    }

    @Test
    public void test5237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5237");
        int int2 = sum.Toplama.sum(3301, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3401 + "'", int2 == 3401);
    }

    @Test
    public void test5238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5238");
        int int2 = sum.Toplama.sum(2788, 3160);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5948 + "'", int2 == 5948);
    }

    @Test
    public void test5239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5239");
        int int2 = sum.Toplama.sum(15779, 6585);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22364 + "'", int2 == 22364);
    }

    @Test
    public void test5240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5240");
        int int2 = sum.Toplama.sum(17466, 28065);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45531 + "'", int2 == 45531);
    }

    @Test
    public void test5241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5241");
        int int2 = sum.Toplama.sum(0, 6232);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6232 + "'", int2 == 6232);
    }

    @Test
    public void test5242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5242");
        int int2 = sum.Toplama.sum(35814, 761);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36575 + "'", int2 == 36575);
    }

    @Test
    public void test5243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5243");
        int int2 = sum.Toplama.sum(1622, 17031);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18653 + "'", int2 == 18653);
    }

    @Test
    public void test5244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5244");
        int int2 = sum.Toplama.sum(0, 3566);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3566 + "'", int2 == 3566);
    }

    @Test
    public void test5245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5245");
        int int2 = sum.Toplama.sum(730, 6232);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6962 + "'", int2 == 6962);
    }

    @Test
    public void test5246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5246");
        int int2 = sum.Toplama.sum(4553, 17488);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22041 + "'", int2 == 22041);
    }

    @Test
    public void test5247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5247");
        int int2 = sum.Toplama.sum(31507, 2923);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34430 + "'", int2 == 34430);
    }

    @Test
    public void test5248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5248");
        int int2 = sum.Toplama.sum(1370, 36277);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37647 + "'", int2 == 37647);
    }

    @Test
    public void test5249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5249");
        int int2 = sum.Toplama.sum(25152, 9146);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34298 + "'", int2 == 34298);
    }

    @Test
    public void test5250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5250");
        int int2 = sum.Toplama.sum(3409, 3949);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7358 + "'", int2 == 7358);
    }

    @Test
    public void test5251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5251");
        int int2 = sum.Toplama.sum(2942, 10897);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13839 + "'", int2 == 13839);
    }

    @Test
    public void test5252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5252");
        int int2 = sum.Toplama.sum(42355, 16613);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58968 + "'", int2 == 58968);
    }

    @Test
    public void test5253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5253");
        int int2 = sum.Toplama.sum(3310, 19819);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23129 + "'", int2 == 23129);
    }

    @Test
    public void test5254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5254");
        int int2 = sum.Toplama.sum(6485, 31033);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37518 + "'", int2 == 37518);
    }

    @Test
    public void test5255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5255");
        int int2 = sum.Toplama.sum(12826, 14635);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27461 + "'", int2 == 27461);
    }

    @Test
    public void test5256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5256");
        int int2 = sum.Toplama.sum(2386, 45459);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47845 + "'", int2 == 47845);
    }

    @Test
    public void test5257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5257");
        int int2 = sum.Toplama.sum(6378, 2742);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9120 + "'", int2 == 9120);
    }

    @Test
    public void test5258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5258");
        int int2 = sum.Toplama.sum(46214, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46214 + "'", int2 == 46214);
    }

    @Test
    public void test5259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5259");
        int int2 = sum.Toplama.sum(31516, 43972);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 75488 + "'", int2 == 75488);
    }

    @Test
    public void test5260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5260");
        int int2 = sum.Toplama.sum(110864, 15182);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 126046 + "'", int2 == 126046);
    }

    @Test
    public void test5261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5261");
        int int2 = sum.Toplama.sum(6868, 3927);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10795 + "'", int2 == 10795);
    }

    @Test
    public void test5262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5262");
        int int2 = sum.Toplama.sum(5853, 11702);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17555 + "'", int2 == 17555);
    }

    @Test
    public void test5263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5263");
        int int2 = sum.Toplama.sum(24533, 3662);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28195 + "'", int2 == 28195);
    }

    @Test
    public void test5264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5264");
        int int2 = sum.Toplama.sum(24344, 48790);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 73134 + "'", int2 == 73134);
    }

    @Test
    public void test5265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5265");
        int int2 = sum.Toplama.sum(5236, 20758);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25994 + "'", int2 == 25994);
    }

    @Test
    public void test5266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5266");
        int int2 = sum.Toplama.sum(64812, 15514);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80326 + "'", int2 == 80326);
    }

    @Test
    public void test5267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5267");
        int int2 = sum.Toplama.sum(10216, 44858);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55074 + "'", int2 == 55074);
    }

    @Test
    public void test5268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5268");
        int int2 = sum.Toplama.sum(3323, 7568);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10891 + "'", int2 == 10891);
    }

    @Test
    public void test5269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5269");
        int int2 = sum.Toplama.sum(5305, 12985);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18290 + "'", int2 == 18290);
    }

    @Test
    public void test5270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5270");
        int int2 = sum.Toplama.sum(5080, 9119);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14199 + "'", int2 == 14199);
    }

    @Test
    public void test5271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5271");
        int int2 = sum.Toplama.sum(1268, 18424);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19692 + "'", int2 == 19692);
    }

    @Test
    public void test5272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5272");
        int int2 = sum.Toplama.sum(34349, 33138);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67487 + "'", int2 == 67487);
    }

    @Test
    public void test5273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5273");
        int int2 = sum.Toplama.sum(29011, 6705);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35716 + "'", int2 == 35716);
    }

    @Test
    public void test5274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5274");
        int int2 = sum.Toplama.sum(761, 8379);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9140 + "'", int2 == 9140);
    }

    @Test
    public void test5275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5275");
        int int2 = sum.Toplama.sum(5621, 6001);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11622 + "'", int2 == 11622);
    }

    @Test
    public void test5276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5276");
        int int2 = sum.Toplama.sum(6327, 5008);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11335 + "'", int2 == 11335);
    }

    @Test
    public void test5277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5277");
        int int2 = sum.Toplama.sum(1331, 13496);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14827 + "'", int2 == 14827);
    }

    @Test
    public void test5278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5278");
        int int2 = sum.Toplama.sum(43636, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43636 + "'", int2 == 43636);
    }

    @Test
    public void test5279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5279");
        int int2 = sum.Toplama.sum(3304, 37425);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40729 + "'", int2 == 40729);
    }

    @Test
    public void test5280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5280");
        int int2 = sum.Toplama.sum(14139, 54173);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68312 + "'", int2 == 68312);
    }

    @Test
    public void test5281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5281");
        int int2 = sum.Toplama.sum(7666, 10004);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17670 + "'", int2 == 17670);
    }

    @Test
    public void test5282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5282");
        int int2 = sum.Toplama.sum(7866, 10918);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18784 + "'", int2 == 18784);
    }

    @Test
    public void test5283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5283");
        int int2 = sum.Toplama.sum(7625, 392);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8017 + "'", int2 == 8017);
    }

    @Test
    public void test5284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5284");
        int int2 = sum.Toplama.sum(0, 21117);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21117 + "'", int2 == 21117);
    }

    @Test
    public void test5285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5285");
        int int2 = sum.Toplama.sum(32049, 1652);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33701 + "'", int2 == 33701);
    }

    @Test
    public void test5286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5286");
        int int2 = sum.Toplama.sum(87273, 10931);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 98204 + "'", int2 == 98204);
    }

    @Test
    public void test5287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5287");
        int int2 = sum.Toplama.sum(54429, 7568);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61997 + "'", int2 == 61997);
    }

    @Test
    public void test5288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5288");
        int int2 = sum.Toplama.sum(10834, 24758);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35592 + "'", int2 == 35592);
    }

    @Test
    public void test5289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5289");
        int int2 = sum.Toplama.sum(27283, 12342);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39625 + "'", int2 == 39625);
    }

    @Test
    public void test5290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5290");
        int int2 = sum.Toplama.sum(19725, 1482);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21207 + "'", int2 == 21207);
    }

    @Test
    public void test5291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5291");
        int int2 = sum.Toplama.sum(0, 11622);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11622 + "'", int2 == 11622);
    }

    @Test
    public void test5292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5292");
        int int2 = sum.Toplama.sum(3779, 6275);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10054 + "'", int2 == 10054);
    }

    @Test
    public void test5293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5293");
        int int2 = sum.Toplama.sum(18177, 7675);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25852 + "'", int2 == 25852);
    }

    @Test
    public void test5294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5294");
        int int2 = sum.Toplama.sum(3692, 25969);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29661 + "'", int2 == 29661);
    }

    @Test
    public void test5295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5295");
        int int2 = sum.Toplama.sum(14587, 20923);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35510 + "'", int2 == 35510);
    }

    @Test
    public void test5296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5296");
        int int2 = sum.Toplama.sum(33838, 6214);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40052 + "'", int2 == 40052);
    }

    @Test
    public void test5297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5297");
        int int2 = sum.Toplama.sum(19162, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19162 + "'", int2 == 19162);
    }

    @Test
    public void test5298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5298");
        int int2 = sum.Toplama.sum(51225, 24495);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 75720 + "'", int2 == 75720);
    }

    @Test
    public void test5299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5299");
        int int2 = sum.Toplama.sum(13663, 64128);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 77791 + "'", int2 == 77791);
    }

    @Test
    public void test5300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5300");
        int int2 = sum.Toplama.sum(14576, 79420);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 93996 + "'", int2 == 93996);
    }

    @Test
    public void test5301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5301");
        int int2 = sum.Toplama.sum(11397, 27704);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39101 + "'", int2 == 39101);
    }

    @Test
    public void test5302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5302");
        int int2 = sum.Toplama.sum(16878, 4768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21646 + "'", int2 == 21646);
    }

    @Test
    public void test5303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5303");
        int int2 = sum.Toplama.sum(34475, 11801);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46276 + "'", int2 == 46276);
    }

    @Test
    public void test5304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5304");
        int int2 = sum.Toplama.sum(14803, 8779);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23582 + "'", int2 == 23582);
    }

    @Test
    public void test5305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5305");
        int int2 = sum.Toplama.sum(4856, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4856 + "'", int2 == 4856);
    }

    @Test
    public void test5306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5306");
        int int2 = sum.Toplama.sum(11074, 381);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11455 + "'", int2 == 11455);
    }

    @Test
    public void test5307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5307");
        int int2 = sum.Toplama.sum(11401, 22301);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33702 + "'", int2 == 33702);
    }

    @Test
    public void test5308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5308");
        int int2 = sum.Toplama.sum(9396, 41734);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51130 + "'", int2 == 51130);
    }

    @Test
    public void test5309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5309");
        int int2 = sum.Toplama.sum(5284, 20385);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25669 + "'", int2 == 25669);
    }

    @Test
    public void test5310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5310");
        int int2 = sum.Toplama.sum(61597, 10627);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72224 + "'", int2 == 72224);
    }

    @Test
    public void test5311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5311");
        int int2 = sum.Toplama.sum(17255, 3274);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20529 + "'", int2 == 20529);
    }

    @Test
    public void test5312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5312");
        int int2 = sum.Toplama.sum(52439, 4754);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57193 + "'", int2 == 57193);
    }

    @Test
    public void test5313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5313");
        int int2 = sum.Toplama.sum(13861, 1963);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15824 + "'", int2 == 15824);
    }

    @Test
    public void test5314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5314");
        int int2 = sum.Toplama.sum(36949, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36949 + "'", int2 == 36949);
    }

    @Test
    public void test5315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5315");
        int int2 = sum.Toplama.sum(95314, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 95314 + "'", int2 == 95314);
    }

    @Test
    public void test5316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5316");
        int int2 = sum.Toplama.sum(10701, 1622);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12323 + "'", int2 == 12323);
    }

    @Test
    public void test5317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5317");
        int int2 = sum.Toplama.sum(17825, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17825 + "'", int2 == 17825);
    }

    @Test
    public void test5318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5318");
        int int2 = sum.Toplama.sum(23104, 29845);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52949 + "'", int2 == 52949);
    }

    @Test
    public void test5319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5319");
        int int2 = sum.Toplama.sum(41105, 47594);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 88699 + "'", int2 == 88699);
    }

    @Test
    public void test5320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5320");
        int int2 = sum.Toplama.sum(10883, 10170);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21053 + "'", int2 == 21053);
    }

    @Test
    public void test5321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5321");
        int int2 = sum.Toplama.sum(0, 20215);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20215 + "'", int2 == 20215);
    }

    @Test
    public void test5322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5322");
        int int2 = sum.Toplama.sum(9191, 11228);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20419 + "'", int2 == 20419);
    }

    @Test
    public void test5323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5323");
        int int2 = sum.Toplama.sum(19149, 28664);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47813 + "'", int2 == 47813);
    }

    @Test
    public void test5324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5324");
        int int2 = sum.Toplama.sum(3113, 1292);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4405 + "'", int2 == 4405);
    }

    @Test
    public void test5325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5325");
        int int2 = sum.Toplama.sum(13147, 55169);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68316 + "'", int2 == 68316);
    }

    @Test
    public void test5326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5326");
        int int2 = sum.Toplama.sum(6107, 8351);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14458 + "'", int2 == 14458);
    }

    @Test
    public void test5327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5327");
        int int2 = sum.Toplama.sum(639, 10990);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11629 + "'", int2 == 11629);
    }

    @Test
    public void test5328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5328");
        int int2 = sum.Toplama.sum(32556, 26689);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59245 + "'", int2 == 59245);
    }

    @Test
    public void test5329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5329");
        int int2 = sum.Toplama.sum(13237, 18548);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31785 + "'", int2 == 31785);
    }

    @Test
    public void test5330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5330");
        int int2 = sum.Toplama.sum(4451, 23601);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28052 + "'", int2 == 28052);
    }

    @Test
    public void test5331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5331");
        int int2 = sum.Toplama.sum(1000, 35592);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36592 + "'", int2 == 36592);
    }

    @Test
    public void test5332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5332");
        int int2 = sum.Toplama.sum(5541, 18841);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24382 + "'", int2 == 24382);
    }

    @Test
    public void test5333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5333");
        int int2 = sum.Toplama.sum(45879, 66905);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 112784 + "'", int2 == 112784);
    }

    @Test
    public void test5334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5334");
        int int2 = sum.Toplama.sum(6853, 41196);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48049 + "'", int2 == 48049);
    }

    @Test
    public void test5335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5335");
        int int2 = sum.Toplama.sum(60715, 37142);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97857 + "'", int2 == 97857);
    }

    @Test
    public void test5336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5336");
        int int2 = sum.Toplama.sum(4552, 30673);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35225 + "'", int2 == 35225);
    }

    @Test
    public void test5337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5337");
        int int2 = sum.Toplama.sum(12593, 27426);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40019 + "'", int2 == 40019);
    }

    @Test
    public void test5338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5338");
        int int2 = sum.Toplama.sum(0, 12834);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12834 + "'", int2 == 12834);
    }

    @Test
    public void test5339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5339");
        int int2 = sum.Toplama.sum(3258, 20468);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23726 + "'", int2 == 23726);
    }

    @Test
    public void test5340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5340");
        int int2 = sum.Toplama.sum(25476, 33651);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59127 + "'", int2 == 59127);
    }

    @Test
    public void test5341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5341");
        int int2 = sum.Toplama.sum(24466, 23956);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48422 + "'", int2 == 48422);
    }

    @Test
    public void test5342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5342");
        int int2 = sum.Toplama.sum(10590, 16274);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26864 + "'", int2 == 26864);
    }

    @Test
    public void test5343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5343");
        int int2 = sum.Toplama.sum(4470, 1784);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6254 + "'", int2 == 6254);
    }

    @Test
    public void test5344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5344");
        int int2 = sum.Toplama.sum(7903, 21595);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29498 + "'", int2 == 29498);
    }

    @Test
    public void test5345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5345");
        int int2 = sum.Toplama.sum(1240, 15614);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16854 + "'", int2 == 16854);
    }

    @Test
    public void test5346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5346");
        int int2 = sum.Toplama.sum(2452, 5458);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7910 + "'", int2 == 7910);
    }

    @Test
    public void test5347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5347");
        int int2 = sum.Toplama.sum(3124, 19417);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22541 + "'", int2 == 22541);
    }

    @Test
    public void test5348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5348");
        int int2 = sum.Toplama.sum(17933, 10079);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28012 + "'", int2 == 28012);
    }

    @Test
    public void test5349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5349");
        int int2 = sum.Toplama.sum(35225, 8454);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43679 + "'", int2 == 43679);
    }

    @Test
    public void test5350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5350");
        int int2 = sum.Toplama.sum(2368, 14726);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17094 + "'", int2 == 17094);
    }

    @Test
    public void test5351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5351");
        int int2 = sum.Toplama.sum(14576, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14576 + "'", int2 == 14576);
    }

    @Test
    public void test5352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5352");
        int int2 = sum.Toplama.sum(34062, 47594);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 81656 + "'", int2 == 81656);
    }

    @Test
    public void test5353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5353");
        int int2 = sum.Toplama.sum(48219, 11514);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59733 + "'", int2 == 59733);
    }

    @Test
    public void test5354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5354");
        int int2 = sum.Toplama.sum(12432, 2045);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14477 + "'", int2 == 14477);
    }

    @Test
    public void test5355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5355");
        int int2 = sum.Toplama.sum(3503, 20486);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23989 + "'", int2 == 23989);
    }

    @Test
    public void test5356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5356");
        int int2 = sum.Toplama.sum(19425, 2282);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21707 + "'", int2 == 21707);
    }

    @Test
    public void test5357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5357");
        int int2 = sum.Toplama.sum(964, 8924);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9888 + "'", int2 == 9888);
    }

    @Test
    public void test5358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5358");
        int int2 = sum.Toplama.sum(3521, 42316);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45837 + "'", int2 == 45837);
    }

    @Test
    public void test5359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5359");
        int int2 = sum.Toplama.sum(6124, 29504);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35628 + "'", int2 == 35628);
    }

    @Test
    public void test5360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5360");
        int int2 = sum.Toplama.sum(10318, 5774);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16092 + "'", int2 == 16092);
    }

    @Test
    public void test5361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5361");
        int int2 = sum.Toplama.sum(269, 11931);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12200 + "'", int2 == 12200);
    }

    @Test
    public void test5362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5362");
        int int2 = sum.Toplama.sum(39970, 70279);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 110249 + "'", int2 == 110249);
    }

    @Test
    public void test5363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5363");
        int int2 = sum.Toplama.sum(14609, 30225);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44834 + "'", int2 == 44834);
    }

    @Test
    public void test5364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5364");
        int int2 = sum.Toplama.sum(13208, 41196);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54404 + "'", int2 == 54404);
    }

    @Test
    public void test5365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5365");
        int int2 = sum.Toplama.sum(36295, 3326);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39621 + "'", int2 == 39621);
    }

    @Test
    public void test5366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5366");
        int int2 = sum.Toplama.sum(8952, 34298);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43250 + "'", int2 == 43250);
    }

    @Test
    public void test5367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5367");
        int int2 = sum.Toplama.sum(18488, 4980);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23468 + "'", int2 == 23468);
    }

    @Test
    public void test5368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5368");
        int int2 = sum.Toplama.sum(43927, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43927 + "'", int2 == 43927);
    }

    @Test
    public void test5369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5369");
        int int2 = sum.Toplama.sum(210, 8120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8330 + "'", int2 == 8330);
    }

    @Test
    public void test5370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5370");
        int int2 = sum.Toplama.sum(0, 98204);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 98204 + "'", int2 == 98204);
    }

    @Test
    public void test5371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5371");
        int int2 = sum.Toplama.sum(12439, 22041);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34480 + "'", int2 == 34480);
    }

    @Test
    public void test5372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5372");
        int int2 = sum.Toplama.sum(12927, 5853);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18780 + "'", int2 == 18780);
    }

    @Test
    public void test5373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5373");
        int int2 = sum.Toplama.sum(384, 8011);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8395 + "'", int2 == 8395);
    }

    @Test
    public void test5374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5374");
        int int2 = sum.Toplama.sum(4372, 27473);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31845 + "'", int2 == 31845);
    }

    @Test
    public void test5375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5375");
        int int2 = sum.Toplama.sum(2126, 22868);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24994 + "'", int2 == 24994);
    }

    @Test
    public void test5376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5376");
        int int2 = sum.Toplama.sum(36987, 25564);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62551 + "'", int2 == 62551);
    }

    @Test
    public void test5377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5377");
        int int2 = sum.Toplama.sum(20625, 13657);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34282 + "'", int2 == 34282);
    }

    @Test
    public void test5378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5378");
        int int2 = sum.Toplama.sum(17461, 5139);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22600 + "'", int2 == 22600);
    }

    @Test
    public void test5379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5379");
        int int2 = sum.Toplama.sum(17452, 13869);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31321 + "'", int2 == 31321);
    }

    @Test
    public void test5380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5380");
        int int2 = sum.Toplama.sum(1023, 114321);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 115344 + "'", int2 == 115344);
    }

    @Test
    public void test5381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5381");
        int int2 = sum.Toplama.sum(2814, 31729);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34543 + "'", int2 == 34543);
    }

    @Test
    public void test5382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5382");
        int int2 = sum.Toplama.sum(23658, 61597);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 85255 + "'", int2 == 85255);
    }

    @Test
    public void test5383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5383");
        int int2 = sum.Toplama.sum(40804, 28195);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68999 + "'", int2 == 68999);
    }

    @Test
    public void test5384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5384");
        int int2 = sum.Toplama.sum(11593, 14929);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26522 + "'", int2 == 26522);
    }

    @Test
    public void test5385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5385");
        int int2 = sum.Toplama.sum(3460, 17405);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20865 + "'", int2 == 20865);
    }

    @Test
    public void test5386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5386");
        int int2 = sum.Toplama.sum(11397, 12968);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24365 + "'", int2 == 24365);
    }

    @Test
    public void test5387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5387");
        int int2 = sum.Toplama.sum(13929, 8738);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22667 + "'", int2 == 22667);
    }

    @Test
    public void test5388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5388");
        int int2 = sum.Toplama.sum(5012, 26522);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31534 + "'", int2 == 31534);
    }

    @Test
    public void test5389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5389");
        int int2 = sum.Toplama.sum(24168, 5969);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30137 + "'", int2 == 30137);
    }

    @Test
    public void test5390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5390");
        int int2 = sum.Toplama.sum(21540, 5659);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27199 + "'", int2 == 27199);
    }

    @Test
    public void test5391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5391");
        int int2 = sum.Toplama.sum(22613, 5635);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28248 + "'", int2 == 28248);
    }

    @Test
    public void test5392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5392");
        int int2 = sum.Toplama.sum(6726, 4283);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11009 + "'", int2 == 11009);
    }

    @Test
    public void test5393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5393");
        int int2 = sum.Toplama.sum(2347, 19915);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22262 + "'", int2 == 22262);
    }

    @Test
    public void test5394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5394");
        int int2 = sum.Toplama.sum(2445, 6905);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9350 + "'", int2 == 9350);
    }

    @Test
    public void test5395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5395");
        int int2 = sum.Toplama.sum(3918, 13300);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17218 + "'", int2 == 17218);
    }

    @Test
    public void test5396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5396");
        int int2 = sum.Toplama.sum(15467, 14377);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29844 + "'", int2 == 29844);
    }

    @Test
    public void test5397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5397");
        int int2 = sum.Toplama.sum(2140, 2215);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4355 + "'", int2 == 4355);
    }

    @Test
    public void test5398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5398");
        int int2 = sum.Toplama.sum(59245, 4407);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63652 + "'", int2 == 63652);
    }

    @Test
    public void test5399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5399");
        int int2 = sum.Toplama.sum(14136, 10786);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24922 + "'", int2 == 24922);
    }

    @Test
    public void test5400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5400");
        int int2 = sum.Toplama.sum(81571, 17896);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99467 + "'", int2 == 99467);
    }

    @Test
    public void test5401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5401");
        int int2 = sum.Toplama.sum(28373, 25965);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54338 + "'", int2 == 54338);
    }

    @Test
    public void test5402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5402");
        int int2 = sum.Toplama.sum(4902, 68658);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 73560 + "'", int2 == 73560);
    }

    @Test
    public void test5403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5403");
        int int2 = sum.Toplama.sum(1050, 2634);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3684 + "'", int2 == 3684);
    }

    @Test
    public void test5404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5404");
        int int2 = sum.Toplama.sum(22627, 22413);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45040 + "'", int2 == 45040);
    }

    @Test
    public void test5405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5405");
        int int2 = sum.Toplama.sum(3807, 12313);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16120 + "'", int2 == 16120);
    }

    @Test
    public void test5406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5406");
        int int2 = sum.Toplama.sum(18656, 40050);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58706 + "'", int2 == 58706);
    }

    @Test
    public void test5407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5407");
        int int2 = sum.Toplama.sum(1572, 13372);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14944 + "'", int2 == 14944);
    }

    @Test
    public void test5408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5408");
        int int2 = sum.Toplama.sum(96458, 110741);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 207199 + "'", int2 == 207199);
    }

    @Test
    public void test5409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5409");
        int int2 = sum.Toplama.sum(12227, 21152);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33379 + "'", int2 == 33379);
    }

    @Test
    public void test5410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5410");
        int int2 = sum.Toplama.sum(45089, 34282);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 79371 + "'", int2 == 79371);
    }

    @Test
    public void test5411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5411");
        int int2 = sum.Toplama.sum(3326, 30990);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34316 + "'", int2 == 34316);
    }

    @Test
    public void test5412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5412");
        int int2 = sum.Toplama.sum(20468, 2882);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23350 + "'", int2 == 23350);
    }

    @Test
    public void test5413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5413");
        int int2 = sum.Toplama.sum(35225, 8870);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44095 + "'", int2 == 44095);
    }

    @Test
    public void test5414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5414");
        int int2 = sum.Toplama.sum(39542, 13657);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53199 + "'", int2 == 53199);
    }

    @Test
    public void test5415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5415");
        int int2 = sum.Toplama.sum(34126, 8804);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42930 + "'", int2 == 42930);
    }

    @Test
    public void test5416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5416");
        int int2 = sum.Toplama.sum(0, 4311);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4311 + "'", int2 == 4311);
    }

    @Test
    public void test5417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5417");
        int int2 = sum.Toplama.sum(4094, 8442);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12536 + "'", int2 == 12536);
    }

    @Test
    public void test5418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5418");
        int int2 = sum.Toplama.sum(31365, 107);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31472 + "'", int2 == 31472);
    }

    @Test
    public void test5419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5419");
        int int2 = sum.Toplama.sum(17600, 2150);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19750 + "'", int2 == 19750);
    }

    @Test
    public void test5420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5420");
        int int2 = sum.Toplama.sum(49025, 30384);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 79409 + "'", int2 == 79409);
    }

    @Test
    public void test5421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5421");
        int int2 = sum.Toplama.sum(0, 12363);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12363 + "'", int2 == 12363);
    }

    @Test
    public void test5422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5422");
        int int2 = sum.Toplama.sum(31137, 8477);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39614 + "'", int2 == 39614);
    }

    @Test
    public void test5423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5423");
        int int2 = sum.Toplama.sum(0, 2923);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2923 + "'", int2 == 2923);
    }

    @Test
    public void test5424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5424");
        int int2 = sum.Toplama.sum(6895, 40680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47575 + "'", int2 == 47575);
    }

    @Test
    public void test5425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5425");
        int int2 = sum.Toplama.sum(520, 34289);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34809 + "'", int2 == 34809);
    }

    @Test
    public void test5426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5426");
        int int2 = sum.Toplama.sum(7318, 30017);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37335 + "'", int2 == 37335);
    }

    @Test
    public void test5427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5427");
        int int2 = sum.Toplama.sum(19035, 10694);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29729 + "'", int2 == 29729);
    }

    @Test
    public void test5428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5428");
        int int2 = sum.Toplama.sum(2004, 7903);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9907 + "'", int2 == 9907);
    }

    @Test
    public void test5429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5429");
        int int2 = sum.Toplama.sum(11849, 17533);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29382 + "'", int2 == 29382);
    }

    @Test
    public void test5430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5430");
        int int2 = sum.Toplama.sum(109, 11339);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11448 + "'", int2 == 11448);
    }

    @Test
    public void test5431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5431");
        int int2 = sum.Toplama.sum(1171, 742);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1913 + "'", int2 == 1913);
    }

    @Test
    public void test5432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5432");
        int int2 = sum.Toplama.sum(2492, 18226);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20718 + "'", int2 == 20718);
    }

    @Test
    public void test5433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5433");
        int int2 = sum.Toplama.sum(3362, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3362 + "'", int2 == 3362);
    }

    @Test
    public void test5434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5434");
        int int2 = sum.Toplama.sum(680, 3974);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4654 + "'", int2 == 4654);
    }

    @Test
    public void test5435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5435");
        int int2 = sum.Toplama.sum(1317, 12799);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14116 + "'", int2 == 14116);
    }

    @Test
    public void test5436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5436");
        int int2 = sum.Toplama.sum(2973, 39696);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42669 + "'", int2 == 42669);
    }

    @Test
    public void test5437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5437");
        int int2 = sum.Toplama.sum(584, 25546);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26130 + "'", int2 == 26130);
    }

    @Test
    public void test5438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5438");
        int int2 = sum.Toplama.sum(29498, 10361);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39859 + "'", int2 == 39859);
    }

    @Test
    public void test5439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5439");
        int int2 = sum.Toplama.sum(8105, 8117);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16222 + "'", int2 == 16222);
    }

    @Test
    public void test5440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5440");
        int int2 = sum.Toplama.sum(9043, 22012);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31055 + "'", int2 == 31055);
    }

    @Test
    public void test5441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5441");
        int int2 = sum.Toplama.sum(3772, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3772 + "'", int2 == 3772);
    }

    @Test
    public void test5442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5442");
        int int2 = sum.Toplama.sum(6129, 3305);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9434 + "'", int2 == 9434);
    }

    @Test
    public void test5443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5443");
        int int2 = sum.Toplama.sum(5751, 34310);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40061 + "'", int2 == 40061);
    }

    @Test
    public void test5444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5444");
        int int2 = sum.Toplama.sum(4254, 18014);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22268 + "'", int2 == 22268);
    }

    @Test
    public void test5445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5445");
        int int2 = sum.Toplama.sum(41146, 32531);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 73677 + "'", int2 == 73677);
    }

    @Test
    public void test5446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5446");
        int int2 = sum.Toplama.sum(24272, 31916);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56188 + "'", int2 == 56188);
    }

    @Test
    public void test5447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5447");
        int int2 = sum.Toplama.sum(14723, 17009);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31732 + "'", int2 == 31732);
    }

    @Test
    public void test5448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5448");
        int int2 = sum.Toplama.sum(52593, 34223);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 86816 + "'", int2 == 86816);
    }

    @Test
    public void test5449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5449");
        int int2 = sum.Toplama.sum(2146, 17912);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20058 + "'", int2 == 20058);
    }

    @Test
    public void test5450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5450");
        int int2 = sum.Toplama.sum(42182, 3848);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46030 + "'", int2 == 46030);
    }

    @Test
    public void test5451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5451");
        int int2 = sum.Toplama.sum(251, 14709);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14960 + "'", int2 == 14960);
    }

    @Test
    public void test5452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5452");
        int int2 = sum.Toplama.sum(1652, 70686);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72338 + "'", int2 == 72338);
    }

    @Test
    public void test5453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5453");
        int int2 = sum.Toplama.sum(19136, 14881);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34017 + "'", int2 == 34017);
    }

    @Test
    public void test5454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5454");
        int int2 = sum.Toplama.sum(8437, 10694);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19131 + "'", int2 == 19131);
    }

    @Test
    public void test5455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5455");
        int int2 = sum.Toplama.sum((int) (short) 10, 41063);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41073 + "'", int2 == 41073);
    }

    @Test
    public void test5456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5456");
        int int2 = sum.Toplama.sum(82425, 51587);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 134012 + "'", int2 == 134012);
    }

    @Test
    public void test5457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5457");
        int int2 = sum.Toplama.sum(11641, 1427);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13068 + "'", int2 == 13068);
    }

    @Test
    public void test5458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5458");
        int int2 = sum.Toplama.sum(8424, 3169);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11593 + "'", int2 == 11593);
    }

    @Test
    public void test5459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5459");
        int int2 = sum.Toplama.sum(10594, 5182);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15776 + "'", int2 == 15776);
    }

    @Test
    public void test5460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5460");
        int int2 = sum.Toplama.sum(29158, 1862);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31020 + "'", int2 == 31020);
    }

    @Test
    public void test5461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5461");
        int int2 = sum.Toplama.sum(12238, 11391);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23629 + "'", int2 == 23629);
    }

    @Test
    public void test5462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5462");
        int int2 = sum.Toplama.sum(19871, 69736);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 89607 + "'", int2 == 89607);
    }

    @Test
    public void test5463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5463");
        int int2 = sum.Toplama.sum(19578, 53363);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72941 + "'", int2 == 72941);
    }

    @Test
    public void test5464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5464");
        int int2 = sum.Toplama.sum(5476, 4712);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10188 + "'", int2 == 10188);
    }

    @Test
    public void test5465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5465");
        int int2 = sum.Toplama.sum(32735, 65089);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97824 + "'", int2 == 97824);
    }

    @Test
    public void test5466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5466");
        int int2 = sum.Toplama.sum(29661, 20004);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49665 + "'", int2 == 49665);
    }

    @Test
    public void test5467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5467");
        int int2 = sum.Toplama.sum(36973, 34321);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 71294 + "'", int2 == 71294);
    }

    @Test
    public void test5468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5468");
        int int2 = sum.Toplama.sum(3627, 1276);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4903 + "'", int2 == 4903);
    }

    @Test
    public void test5469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5469");
        int int2 = sum.Toplama.sum(33449, 14731);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48180 + "'", int2 == 48180);
    }

    @Test
    public void test5470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5470");
        int int2 = sum.Toplama.sum(3553, 54450);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58003 + "'", int2 == 58003);
    }

    @Test
    public void test5471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5471");
        int int2 = sum.Toplama.sum(30036, 2118);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32154 + "'", int2 == 32154);
    }

    @Test
    public void test5472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5472");
        int int2 = sum.Toplama.sum(15901, 23340);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39241 + "'", int2 == 39241);
    }

    @Test
    public void test5473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5473");
        int int2 = sum.Toplama.sum(20854, 4179);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25033 + "'", int2 == 25033);
    }

    @Test
    public void test5474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5474");
        int int2 = sum.Toplama.sum(38318, 2340);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40658 + "'", int2 == 40658);
    }

    @Test
    public void test5475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5475");
        int int2 = sum.Toplama.sum(0, 1932);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1932 + "'", int2 == 1932);
    }

    @Test
    public void test5476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5476");
        int int2 = sum.Toplama.sum(55034, 8156);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63190 + "'", int2 == 63190);
    }

    @Test
    public void test5477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5477");
        int int2 = sum.Toplama.sum(980, 3044);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4024 + "'", int2 == 4024);
    }

    @Test
    public void test5478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5478");
        int int2 = sum.Toplama.sum(30830, 6986);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37816 + "'", int2 == 37816);
    }

    @Test
    public void test5479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5479");
        int int2 = sum.Toplama.sum(20098, 1896);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21994 + "'", int2 == 21994);
    }

    @Test
    public void test5480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5480");
        int int2 = sum.Toplama.sum(131, 62900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63031 + "'", int2 == 63031);
    }

    @Test
    public void test5481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5481");
        int int2 = sum.Toplama.sum(11388, 18653);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30041 + "'", int2 == 30041);
    }

    @Test
    public void test5482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5482");
        int int2 = sum.Toplama.sum(7337, 24344);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31681 + "'", int2 == 31681);
    }

    @Test
    public void test5483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5483");
        int int2 = sum.Toplama.sum(33948, 11790);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45738 + "'", int2 == 45738);
    }

    @Test
    public void test5484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5484");
        int int2 = sum.Toplama.sum(19365, 17031);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36396 + "'", int2 == 36396);
    }

    @Test
    public void test5485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5485");
        int int2 = sum.Toplama.sum(28991, 2140);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31131 + "'", int2 == 31131);
    }

    @Test
    public void test5486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5486");
        int int2 = sum.Toplama.sum(19724, 31157);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50881 + "'", int2 == 50881);
    }

    @Test
    public void test5487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5487");
        int int2 = sum.Toplama.sum(15721, 1193);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16914 + "'", int2 == 16914);
    }

    @Test
    public void test5488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5488");
        int int2 = sum.Toplama.sum(4987, 25775);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30762 + "'", int2 == 30762);
    }

    @Test
    public void test5489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5489");
        int int2 = sum.Toplama.sum(746, 3848);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4594 + "'", int2 == 4594);
    }

    @Test
    public void test5490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5490");
        int int2 = sum.Toplama.sum(200, 6136);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6336 + "'", int2 == 6336);
    }

    @Test
    public void test5491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5491");
        int int2 = sum.Toplama.sum(54429, 5039);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59468 + "'", int2 == 59468);
    }

    @Test
    public void test5492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5492");
        int int2 = sum.Toplama.sum(8845, 26669);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35514 + "'", int2 == 35514);
    }

    @Test
    public void test5493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5493");
        int int2 = sum.Toplama.sum(9350, 45733);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55083 + "'", int2 == 55083);
    }

    @Test
    public void test5494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5494");
        int int2 = sum.Toplama.sum(19136, 352);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19488 + "'", int2 == 19488);
    }

    @Test
    public void test5495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5495");
        int int2 = sum.Toplama.sum(14791, 1932);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16723 + "'", int2 == 16723);
    }

    @Test
    public void test5496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5496");
        int int2 = sum.Toplama.sum(108223, 35728);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 143951 + "'", int2 == 143951);
    }

    @Test
    public void test5497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5497");
        int int2 = sum.Toplama.sum(11651, 17613);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29264 + "'", int2 == 29264);
    }

    @Test
    public void test5498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5498");
        int int2 = sum.Toplama.sum(1752, 14731);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16483 + "'", int2 == 16483);
    }

    @Test
    public void test5499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5499");
        int int2 = sum.Toplama.sum(4479, 2723);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7202 + "'", int2 == 7202);
    }

    @Test
    public void test5500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5500");
        int int2 = sum.Toplama.sum(21893, 30536);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52429 + "'", int2 == 52429);
    }
}

