import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest9 {

    public static boolean debug = false;

    @Test
    public void test4501() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4501");
        int int2 = sum.Toplama.sum(1239, 12576);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13815 + "'", int2 == 13815);
    }

    @Test
    public void test4502() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4502");
        int int2 = sum.Toplama.sum(5114, 2953);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8067 + "'", int2 == 8067);
    }

    @Test
    public void test4503() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4503");
        int int2 = sum.Toplama.sum(14416, 22357);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36773 + "'", int2 == 36773);
    }

    @Test
    public void test4504() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4504");
        int int2 = sum.Toplama.sum(0, 1735);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1735 + "'", int2 == 1735);
    }

    @Test
    public void test4505() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4505");
        int int2 = sum.Toplama.sum(28980, 25073);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54053 + "'", int2 == 54053);
    }

    @Test
    public void test4506() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4506");
        int int2 = sum.Toplama.sum(216, 16902);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17118 + "'", int2 == 17118);
    }

    @Test
    public void test4507() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4507");
        int int2 = sum.Toplama.sum(16606, 6764);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23370 + "'", int2 == 23370);
    }

    @Test
    public void test4508() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4508");
        int int2 = sum.Toplama.sum(17244, 93176);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 110420 + "'", int2 == 110420);
    }

    @Test
    public void test4509() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4509");
        int int2 = sum.Toplama.sum(2272, 7331);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9603 + "'", int2 == 9603);
    }

    @Test
    public void test4510() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4510");
        int int2 = sum.Toplama.sum(18656, 7316);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25972 + "'", int2 == 25972);
    }

    @Test
    public void test4511() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4511");
        int int2 = sum.Toplama.sum(27872, 10909);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38781 + "'", int2 == 38781);
    }

    @Test
    public void test4512() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4512");
        int int2 = sum.Toplama.sum(241, 520);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 761 + "'", int2 == 761);
    }

    @Test
    public void test4513() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4513");
        int int2 = sum.Toplama.sum(30293, 27083);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57376 + "'", int2 == 57376);
    }

    @Test
    public void test4514() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4514");
        int int2 = sum.Toplama.sum(21274, 270);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21544 + "'", int2 == 21544);
    }

    @Test
    public void test4515() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4515");
        int int2 = sum.Toplama.sum(27851, 395);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28246 + "'", int2 == 28246);
    }

    @Test
    public void test4516() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4516");
        int int2 = sum.Toplama.sum(2556, 13480);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16036 + "'", int2 == 16036);
    }

    @Test
    public void test4517() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4517");
        int int2 = sum.Toplama.sum(63720, 7071);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70791 + "'", int2 == 70791);
    }

    @Test
    public void test4518() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4518");
        int int2 = sum.Toplama.sum(16577, 26660);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43237 + "'", int2 == 43237);
    }

    @Test
    public void test4519() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4519");
        int int2 = sum.Toplama.sum(11460, 2111);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13571 + "'", int2 == 13571);
    }

    @Test
    public void test4520() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4520");
        int int2 = sum.Toplama.sum(10198, 5399);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15597 + "'", int2 == 15597);
    }

    @Test
    public void test4521() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4521");
        int int2 = sum.Toplama.sum(8370, 26951);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35321 + "'", int2 == 35321);
    }

    @Test
    public void test4522() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4522");
        int int2 = sum.Toplama.sum(13652, 7105);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20757 + "'", int2 == 20757);
    }

    @Test
    public void test4523() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4523");
        int int2 = sum.Toplama.sum(10166, 25450);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35616 + "'", int2 == 35616);
    }

    @Test
    public void test4524() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4524");
        int int2 = sum.Toplama.sum(7651, 805);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8456 + "'", int2 == 8456);
    }

    @Test
    public void test4525() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4525");
        int int2 = sum.Toplama.sum(7007, 17026);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24033 + "'", int2 == 24033);
    }

    @Test
    public void test4526() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4526");
        int int2 = sum.Toplama.sum(25268, 5519);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30787 + "'", int2 == 30787);
    }

    @Test
    public void test4527() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4527");
        int int2 = sum.Toplama.sum(51210, 25176);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 76386 + "'", int2 == 76386);
    }

    @Test
    public void test4528() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4528");
        int int2 = sum.Toplama.sum(16583, 6219);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22802 + "'", int2 == 22802);
    }

    @Test
    public void test4529() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4529");
        int int2 = sum.Toplama.sum(8767, 24382);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33149 + "'", int2 == 33149);
    }

    @Test
    public void test4530() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4530");
        int int2 = sum.Toplama.sum(13410, 1631);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15041 + "'", int2 == 15041);
    }

    @Test
    public void test4531() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4531");
        int int2 = sum.Toplama.sum(20750, 3176);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23926 + "'", int2 == 23926);
    }

    @Test
    public void test4532() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4532");
        int int2 = sum.Toplama.sum(0, 39969);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39969 + "'", int2 == 39969);
    }

    @Test
    public void test4533() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4533");
        int int2 = sum.Toplama.sum(17040, 4246);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21286 + "'", int2 == 21286);
    }

    @Test
    public void test4534() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4534");
        int int2 = sum.Toplama.sum(27209, 1239);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28448 + "'", int2 == 28448);
    }

    @Test
    public void test4535() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4535");
        int int2 = sum.Toplama.sum(1087, 28803);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29890 + "'", int2 == 29890);
    }

    @Test
    public void test4536() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4536");
        int int2 = sum.Toplama.sum(9870, 12588);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22458 + "'", int2 == 22458);
    }

    @Test
    public void test4537() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4537");
        int int2 = sum.Toplama.sum(17054, 14556);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31610 + "'", int2 == 31610);
    }

    @Test
    public void test4538() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4538");
        int int2 = sum.Toplama.sum(12183, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12183 + "'", int2 == 12183);
    }

    @Test
    public void test4539() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4539");
        int int2 = sum.Toplama.sum(0, 3368);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3368 + "'", int2 == 3368);
    }

    @Test
    public void test4540() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4540");
        int int2 = sum.Toplama.sum(0, 1064);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1064 + "'", int2 == 1064);
    }

    @Test
    public void test4541() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4541");
        int int2 = sum.Toplama.sum(9342, 1296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10638 + "'", int2 == 10638);
    }

    @Test
    public void test4542() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4542");
        int int2 = sum.Toplama.sum(5034, 10759);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15793 + "'", int2 == 15793);
    }

    @Test
    public void test4543() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4543");
        int int2 = sum.Toplama.sum(1274, 8139);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9413 + "'", int2 == 9413);
    }

    @Test
    public void test4544() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4544");
        int int2 = sum.Toplama.sum(13266, 9088);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22354 + "'", int2 == 22354);
    }

    @Test
    public void test4545() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4545");
        int int2 = sum.Toplama.sum(0, 84820);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 84820 + "'", int2 == 84820);
    }

    @Test
    public void test4546() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4546");
        int int2 = sum.Toplama.sum(6078, 8671);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14749 + "'", int2 == 14749);
    }

    @Test
    public void test4547() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4547");
        int int2 = sum.Toplama.sum(19406, 6195);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25601 + "'", int2 == 25601);
    }

    @Test
    public void test4548() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4548");
        int int2 = sum.Toplama.sum(20098, 2222);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22320 + "'", int2 == 22320);
    }

    @Test
    public void test4549() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4549");
        int int2 = sum.Toplama.sum(12178, 5658);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17836 + "'", int2 == 17836);
    }

    @Test
    public void test4550() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4550");
        int int2 = sum.Toplama.sum(100, 3392);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3492 + "'", int2 == 3492);
    }

    @Test
    public void test4551() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4551");
        int int2 = sum.Toplama.sum(33272, 34400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67672 + "'", int2 == 67672);
    }

    @Test
    public void test4552() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4552");
        int int2 = sum.Toplama.sum(6327, 48842);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55169 + "'", int2 == 55169);
    }

    @Test
    public void test4553() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4553");
        int int2 = sum.Toplama.sum(12635, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12635 + "'", int2 == 12635);
    }

    @Test
    public void test4554() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4554");
        int int2 = sum.Toplama.sum(16910, 20776);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37686 + "'", int2 == 37686);
    }

    @Test
    public void test4555() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4555");
        int int2 = sum.Toplama.sum(15503, 1398);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16901 + "'", int2 == 16901);
    }

    @Test
    public void test4556() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4556");
        int int2 = sum.Toplama.sum(4527, 22210);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26737 + "'", int2 == 26737);
    }

    @Test
    public void test4557() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4557");
        int int2 = sum.Toplama.sum(7232, 3091);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10323 + "'", int2 == 10323);
    }

    @Test
    public void test4558() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4558");
        int int2 = sum.Toplama.sum(12328, 623);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12951 + "'", int2 == 12951);
    }

    @Test
    public void test4559() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4559");
        int int2 = sum.Toplama.sum(18212, 31396);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49608 + "'", int2 == 49608);
    }

    @Test
    public void test4560() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4560");
        int int2 = sum.Toplama.sum(10070, 10013);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20083 + "'", int2 == 20083);
    }

    @Test
    public void test4561() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4561");
        int int2 = sum.Toplama.sum((int) (byte) 10, 6453);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6463 + "'", int2 == 6463);
    }

    @Test
    public void test4562() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4562");
        int int2 = sum.Toplama.sum(10981, 7903);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18884 + "'", int2 == 18884);
    }

    @Test
    public void test4563() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4563");
        int int2 = sum.Toplama.sum(14782, 2318);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17100 + "'", int2 == 17100);
    }

    @Test
    public void test4564() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4564");
        int int2 = sum.Toplama.sum(16645, 13176);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29821 + "'", int2 == 29821);
    }

    @Test
    public void test4565() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4565");
        int int2 = sum.Toplama.sum(14621, 8950);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23571 + "'", int2 == 23571);
    }

    @Test
    public void test4566() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4566");
        int int2 = sum.Toplama.sum(14097, 1624);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15721 + "'", int2 == 15721);
    }

    @Test
    public void test4567() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4567");
        int int2 = sum.Toplama.sum(7457, 13804);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21261 + "'", int2 == 21261);
    }

    @Test
    public void test4568() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4568");
        int int2 = sum.Toplama.sum(1521, 7374);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8895 + "'", int2 == 8895);
    }

    @Test
    public void test4569() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4569");
        int int2 = sum.Toplama.sum(7839, 29044);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36883 + "'", int2 == 36883);
    }

    @Test
    public void test4570() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4570");
        int int2 = sum.Toplama.sum(3628, 27959);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31587 + "'", int2 == 31587);
    }

    @Test
    public void test4571() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4571");
        int int2 = sum.Toplama.sum(11790, 37191);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48981 + "'", int2 == 48981);
    }

    @Test
    public void test4572() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4572");
        int int2 = sum.Toplama.sum(69070, 2986);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72056 + "'", int2 == 72056);
    }

    @Test
    public void test4573() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4573");
        int int2 = sum.Toplama.sum(24238, 30865);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55103 + "'", int2 == 55103);
    }

    @Test
    public void test4574() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4574");
        int int2 = sum.Toplama.sum(2950, 13663);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16613 + "'", int2 == 16613);
    }

    @Test
    public void test4575() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4575");
        int int2 = sum.Toplama.sum(3578, 1837);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5415 + "'", int2 == 5415);
    }

    @Test
    public void test4576() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4576");
        int int2 = sum.Toplama.sum(25546, 13480);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39026 + "'", int2 == 39026);
    }

    @Test
    public void test4577() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4577");
        int int2 = sum.Toplama.sum(67627, 8130);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 75757 + "'", int2 == 75757);
    }

    @Test
    public void test4578() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4578");
        int int2 = sum.Toplama.sum(11211, 3045);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14256 + "'", int2 == 14256);
    }

    @Test
    public void test4579() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4579");
        int int2 = sum.Toplama.sum(19931, 3593);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23524 + "'", int2 == 23524);
    }

    @Test
    public void test4580() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4580");
        int int2 = sum.Toplama.sum(11072, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11072 + "'", int2 == 11072);
    }

    @Test
    public void test4581() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4581");
        int int2 = sum.Toplama.sum(11667, 12166);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23833 + "'", int2 == 23833);
    }

    @Test
    public void test4582() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4582");
        int int2 = sum.Toplama.sum(30830, 11710);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42540 + "'", int2 == 42540);
    }

    @Test
    public void test4583() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4583");
        int int2 = sum.Toplama.sum(7713, 5841);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13554 + "'", int2 == 13554);
    }

    @Test
    public void test4584() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4584");
        int int2 = sum.Toplama.sum(1970, 112044);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 114014 + "'", int2 == 114014);
    }

    @Test
    public void test4585() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4585");
        int int2 = sum.Toplama.sum(14265, 538);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14803 + "'", int2 == 14803);
    }

    @Test
    public void test4586() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4586");
        int int2 = sum.Toplama.sum(5107, 56777);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61884 + "'", int2 == 61884);
    }

    @Test
    public void test4587() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4587");
        int int2 = sum.Toplama.sum(39560, 20468);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60028 + "'", int2 == 60028);
    }

    @Test
    public void test4588() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4588");
        int int2 = sum.Toplama.sum(25412, 52895);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78307 + "'", int2 == 78307);
    }

    @Test
    public void test4589() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4589");
        int int2 = sum.Toplama.sum(7329, 5116);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12445 + "'", int2 == 12445);
    }

    @Test
    public void test4590() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4590");
        int int2 = sum.Toplama.sum(0, 25965);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25965 + "'", int2 == 25965);
    }

    @Test
    public void test4591() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4591");
        int int2 = sum.Toplama.sum(3092, 68749);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 71841 + "'", int2 == 71841);
    }

    @Test
    public void test4592() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4592");
        int int2 = sum.Toplama.sum(39721, 5368);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45089 + "'", int2 == 45089);
    }

    @Test
    public void test4593() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4593");
        int int2 = sum.Toplama.sum(15287, 10772);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26059 + "'", int2 == 26059);
    }

    @Test
    public void test4594() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4594");
        int int2 = sum.Toplama.sum(13123, 3900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17023 + "'", int2 == 17023);
    }

    @Test
    public void test4595() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4595");
        int int2 = sum.Toplama.sum(11022, 405);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11427 + "'", int2 == 11427);
    }

    @Test
    public void test4596() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4596");
        int int2 = sum.Toplama.sum(0, 38561);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38561 + "'", int2 == 38561);
    }

    @Test
    public void test4597() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4597");
        int int2 = sum.Toplama.sum(18216, 31119);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49335 + "'", int2 == 49335);
    }

    @Test
    public void test4598() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4598");
        int int2 = sum.Toplama.sum(6377, 8148);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14525 + "'", int2 == 14525);
    }

    @Test
    public void test4599() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4599");
        int int2 = sum.Toplama.sum(14431, 55848);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70279 + "'", int2 == 70279);
    }

    @Test
    public void test4600() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4600");
        int int2 = sum.Toplama.sum(1680, 3695);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5375 + "'", int2 == 5375);
    }

    @Test
    public void test4601() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4601");
        int int2 = sum.Toplama.sum(6377, 23601);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29978 + "'", int2 == 29978);
    }

    @Test
    public void test4602() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4602");
        int int2 = sum.Toplama.sum(35283, 790);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36073 + "'", int2 == 36073);
    }

    @Test
    public void test4603() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4603");
        int int2 = sum.Toplama.sum(12004, 15817);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27821 + "'", int2 == 27821);
    }

    @Test
    public void test4604() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4604");
        int int2 = sum.Toplama.sum(34852, 18435);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53287 + "'", int2 == 53287);
    }

    @Test
    public void test4605() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4605");
        int int2 = sum.Toplama.sum(49092, 421);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49513 + "'", int2 == 49513);
    }

    @Test
    public void test4606() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4606");
        int int2 = sum.Toplama.sum(33180, 2698);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35878 + "'", int2 == 35878);
    }

    @Test
    public void test4607() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4607");
        int int2 = sum.Toplama.sum(9119, 954);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10073 + "'", int2 == 10073);
    }

    @Test
    public void test4608() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4608");
        int int2 = sum.Toplama.sum(22285, 1271);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23556 + "'", int2 == 23556);
    }

    @Test
    public void test4609() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4609");
        int int2 = sum.Toplama.sum(11442, 3844);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15286 + "'", int2 == 15286);
    }

    @Test
    public void test4610() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4610");
        int int2 = sum.Toplama.sum(20757, 29789);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50546 + "'", int2 == 50546);
    }

    @Test
    public void test4611() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4611");
        int int2 = sum.Toplama.sum(25481, 15817);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41298 + "'", int2 == 41298);
    }

    @Test
    public void test4612() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4612");
        int int2 = sum.Toplama.sum(14568, 9004);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23572 + "'", int2 == 23572);
    }

    @Test
    public void test4613() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4613");
        int int2 = sum.Toplama.sum(11292, 280);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11572 + "'", int2 == 11572);
    }

    @Test
    public void test4614() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4614");
        int int2 = sum.Toplama.sum(4945, 30734);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35679 + "'", int2 == 35679);
    }

    @Test
    public void test4615() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4615");
        int int2 = sum.Toplama.sum(4215, 1230);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5445 + "'", int2 == 5445);
    }

    @Test
    public void test4616() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4616");
        int int2 = sum.Toplama.sum(21261, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21261 + "'", int2 == 21261);
    }

    @Test
    public void test4617() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4617");
        int int2 = sum.Toplama.sum(38724, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38724 + "'", int2 == 38724);
    }

    @Test
    public void test4618() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4618");
        int int2 = sum.Toplama.sum(36930, 7545);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44475 + "'", int2 == 44475);
    }

    @Test
    public void test4619() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4619");
        int int2 = sum.Toplama.sum(17906, 63665);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 81571 + "'", int2 == 81571);
    }

    @Test
    public void test4620() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4620");
        int int2 = sum.Toplama.sum(1960, 45879);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47839 + "'", int2 == 47839);
    }

    @Test
    public void test4621() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4621");
        int int2 = sum.Toplama.sum(16212, 31137);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47349 + "'", int2 == 47349);
    }

    @Test
    public void test4622() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4622");
        int int2 = sum.Toplama.sum(56140, 9689);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 65829 + "'", int2 == 65829);
    }

    @Test
    public void test4623() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4623");
        int int2 = sum.Toplama.sum(11710, 39560);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51270 + "'", int2 == 51270);
    }

    @Test
    public void test4624() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4624");
        int int2 = sum.Toplama.sum(3102, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3101 + "'", int2 == 3101);
    }

    @Test
    public void test4625() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4625");
        int int2 = sum.Toplama.sum(13871, 15614);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29485 + "'", int2 == 29485);
    }

    @Test
    public void test4626() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4626");
        int int2 = sum.Toplama.sum(20917, 18108);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39025 + "'", int2 == 39025);
    }

    @Test
    public void test4627() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4627");
        int int2 = sum.Toplama.sum(4582, 49025);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53607 + "'", int2 == 53607);
    }

    @Test
    public void test4628() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4628");
        int int2 = sum.Toplama.sum(11931, 8785);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20716 + "'", int2 == 20716);
    }

    @Test
    public void test4629() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4629");
        int int2 = sum.Toplama.sum(69985, 13349);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 83334 + "'", int2 == 83334);
    }

    @Test
    public void test4630() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4630");
        int int2 = sum.Toplama.sum(3410, 26435);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29845 + "'", int2 == 29845);
    }

    @Test
    public void test4631() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4631");
        int int2 = sum.Toplama.sum(2609, 51953);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54562 + "'", int2 == 54562);
    }

    @Test
    public void test4632() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4632");
        int int2 = sum.Toplama.sum(22210, 10321);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32531 + "'", int2 == 32531);
    }

    @Test
    public void test4633() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4633");
        int int2 = sum.Toplama.sum(54450, 3598);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58048 + "'", int2 == 58048);
    }

    @Test
    public void test4634() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4634");
        int int2 = sum.Toplama.sum(18212, 23522);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41734 + "'", int2 == 41734);
    }

    @Test
    public void test4635() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4635");
        int int2 = sum.Toplama.sum(3965, 2325);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6290 + "'", int2 == 6290);
    }

    @Test
    public void test4636() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4636");
        int int2 = sum.Toplama.sum(558, 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 657 + "'", int2 == 657);
    }

    @Test
    public void test4637() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4637");
        int int2 = sum.Toplama.sum(54921, 5213);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60134 + "'", int2 == 60134);
    }

    @Test
    public void test4638() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4638");
        int int2 = sum.Toplama.sum(802, 4090);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4892 + "'", int2 == 4892);
    }

    @Test
    public void test4639() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4639");
        int int2 = sum.Toplama.sum(6643, 24753);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31396 + "'", int2 == 31396);
    }

    @Test
    public void test4640() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4640");
        int int2 = sum.Toplama.sum(8470, 3900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12370 + "'", int2 == 12370);
    }

    @Test
    public void test4641() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4641");
        int int2 = sum.Toplama.sum(0, 10318);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10318 + "'", int2 == 10318);
    }

    @Test
    public void test4642() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4642");
        int int2 = sum.Toplama.sum(1, 13545);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13546 + "'", int2 == 13546);
    }

    @Test
    public void test4643() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4643");
        int int2 = sum.Toplama.sum(44602, 1601);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46203 + "'", int2 == 46203);
    }

    @Test
    public void test4644() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4644");
        int int2 = sum.Toplama.sum(5764, 24620);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30384 + "'", int2 == 30384);
    }

    @Test
    public void test4645() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4645");
        int int2 = sum.Toplama.sum(34008, 5030);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39038 + "'", int2 == 39038);
    }

    @Test
    public void test4646() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4646");
        int int2 = sum.Toplama.sum(17920, 4145);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22065 + "'", int2 == 22065);
    }

    @Test
    public void test4647() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4647");
        int int2 = sum.Toplama.sum(17273, 17016);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34289 + "'", int2 == 34289);
    }

    @Test
    public void test4648() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4648");
        int int2 = sum.Toplama.sum(22324, 19346);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41670 + "'", int2 == 41670);
    }

    @Test
    public void test4649() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4649");
        int int2 = sum.Toplama.sum(3241, 18899);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22140 + "'", int2 == 22140);
    }

    @Test
    public void test4650() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4650");
        int int2 = sum.Toplama.sum(28560, 26474);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55034 + "'", int2 == 55034);
    }

    @Test
    public void test4651() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4651");
        int int2 = sum.Toplama.sum(63665, 24551);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 88216 + "'", int2 == 88216);
    }

    @Test
    public void test4652() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4652");
        int int2 = sum.Toplama.sum(66363, 1768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68131 + "'", int2 == 68131);
    }

    @Test
    public void test4653() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4653");
        int int2 = sum.Toplama.sum(3061, 63217);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 66278 + "'", int2 == 66278);
    }

    @Test
    public void test4654() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4654");
        int int2 = sum.Toplama.sum(8445, 30925);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39370 + "'", int2 == 39370);
    }

    @Test
    public void test4655() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4655");
        int int2 = sum.Toplama.sum(8864, 41698);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50562 + "'", int2 == 50562);
    }

    @Test
    public void test4656() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4656");
        int int2 = sum.Toplama.sum(17873, 3078);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20951 + "'", int2 == 20951);
    }

    @Test
    public void test4657() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4657");
        int int2 = sum.Toplama.sum(35679, 8457);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44136 + "'", int2 == 44136);
    }

    @Test
    public void test4658() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4658");
        int int2 = sum.Toplama.sum(24295, 33785);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58080 + "'", int2 == 58080);
    }

    @Test
    public void test4659() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4659");
        int int2 = sum.Toplama.sum(554, 19307);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19861 + "'", int2 == 19861);
    }

    @Test
    public void test4660() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4660");
        int int2 = sum.Toplama.sum(0, 341);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 341 + "'", int2 == 341);
    }

    @Test
    public void test4661() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4661");
        int int2 = sum.Toplama.sum(8532, 3403);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11935 + "'", int2 == 11935);
    }

    @Test
    public void test4662() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4662");
        int int2 = sum.Toplama.sum(24248, 10073);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34321 + "'", int2 == 34321);
    }

    @Test
    public void test4663() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4663");
        int int2 = sum.Toplama.sum(0, 16522);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16522 + "'", int2 == 16522);
    }

    @Test
    public void test4664() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4664");
        int int2 = sum.Toplama.sum(6755, 40999);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47754 + "'", int2 == 47754);
    }

    @Test
    public void test4665() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4665");
        int int2 = sum.Toplama.sum(8951, 29845);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38796 + "'", int2 == 38796);
    }

    @Test
    public void test4666() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4666");
        int int2 = sum.Toplama.sum(4388, 6220);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10608 + "'", int2 == 10608);
    }

    @Test
    public void test4667() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4667");
        int int2 = sum.Toplama.sum((int) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test4668() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4668");
        int int2 = sum.Toplama.sum(13435, 8673);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22108 + "'", int2 == 22108);
    }

    @Test
    public void test4669() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4669");
        int int2 = sum.Toplama.sum(5302, 6142);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11444 + "'", int2 == 11444);
    }

    @Test
    public void test4670() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4670");
        int int2 = sum.Toplama.sum(48921, 40362);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 89283 + "'", int2 == 89283);
    }

    @Test
    public void test4671() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4671");
        int int2 = sum.Toplama.sum(12786, 35929);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48715 + "'", int2 == 48715);
    }

    @Test
    public void test4672() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4672");
        int int2 = sum.Toplama.sum(9991, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9991 + "'", int2 == 9991);
    }

    @Test
    public void test4673() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4673");
        int int2 = sum.Toplama.sum(6235, 16205);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22440 + "'", int2 == 22440);
    }

    @Test
    public void test4674() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4674");
        int int2 = sum.Toplama.sum(2123, 624);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2747 + "'", int2 == 2747);
    }

    @Test
    public void test4675() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4675");
        int int2 = sum.Toplama.sum(23766, 4978);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28744 + "'", int2 == 28744);
    }

    @Test
    public void test4676() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4676");
        int int2 = sum.Toplama.sum(5812, 54053);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59865 + "'", int2 == 59865);
    }

    @Test
    public void test4677() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4677");
        int int2 = sum.Toplama.sum(5097, 22759);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27856 + "'", int2 == 27856);
    }

    @Test
    public void test4678() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4678");
        int int2 = sum.Toplama.sum(4372, 19343);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23715 + "'", int2 == 23715);
    }

    @Test
    public void test4679() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4679");
        int int2 = sum.Toplama.sum(16848, 12232);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29080 + "'", int2 == 29080);
    }

    @Test
    public void test4680() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4680");
        int int2 = sum.Toplama.sum(2067, 15548);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17615 + "'", int2 == 17615);
    }

    @Test
    public void test4681() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4681");
        int int2 = sum.Toplama.sum(11126, 2411);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13537 + "'", int2 == 13537);
    }

    @Test
    public void test4682() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4682");
        int int2 = sum.Toplama.sum(980, 40352);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41332 + "'", int2 == 41332);
    }

    @Test
    public void test4683() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4683");
        int int2 = sum.Toplama.sum(3414, 49025);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52439 + "'", int2 == 52439);
    }

    @Test
    public void test4684() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4684");
        int int2 = sum.Toplama.sum(1424, 41670);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43094 + "'", int2 == 43094);
    }

    @Test
    public void test4685() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4685");
        int int2 = sum.Toplama.sum(15718, 17118);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32836 + "'", int2 == 32836);
    }

    @Test
    public void test4686() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4686");
        int int2 = sum.Toplama.sum(38002, 3737);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41739 + "'", int2 == 41739);
    }

    @Test
    public void test4687() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4687");
        int int2 = sum.Toplama.sum(6188, 23524);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29712 + "'", int2 == 29712);
    }

    @Test
    public void test4688() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4688");
        int int2 = sum.Toplama.sum(2380, 40999);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43379 + "'", int2 == 43379);
    }

    @Test
    public void test4689() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4689");
        int int2 = sum.Toplama.sum(1936, 37869);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39805 + "'", int2 == 39805);
    }

    @Test
    public void test4690() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4690");
        int int2 = sum.Toplama.sum(18177, 13604);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31781 + "'", int2 == 31781);
    }

    @Test
    public void test4691() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4691");
        int int2 = sum.Toplama.sum(17488, 27208);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44696 + "'", int2 == 44696);
    }

    @Test
    public void test4692() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4692");
        int int2 = sum.Toplama.sum(2440, 4451);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6891 + "'", int2 == 6891);
    }

    @Test
    public void test4693() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4693");
        int int2 = sum.Toplama.sum(13808, 4114);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17922 + "'", int2 == 17922);
    }

    @Test
    public void test4694() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4694");
        int int2 = sum.Toplama.sum(3061, 31001);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34062 + "'", int2 == 34062);
    }

    @Test
    public void test4695() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4695");
        int int2 = sum.Toplama.sum(12337, 74481);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 86818 + "'", int2 == 86818);
    }

    @Test
    public void test4696() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4696");
        int int2 = sum.Toplama.sum(19785, 72812);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 92597 + "'", int2 == 92597);
    }

    @Test
    public void test4697() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4697");
        int int2 = sum.Toplama.sum(10694, 6561);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17255 + "'", int2 == 17255);
    }

    @Test
    public void test4698() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4698");
        int int2 = sum.Toplama.sum(2065, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2065 + "'", int2 == 2065);
    }

    @Test
    public void test4699() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4699");
        int int2 = sum.Toplama.sum(270, 7483);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7753 + "'", int2 == 7753);
    }

    @Test
    public void test4700() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4700");
        int int2 = sum.Toplama.sum(29485, 11065);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40550 + "'", int2 == 40550);
    }

    @Test
    public void test4701() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4701");
        int int2 = sum.Toplama.sum(10195, 21961);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32156 + "'", int2 == 32156);
    }

    @Test
    public void test4702() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4702");
        int int2 = sum.Toplama.sum(14437, 2572);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17009 + "'", int2 == 17009);
    }

    @Test
    public void test4703() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4703");
        int int2 = sum.Toplama.sum(0, 78531);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78531 + "'", int2 == 78531);
    }

    @Test
    public void test4704() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4704");
        int int2 = sum.Toplama.sum(4682, 36483);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41165 + "'", int2 == 41165);
    }

    @Test
    public void test4705() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4705");
        int int2 = sum.Toplama.sum(13389, 11072);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24461 + "'", int2 == 24461);
    }

    @Test
    public void test4706() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4706");
        int int2 = sum.Toplama.sum(5853, 1002);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6855 + "'", int2 == 6855);
    }

    @Test
    public void test4707() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4707");
        int int2 = sum.Toplama.sum(27261, 270);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27531 + "'", int2 == 27531);
    }

    @Test
    public void test4708() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4708");
        int int2 = sum.Toplama.sum(1624, 19639);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21263 + "'", int2 == 21263);
    }

    @Test
    public void test4709() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4709");
        int int2 = sum.Toplama.sum(4169, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4266 + "'", int2 == 4266);
    }

    @Test
    public void test4710() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4710");
        int int2 = sum.Toplama.sum(30709, 18740);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49449 + "'", int2 == 49449);
    }

    @Test
    public void test4711() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4711");
        int int2 = sum.Toplama.sum(23652, 47839);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 71491 + "'", int2 == 71491);
    }

    @Test
    public void test4712() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4712");
        int int2 = sum.Toplama.sum(68749, 6485);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 75234 + "'", int2 == 75234);
    }

    @Test
    public void test4713() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4713");
        int int2 = sum.Toplama.sum(50244, 9868);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60112 + "'", int2 == 60112);
    }

    @Test
    public void test4714() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4714");
        int int2 = sum.Toplama.sum(43082, 16645);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59727 + "'", int2 == 59727);
    }

    @Test
    public void test4715() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4715");
        int int2 = sum.Toplama.sum(3130, 2126);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5256 + "'", int2 == 5256);
    }

    @Test
    public void test4716() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4716");
        int int2 = sum.Toplama.sum(19753, 13385);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33138 + "'", int2 == 33138);
    }

    @Test
    public void test4717() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4717");
        int int2 = sum.Toplama.sum(24301, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24301 + "'", int2 == 24301);
    }

    @Test
    public void test4718() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4718");
        int int2 = sum.Toplama.sum(3453, 6454);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9907 + "'", int2 == 9907);
    }

    @Test
    public void test4719() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4719");
        int int2 = sum.Toplama.sum(7675, 6451);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14126 + "'", int2 == 14126);
    }

    @Test
    public void test4720() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4720");
        int int2 = sum.Toplama.sum(4855, 2013);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6868 + "'", int2 == 6868);
    }

    @Test
    public void test4721() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4721");
        int int2 = sum.Toplama.sum(9868, 7368);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17236 + "'", int2 == 17236);
    }

    @Test
    public void test4722() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4722");
        int int2 = sum.Toplama.sum(7860, 1747);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9607 + "'", int2 == 9607);
    }

    @Test
    public void test4723() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4723");
        int int2 = sum.Toplama.sum(13385, 19026);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32411 + "'", int2 == 32411);
    }

    @Test
    public void test4724() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4724");
        int int2 = sum.Toplama.sum(40519, 46754);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 87273 + "'", int2 == 87273);
    }

    @Test
    public void test4725() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4725");
        int int2 = sum.Toplama.sum(6133, 8408);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14541 + "'", int2 == 14541);
    }

    @Test
    public void test4726() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4726");
        int int2 = sum.Toplama.sum(15575, 2609);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18184 + "'", int2 == 18184);
    }

    @Test
    public void test4727() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4727");
        int int2 = sum.Toplama.sum(1317, 2862);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4179 + "'", int2 == 4179);
    }

    @Test
    public void test4728() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4728");
        int int2 = sum.Toplama.sum(33146, 44633);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 77779 + "'", int2 == 77779);
    }

    @Test
    public void test4729() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4729");
        int int2 = sum.Toplama.sum(6643, 8054);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14697 + "'", int2 == 14697);
    }

    @Test
    public void test4730() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4730");
        int int2 = sum.Toplama.sum(17244, 4313);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21557 + "'", int2 == 21557);
    }

    @Test
    public void test4731() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4731");
        int int2 = sum.Toplama.sum(31643, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31644 + "'", int2 == 31644);
    }

    @Test
    public void test4732() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4732");
        int int2 = sum.Toplama.sum(0, 25825);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25825 + "'", int2 == 25825);
    }

    @Test
    public void test4733() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4733");
        int int2 = sum.Toplama.sum(909, 8120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9029 + "'", int2 == 9029);
    }

    @Test
    public void test4734() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4734");
        int int2 = sum.Toplama.sum(56747, 15614);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72361 + "'", int2 == 72361);
    }

    @Test
    public void test4735() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4735");
        int int2 = sum.Toplama.sum(20583, 6714);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27297 + "'", int2 == 27297);
    }

    @Test
    public void test4736() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4736");
        int int2 = sum.Toplama.sum(9136, 27851);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36987 + "'", int2 == 36987);
    }

    @Test
    public void test4737() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4737");
        int int2 = sum.Toplama.sum(432, 10079);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10511 + "'", int2 == 10511);
    }

    @Test
    public void test4738() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4738");
        int int2 = sum.Toplama.sum(0, 22543);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22543 + "'", int2 == 22543);
    }

    @Test
    public void test4739() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4739");
        int int2 = sum.Toplama.sum(31053, 21901);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52954 + "'", int2 == 52954);
    }

    @Test
    public void test4740() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4740");
        int int2 = sum.Toplama.sum(2913, 7268);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10181 + "'", int2 == 10181);
    }

    @Test
    public void test4741() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4741");
        int int2 = sum.Toplama.sum(32839, 630);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33469 + "'", int2 == 33469);
    }

    @Test
    public void test4742() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4742");
        int int2 = sum.Toplama.sum(3784, 12427);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16211 + "'", int2 == 16211);
    }

    @Test
    public void test4743() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4743");
        int int2 = sum.Toplama.sum(46171, 432);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46603 + "'", int2 == 46603);
    }

    @Test
    public void test4744() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4744");
        int int2 = sum.Toplama.sum(6666, 25737);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32403 + "'", int2 == 32403);
    }

    @Test
    public void test4745() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4745");
        int int2 = sum.Toplama.sum(27652, 30536);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58188 + "'", int2 == 58188);
    }

    @Test
    public void test4746() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4746");
        int int2 = sum.Toplama.sum(9670, 70279);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 79949 + "'", int2 == 79949);
    }

    @Test
    public void test4747() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4747");
        int int2 = sum.Toplama.sum(315, 2775);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3090 + "'", int2 == 3090);
    }

    @Test
    public void test4748() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4748");
        int int2 = sum.Toplama.sum(10000, 35990);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45990 + "'", int2 == 45990);
    }

    @Test
    public void test4749() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4749");
        int int2 = sum.Toplama.sum(9024, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9024 + "'", int2 == 9024);
    }

    @Test
    public void test4750() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4750");
        int int2 = sum.Toplama.sum(0, 680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 680 + "'", int2 == 680);
    }

    @Test
    public void test4751() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4751");
        int int2 = sum.Toplama.sum(4377, 7024);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11401 + "'", int2 == 11401);
    }

    @Test
    public void test4752() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4752");
        int int2 = sum.Toplama.sum(17846, 19036);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36882 + "'", int2 == 36882);
    }

    @Test
    public void test4753() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4753");
        int int2 = sum.Toplama.sum(5558, 60464);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 66022 + "'", int2 == 66022);
    }

    @Test
    public void test4754() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4754");
        int int2 = sum.Toplama.sum(7615, 51);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7666 + "'", int2 == 7666);
    }

    @Test
    public void test4755() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4755");
        int int2 = sum.Toplama.sum(20775, 2635);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23410 + "'", int2 == 23410);
    }

    @Test
    public void test4756() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4756");
        int int2 = sum.Toplama.sum(16443, 4677);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21120 + "'", int2 == 21120);
    }

    @Test
    public void test4757() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4757");
        int int2 = sum.Toplama.sum(9689, 3959);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13648 + "'", int2 == 13648);
    }

    @Test
    public void test4758() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4758");
        int int2 = sum.Toplama.sum(25268, 16844);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42112 + "'", int2 == 42112);
    }

    @Test
    public void test4759() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4759");
        int int2 = sum.Toplama.sum(42676, 42476);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 85152 + "'", int2 == 85152);
    }

    @Test
    public void test4760() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4760");
        int int2 = sum.Toplama.sum(13804, 1378);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15182 + "'", int2 == 15182);
    }

    @Test
    public void test4761() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4761");
        int int2 = sum.Toplama.sum(110420, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 110420 + "'", int2 == 110420);
    }

    @Test
    public void test4762() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4762");
        int int2 = sum.Toplama.sum(650, 2741);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3391 + "'", int2 == 3391);
    }

    @Test
    public void test4763() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4763");
        int int2 = sum.Toplama.sum(97, 37435);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37532 + "'", int2 == 37532);
    }

    @Test
    public void test4764() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4764");
        int int2 = sum.Toplama.sum(7510, 15117);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22627 + "'", int2 == 22627);
    }

    @Test
    public void test4765() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4765");
        int int2 = sum.Toplama.sum(870, 689);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1559 + "'", int2 == 1559);
    }

    @Test
    public void test4766() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4766");
        int int2 = sum.Toplama.sum(2292, 2533);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4825 + "'", int2 == 4825);
    }

    @Test
    public void test4767() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4767");
        int int2 = sum.Toplama.sum(7290, 1518);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8808 + "'", int2 == 8808);
    }

    @Test
    public void test4768() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4768");
        int int2 = sum.Toplama.sum(19309, 43591);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62900 + "'", int2 == 62900);
    }

    @Test
    public void test4769() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4769");
        int int2 = sum.Toplama.sum(8515, 13736);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22251 + "'", int2 == 22251);
    }

    @Test
    public void test4770() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4770");
        int int2 = sum.Toplama.sum(1411, 2572);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3983 + "'", int2 == 3983);
    }

    @Test
    public void test4771() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4771");
        int int2 = sum.Toplama.sum(37734, 5774);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43508 + "'", int2 == 43508);
    }

    @Test
    public void test4772() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4772");
        int int2 = sum.Toplama.sum(6739, 6335);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13074 + "'", int2 == 13074);
    }

    @Test
    public void test4773() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4773");
        int int2 = sum.Toplama.sum(10298, 14377);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24675 + "'", int2 == 24675);
    }

    @Test
    public void test4774() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4774");
        int int2 = sum.Toplama.sum(19499, 35320);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54819 + "'", int2 == 54819);
    }

    @Test
    public void test4775() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4775");
        int int2 = sum.Toplama.sum(8084, 34900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42984 + "'", int2 == 42984);
    }

    @Test
    public void test4776() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4776");
        int int2 = sum.Toplama.sum(835, 1387);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2222 + "'", int2 == 2222);
    }

    @Test
    public void test4777() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4777");
        int int2 = sum.Toplama.sum((int) ' ', 10073);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10105 + "'", int2 == 10105);
    }

    @Test
    public void test4778() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4778");
        int int2 = sum.Toplama.sum(13198, 17827);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31025 + "'", int2 == 31025);
    }

    @Test
    public void test4779() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4779");
        int int2 = sum.Toplama.sum(2134, 4283);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6417 + "'", int2 == 6417);
    }

    @Test
    public void test4780() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4780");
        int int2 = sum.Toplama.sum(23104, 11022);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34126 + "'", int2 == 34126);
    }

    @Test
    public void test4781() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4781");
        int int2 = sum.Toplama.sum(5997, 554);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6551 + "'", int2 == 6551);
    }

    @Test
    public void test4782() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4782");
        int int2 = sum.Toplama.sum(17853, 22759);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40612 + "'", int2 == 40612);
    }

    @Test
    public void test4783() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4783");
        int int2 = sum.Toplama.sum(6454, 8424);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14878 + "'", int2 == 14878);
    }

    @Test
    public void test4784() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4784");
        int int2 = sum.Toplama.sum(474, 1278);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1752 + "'", int2 == 1752);
    }

    @Test
    public void test4785() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4785");
        int int2 = sum.Toplama.sum(1468, 5720);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7188 + "'", int2 == 7188);
    }

    @Test
    public void test4786() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4786");
        int int2 = sum.Toplama.sum(149, 10897);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11046 + "'", int2 == 11046);
    }

    @Test
    public void test4787() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4787");
        int int2 = sum.Toplama.sum(910, 7527);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8437 + "'", int2 == 8437);
    }

    @Test
    public void test4788() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4788");
        int int2 = sum.Toplama.sum(2635, 3983);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6618 + "'", int2 == 6618);
    }

    @Test
    public void test4789() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4789");
        int int2 = sum.Toplama.sum(251, 1606);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1857 + "'", int2 == 1857);
    }

    @Test
    public void test4790() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4790");
        int int2 = sum.Toplama.sum(19053, 34655);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53708 + "'", int2 == 53708);
    }

    @Test
    public void test4791() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4791");
        int int2 = sum.Toplama.sum(62033, 28232);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90265 + "'", int2 == 90265);
    }

    @Test
    public void test4792() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4792");
        int int2 = sum.Toplama.sum(2030, 8089);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10119 + "'", int2 == 10119);
    }

    @Test
    public void test4793() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4793");
        int int2 = sum.Toplama.sum(12475, 1398);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13873 + "'", int2 == 13873);
    }

    @Test
    public void test4794() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4794");
        int int2 = sum.Toplama.sum(25086, 31643);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56729 + "'", int2 == 56729);
    }

    @Test
    public void test4795() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4795");
        int int2 = sum.Toplama.sum(5917, 37191);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43108 + "'", int2 == 43108);
    }

    @Test
    public void test4796() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4796");
        int int2 = sum.Toplama.sum(14002, 67518);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 81520 + "'", int2 == 81520);
    }

    @Test
    public void test4797() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4797");
        int int2 = sum.Toplama.sum(5249, 1012);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6261 + "'", int2 == 6261);
    }

    @Test
    public void test4798() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4798");
        int int2 = sum.Toplama.sum(4470, 17152);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21622 + "'", int2 == 21622);
    }

    @Test
    public void test4799() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4799");
        int int2 = sum.Toplama.sum(21082, 4307);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25389 + "'", int2 == 25389);
    }

    @Test
    public void test4800() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4800");
        int int2 = sum.Toplama.sum(0, 8831);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8831 + "'", int2 == 8831);
    }

    @Test
    public void test4801() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4801");
        int int2 = sum.Toplama.sum(14353, 7318);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21671 + "'", int2 == 21671);
    }

    @Test
    public void test4802() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4802");
        int int2 = sum.Toplama.sum(3038, 10104);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13142 + "'", int2 == 13142);
    }

    @Test
    public void test4803() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4803");
        int int2 = sum.Toplama.sum(13546, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13643 + "'", int2 == 13643);
    }

    @Test
    public void test4804() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4804");
        int int2 = sum.Toplama.sum((int) (short) 0, 909);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 909 + "'", int2 == 909);
    }

    @Test
    public void test4805() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4805");
        int int2 = sum.Toplama.sum(14416, 48790);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63206 + "'", int2 == 63206);
    }

    @Test
    public void test4806() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4806");
        int int2 = sum.Toplama.sum(1301, 9191);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10492 + "'", int2 == 10492);
    }

    @Test
    public void test4807() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4807");
        int int2 = sum.Toplama.sum(2218, 53607);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55825 + "'", int2 == 55825);
    }

    @Test
    public void test4808() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4808");
        int int2 = sum.Toplama.sum(1579, 7200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8779 + "'", int2 == 8779);
    }

    @Test
    public void test4809() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4809");
        int int2 = sum.Toplama.sum(1460, 28642);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30102 + "'", int2 == 30102);
    }

    @Test
    public void test4810() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4810");
        int int2 = sum.Toplama.sum(520, 3850);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4370 + "'", int2 == 4370);
    }

    @Test
    public void test4811() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4811");
        int int2 = sum.Toplama.sum(15458, 14135);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29593 + "'", int2 == 29593);
    }

    @Test
    public void test4812() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4812");
        int int2 = sum.Toplama.sum(2537, 6556);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9093 + "'", int2 == 9093);
    }

    @Test
    public void test4813() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4813");
        int int2 = sum.Toplama.sum(21018, 20776);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41794 + "'", int2 == 41794);
    }

    @Test
    public void test4814() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4814");
        int int2 = sum.Toplama.sum(4677, 24168);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28845 + "'", int2 == 28845);
    }

    @Test
    public void test4815() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4815");
        int int2 = sum.Toplama.sum(2240, 31249);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33489 + "'", int2 == 33489);
    }

    @Test
    public void test4816() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4816");
        int int2 = sum.Toplama.sum(20655, 32156);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52811 + "'", int2 == 52811);
    }

    @Test
    public void test4817() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4817");
        int int2 = sum.Toplama.sum(56729, 51494);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 108223 + "'", int2 == 108223);
    }

    @Test
    public void test4818() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4818");
        int int2 = sum.Toplama.sum(5939, 4132);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10071 + "'", int2 == 10071);
    }

    @Test
    public void test4819() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4819");
        int int2 = sum.Toplama.sum(2990, 37850);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40840 + "'", int2 == 40840);
    }

    @Test
    public void test4820() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4820");
        int int2 = sum.Toplama.sum(995, 46171);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47166 + "'", int2 == 47166);
    }

    @Test
    public void test4821() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4821");
        int int2 = sum.Toplama.sum(29032, 34289);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63321 + "'", int2 == 63321);
    }

    @Test
    public void test4822() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4822");
        int int2 = sum.Toplama.sum(10565, 23658);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34223 + "'", int2 == 34223);
    }

    @Test
    public void test4823() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4823");
        int int2 = sum.Toplama.sum(4214, 43380);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47594 + "'", int2 == 47594);
    }

    @Test
    public void test4824() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4824");
        int int2 = sum.Toplama.sum(33911, 6041);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39952 + "'", int2 == 39952);
    }

    @Test
    public void test4825() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4825");
        int int2 = sum.Toplama.sum(2527, 11715);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14242 + "'", int2 == 14242);
    }

    @Test
    public void test4826() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4826");
        int int2 = sum.Toplama.sum(7967, 6874);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14841 + "'", int2 == 14841);
    }

    @Test
    public void test4827() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4827");
        int int2 = sum.Toplama.sum(38743, 3814);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42557 + "'", int2 == 42557);
    }

    @Test
    public void test4828() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4828");
        int int2 = sum.Toplama.sum(21261, 18435);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39696 + "'", int2 == 39696);
    }

    @Test
    public void test4829() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4829");
        int int2 = sum.Toplama.sum(3283, 2502);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5785 + "'", int2 == 5785);
    }

    @Test
    public void test4830() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4830");
        int int2 = sum.Toplama.sum(31396, 2329);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33725 + "'", int2 == 33725);
    }

    @Test
    public void test4831() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4831");
        int int2 = sum.Toplama.sum(24485, 19442);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43927 + "'", int2 == 43927);
    }

    @Test
    public void test4832() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4832");
        int int2 = sum.Toplama.sum(23370, 5032);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28402 + "'", int2 == 28402);
    }

    @Test
    public void test4833() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4833");
        int int2 = sum.Toplama.sum(44935, 889);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45824 + "'", int2 == 45824);
    }

    @Test
    public void test4834() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4834");
        int int2 = sum.Toplama.sum(2882, 422);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3304 + "'", int2 == 3304);
    }

    @Test
    public void test4835() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4835");
        int int2 = sum.Toplama.sum(15704, 26159);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41863 + "'", int2 == 41863);
    }

    @Test
    public void test4836() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4836");
        int int2 = sum.Toplama.sum(17650, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17650 + "'", int2 == 17650);
    }

    @Test
    public void test4837() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4837");
        int int2 = sum.Toplama.sum(12834, 12432);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25266 + "'", int2 == 25266);
    }

    @Test
    public void test4838() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4838");
        int int2 = sum.Toplama.sum(181, 37869);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38050 + "'", int2 == 38050);
    }

    @Test
    public void test4839() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4839");
        int int2 = sum.Toplama.sum(4080, 3247);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7327 + "'", int2 == 7327);
    }

    @Test
    public void test4840() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4840");
        int int2 = sum.Toplama.sum(1622, 23715);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25337 + "'", int2 == 25337);
    }

    @Test
    public void test4841() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4841");
        int int2 = sum.Toplama.sum(5669, 63321);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68990 + "'", int2 == 68990);
    }

    @Test
    public void test4842() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4842");
        int int2 = sum.Toplama.sum(12483, 23855);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36338 + "'", int2 == 36338);
    }

    @Test
    public void test4843() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4843");
        int int2 = sum.Toplama.sum(39330, 3663);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42993 + "'", int2 == 42993);
    }

    @Test
    public void test4844() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4844");
        int int2 = sum.Toplama.sum(22301, 25389);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47690 + "'", int2 == 47690);
    }

    @Test
    public void test4845() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4845");
        int int2 = sum.Toplama.sum(2810, 4472);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7282 + "'", int2 == 7282);
    }

    @Test
    public void test4846() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4846");
        int int2 = sum.Toplama.sum(1249, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1249 + "'", int2 == 1249);
    }

    @Test
    public void test4847() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4847");
        int int2 = sum.Toplama.sum(20664, 56928);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 77592 + "'", int2 == 77592);
    }

    @Test
    public void test4848() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4848");
        int int2 = sum.Toplama.sum(2788, 29768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32556 + "'", int2 == 32556);
    }

    @Test
    public void test4849() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4849");
        int int2 = sum.Toplama.sum(12482, 7903);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20385 + "'", int2 == 20385);
    }

    @Test
    public void test4850() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4850");
        int int2 = sum.Toplama.sum(33651, 114693);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 148344 + "'", int2 == 148344);
    }

    @Test
    public void test4851() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4851");
        int int2 = sum.Toplama.sum(2958, 3900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6858 + "'", int2 == 6858);
    }

    @Test
    public void test4852() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4852");
        int int2 = sum.Toplama.sum(20805, 2249);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23054 + "'", int2 == 23054);
    }

    @Test
    public void test4853() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4853");
        int int2 = sum.Toplama.sum(300, 13480);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13780 + "'", int2 == 13780);
    }

    @Test
    public void test4854() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4854");
        int int2 = sum.Toplama.sum(30484, 15598);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46082 + "'", int2 == 46082);
    }

    @Test
    public void test4855() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4855");
        int int2 = sum.Toplama.sum(28845, 922);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29767 + "'", int2 == 29767);
    }

    @Test
    public void test4856() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4856");
        int int2 = sum.Toplama.sum(31462, 3933);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35395 + "'", int2 == 35395);
    }

    @Test
    public void test4857() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4857");
        int int2 = sum.Toplama.sum(0, 17306);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17306 + "'", int2 == 17306);
    }

    @Test
    public void test4858() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4858");
        int int2 = sum.Toplama.sum(475, 36806);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37281 + "'", int2 == 37281);
    }

    @Test
    public void test4859() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4859");
        int int2 = sum.Toplama.sum(5034, 25913);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30947 + "'", int2 == 30947);
    }

    @Test
    public void test4860() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4860");
        int int2 = sum.Toplama.sum(3040, 33320);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36360 + "'", int2 == 36360);
    }

    @Test
    public void test4861() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4861");
        int int2 = sum.Toplama.sum(10268, 27918);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38186 + "'", int2 == 38186);
    }

    @Test
    public void test4862() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4862");
        int int2 = sum.Toplama.sum(527, 13785);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14312 + "'", int2 == 14312);
    }

    @Test
    public void test4863() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4863");
        int int2 = sum.Toplama.sum(33513, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33513 + "'", int2 == 33513);
    }

    @Test
    public void test4864() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4864");
        int int2 = sum.Toplama.sum(11071, 216);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11287 + "'", int2 == 11287);
    }

    @Test
    public void test4865() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4865");
        int int2 = sum.Toplama.sum(5284, 7731);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13015 + "'", int2 == 13015);
    }

    @Test
    public void test4866() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4866");
        int int2 = sum.Toplama.sum(22413, 15900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38313 + "'", int2 == 38313);
    }

    @Test
    public void test4867() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4867");
        int int2 = sum.Toplama.sum(20463, 15812);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36275 + "'", int2 == 36275);
    }

    @Test
    public void test4868() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4868");
        int int2 = sum.Toplama.sum(10762, 5368);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16130 + "'", int2 == 16130);
    }

    @Test
    public void test4869() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4869");
        int int2 = sum.Toplama.sum(11480, 5125);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16605 + "'", int2 == 16605);
    }

    @Test
    public void test4870() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4870");
        int int2 = sum.Toplama.sum(46142, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46142 + "'", int2 == 46142);
    }

    @Test
    public void test4871() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4871");
        int int2 = sum.Toplama.sum(582, 2645);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3227 + "'", int2 == 3227);
    }

    @Test
    public void test4872() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4872");
        int int2 = sum.Toplama.sum(30865, 5703);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36568 + "'", int2 == 36568);
    }

    @Test
    public void test4873() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4873");
        int int2 = sum.Toplama.sum(46272, 3414);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49686 + "'", int2 == 49686);
    }

    @Test
    public void test4874() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4874");
        int int2 = sum.Toplama.sum(16911, 34223);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51134 + "'", int2 == 51134);
    }

    @Test
    public void test4875() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4875");
        int int2 = sum.Toplama.sum(9010, 22301);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31311 + "'", int2 == 31311);
    }

    @Test
    public void test4876() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4876");
        int int2 = sum.Toplama.sum(8845, 6440);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15285 + "'", int2 == 15285);
    }

    @Test
    public void test4877() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4877");
        int int2 = sum.Toplama.sum(97, 25388);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25485 + "'", int2 == 25485);
    }

    @Test
    public void test4878() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4878");
        int int2 = sum.Toplama.sum(88216, 1357);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 89573 + "'", int2 == 89573);
    }

    @Test
    public void test4879() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4879");
        int int2 = sum.Toplama.sum(12544, 1857);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14401 + "'", int2 == 14401);
    }

    @Test
    public void test4880() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4880");
        int int2 = sum.Toplama.sum(20529, 32370);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52899 + "'", int2 == 52899);
    }

    @Test
    public void test4881() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4881");
        int int2 = sum.Toplama.sum(16821, 2882);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19703 + "'", int2 == 19703);
    }

    @Test
    public void test4882() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4882");
        int int2 = sum.Toplama.sum(7997, 3391);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11388 + "'", int2 == 11388);
    }

    @Test
    public void test4883() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4883");
        int int2 = sum.Toplama.sum(90265, 13790);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 104055 + "'", int2 == 104055);
    }

    @Test
    public void test4884() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4884");
        int int2 = sum.Toplama.sum(4563, 14929);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19492 + "'", int2 == 19492);
    }

    @Test
    public void test4885() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4885");
        int int2 = sum.Toplama.sum(17273, 35320);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52593 + "'", int2 == 52593);
    }

    @Test
    public void test4886() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4886");
        int int2 = sum.Toplama.sum(11713, 72361);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 84074 + "'", int2 == 84074);
    }

    @Test
    public void test4887() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4887");
        int int2 = sum.Toplama.sum(0, 17275);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17275 + "'", int2 == 17275);
    }

    @Test
    public void test4888() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4888");
        int int2 = sum.Toplama.sum(2352, 15279);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17631 + "'", int2 == 17631);
    }

    @Test
    public void test4889() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4889");
        int int2 = sum.Toplama.sum(1950, 5969);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7919 + "'", int2 == 7919);
    }

    @Test
    public void test4890() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4890");
        int int2 = sum.Toplama.sum(5008, 18435);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23443 + "'", int2 == 23443);
    }

    @Test
    public void test4891() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4891");
        int int2 = sum.Toplama.sum(61884, 1631);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63515 + "'", int2 == 63515);
    }

    @Test
    public void test4892() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4892");
        int int2 = sum.Toplama.sum(53287, 5840);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59127 + "'", int2 == 59127);
    }

    @Test
    public void test4893() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4893");
        int int2 = sum.Toplama.sum(13176, 16325);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29501 + "'", int2 == 29501);
    }

    @Test
    public void test4894() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4894");
        int int2 = sum.Toplama.sum(2467, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2467 + "'", int2 == 2467);
    }

    @Test
    public void test4895() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4895");
        int int2 = sum.Toplama.sum(8148, 980);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9128 + "'", int2 == 9128);
    }

    @Test
    public void test4896() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4896");
        int int2 = sum.Toplama.sum(7484, 29134);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36618 + "'", int2 == 36618);
    }

    @Test
    public void test4897() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4897");
        int int2 = sum.Toplama.sum(63201, 17253);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80454 + "'", int2 == 80454);
    }

    @Test
    public void test4898() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4898");
        int int2 = sum.Toplama.sum(22310, 20005);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42315 + "'", int2 == 42315);
    }

    @Test
    public void test4899() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4899");
        int int2 = sum.Toplama.sum(49949, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49950 + "'", int2 == 49950);
    }

    @Test
    public void test4900() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4900");
        int int2 = sum.Toplama.sum(7585, 45778);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53363 + "'", int2 == 53363);
    }

    @Test
    public void test4901() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4901");
        int int2 = sum.Toplama.sum(10119, 21783);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31902 + "'", int2 == 31902);
    }

    @Test
    public void test4902() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4902");
        int int2 = sum.Toplama.sum(35283, 10701);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45984 + "'", int2 == 45984);
    }

    @Test
    public void test4903() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4903");
        int int2 = sum.Toplama.sum(25266, 13811);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39077 + "'", int2 == 39077);
    }

    @Test
    public void test4904() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4904");
        int int2 = sum.Toplama.sum(9978, 39611);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49589 + "'", int2 == 49589);
    }

    @Test
    public void test4905() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4905");
        int int2 = sum.Toplama.sum(0, 34158);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34158 + "'", int2 == 34158);
    }

    @Test
    public void test4906() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4906");
        int int2 = sum.Toplama.sum(15115, 10063);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25178 + "'", int2 == 25178);
    }

    @Test
    public void test4907() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4907");
        int int2 = sum.Toplama.sum(8912, 19270);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28182 + "'", int2 == 28182);
    }

    @Test
    public void test4908() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4908");
        int int2 = sum.Toplama.sum(14723, 25086);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39809 + "'", int2 == 39809);
    }

    @Test
    public void test4909() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4909");
        int int2 = sum.Toplama.sum(12166, 21736);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33902 + "'", int2 == 33902);
    }

    @Test
    public void test4910() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4910");
        int int2 = sum.Toplama.sum(1276, 26059);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27335 + "'", int2 == 27335);
    }

    @Test
    public void test4911() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4911");
        int int2 = sum.Toplama.sum(5670, 14779);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20449 + "'", int2 == 20449);
    }

    @Test
    public void test4912() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4912");
        int int2 = sum.Toplama.sum(776, 6142);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6918 + "'", int2 == 6918);
    }

    @Test
    public void test4913() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4913");
        int int2 = sum.Toplama.sum(12544, 38505);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51049 + "'", int2 == 51049);
    }

    @Test
    public void test4914() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4914");
        int int2 = sum.Toplama.sum(13147, 11102);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24249 + "'", int2 == 24249);
    }

    @Test
    public void test4915() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4915");
        int int2 = sum.Toplama.sum(1002, 5139);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6141 + "'", int2 == 6141);
    }

    @Test
    public void test4916() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4916");
        int int2 = sum.Toplama.sum(9916, 31729);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41645 + "'", int2 == 41645);
    }

    @Test
    public void test4917() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4917");
        int int2 = sum.Toplama.sum(917, 38606);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39523 + "'", int2 == 39523);
    }

    @Test
    public void test4918() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4918");
        int int2 = sum.Toplama.sum(0, 10774);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10774 + "'", int2 == 10774);
    }

    @Test
    public void test4919() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4919");
        int int2 = sum.Toplama.sum(36775, 33911);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70686 + "'", int2 == 70686);
    }

    @Test
    public void test4920() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4920");
        int int2 = sum.Toplama.sum(6113, 18115);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24228 + "'", int2 == 24228);
    }

    @Test
    public void test4921() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4921");
        int int2 = sum.Toplama.sum(14474, 8422);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22896 + "'", int2 == 22896);
    }

    @Test
    public void test4922() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4922");
        int int2 = sum.Toplama.sum(18926, 80454);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99380 + "'", int2 == 99380);
    }

    @Test
    public void test4923() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4923");
        int int2 = sum.Toplama.sum(38487, 15686);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54173 + "'", int2 == 54173);
    }

    @Test
    public void test4924() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4924");
        int int2 = sum.Toplama.sum(35321, 51587);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 86908 + "'", int2 == 86908);
    }

    @Test
    public void test4925() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4925");
        int int2 = sum.Toplama.sum(13679, 54979);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68658 + "'", int2 == 68658);
    }

    @Test
    public void test4926() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4926");
        int int2 = sum.Toplama.sum(1570, 65151);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 66721 + "'", int2 == 66721);
    }

    @Test
    public void test4927() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4927");
        int int2 = sum.Toplama.sum(2602, 31666);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34268 + "'", int2 == 34268);
    }

    @Test
    public void test4928() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4928");
        int int2 = sum.Toplama.sum(16123, 17825);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33948 + "'", int2 == 33948);
    }

    @Test
    public void test4929() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4929");
        int int2 = sum.Toplama.sum(10100, 1716);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11816 + "'", int2 == 11816);
    }

    @Test
    public void test4930() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4930");
        int int2 = sum.Toplama.sum(25631, 2973);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28604 + "'", int2 == 28604);
    }

    @Test
    public void test4931() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4931");
        int int2 = sum.Toplama.sum(23340, 16121);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39461 + "'", int2 == 39461);
    }

    @Test
    public void test4932() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4932");
        int int2 = sum.Toplama.sum(41863, 15516);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57379 + "'", int2 == 57379);
    }

    @Test
    public void test4933() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4933");
        int int2 = sum.Toplama.sum(70279, 7285);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 77564 + "'", int2 == 77564);
    }

    @Test
    public void test4934() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4934");
        int int2 = sum.Toplama.sum(2045, 12358);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14403 + "'", int2 == 14403);
    }

    @Test
    public void test4935() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4935");
        int int2 = sum.Toplama.sum(10308, 26121);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36429 + "'", int2 == 36429);
    }

    @Test
    public void test4936() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4936");
        int int2 = sum.Toplama.sum(2292, 59370);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61662 + "'", int2 == 61662);
    }

    @Test
    public void test4937() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4937");
        int int2 = sum.Toplama.sum(4882, 39344);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44226 + "'", int2 == 44226);
    }

    @Test
    public void test4938() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4938");
        int int2 = sum.Toplama.sum(5967, 5611);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11578 + "'", int2 == 11578);
    }

    @Test
    public void test4939() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4939");
        int int2 = sum.Toplama.sum(8556, 2835);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11391 + "'", int2 == 11391);
    }

    @Test
    public void test4940() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4940");
        int int2 = sum.Toplama.sum(210, 37532);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37742 + "'", int2 == 37742);
    }

    @Test
    public void test4941() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4941");
        int int2 = sum.Toplama.sum(2070, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2070 + "'", int2 == 2070);
    }

    @Test
    public void test4942() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4942");
        int int2 = sum.Toplama.sum(27774, 4030);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31804 + "'", int2 == 31804);
    }

    @Test
    public void test4943() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4943");
        int int2 = sum.Toplama.sum(11069, 23219);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34288 + "'", int2 == 34288);
    }

    @Test
    public void test4944() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4944");
        int int2 = sum.Toplama.sum(21261, 1797);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23058 + "'", int2 == 23058);
    }

    @Test
    public void test4945() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4945");
        int int2 = sum.Toplama.sum(19121, 2498);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21619 + "'", int2 == 21619);
    }

    @Test
    public void test4946() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4946");
        int int2 = sum.Toplama.sum(35270, 11684);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46954 + "'", int2 == 46954);
    }

    @Test
    public void test4947() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4947");
        int int2 = sum.Toplama.sum(18166, 50847);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69013 + "'", int2 == 69013);
    }

    @Test
    public void test4948() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4948");
        int int2 = sum.Toplama.sum(30293, 13554);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43847 + "'", int2 == 43847);
    }

    @Test
    public void test4949() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4949");
        int int2 = sum.Toplama.sum(68276, 4817);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 73093 + "'", int2 == 73093);
    }

    @Test
    public void test4950() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4950");
        int int2 = sum.Toplama.sum(422, 12004);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12426 + "'", int2 == 12426);
    }

    @Test
    public void test4951() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4951");
        int int2 = sum.Toplama.sum(720, 13367);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14087 + "'", int2 == 14087);
    }

    @Test
    public void test4952() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4952");
        int int2 = sum.Toplama.sum(5327, 60884);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 66211 + "'", int2 == 66211);
    }

    @Test
    public void test4953() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4953");
        int int2 = sum.Toplama.sum(1585, 13246);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14831 + "'", int2 == 14831);
    }

    @Test
    public void test4954() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4954");
        int int2 = sum.Toplama.sum(4094, 5111);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9205 + "'", int2 == 9205);
    }

    @Test
    public void test4955() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4955");
        int int2 = sum.Toplama.sum(3075, 2055);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5130 + "'", int2 == 5130);
    }

    @Test
    public void test4956() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4956");
        int int2 = sum.Toplama.sum(58434, 2109);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60543 + "'", int2 == 60543);
    }

    @Test
    public void test4957() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4957");
        int int2 = sum.Toplama.sum(35283, 4504);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39787 + "'", int2 == 39787);
    }

    @Test
    public void test4958() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4958");
        int int2 = sum.Toplama.sum(49174, 5800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54974 + "'", int2 == 54974);
    }

    @Test
    public void test4959() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4959");
        int int2 = sum.Toplama.sum(25152, 970);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26122 + "'", int2 == 26122);
    }

    @Test
    public void test4960() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4960");
        int int2 = sum.Toplama.sum(5946, 13654);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19600 + "'", int2 == 19600);
    }

    @Test
    public void test4961() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4961");
        int int2 = sum.Toplama.sum(8448, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8448 + "'", int2 == 8448);
    }

    @Test
    public void test4962() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4962");
        int int2 = sum.Toplama.sum(2292, 62900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 65192 + "'", int2 == 65192);
    }

    @Test
    public void test4963() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4963");
        int int2 = sum.Toplama.sum(17873, 17873);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35746 + "'", int2 == 35746);
    }

    @Test
    public void test4964() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4964");
        int int2 = sum.Toplama.sum(10332, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10332 + "'", int2 == 10332);
    }

    @Test
    public void test4965() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4965");
        int int2 = sum.Toplama.sum(10909, 18573);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29482 + "'", int2 == 29482);
    }

    @Test
    public void test4966() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4966");
        int int2 = sum.Toplama.sum(31643, 23546);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55189 + "'", int2 == 55189);
    }

    @Test
    public void test4967() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4967");
        int int2 = sum.Toplama.sum(10084, 543);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10627 + "'", int2 == 10627);
    }

    @Test
    public void test4968() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4968");
        int int2 = sum.Toplama.sum(35, 3737);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3772 + "'", int2 == 3772);
    }

    @Test
    public void test4969() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4969");
        int int2 = sum.Toplama.sum(6078, 36277);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42355 + "'", int2 == 42355);
    }

    @Test
    public void test4970() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4970");
        int int2 = sum.Toplama.sum(55848, 7669);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63517 + "'", int2 == 63517);
    }

    @Test
    public void test4971() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4971");
        int int2 = sum.Toplama.sum(11746, 34501);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46247 + "'", int2 == 46247);
    }

    @Test
    public void test4972() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4972");
        int int2 = sum.Toplama.sum(27860, 9565);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37425 + "'", int2 == 37425);
    }

    @Test
    public void test4973() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4973");
        int int2 = sum.Toplama.sum(109, 11734);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11843 + "'", int2 == 11843);
    }

    @Test
    public void test4974() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4974");
        int int2 = sum.Toplama.sum(23473, 8089);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31562 + "'", int2 == 31562);
    }

    @Test
    public void test4975() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4975");
        int int2 = sum.Toplama.sum(2804, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2804 + "'", int2 == 2804);
    }

    @Test
    public void test4976() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4976");
        int int2 = sum.Toplama.sum(15812, 23014);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38826 + "'", int2 == 38826);
    }

    @Test
    public void test4977() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4977");
        int int2 = sum.Toplama.sum(2942, 15614);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18556 + "'", int2 == 18556);
    }

    @Test
    public void test4978() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4978");
        int int2 = sum.Toplama.sum(14635, 23572);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38207 + "'", int2 == 38207);
    }

    @Test
    public void test4979() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4979");
        int int2 = sum.Toplama.sum(0, 1108);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1108 + "'", int2 == 1108);
    }

    @Test
    public void test4980() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4980");
        int int2 = sum.Toplama.sum(24533, 11702);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36235 + "'", int2 == 36235);
    }

    @Test
    public void test4981() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4981");
        int int2 = sum.Toplama.sum(31311, 4730);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36041 + "'", int2 == 36041);
    }

    @Test
    public void test4982() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4982");
        int int2 = sum.Toplama.sum(7932, 26417);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34349 + "'", int2 == 34349);
    }

    @Test
    public void test4983() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4983");
        int int2 = sum.Toplama.sum(976, 4738);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5714 + "'", int2 == 5714);
    }

    @Test
    public void test4984() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4984");
        int int2 = sum.Toplama.sum(15614, 29845);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45459 + "'", int2 == 45459);
    }

    @Test
    public void test4985() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4985");
        int int2 = sum.Toplama.sum(623, 1064);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1687 + "'", int2 == 1687);
    }

    @Test
    public void test4986() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4986");
        int int2 = sum.Toplama.sum(1438, 9006);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10444 + "'", int2 == 10444);
    }

    @Test
    public void test4987() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4987");
        int int2 = sum.Toplama.sum(20801, 42182);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62983 + "'", int2 == 62983);
    }

    @Test
    public void test4988() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4988");
        int int2 = sum.Toplama.sum(1936, 52716);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54652 + "'", int2 == 54652);
    }

    @Test
    public void test4989() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4989");
        int int2 = sum.Toplama.sum(2897, 14541);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17438 + "'", int2 == 17438);
    }

    @Test
    public void test4990() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4990");
        int int2 = sum.Toplama.sum(3410, 11381);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14791 + "'", int2 == 14791);
    }

    @Test
    public void test4991() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4991");
        int int2 = sum.Toplama.sum(1270, 6378);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7648 + "'", int2 == 7648);
    }

    @Test
    public void test4992() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4992");
        int int2 = sum.Toplama.sum(22560, 6625);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29185 + "'", int2 == 29185);
    }

    @Test
    public void test4993() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4993");
        int int2 = sum.Toplama.sum(27538, 3861);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31399 + "'", int2 == 31399);
    }

    @Test
    public void test4994() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4994");
        int int2 = sum.Toplama.sum(5919, 25261);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31180 + "'", int2 == 31180);
    }

    @Test
    public void test4995() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4995");
        int int2 = sum.Toplama.sum(3623, 22617);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26240 + "'", int2 == 26240);
    }

    @Test
    public void test4996() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4996");
        int int2 = sum.Toplama.sum(17583, 33500);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51083 + "'", int2 == 51083);
    }

    @Test
    public void test4997() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4997");
        int int2 = sum.Toplama.sum(2986, 8827);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11813 + "'", int2 == 11813);
    }

    @Test
    public void test4998() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4998");
        int int2 = sum.Toplama.sum(3918, 34400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38318 + "'", int2 == 38318);
    }

    @Test
    public void test4999() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test4999");
        int int2 = sum.Toplama.sum(11007, 6879);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17886 + "'", int2 == 17886);
    }

    @Test
    public void test5000() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test5000");
        int int2 = sum.Toplama.sum(4521, 1958);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6479 + "'", int2 == 6479);
    }
}

