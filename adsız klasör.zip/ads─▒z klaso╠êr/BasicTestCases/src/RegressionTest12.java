import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest12 {

    public static boolean debug = false;

    @Test
    public void test6001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6001");
        int int2 = sum.Toplama.sum(11109, 12994);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24103 + "'", int2 == 24103);
    }

    @Test
    public void test6002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6002");
        int int2 = sum.Toplama.sum(55630, 42355);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97985 + "'", int2 == 97985);
    }

    @Test
    public void test6003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6003");
        int int2 = sum.Toplama.sum(28871, 16222);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45093 + "'", int2 == 45093);
    }

    @Test
    public void test6004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6004");
        int int2 = sum.Toplama.sum(15182, 2844);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18026 + "'", int2 == 18026);
    }

    @Test
    public void test6005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6005");
        int int2 = sum.Toplama.sum(19442, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19442 + "'", int2 == 19442);
    }

    @Test
    public void test6006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6006");
        int int2 = sum.Toplama.sum(12857, 20505);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33362 + "'", int2 == 33362);
    }

    @Test
    public void test6007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6007");
        int int2 = sum.Toplama.sum(0, 6078);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6078 + "'", int2 == 6078);
    }

    @Test
    public void test6008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6008");
        int int2 = sum.Toplama.sum(88, 86908);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 86996 + "'", int2 == 86996);
    }

    @Test
    public void test6009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6009");
        int int2 = sum.Toplama.sum(7268, 11258);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18526 + "'", int2 == 18526);
    }

    @Test
    public void test6010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6010");
        int int2 = sum.Toplama.sum(6962, 28699);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35661 + "'", int2 == 35661);
    }

    @Test
    public void test6011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6011");
        int int2 = sum.Toplama.sum(2145, 19064);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21209 + "'", int2 == 21209);
    }

    @Test
    public void test6012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6012");
        int int2 = sum.Toplama.sum(27486, 64);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27550 + "'", int2 == 27550);
    }

    @Test
    public void test6013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6013");
        int int2 = sum.Toplama.sum(1639, 95352);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96991 + "'", int2 == 96991);
    }

    @Test
    public void test6014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6014");
        int int2 = sum.Toplama.sum(46533, 8759);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55292 + "'", int2 == 55292);
    }

    @Test
    public void test6015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6015");
        int int2 = sum.Toplama.sum(55997, 20191);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 76188 + "'", int2 == 76188);
    }

    @Test
    public void test6016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6016");
        int int2 = sum.Toplama.sum(56747, 45502);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 102249 + "'", int2 == 102249);
    }

    @Test
    public void test6017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6017");
        int int2 = sum.Toplama.sum(21258, 19121);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40379 + "'", int2 == 40379);
    }

    @Test
    public void test6018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6018");
        int int2 = sum.Toplama.sum(56188, 14477);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70665 + "'", int2 == 70665);
    }

    @Test
    public void test6019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6019");
        int int2 = sum.Toplama.sum(4561, 6282);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10843 + "'", int2 == 10843);
    }

    @Test
    public void test6020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6020");
        int int2 = sum.Toplama.sum(13088, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13088 + "'", int2 == 13088);
    }

    @Test
    public void test6021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6021");
        int int2 = sum.Toplama.sum(1481, 11931);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13412 + "'", int2 == 13412);
    }

    @Test
    public void test6022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6022");
        int int2 = sum.Toplama.sum(11654, 9733);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21387 + "'", int2 == 21387);
    }

    @Test
    public void test6023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6023");
        int int2 = sum.Toplama.sum(25635, 26147);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51782 + "'", int2 == 51782);
    }

    @Test
    public void test6024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6024");
        int int2 = sum.Toplama.sum(17490, 16878);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34368 + "'", int2 == 34368);
    }

    @Test
    public void test6025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6025");
        int int2 = sum.Toplama.sum(39688, 11712);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51400 + "'", int2 == 51400);
    }

    @Test
    public void test6026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6026");
        int int2 = sum.Toplama.sum(79949, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 79949 + "'", int2 == 79949);
    }

    @Test
    public void test6027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6027");
        int int2 = sum.Toplama.sum(47305, 2635);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49940 + "'", int2 == 49940);
    }

    @Test
    public void test6028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6028");
        int int2 = sum.Toplama.sum(23274, 29767);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53041 + "'", int2 == 53041);
    }

    @Test
    public void test6029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6029");
        int int2 = sum.Toplama.sum(53987, 1427);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55414 + "'", int2 == 55414);
    }

    @Test
    public void test6030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6030");
        int int2 = sum.Toplama.sum(9755, 104055);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 113810 + "'", int2 == 113810);
    }

    @Test
    public void test6031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6031");
        int int2 = sum.Toplama.sum(16244, 3991);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20235 + "'", int2 == 20235);
    }

    @Test
    public void test6032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6032");
        int int2 = sum.Toplama.sum(3392, 52429);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55821 + "'", int2 == 55821);
    }

    @Test
    public void test6033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6033");
        int int2 = sum.Toplama.sum(24553, 15457);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40010 + "'", int2 == 40010);
    }

    @Test
    public void test6034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6034");
        int int2 = sum.Toplama.sum(9868, 38655);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48523 + "'", int2 == 48523);
    }

    @Test
    public void test6035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6035");
        int int2 = sum.Toplama.sum(22868, 29095);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51963 + "'", int2 == 51963);
    }

    @Test
    public void test6036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6036");
        int int2 = sum.Toplama.sum(51795, 11102);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62897 + "'", int2 == 62897);
    }

    @Test
    public void test6037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6037");
        int int2 = sum.Toplama.sum(4193, 51587);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55780 + "'", int2 == 55780);
    }

    @Test
    public void test6038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6038");
        int int2 = sum.Toplama.sum(35432, 9979);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45411 + "'", int2 == 45411);
    }

    @Test
    public void test6039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6039");
        int int2 = sum.Toplama.sum(7498, 16821);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24319 + "'", int2 == 24319);
    }

    @Test
    public void test6040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6040");
        int int2 = sum.Toplama.sum(0, 10079);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10079 + "'", int2 == 10079);
    }

    @Test
    public void test6041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6041");
        int int2 = sum.Toplama.sum(45623, 13947);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59570 + "'", int2 == 59570);
    }

    @Test
    public void test6042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6042");
        int int2 = sum.Toplama.sum(24033, 24691);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48724 + "'", int2 == 48724);
    }

    @Test
    public void test6043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6043");
        int int2 = sum.Toplama.sum(1023, 25913);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26936 + "'", int2 == 26936);
    }

    @Test
    public void test6044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6044");
        int int2 = sum.Toplama.sum(27652, 9204);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36856 + "'", int2 == 36856);
    }

    @Test
    public void test6045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6045");
        int int2 = sum.Toplama.sum(17912, 880);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18792 + "'", int2 == 18792);
    }

    @Test
    public void test6046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6046");
        int int2 = sum.Toplama.sum(53730, 7582);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61312 + "'", int2 == 61312);
    }

    @Test
    public void test6047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6047");
        int int2 = sum.Toplama.sum(19010, 3949);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22959 + "'", int2 == 22959);
    }

    @Test
    public void test6048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6048");
        int int2 = sum.Toplama.sum(35776, 30432);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 66208 + "'", int2 == 66208);
    }

    @Test
    public void test6049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6049");
        int int2 = sum.Toplama.sum(8895, 8448);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17343 + "'", int2 == 17343);
    }

    @Test
    public void test6050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6050");
        int int2 = sum.Toplama.sum(59468, 3447);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62915 + "'", int2 == 62915);
    }

    @Test
    public void test6051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6051");
        int int2 = sum.Toplama.sum(21060, 9088);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30148 + "'", int2 == 30148);
    }

    @Test
    public void test6052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6052");
        int int2 = sum.Toplama.sum(19841, 543);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20384 + "'", int2 == 20384);
    }

    @Test
    public void test6053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6053");
        int int2 = sum.Toplama.sum(47762, 1877);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49639 + "'", int2 == 49639);
    }

    @Test
    public void test6054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6054");
        int int2 = sum.Toplama.sum(31129, 13079);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44208 + "'", int2 == 44208);
    }

    @Test
    public void test6055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6055");
        int int2 = sum.Toplama.sum(2661, 10070);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12731 + "'", int2 == 12731);
    }

    @Test
    public void test6056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6056");
        int int2 = sum.Toplama.sum(16655, 13297);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29952 + "'", int2 == 29952);
    }

    @Test
    public void test6057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6057");
        int int2 = sum.Toplama.sum(10323, 10505);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20828 + "'", int2 == 20828);
    }

    @Test
    public void test6058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6058");
        int int2 = sum.Toplama.sum(7495, 13149);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20644 + "'", int2 == 20644);
    }

    @Test
    public void test6059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6059");
        int int2 = sum.Toplama.sum(6343, 4149);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10492 + "'", int2 == 10492);
    }

    @Test
    public void test6060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6060");
        int int2 = sum.Toplama.sum(14557, 11155);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25712 + "'", int2 == 25712);
    }

    @Test
    public void test6061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6061");
        int int2 = sum.Toplama.sum(44316, 24675);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68991 + "'", int2 == 68991);
    }

    @Test
    public void test6062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6062");
        int int2 = sum.Toplama.sum(1881, 6768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8649 + "'", int2 == 8649);
    }

    @Test
    public void test6063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6063");
        int int2 = sum.Toplama.sum(11836, 33911);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45747 + "'", int2 == 45747);
    }

    @Test
    public void test6064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6064");
        int int2 = sum.Toplama.sum(7459, 10981);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18440 + "'", int2 == 18440);
    }

    @Test
    public void test6065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6065");
        int int2 = sum.Toplama.sum(16881, 1177);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18058 + "'", int2 == 18058);
    }

    @Test
    public void test6066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6066");
        int int2 = sum.Toplama.sum(18652, 654);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19306 + "'", int2 == 19306);
    }

    @Test
    public void test6067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6067");
        int int2 = sum.Toplama.sum(10286, 36856);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47142 + "'", int2 == 47142);
    }

    @Test
    public void test6068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6068");
        int int2 = sum.Toplama.sum(6725, 229);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6954 + "'", int2 == 6954);
    }

    @Test
    public void test6069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6069");
        int int2 = sum.Toplama.sum(19839, 58258);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78097 + "'", int2 == 78097);
    }

    @Test
    public void test6070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6070");
        int int2 = sum.Toplama.sum(29978, 1014);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30992 + "'", int2 == 30992);
    }

    @Test
    public void test6071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6071");
        int int2 = sum.Toplama.sum(55034, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55034 + "'", int2 == 55034);
    }

    @Test
    public void test6072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6072");
        int int2 = sum.Toplama.sum(85255, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 85255 + "'", int2 == 85255);
    }

    @Test
    public void test6073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6073");
        int int2 = sum.Toplama.sum(1271, 12451);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13722 + "'", int2 == 13722);
    }

    @Test
    public void test6074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6074");
        int int2 = sum.Toplama.sum(3090, 13546);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16636 + "'", int2 == 16636);
    }

    @Test
    public void test6075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6075");
        int int2 = sum.Toplama.sum(7331, 7844);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15175 + "'", int2 == 15175);
    }

    @Test
    public void test6076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6076");
        int int2 = sum.Toplama.sum(70664, 23601);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 94265 + "'", int2 == 94265);
    }

    @Test
    public void test6077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6077");
        int int2 = sum.Toplama.sum(12410, 15117);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27527 + "'", int2 == 27527);
    }

    @Test
    public void test6078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6078");
        int int2 = sum.Toplama.sum(30673, 24733);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55406 + "'", int2 == 55406);
    }

    @Test
    public void test6079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6079");
        int int2 = sum.Toplama.sum(70103, 1797);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 71900 + "'", int2 == 71900);
    }

    @Test
    public void test6080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6080");
        int int2 = sum.Toplama.sum(10201, 1685);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11886 + "'", int2 == 11886);
    }

    @Test
    public void test6081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6081");
        int int2 = sum.Toplama.sum(4379, 22560);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26939 + "'", int2 == 26939);
    }

    @Test
    public void test6082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6082");
        int int2 = sum.Toplama.sum(2318, 32281);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34599 + "'", int2 == 34599);
    }

    @Test
    public void test6083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6083");
        int int2 = sum.Toplama.sum(0, 5643);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5643 + "'", int2 == 5643);
    }

    @Test
    public void test6084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6084");
        int int2 = sum.Toplama.sum(21595, 421);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22016 + "'", int2 == 22016);
    }

    @Test
    public void test6085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6085");
        int int2 = sum.Toplama.sum(21120, 6219);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27339 + "'", int2 == 27339);
    }

    @Test
    public void test6086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6086");
        int int2 = sum.Toplama.sum(18628, 21007);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39635 + "'", int2 == 39635);
    }

    @Test
    public void test6087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6087");
        int int2 = sum.Toplama.sum(522, 16475);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16997 + "'", int2 == 16997);
    }

    @Test
    public void test6088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6088");
        int int2 = sum.Toplama.sum(38743, 511);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39254 + "'", int2 == 39254);
    }

    @Test
    public void test6089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6089");
        int int2 = sum.Toplama.sum(29978, 2145);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32123 + "'", int2 == 32123);
    }

    @Test
    public void test6090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6090");
        int int2 = sum.Toplama.sum(29999, 22613);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52612 + "'", int2 == 52612);
    }

    @Test
    public void test6091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6091");
        int int2 = sum.Toplama.sum(8001, 28984);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36985 + "'", int2 == 36985);
    }

    @Test
    public void test6092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6092");
        int int2 = sum.Toplama.sum(34062, 1954);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36016 + "'", int2 == 36016);
    }

    @Test
    public void test6093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6093");
        int int2 = sum.Toplama.sum(12054, 12689);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24743 + "'", int2 == 24743);
    }

    @Test
    public void test6094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6094");
        int int2 = sum.Toplama.sum(12631, 1943);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14574 + "'", int2 == 14574);
    }

    @Test
    public void test6095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6095");
        int int2 = sum.Toplama.sum(35283, 3695);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38978 + "'", int2 == 38978);
    }

    @Test
    public void test6096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6096");
        int int2 = sum.Toplama.sum(1041, 13297);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14338 + "'", int2 == 14338);
    }

    @Test
    public void test6097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6097");
        int int2 = sum.Toplama.sum(2556, 393);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2949 + "'", int2 == 2949);
    }

    @Test
    public void test6098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6098");
        int int2 = sum.Toplama.sum(14758, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14768 + "'", int2 == 14768);
    }

    @Test
    public void test6099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6099");
        int int2 = sum.Toplama.sum(8274, 7597);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15871 + "'", int2 == 15871);
    }

    @Test
    public void test6100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6100");
        int int2 = sum.Toplama.sum(48736, 585);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49321 + "'", int2 == 49321);
    }

    @Test
    public void test6101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6101");
        int int2 = sum.Toplama.sum(0, 13663);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13663 + "'", int2 == 13663);
    }

    @Test
    public void test6102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6102");
        int int2 = sum.Toplama.sum(32648, 42557);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 75205 + "'", int2 == 75205);
    }

    @Test
    public void test6103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6103");
        int int2 = sum.Toplama.sum(80454, 10931);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 91385 + "'", int2 == 91385);
    }

    @Test
    public void test6104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6104");
        int int2 = sum.Toplama.sum(3698, 2474);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6172 + "'", int2 == 6172);
    }

    @Test
    public void test6105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6105");
        int int2 = sum.Toplama.sum(4265, 23038);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27303 + "'", int2 == 27303);
    }

    @Test
    public void test6106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6106");
        int int2 = sum.Toplama.sum(16821, 31020);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47841 + "'", int2 == 47841);
    }

    @Test
    public void test6107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6107");
        int int2 = sum.Toplama.sum(54740, 2735);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57475 + "'", int2 == 57475);
    }

    @Test
    public void test6108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6108");
        int int2 = sum.Toplama.sum(38781, 30709);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69490 + "'", int2 == 69490);
    }

    @Test
    public void test6109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6109");
        int int2 = sum.Toplama.sum(36360, 1408);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37768 + "'", int2 == 37768);
    }

    @Test
    public void test6110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6110");
        int int2 = sum.Toplama.sum(11434, 8465);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19899 + "'", int2 == 19899);
    }

    @Test
    public void test6111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6111");
        int int2 = sum.Toplama.sum(3363, 9119);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12482 + "'", int2 == 12482);
    }

    @Test
    public void test6112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6112");
        int int2 = sum.Toplama.sum(0, 46126);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46126 + "'", int2 == 46126);
    }

    @Test
    public void test6113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6113");
        int int2 = sum.Toplama.sum(64812, 7642);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72454 + "'", int2 == 72454);
    }

    @Test
    public void test6114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6114");
        int int2 = sum.Toplama.sum(13420, 19309);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32729 + "'", int2 == 32729);
    }

    @Test
    public void test6115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6115");
        int int2 = sum.Toplama.sum(0, 33230);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33230 + "'", int2 == 33230);
    }

    @Test
    public void test6116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6116");
        int int2 = sum.Toplama.sum(6152, 2797);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8949 + "'", int2 == 8949);
    }

    @Test
    public void test6117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6117");
        int int2 = sum.Toplama.sum(5060, 19987);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25047 + "'", int2 == 25047);
    }

    @Test
    public void test6118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6118");
        int int2 = sum.Toplama.sum(47676, 24863);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72539 + "'", int2 == 72539);
    }

    @Test
    public void test6119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6119");
        int int2 = sum.Toplama.sum(11593, 13869);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25462 + "'", int2 == 25462);
    }

    @Test
    public void test6120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6120");
        int int2 = sum.Toplama.sum(0, 108004);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 108004 + "'", int2 == 108004);
    }

    @Test
    public void test6121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6121");
        int int2 = sum.Toplama.sum(30609, 20124);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50733 + "'", int2 == 50733);
    }

    @Test
    public void test6122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6122");
        int int2 = sum.Toplama.sum(49329, 11182);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60511 + "'", int2 == 60511);
    }

    @Test
    public void test6123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6123");
        int int2 = sum.Toplama.sum(6278, 4403);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10681 + "'", int2 == 10681);
    }

    @Test
    public void test6124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6124");
        int int2 = sum.Toplama.sum(7125, 3742);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10867 + "'", int2 == 10867);
    }

    @Test
    public void test6125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6125");
        int int2 = sum.Toplama.sum(52456, 10565);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63021 + "'", int2 == 63021);
    }

    @Test
    public void test6126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6126");
        int int2 = sum.Toplama.sum(23340, 6918);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30258 + "'", int2 == 30258);
    }

    @Test
    public void test6127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6127");
        int int2 = sum.Toplama.sum(2459, 11001);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13460 + "'", int2 == 13460);
    }

    @Test
    public void test6128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6128");
        int int2 = sum.Toplama.sum(13554, 22515);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36069 + "'", int2 == 36069);
    }

    @Test
    public void test6129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6129");
        int int2 = sum.Toplama.sum(9171, 554);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9725 + "'", int2 == 9725);
    }

    @Test
    public void test6130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6130");
        int int2 = sum.Toplama.sum(29616, 39696);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69312 + "'", int2 == 69312);
    }

    @Test
    public void test6131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6131");
        int int2 = sum.Toplama.sum(12689, 25268);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37957 + "'", int2 == 37957);
    }

    @Test
    public void test6132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6132");
        int int2 = sum.Toplama.sum(8047, 47805);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55852 + "'", int2 == 55852);
    }

    @Test
    public void test6133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6133");
        int int2 = sum.Toplama.sum(24458, 36985);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61443 + "'", int2 == 61443);
    }

    @Test
    public void test6134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6134");
        int int2 = sum.Toplama.sum(90837, 11654);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 102491 + "'", int2 == 102491);
    }

    @Test
    public void test6135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6135");
        int int2 = sum.Toplama.sum(3283, 63720);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67003 + "'", int2 == 67003);
    }

    @Test
    public void test6136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6136");
        int int2 = sum.Toplama.sum(543, 53815);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54358 + "'", int2 == 54358);
    }

    @Test
    public void test6137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6137");
        int int2 = sum.Toplama.sum(46030, 3447);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49477 + "'", int2 == 49477);
    }

    @Test
    public void test6138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6138");
        int int2 = sum.Toplama.sum(22959, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22959 + "'", int2 == 22959);
    }

    @Test
    public void test6139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6139");
        int int2 = sum.Toplama.sum(45093, 15736);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60829 + "'", int2 == 60829);
    }

    @Test
    public void test6140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6140");
        int int2 = sum.Toplama.sum(2045, 7105);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9150 + "'", int2 == 9150);
    }

    @Test
    public void test6141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6141");
        int int2 = sum.Toplama.sum(359, 32163);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32522 + "'", int2 == 32522);
    }

    @Test
    public void test6142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6142");
        int int2 = sum.Toplama.sum(25712, 17023);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42735 + "'", int2 == 42735);
    }

    @Test
    public void test6143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6143");
        int int2 = sum.Toplama.sum(3056, 19162);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22218 + "'", int2 == 22218);
    }

    @Test
    public void test6144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6144");
        int int2 = sum.Toplama.sum(47268, 21286);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68554 + "'", int2 == 68554);
    }

    @Test
    public void test6145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6145");
        int int2 = sum.Toplama.sum(12968, 812);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13780 + "'", int2 == 13780);
    }

    @Test
    public void test6146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6146");
        int int2 = sum.Toplama.sum(10754, 3390);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14144 + "'", int2 == 14144);
    }

    @Test
    public void test6147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6147");
        int int2 = sum.Toplama.sum(123089, 3918);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 127007 + "'", int2 == 127007);
    }

    @Test
    public void test6148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6148");
        int int2 = sum.Toplama.sum(6714, 720);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7434 + "'", int2 == 7434);
    }

    @Test
    public void test6149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6149");
        int int2 = sum.Toplama.sum(12505, 4561);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17066 + "'", int2 == 17066);
    }

    @Test
    public void test6150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6150");
        int int2 = sum.Toplama.sum(0, 13887);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13887 + "'", int2 == 13887);
    }

    @Test
    public void test6151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6151");
        int int2 = sum.Toplama.sum(48527, 51782);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100309 + "'", int2 == 100309);
    }

    @Test
    public void test6152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6152");
        int int2 = sum.Toplama.sum(0, 54429);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54429 + "'", int2 == 54429);
    }

    @Test
    public void test6153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6153");
        int int2 = sum.Toplama.sum(21606, 56086);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 77692 + "'", int2 == 77692);
    }

    @Test
    public void test6154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6154");
        int int2 = sum.Toplama.sum(2569, 14152);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16721 + "'", int2 == 16721);
    }

    @Test
    public void test6155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6155");
        int int2 = sum.Toplama.sum(2451, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2451 + "'", int2 == 2451);
    }

    @Test
    public void test6156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6156");
        int int2 = sum.Toplama.sum(50847, 11069);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61916 + "'", int2 == 61916);
    }

    @Test
    public void test6157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6157");
        int int2 = sum.Toplama.sum(3061, 3410);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6471 + "'", int2 == 6471);
    }

    @Test
    public void test6158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6158");
        int int2 = sum.Toplama.sum(35929, 40141);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 76070 + "'", int2 == 76070);
    }

    @Test
    public void test6159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6159");
        int int2 = sum.Toplama.sum(616, 2747);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3363 + "'", int2 == 3363);
    }

    @Test
    public void test6160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6160");
        int int2 = sum.Toplama.sum(18983, 52593);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 71576 + "'", int2 == 71576);
    }

    @Test
    public void test6161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6161");
        int int2 = sum.Toplama.sum(8395, 1710);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10105 + "'", int2 == 10105);
    }

    @Test
    public void test6162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6162");
        int int2 = sum.Toplama.sum(18841, 4567);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23408 + "'", int2 == 23408);
    }

    @Test
    public void test6163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6163");
        int int2 = sum.Toplama.sum(10909, 4149);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15058 + "'", int2 == 15058);
    }

    @Test
    public void test6164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6164");
        int int2 = sum.Toplama.sum(26420, 39039);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 65459 + "'", int2 == 65459);
    }

    @Test
    public void test6165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6165");
        int int2 = sum.Toplama.sum(43675, 790);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44465 + "'", int2 == 44465);
    }

    @Test
    public void test6166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6166");
        int int2 = sum.Toplama.sum(2365, 33513);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35878 + "'", int2 == 35878);
    }

    @Test
    public void test6167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6167");
        int int2 = sum.Toplama.sum(30041, 21874);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51915 + "'", int2 == 51915);
    }

    @Test
    public void test6168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6168");
        int int2 = sum.Toplama.sum(5652, 16776);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22428 + "'", int2 == 22428);
    }

    @Test
    public void test6169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6169");
        int int2 = sum.Toplama.sum(57193, 12342);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69535 + "'", int2 == 69535);
    }

    @Test
    public void test6170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6170");
        int int2 = sum.Toplama.sum(5639, 48842);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54481 + "'", int2 == 54481);
    }

    @Test
    public void test6171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6171");
        int int2 = sum.Toplama.sum(32511, 18290);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50801 + "'", int2 == 50801);
    }

    @Test
    public void test6172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6172");
        int int2 = sum.Toplama.sum(7569, 42557);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50126 + "'", int2 == 50126);
    }

    @Test
    public void test6173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6173");
        int int2 = sum.Toplama.sum(40141, 39421);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 79562 + "'", int2 == 79562);
    }

    @Test
    public void test6174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6174");
        int int2 = sum.Toplama.sum(0, 6463);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6463 + "'", int2 == 6463);
    }

    @Test
    public void test6175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6175");
        int int2 = sum.Toplama.sum(9577, 44581);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54158 + "'", int2 == 54158);
    }

    @Test
    public void test6176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6176");
        int int2 = sum.Toplama.sum(3326, 7608);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10934 + "'", int2 == 10934);
    }

    @Test
    public void test6177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6177");
        int int2 = sum.Toplama.sum(33081, 3521);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36602 + "'", int2 == 36602);
    }

    @Test
    public void test6178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6178");
        int int2 = sum.Toplama.sum(1531, 32156);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33687 + "'", int2 == 33687);
    }

    @Test
    public void test6179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6179");
        int int2 = sum.Toplama.sum(2824, 8454);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11278 + "'", int2 == 11278);
    }

    @Test
    public void test6180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6180");
        int int2 = sum.Toplama.sum(12439, 6465);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18904 + "'", int2 == 18904);
    }

    @Test
    public void test6181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6181");
        int int2 = sum.Toplama.sum(17119, 13059);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30178 + "'", int2 == 30178);
    }

    @Test
    public void test6182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6182");
        int int2 = sum.Toplama.sum(3469, 12951);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16420 + "'", int2 == 16420);
    }

    @Test
    public void test6183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6183");
        int int2 = sum.Toplama.sum(19543, 16109);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35652 + "'", int2 == 35652);
    }

    @Test
    public void test6184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6184");
        int int2 = sum.Toplama.sum(29816, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29816 + "'", int2 == 29816);
    }

    @Test
    public void test6185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6185");
        int int2 = sum.Toplama.sum(5859, 8975);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14834 + "'", int2 == 14834);
    }

    @Test
    public void test6186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6186");
        int int2 = sum.Toplama.sum(3901, 54450);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58351 + "'", int2 == 58351);
    }

    @Test
    public void test6187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6187");
        int int2 = sum.Toplama.sum(0, 20730);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20730 + "'", int2 == 20730);
    }

    @Test
    public void test6188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6188");
        int int2 = sum.Toplama.sum(1784, 6471);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8255 + "'", int2 == 8255);
    }

    @Test
    public void test6189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6189");
        int int2 = sum.Toplama.sum(8351, 7469);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15820 + "'", int2 == 15820);
    }

    @Test
    public void test6190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6190");
        int int2 = sum.Toplama.sum(14944, 58351);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 73295 + "'", int2 == 73295);
    }

    @Test
    public void test6191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6191");
        int int2 = sum.Toplama.sum(53, 19026);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19079 + "'", int2 == 19079);
    }

    @Test
    public void test6192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6192");
        int int2 = sum.Toplama.sum(4786, 6531);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11317 + "'", int2 == 11317);
    }

    @Test
    public void test6193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6193");
        int int2 = sum.Toplama.sum(32648, 17466);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50114 + "'", int2 == 50114);
    }

    @Test
    public void test6194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6194");
        int int2 = sum.Toplama.sum(18904, 4132);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23036 + "'", int2 == 23036);
    }

    @Test
    public void test6195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6195");
        int int2 = sum.Toplama.sum(17094, 24489);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41583 + "'", int2 == 41583);
    }

    @Test
    public void test6196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6196");
        int int2 = sum.Toplama.sum(9858, 38597);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48455 + "'", int2 == 48455);
    }

    @Test
    public void test6197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6197");
        int int2 = sum.Toplama.sum(17409, 1970);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19379 + "'", int2 == 19379);
    }

    @Test
    public void test6198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6198");
        int int2 = sum.Toplama.sum(2843, 26122);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28965 + "'", int2 == 28965);
    }

    @Test
    public void test6199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6199");
        int int2 = sum.Toplama.sum(26689, 817);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27506 + "'", int2 == 27506);
    }

    @Test
    public void test6200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6200");
        int int2 = sum.Toplama.sum(3487, 2953);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6440 + "'", int2 == 6440);
    }

    @Test
    public void test6201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6201");
        int int2 = sum.Toplama.sum(15514, 4266);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19780 + "'", int2 == 19780);
    }

    @Test
    public void test6202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6202");
        int int2 = sum.Toplama.sum(27706, 9058);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36764 + "'", int2 == 36764);
    }

    @Test
    public void test6203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6203");
        int int2 = sum.Toplama.sum(3553, 39542);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43095 + "'", int2 == 43095);
    }

    @Test
    public void test6204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6204");
        int int2 = sum.Toplama.sum(0, 20808);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20808 + "'", int2 == 20808);
    }

    @Test
    public void test6205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6205");
        int int2 = sum.Toplama.sum(51932, 14536);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 66468 + "'", int2 == 66468);
    }

    @Test
    public void test6206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6206");
        int int2 = sum.Toplama.sum(65487, 22065);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 87552 + "'", int2 == 87552);
    }

    @Test
    public void test6207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6207");
        int int2 = sum.Toplama.sum(280, 2414);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2694 + "'", int2 == 2694);
    }

    @Test
    public void test6208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6208");
        int int2 = sum.Toplama.sum(6983, 31516);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38499 + "'", int2 == 38499);
    }

    @Test
    public void test6209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6209");
        int int2 = sum.Toplama.sum(35895, 8808);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44703 + "'", int2 == 44703);
    }

    @Test
    public void test6210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6210");
        int int2 = sum.Toplama.sum(38110, 29095);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67205 + "'", int2 == 67205);
    }

    @Test
    public void test6211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6211");
        int int2 = sum.Toplama.sum(51130, 38904);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90034 + "'", int2 == 90034);
    }

    @Test
    public void test6212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6212");
        int int2 = sum.Toplama.sum(1539, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1539 + "'", int2 == 1539);
    }

    @Test
    public void test6213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6213");
        int int2 = sum.Toplama.sum(15285, 15587);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30872 + "'", int2 == 30872);
    }

    @Test
    public void test6214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6214");
        int int2 = sum.Toplama.sum(5208, 27673);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32881 + "'", int2 == 32881);
    }

    @Test
    public void test6215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6215");
        int int2 = sum.Toplama.sum(12426, 6954);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19380 + "'", int2 == 19380);
    }

    @Test
    public void test6216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6216");
        int int2 = sum.Toplama.sum(7844, 37410);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45254 + "'", int2 == 45254);
    }

    @Test
    public void test6217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6217");
        int int2 = sum.Toplama.sum(25704, 512);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26216 + "'", int2 == 26216);
    }

    @Test
    public void test6218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6218");
        int int2 = sum.Toplama.sum(15704, 26837);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42541 + "'", int2 == 42541);
    }

    @Test
    public void test6219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6219");
        int int2 = sum.Toplama.sum(0, 9089);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9089 + "'", int2 == 9089);
    }

    @Test
    public void test6220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6220");
        int int2 = sum.Toplama.sum(34543, 10448);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44991 + "'", int2 == 44991);
    }

    @Test
    public void test6221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6221");
        int int2 = sum.Toplama.sum(3740, 22021);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25761 + "'", int2 == 25761);
    }

    @Test
    public void test6222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6222");
        int int2 = sum.Toplama.sum(54819, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54819 + "'", int2 == 54819);
    }

    @Test
    public void test6223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6223");
        int int2 = sum.Toplama.sum(2942, 14206);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17148 + "'", int2 == 17148);
    }

    @Test
    public void test6224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6224");
        int int2 = sum.Toplama.sum(4149, 4626);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8775 + "'", int2 == 8775);
    }

    @Test
    public void test6225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6225");
        int int2 = sum.Toplama.sum(91584, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 91584 + "'", int2 == 91584);
    }

    @Test
    public void test6226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6226");
        int int2 = sum.Toplama.sum(7675, 11001);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18676 + "'", int2 == 18676);
    }

    @Test
    public void test6227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6227");
        int int2 = sum.Toplama.sum(14621, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14621 + "'", int2 == 14621);
    }

    @Test
    public void test6228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6228");
        int int2 = sum.Toplama.sum(15007, 2026);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17033 + "'", int2 == 17033);
    }

    @Test
    public void test6229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6229");
        int int2 = sum.Toplama.sum(16475, 21053);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37528 + "'", int2 == 37528);
    }

    @Test
    public void test6230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6230");
        int int2 = sum.Toplama.sum(33113, 735);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33848 + "'", int2 == 33848);
    }

    @Test
    public void test6231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6231");
        int int2 = sum.Toplama.sum(4182, 37875);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42057 + "'", int2 == 42057);
    }

    @Test
    public void test6232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6232");
        int int2 = sum.Toplama.sum(13972, 11228);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25200 + "'", int2 == 25200);
    }

    @Test
    public void test6233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6233");
        int int2 = sum.Toplama.sum(369, 13811);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14180 + "'", int2 == 14180);
    }

    @Test
    public void test6234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6234");
        int int2 = sum.Toplama.sum(1161, 9050);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10211 + "'", int2 == 10211);
    }

    @Test
    public void test6235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6235");
        int int2 = sum.Toplama.sum(26936, 1539);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28475 + "'", int2 == 28475);
    }

    @Test
    public void test6236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6236");
        int int2 = sum.Toplama.sum(4653, 16855);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21508 + "'", int2 == 21508);
    }

    @Test
    public void test6237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6237");
        int int2 = sum.Toplama.sum(0, 38113);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38113 + "'", int2 == 38113);
    }

    @Test
    public void test6238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6238");
        int int2 = sum.Toplama.sum(34349, 17073);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51422 + "'", int2 == 51422);
    }

    @Test
    public void test6239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6239");
        int int2 = sum.Toplama.sum(18102, 1797);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19899 + "'", int2 == 19899);
    }

    @Test
    public void test6240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6240");
        int int2 = sum.Toplama.sum(18038, 16483);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34521 + "'", int2 == 34521);
    }

    @Test
    public void test6241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6241");
        int int2 = sum.Toplama.sum(21220, 304);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21524 + "'", int2 == 21524);
    }

    @Test
    public void test6242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6242");
        int int2 = sum.Toplama.sum(5832, 19334);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25166 + "'", int2 == 25166);
    }

    @Test
    public void test6243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6243");
        int int2 = sum.Toplama.sum(14189, 34966);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49155 + "'", int2 == 49155);
    }

    @Test
    public void test6244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6244");
        int int2 = sum.Toplama.sum(27706, 2359);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30065 + "'", int2 == 30065);
    }

    @Test
    public void test6245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6245");
        int int2 = sum.Toplama.sum(2761, 6561);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9322 + "'", int2 == 9322);
    }

    @Test
    public void test6246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6246");
        int int2 = sum.Toplama.sum(5125, 62033);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67158 + "'", int2 == 67158);
    }

    @Test
    public void test6247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6247");
        int int2 = sum.Toplama.sum(3569, 20215);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23784 + "'", int2 == 23784);
    }

    @Test
    public void test6248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6248");
        int int2 = sum.Toplama.sum(1867, 13435);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15302 + "'", int2 == 15302);
    }

    @Test
    public void test6249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6249");
        int int2 = sum.Toplama.sum(7106, 32522);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39628 + "'", int2 == 39628);
    }

    @Test
    public void test6250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6250");
        int int2 = sum.Toplama.sum(11793, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11793 + "'", int2 == 11793);
    }

    @Test
    public void test6251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6251");
        int int2 = sum.Toplama.sum(27538, 2742);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30280 + "'", int2 == 30280);
    }

    @Test
    public void test6252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6252");
        int int2 = sum.Toplama.sum(4283, 4320);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8603 + "'", int2 == 8603);
    }

    @Test
    public void test6253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6253");
        int int2 = sum.Toplama.sum(0, 23031);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23031 + "'", int2 == 23031);
    }

    @Test
    public void test6254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6254");
        int int2 = sum.Toplama.sum(16821, 12191);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29012 + "'", int2 == 29012);
    }

    @Test
    public void test6255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6255");
        int int2 = sum.Toplama.sum((int) (byte) 1, 71294);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 71295 + "'", int2 == 71295);
    }

    @Test
    public void test6256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6256");
        int int2 = sum.Toplama.sum(33465, 3798);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37263 + "'", int2 == 37263);
    }

    @Test
    public void test6257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6257");
        int int2 = sum.Toplama.sum(50403, 5041);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55444 + "'", int2 == 55444);
    }

    @Test
    public void test6258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6258");
        int int2 = sum.Toplama.sum(33146, 16533);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49679 + "'", int2 == 49679);
    }

    @Test
    public void test6259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6259");
        int int2 = sum.Toplama.sum(13410, 12191);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25601 + "'", int2 == 25601);
    }

    @Test
    public void test6260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6260");
        int int2 = sum.Toplama.sum(5182, 9311);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14493 + "'", int2 == 14493);
    }

    @Test
    public void test6261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6261");
        int int2 = sum.Toplama.sum(51953, 6290);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58243 + "'", int2 == 58243);
    }

    @Test
    public void test6262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6262");
        int int2 = sum.Toplama.sum(15302, 11713);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27015 + "'", int2 == 27015);
    }

    @Test
    public void test6263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6263");
        int int2 = sum.Toplama.sum(0, 65272);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 65272 + "'", int2 == 65272);
    }

    @Test
    public void test6264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6264");
        int int2 = sum.Toplama.sum(9578, 6142);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15720 + "'", int2 == 15720);
    }

    @Test
    public void test6265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6265");
        int int2 = sum.Toplama.sum(3766, 31462);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35228 + "'", int2 == 35228);
    }

    @Test
    public void test6266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6266");
        int int2 = sum.Toplama.sum(1037, 17836);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18873 + "'", int2 == 18873);
    }

    @Test
    public void test6267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6267");
        int int2 = sum.Toplama.sum(30008, 39294);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69302 + "'", int2 == 69302);
    }

    @Test
    public void test6268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6268");
        int int2 = sum.Toplama.sum(294, 75777);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 76071 + "'", int2 == 76071);
    }

    @Test
    public void test6269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6269");
        int int2 = sum.Toplama.sum(55083, 6162);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61245 + "'", int2 == 61245);
    }

    @Test
    public void test6270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6270");
        int int2 = sum.Toplama.sum(9350, 91584);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100934 + "'", int2 == 100934);
    }

    @Test
    public void test6271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6271");
        int int2 = sum.Toplama.sum(5030, 32049);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37079 + "'", int2 == 37079);
    }

    @Test
    public void test6272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6272");
        int int2 = sum.Toplama.sum(25680, 43844);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69524 + "'", int2 == 69524);
    }

    @Test
    public void test6273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6273");
        int int2 = sum.Toplama.sum(14960, 7368);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22328 + "'", int2 == 22328);
    }

    @Test
    public void test6274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6274");
        int int2 = sum.Toplama.sum(2292, 15668);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17960 + "'", int2 == 17960);
    }

    @Test
    public void test6275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6275");
        int int2 = sum.Toplama.sum(33767, 47292);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 81059 + "'", int2 == 81059);
    }

    @Test
    public void test6276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6276");
        int int2 = sum.Toplama.sum(13182, 7462);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20644 + "'", int2 == 20644);
    }

    @Test
    public void test6277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6277");
        int int2 = sum.Toplama.sum(25590, 170042);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 195632 + "'", int2 == 195632);
    }

    @Test
    public void test6278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6278");
        int int2 = sum.Toplama.sum(105863, 22041);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 127904 + "'", int2 == 127904);
    }

    @Test
    public void test6279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6279");
        int int2 = sum.Toplama.sum(29095, 12426);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41521 + "'", int2 == 41521);
    }

    @Test
    public void test6280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6280");
        int int2 = sum.Toplama.sum(16448, 33793);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50241 + "'", int2 == 50241);
    }

    @Test
    public void test6281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6281");
        int int2 = sum.Toplama.sum(13397, 16483);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29880 + "'", int2 == 29880);
    }

    @Test
    public void test6282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6282");
        int int2 = sum.Toplama.sum(36235, 36275);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72510 + "'", int2 == 72510);
    }

    @Test
    public void test6283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6283");
        int int2 = sum.Toplama.sum(859, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 858 + "'", int2 == 858);
    }

    @Test
    public void test6284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6284");
        int int2 = sum.Toplama.sum(12576, 23499);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36075 + "'", int2 == 36075);
    }

    @Test
    public void test6285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6285");
        int int2 = sum.Toplama.sum(8117, 18616);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26733 + "'", int2 == 26733);
    }

    @Test
    public void test6286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6286");
        int int2 = sum.Toplama.sum(54594, 15970);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70564 + "'", int2 == 70564);
    }

    @Test
    public void test6287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6287");
        int int2 = sum.Toplama.sum(5922, 17670);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23592 + "'", int2 == 23592);
    }

    @Test
    public void test6288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6288");
        int int2 = sum.Toplama.sum(13188, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13188 + "'", int2 == 13188);
    }

    @Test
    public void test6289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6289");
        int int2 = sum.Toplama.sum(17331, 6463);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23794 + "'", int2 == 23794);
    }

    @Test
    public void test6290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6290");
        int int2 = sum.Toplama.sum(22667, 31841);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54508 + "'", int2 == 54508);
    }

    @Test
    public void test6291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6291");
        int int2 = sum.Toplama.sum(30017, 21082);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51099 + "'", int2 == 51099);
    }

    @Test
    public void test6292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6292");
        int int2 = sum.Toplama.sum(17480, 18251);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35731 + "'", int2 == 35731);
    }

    @Test
    public void test6293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6293");
        int int2 = sum.Toplama.sum(30734, 34354);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 65088 + "'", int2 == 65088);
    }

    @Test
    public void test6294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6294");
        int int2 = sum.Toplama.sum(491, 30280);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30771 + "'", int2 == 30771);
    }

    @Test
    public void test6295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6295");
        int int2 = sum.Toplama.sum(44834, 23356);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68190 + "'", int2 == 68190);
    }

    @Test
    public void test6296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6296");
        int int2 = sum.Toplama.sum(10762, 10037);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20799 + "'", int2 == 20799);
    }

    @Test
    public void test6297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6297");
        int int2 = sum.Toplama.sum(15400, 2215);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17615 + "'", int2 == 17615);
    }

    @Test
    public void test6298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6298");
        int int2 = sum.Toplama.sum(12363, 21280);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33643 + "'", int2 == 33643);
    }

    @Test
    public void test6299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6299");
        int int2 = sum.Toplama.sum(11442, 17738);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29180 + "'", int2 == 29180);
    }

    @Test
    public void test6300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6300");
        int int2 = sum.Toplama.sum(20917, 7817);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28734 + "'", int2 == 28734);
    }

    @Test
    public void test6301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6301");
        int int2 = sum.Toplama.sum(1491, 15113);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16604 + "'", int2 == 16604);
    }

    @Test
    public void test6302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6302");
        int int2 = sum.Toplama.sum(60112, 12482);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72594 + "'", int2 == 72594);
    }

    @Test
    public void test6303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6303");
        int int2 = sum.Toplama.sum(0, 38606);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38606 + "'", int2 == 38606);
    }

    @Test
    public void test6304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6304");
        int int2 = sum.Toplama.sum(11793, 23833);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35626 + "'", int2 == 35626);
    }

    @Test
    public void test6305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6305");
        int int2 = sum.Toplama.sum(16914, 45241);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62155 + "'", int2 == 62155);
    }

    @Test
    public void test6306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6306");
        int int2 = sum.Toplama.sum(2368, 10830);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13198 + "'", int2 == 13198);
    }

    @Test
    public void test6307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6307");
        int int2 = sum.Toplama.sum(8139, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8139 + "'", int2 == 8139);
    }

    @Test
    public void test6308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6308");
        int int2 = sum.Toplama.sum(35990, 1832);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37822 + "'", int2 == 37822);
    }

    @Test
    public void test6309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6309");
        int int2 = sum.Toplama.sum(17409, 41645);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59054 + "'", int2 == 59054);
    }

    @Test
    public void test6310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6310");
        int int2 = sum.Toplama.sum(34680, 36338);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 71018 + "'", int2 == 71018);
    }

    @Test
    public void test6311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6311");
        int int2 = sum.Toplama.sum(33838, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33838 + "'", int2 == 33838);
    }

    @Test
    public void test6312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6312");
        int int2 = sum.Toplama.sum(39536, 1491);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41027 + "'", int2 == 41027);
    }

    @Test
    public void test6313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6313");
        int int2 = sum.Toplama.sum(27958, 14088);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42046 + "'", int2 == 42046);
    }

    @Test
    public void test6314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6314");
        int int2 = sum.Toplama.sum(970, 15770);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16740 + "'", int2 == 16740);
    }

    @Test
    public void test6315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6315");
        int int2 = sum.Toplama.sum(12820, 13546);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26366 + "'", int2 == 26366);
    }

    @Test
    public void test6316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6316");
        int int2 = sum.Toplama.sum(10, 1199);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1209 + "'", int2 == 1209);
    }

    @Test
    public void test6317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6317");
        int int2 = sum.Toplama.sum(2252, 4377);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6629 + "'", int2 == 6629);
    }

    @Test
    public void test6318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6318");
        int int2 = sum.Toplama.sum(6932, 16821);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23753 + "'", int2 == 23753);
    }

    @Test
    public void test6319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6319");
        int int2 = sum.Toplama.sum(4355, 10774);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15129 + "'", int2 == 15129);
    }

    @Test
    public void test6320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6320");
        int int2 = sum.Toplama.sum(9156, 4387);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13543 + "'", int2 == 13543);
    }

    @Test
    public void test6321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6321");
        int int2 = sum.Toplama.sum(5917, 49174);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55091 + "'", int2 == 55091);
    }

    @Test
    public void test6322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6322");
        int int2 = sum.Toplama.sum(972, 38631);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39603 + "'", int2 == 39603);
    }

    @Test
    public void test6323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6323");
        int int2 = sum.Toplama.sum(11635, 48715);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60350 + "'", int2 == 60350);
    }

    @Test
    public void test6324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6324");
        int int2 = sum.Toplama.sum(5334, 22354);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27688 + "'", int2 == 27688);
    }

    @Test
    public void test6325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6325");
        int int2 = sum.Toplama.sum(21593, 27134);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48727 + "'", int2 == 48727);
    }

    @Test
    public void test6326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6326");
        int int2 = sum.Toplama.sum(9979, 27635);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37614 + "'", int2 == 37614);
    }

    @Test
    public void test6327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6327");
        int int2 = sum.Toplama.sum(11784, 5188);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16972 + "'", int2 == 16972);
    }

    @Test
    public void test6328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6328");
        int int2 = sum.Toplama.sum(3282, 20923);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24205 + "'", int2 == 24205);
    }

    @Test
    public void test6329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6329");
        int int2 = sum.Toplama.sum(9808, 25166);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34974 + "'", int2 == 34974);
    }

    @Test
    public void test6330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6330");
        int int2 = sum.Toplama.sum(23546, 7334);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30880 + "'", int2 == 30880);
    }

    @Test
    public void test6331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6331");
        int int2 = sum.Toplama.sum(22041, 4242);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26283 + "'", int2 == 26283);
    }

    @Test
    public void test6332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6332");
        int int2 = sum.Toplama.sum(61884, 497);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62381 + "'", int2 == 62381);
    }

    @Test
    public void test6333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6333");
        int int2 = sum.Toplama.sum(56942, 687);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57629 + "'", int2 == 57629);
    }

    @Test
    public void test6334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6334");
        int int2 = sum.Toplama.sum(23956, 53023);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 76979 + "'", int2 == 76979);
    }

    @Test
    public void test6335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6335");
        int int2 = sum.Toplama.sum(104678, 1408);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 106086 + "'", int2 == 106086);
    }

    @Test
    public void test6336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6336");
        int int2 = sum.Toplama.sum(27959, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27959 + "'", int2 == 27959);
    }

    @Test
    public void test6337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6337");
        int int2 = sum.Toplama.sum(20854, 14467);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35321 + "'", int2 == 35321);
    }

    @Test
    public void test6338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6338");
        int int2 = sum.Toplama.sum(46706, 17503);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64209 + "'", int2 == 64209);
    }

    @Test
    public void test6339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6339");
        int int2 = sum.Toplama.sum(1412, 78097);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 79509 + "'", int2 == 79509);
    }

    @Test
    public void test6340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6340");
        int int2 = sum.Toplama.sum(2146, 105863);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 108009 + "'", int2 == 108009);
    }

    @Test
    public void test6341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6341");
        int int2 = sum.Toplama.sum(32990, 39026);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72016 + "'", int2 == 72016);
    }

    @Test
    public void test6342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6342");
        int int2 = sum.Toplama.sum(54740, 15736);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70476 + "'", int2 == 70476);
    }

    @Test
    public void test6343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6343");
        int int2 = sum.Toplama.sum(0, 55147);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55147 + "'", int2 == 55147);
    }

    @Test
    public void test6344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6344");
        int int2 = sum.Toplama.sum(14506, 5751);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20257 + "'", int2 == 20257);
    }

    @Test
    public void test6345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6345");
        int int2 = sum.Toplama.sum(3321, 35395);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38716 + "'", int2 == 38716);
    }

    @Test
    public void test6346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6346");
        int int2 = sum.Toplama.sum(40804, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40804 + "'", int2 == 40804);
    }

    @Test
    public void test6347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6347");
        int int2 = sum.Toplama.sum(12136, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12136 + "'", int2 == 12136);
    }

    @Test
    public void test6348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6348");
        int int2 = sum.Toplama.sum(3920, 10211);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14131 + "'", int2 == 14131);
    }

    @Test
    public void test6349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6349");
        int int2 = sum.Toplama.sum(1087, 39696);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40783 + "'", int2 == 40783);
    }

    @Test
    public void test6350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6350");
        int int2 = sum.Toplama.sum(2709, 6891);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9600 + "'", int2 == 9600);
    }

    @Test
    public void test6351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6351");
        int int2 = sum.Toplama.sum(4856, 82680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 87536 + "'", int2 == 87536);
    }

    @Test
    public void test6352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6352");
        int int2 = sum.Toplama.sum(82680, 38024);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 120704 + "'", int2 == 120704);
    }

    @Test
    public void test6353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6353");
        int int2 = sum.Toplama.sum(89607, 59712);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 149319 + "'", int2 == 149319);
    }

    @Test
    public void test6354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6354");
        int int2 = sum.Toplama.sum(24272, 9221);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33493 + "'", int2 == 33493);
    }

    @Test
    public void test6355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6355");
        int int2 = sum.Toplama.sum(16636, 10078);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26714 + "'", int2 == 26714);
    }

    @Test
    public void test6356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6356");
        int int2 = sum.Toplama.sum((int) 'a', 259);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 356 + "'", int2 == 356);
    }

    @Test
    public void test6357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6357");
        int int2 = sum.Toplama.sum(11069, 7798);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18867 + "'", int2 == 18867);
    }

    @Test
    public void test6358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6358");
        int int2 = sum.Toplama.sum(11262, 130224);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 141486 + "'", int2 == 141486);
    }

    @Test
    public void test6359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6359");
        int int2 = sum.Toplama.sum(40954, 12200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53154 + "'", int2 == 53154);
    }

    @Test
    public void test6360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6360");
        int int2 = sum.Toplama.sum(474, 14467);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14941 + "'", int2 == 14941);
    }

    @Test
    public void test6361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6361");
        int int2 = sum.Toplama.sum(6305, 28232);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34537 + "'", int2 == 34537);
    }

    @Test
    public void test6362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6362");
        int int2 = sum.Toplama.sum(7514, 730);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8244 + "'", int2 == 8244);
    }

    @Test
    public void test6363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6363");
        int int2 = sum.Toplama.sum(16338, 13142);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29480 + "'", int2 == 29480);
    }

    @Test
    public void test6364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6364");
        int int2 = sum.Toplama.sum(889, 8901);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9790 + "'", int2 == 9790);
    }

    @Test
    public void test6365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6365");
        int int2 = sum.Toplama.sum(30369, 3873);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34242 + "'", int2 == 34242);
    }

    @Test
    public void test6366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6366");
        int int2 = sum.Toplama.sum(65268, 99380);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 164648 + "'", int2 == 164648);
    }

    @Test
    public void test6367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6367");
        int int2 = sum.Toplama.sum(28373, 18326);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46699 + "'", int2 == 46699);
    }

    @Test
    public void test6368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6368");
        int int2 = sum.Toplama.sum(1441, 18166);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19607 + "'", int2 == 19607);
    }

    @Test
    public void test6369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6369");
        int int2 = sum.Toplama.sum(11706, 34033);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45739 + "'", int2 == 45739);
    }

    @Test
    public void test6370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6370");
        int int2 = sum.Toplama.sum(38256, 9035);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47291 + "'", int2 == 47291);
    }

    @Test
    public void test6371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6371");
        int int2 = sum.Toplama.sum(11849, 13412);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25261 + "'", int2 == 25261);
    }

    @Test
    public void test6372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6372");
        int int2 = sum.Toplama.sum(28642, 52429);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 81071 + "'", int2 == 81071);
    }

    @Test
    public void test6373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6373");
        int int2 = sum.Toplama.sum(17461, 39025);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56486 + "'", int2 == 56486);
    }

    @Test
    public void test6374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6374");
        int int2 = sum.Toplama.sum(22310, 10139);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32449 + "'", int2 == 32449);
    }

    @Test
    public void test6375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6375");
        int int2 = sum.Toplama.sum(22802, 3422);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26224 + "'", int2 == 26224);
    }

    @Test
    public void test6376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6376");
        int int2 = sum.Toplama.sum(595, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 595 + "'", int2 == 595);
    }

    @Test
    public void test6377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6377");
        int int2 = sum.Toplama.sum(3689, 75488);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 79177 + "'", int2 == 79177);
    }

    @Test
    public void test6378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6378");
        int int2 = sum.Toplama.sum(3447, 118082);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 121529 + "'", int2 == 121529);
    }

    @Test
    public void test6379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6379");
        int int2 = sum.Toplama.sum(4327, 817);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5144 + "'", int2 == 5144);
    }

    @Test
    public void test6380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6380");
        int int2 = sum.Toplama.sum(6766, 5969);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12735 + "'", int2 == 12735);
    }

    @Test
    public void test6381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6381");
        int int2 = sum.Toplama.sum(64094, 15514);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 79608 + "'", int2 == 79608);
    }

    @Test
    public void test6382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6382");
        int int2 = sum.Toplama.sum(23338, 47472);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70810 + "'", int2 == 70810);
    }

    @Test
    public void test6383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6383");
        int int2 = sum.Toplama.sum(15182, 30527);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45709 + "'", int2 == 45709);
    }

    @Test
    public void test6384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6384");
        int int2 = sum.Toplama.sum(28792, 4171);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32963 + "'", int2 == 32963);
    }

    @Test
    public void test6385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6385");
        int int2 = sum.Toplama.sum(49686, 30553);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80239 + "'", int2 == 80239);
    }

    @Test
    public void test6386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6386");
        int int2 = sum.Toplama.sum(32292, 63854);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96146 + "'", int2 == 96146);
    }

    @Test
    public void test6387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6387");
        int int2 = sum.Toplama.sum(25176, 83186);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 108362 + "'", int2 == 108362);
    }

    @Test
    public void test6388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6388");
        int int2 = sum.Toplama.sum(2968, 8804);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11772 + "'", int2 == 11772);
    }

    @Test
    public void test6389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6389");
        int int2 = sum.Toplama.sum(8912, 3807);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12719 + "'", int2 == 12719);
    }

    @Test
    public void test6390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6390");
        int int2 = sum.Toplama.sum(0, 13120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13120 + "'", int2 == 13120);
    }

    @Test
    public void test6391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6391");
        int int2 = sum.Toplama.sum(21124, 14831);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35955 + "'", int2 == 35955);
    }

    @Test
    public void test6392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6392");
        int int2 = sum.Toplama.sum(3392, 19415);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22807 + "'", int2 == 22807);
    }

    @Test
    public void test6393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6393");
        int int2 = sum.Toplama.sum(16498, 27506);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44004 + "'", int2 == 44004);
    }

    @Test
    public void test6394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6394");
        int int2 = sum.Toplama.sum(22868, 18177);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41045 + "'", int2 == 41045);
    }

    @Test
    public void test6395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6395");
        int int2 = sum.Toplama.sum(7597, 92597);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100194 + "'", int2 == 100194);
    }

    @Test
    public void test6396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6396");
        int int2 = sum.Toplama.sum(19343, 1724);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21067 + "'", int2 == 21067);
    }

    @Test
    public void test6397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6397");
        int int2 = sum.Toplama.sum(8827, 70279);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 79106 + "'", int2 == 79106);
    }

    @Test
    public void test6398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6398");
        int int2 = sum.Toplama.sum(31406, 1239);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32645 + "'", int2 == 32645);
    }

    @Test
    public void test6399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6399");
        int int2 = sum.Toplama.sum(39541, 22462);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62003 + "'", int2 == 62003);
    }

    @Test
    public void test6400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6400");
        int int2 = sum.Toplama.sum(42338, 10139);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52477 + "'", int2 == 52477);
    }

    @Test
    public void test6401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6401");
        int int2 = sum.Toplama.sum(97857, 11397);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 109254 + "'", int2 == 109254);
    }

    @Test
    public void test6402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6402");
        int int2 = sum.Toplama.sum(8599, 59792);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68391 + "'", int2 == 68391);
    }

    @Test
    public void test6403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6403");
        int int2 = sum.Toplama.sum(32785, 1969);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34754 + "'", int2 == 34754);
    }

    @Test
    public void test6404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6404");
        int int2 = sum.Toplama.sum(54115, 26409);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80524 + "'", int2 == 80524);
    }

    @Test
    public void test6405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6405");
        int int2 = sum.Toplama.sum(10165, 7745);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17910 + "'", int2 == 17910);
    }

    @Test
    public void test6406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6406");
        int int2 = sum.Toplama.sum(46706, 49208);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 95914 + "'", int2 == 95914);
    }

    @Test
    public void test6407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6407");
        int int2 = sum.Toplama.sum(7798, 1510);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9308 + "'", int2 == 9308);
    }

    @Test
    public void test6408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6408");
        int int2 = sum.Toplama.sum(10492, 19725);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30217 + "'", int2 == 30217);
    }

    @Test
    public void test6409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6409");
        int int2 = sum.Toplama.sum(27360, 16723);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44083 + "'", int2 == 44083);
    }

    @Test
    public void test6410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6410");
        int int2 = sum.Toplama.sum(22120, 21132);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43252 + "'", int2 == 43252);
    }

    @Test
    public void test6411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6411");
        int int2 = sum.Toplama.sum(31020, 12857);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43877 + "'", int2 == 43877);
    }

    @Test
    public void test6412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6412");
        int int2 = sum.Toplama.sum(27913, 846);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28759 + "'", int2 == 28759);
    }

    @Test
    public void test6413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6413");
        int int2 = sum.Toplama.sum(808, 52174);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52982 + "'", int2 == 52982);
    }

    @Test
    public void test6414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6414");
        int int2 = sum.Toplama.sum(6723, 17960);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24683 + "'", int2 == 24683);
    }

    @Test
    public void test6415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6415");
        int int2 = sum.Toplama.sum(23054, 71900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 94954 + "'", int2 == 94954);
    }

    @Test
    public void test6416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6416");
        int int2 = sum.Toplama.sum(2602, 16987);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19589 + "'", int2 == 19589);
    }

    @Test
    public void test6417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6417");
        int int2 = sum.Toplama.sum(21950, 37983);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59933 + "'", int2 == 59933);
    }

    @Test
    public void test6418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6418");
        int int2 = sum.Toplama.sum(4057, 12696);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16753 + "'", int2 == 16753);
    }

    @Test
    public void test6419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6419");
        int int2 = sum.Toplama.sum(2368, 16533);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18901 + "'", int2 == 18901);
    }

    @Test
    public void test6420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6420");
        int int2 = sum.Toplama.sum(13874, 21278);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35152 + "'", int2 == 35152);
    }

    @Test
    public void test6421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6421");
        int int2 = sum.Toplama.sum(15674, 22354);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38028 + "'", int2 == 38028);
    }

    @Test
    public void test6422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6422");
        int int2 = sum.Toplama.sum(51782, 3167);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54949 + "'", int2 == 54949);
    }

    @Test
    public void test6423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6423");
        int int2 = sum.Toplama.sum(0, 20917);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20917 + "'", int2 == 20917);
    }

    @Test
    public void test6424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6424");
        int int2 = sum.Toplama.sum(13972, 25388);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39360 + "'", int2 == 39360);
    }

    @Test
    public void test6425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6425");
        int int2 = sum.Toplama.sum(22956, 12178);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35134 + "'", int2 == 35134);
    }

    @Test
    public void test6426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6426");
        int int2 = sum.Toplama.sum(9590, 9310);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18900 + "'", int2 == 18900);
    }

    @Test
    public void test6427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6427");
        int int2 = sum.Toplama.sum(33911, 21874);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55785 + "'", int2 == 55785);
    }

    @Test
    public void test6428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6428");
        int int2 = sum.Toplama.sum(69985, 55887);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 125872 + "'", int2 == 125872);
    }

    @Test
    public void test6429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6429");
        int int2 = sum.Toplama.sum(47248, 1465);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48713 + "'", int2 == 48713);
    }

    @Test
    public void test6430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6430");
        int int2 = sum.Toplama.sum(40313, 9059);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49372 + "'", int2 == 49372);
    }

    @Test
    public void test6431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6431");
        int int2 = sum.Toplama.sum(13545, 28991);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42536 + "'", int2 == 42536);
    }

    @Test
    public void test6432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6432");
        int int2 = sum.Toplama.sum(27663, 41045);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68708 + "'", int2 == 68708);
    }

    @Test
    public void test6433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6433");
        int int2 = sum.Toplama.sum(55997, 24033);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80030 + "'", int2 == 80030);
    }

    @Test
    public void test6434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6434");
        int int2 = sum.Toplama.sum(21734, 19193);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40927 + "'", int2 == 40927);
    }

    @Test
    public void test6435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6435");
        int int2 = sum.Toplama.sum(19068, 21261);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40329 + "'", int2 == 40329);
    }

    @Test
    public void test6436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6436");
        int int2 = sum.Toplama.sum(17466, 6330);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23796 + "'", int2 == 23796);
    }

    @Test
    public void test6437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6437");
        int int2 = sum.Toplama.sum(17275, 15587);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32862 + "'", int2 == 32862);
    }

    @Test
    public void test6438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6438");
        int int2 = sum.Toplama.sum(13027, 12420);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25447 + "'", int2 == 25447);
    }

    @Test
    public void test6439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6439");
        int int2 = sum.Toplama.sum(13929, 44703);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58632 + "'", int2 == 58632);
    }

    @Test
    public void test6440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6440");
        int int2 = sum.Toplama.sum(14422, 17825);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32247 + "'", int2 == 32247);
    }

    @Test
    public void test6441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6441");
        int int2 = sum.Toplama.sum(37230, 29952);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67182 + "'", int2 == 67182);
    }

    @Test
    public void test6442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6442");
        int int2 = sum.Toplama.sum(5476, 31845);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37321 + "'", int2 == 37321);
    }

    @Test
    public void test6443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6443");
        int int2 = sum.Toplama.sum(11931, 7919);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19850 + "'", int2 == 19850);
    }

    @Test
    public void test6444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6444");
        int int2 = sum.Toplama.sum(13120, 23833);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36953 + "'", int2 == 36953);
    }

    @Test
    public void test6445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6445");
        int int2 = sum.Toplama.sum(6649, 67487);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 74136 + "'", int2 == 74136);
    }

    @Test
    public void test6446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6446");
        int int2 = sum.Toplama.sum(217, 35990);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36207 + "'", int2 == 36207);
    }

    @Test
    public void test6447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6447");
        int int2 = sum.Toplama.sum(1213, 36321);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37534 + "'", int2 == 37534);
    }

    @Test
    public void test6448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6448");
        int int2 = sum.Toplama.sum(78524, 20529);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99053 + "'", int2 == 99053);
    }

    @Test
    public void test6449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6449");
        int int2 = sum.Toplama.sum(25152, 5249);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30401 + "'", int2 == 30401);
    }

    @Test
    public void test6450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6450");
        int int2 = sum.Toplama.sum(13785, 42406);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56191 + "'", int2 == 56191);
    }

    @Test
    public void test6451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6451");
        int int2 = sum.Toplama.sum(66169, 19492);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 85661 + "'", int2 == 85661);
    }

    @Test
    public void test6452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6452");
        int int2 = sum.Toplama.sum(20854, 5721);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26575 + "'", int2 == 26575);
    }

    @Test
    public void test6453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6453");
        int int2 = sum.Toplama.sum(14458, 16713);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31171 + "'", int2 == 31171);
    }

    @Test
    public void test6454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6454");
        int int2 = sum.Toplama.sum(4653, 31778);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36431 + "'", int2 == 36431);
    }

    @Test
    public void test6455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6455");
        int int2 = sum.Toplama.sum(20559, 51795);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72354 + "'", int2 == 72354);
    }

    @Test
    public void test6456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6456");
        int int2 = sum.Toplama.sum(13080, 20178);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33258 + "'", int2 == 33258);
    }

    @Test
    public void test6457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6457");
        int int2 = sum.Toplama.sum(6282, 21606);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27888 + "'", int2 == 27888);
    }

    @Test
    public void test6458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6458");
        int int2 = sum.Toplama.sum(57478, 12951);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70429 + "'", int2 == 70429);
    }

    @Test
    public void test6459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6459");
        int int2 = sum.Toplama.sum(88, 53154);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53242 + "'", int2 == 53242);
    }

    @Test
    public void test6460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6460");
        int int2 = sum.Toplama.sum(12951, 15668);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28619 + "'", int2 == 28619);
    }

    @Test
    public void test6461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6461");
        int int2 = sum.Toplama.sum(30102, 17534);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47636 + "'", int2 == 47636);
    }

    @Test
    public void test6462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6462");
        int int2 = sum.Toplama.sum(29158, 9204);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38362 + "'", int2 == 38362);
    }

    @Test
    public void test6463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6463");
        int int2 = sum.Toplama.sum(8274, 14881);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23155 + "'", int2 == 23155);
    }

    @Test
    public void test6464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6464");
        int int2 = sum.Toplama.sum(8232, 25154);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33386 + "'", int2 == 33386);
    }

    @Test
    public void test6465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6465");
        int int2 = sum.Toplama.sum(2742, 26733);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29475 + "'", int2 == 29475);
    }

    @Test
    public void test6466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6466");
        int int2 = sum.Toplama.sum(7756, 15041);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22797 + "'", int2 == 22797);
    }

    @Test
    public void test6467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6467");
        int int2 = sum.Toplama.sum(36270, 89283);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 125553 + "'", int2 == 125553);
    }

    @Test
    public void test6468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6468");
        int int2 = sum.Toplama.sum(3078, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3178 + "'", int2 == 3178);
    }

    @Test
    public void test6469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6469");
        int int2 = sum.Toplama.sum(41698, 13566);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55264 + "'", int2 == 55264);
    }

    @Test
    public void test6470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6470");
        int int2 = sum.Toplama.sum(0, 6041);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6041 + "'", int2 == 6041);
    }

    @Test
    public void test6471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6471");
        int int2 = sum.Toplama.sum(5322, 8282);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13604 + "'", int2 == 13604);
    }

    @Test
    public void test6472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6472");
        int int2 = sum.Toplama.sum(8966, 1108);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10074 + "'", int2 == 10074);
    }

    @Test
    public void test6473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6473");
        int int2 = sum.Toplama.sum(7488, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7488 + "'", int2 == 7488);
    }

    @Test
    public void test6474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6474");
        int int2 = sum.Toplama.sum(23007, 32292);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55299 + "'", int2 == 55299);
    }

    @Test
    public void test6475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6475");
        int int2 = sum.Toplama.sum(20257, 36546);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56803 + "'", int2 == 56803);
    }

    @Test
    public void test6476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6476");
        int int2 = sum.Toplama.sum(3266, 67158);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70424 + "'", int2 == 70424);
    }

    @Test
    public void test6477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6477");
        int int2 = sum.Toplama.sum(26864, 4539);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31403 + "'", int2 == 31403);
    }

    @Test
    public void test6478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6478");
        int int2 = sum.Toplama.sum(105863, 29725);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 135588 + "'", int2 == 135588);
    }

    @Test
    public void test6479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6479");
        int int2 = sum.Toplama.sum(0, 11065);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11065 + "'", int2 == 11065);
    }

    @Test
    public void test6480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6480");
        int int2 = sum.Toplama.sum(6254, 19488);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25742 + "'", int2 == 25742);
    }

    @Test
    public void test6481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6481");
        int int2 = sum.Toplama.sum(25155, 25631);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50786 + "'", int2 == 50786);
    }

    @Test
    public void test6482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6482");
        int int2 = sum.Toplama.sum(10683, 3067);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13750 + "'", int2 == 13750);
    }

    @Test
    public void test6483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6483");
        int int2 = sum.Toplama.sum(10871, 8047);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18918 + "'", int2 == 18918);
    }

    @Test
    public void test6484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6484");
        int int2 = sum.Toplama.sum(26147, 30872);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57019 + "'", int2 == 57019);
    }

    @Test
    public void test6485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6485");
        int int2 = sum.Toplama.sum(4986, 11416);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16402 + "'", int2 == 16402);
    }

    @Test
    public void test6486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6486");
        int int2 = sum.Toplama.sum(37679, 21209);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58888 + "'", int2 == 58888);
    }

    @Test
    public void test6487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6487");
        int int2 = sum.Toplama.sum(13453, 80326);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 93779 + "'", int2 == 93779);
    }

    @Test
    public void test6488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6488");
        int int2 = sum.Toplama.sum(0, 13015);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13015 + "'", int2 == 13015);
    }

    @Test
    public void test6489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6489");
        int int2 = sum.Toplama.sum(3125, 877);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4002 + "'", int2 == 4002);
    }

    @Test
    public void test6490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6490");
        int int2 = sum.Toplama.sum(9617, 63253);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72870 + "'", int2 == 72870);
    }

    @Test
    public void test6491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6491");
        int int2 = sum.Toplama.sum(25759, 9475);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35234 + "'", int2 == 35234);
    }

    @Test
    public void test6492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6492");
        int int2 = sum.Toplama.sum(38760, 295);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39055 + "'", int2 == 39055);
    }

    @Test
    public void test6493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6493");
        int int2 = sum.Toplama.sum(26951, 123089);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 150040 + "'", int2 == 150040);
    }

    @Test
    public void test6494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6494");
        int int2 = sum.Toplama.sum(12578, 19534);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32112 + "'", int2 == 32112);
    }

    @Test
    public void test6495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6495");
        int int2 = sum.Toplama.sum(12473, 11843);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24316 + "'", int2 == 24316);
    }

    @Test
    public void test6496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6496");
        int int2 = sum.Toplama.sum(9902, 16911);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26813 + "'", int2 == 26813);
    }

    @Test
    public void test6497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6497");
        int int2 = sum.Toplama.sum(26737, 62033);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 88770 + "'", int2 == 88770);
    }

    @Test
    public void test6498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6498");
        int int2 = sum.Toplama.sum(14798, 31131);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45929 + "'", int2 == 45929);
    }

    @Test
    public void test6499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6499");
        int int2 = sum.Toplama.sum(24692, 25879);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50571 + "'", int2 == 50571);
    }

    @Test
    public void test6500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test6500");
        int int2 = sum.Toplama.sum(46630, 24272);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70902 + "'", int2 == 70902);
    }
}

