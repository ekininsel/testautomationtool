import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest16 {

    public static boolean debug = false;

    @Test
    public void test8001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8001");
        int int2 = sum.Toplama.sum(5224, 19343);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24567 + "'", int2 == 24567);
    }

    @Test
    public void test8002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8002");
        int int2 = sum.Toplama.sum(39151, 27134);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 66285 + "'", int2 == 66285);
    }

    @Test
    public void test8003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8003");
        int int2 = sum.Toplama.sum(80030, 25154);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 105184 + "'", int2 == 105184);
    }

    @Test
    public void test8004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8004");
        int int2 = sum.Toplama.sum(30838, 52593);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 83431 + "'", int2 == 83431);
    }

    @Test
    public void test8005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8005");
        int int2 = sum.Toplama.sum(6808, 16215);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23023 + "'", int2 == 23023);
    }

    @Test
    public void test8006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8006");
        int int2 = sum.Toplama.sum(13754, 2838);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16592 + "'", int2 == 16592);
    }

    @Test
    public void test8007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8007");
        int int2 = sum.Toplama.sum(1488, 20828);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22316 + "'", int2 == 22316);
    }

    @Test
    public void test8008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8008");
        int int2 = sum.Toplama.sum(7615, 55147);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62762 + "'", int2 == 62762);
    }

    @Test
    public void test8009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8009");
        int int2 = sum.Toplama.sum(130224, 110420);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 240644 + "'", int2 == 240644);
    }

    @Test
    public void test8010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8010");
        int int2 = sum.Toplama.sum(2533, 1292);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3825 + "'", int2 == 3825);
    }

    @Test
    public void test8011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8011");
        int int2 = sum.Toplama.sum(47848, 49589);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97437 + "'", int2 == 97437);
    }

    @Test
    public void test8012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8012");
        int int2 = sum.Toplama.sum(2405, 7498);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9903 + "'", int2 == 9903);
    }

    @Test
    public void test8013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8013");
        int int2 = sum.Toplama.sum(3401, 15208);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18609 + "'", int2 == 18609);
    }

    @Test
    public void test8014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8014");
        int int2 = sum.Toplama.sum(11104, 408);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11512 + "'", int2 == 11512);
    }

    @Test
    public void test8015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8015");
        int int2 = sum.Toplama.sum(0, 64502);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64502 + "'", int2 == 64502);
    }

    @Test
    public void test8016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8016");
        int int2 = sum.Toplama.sum(7076, 32964);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40040 + "'", int2 == 40040);
    }

    @Test
    public void test8017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8017");
        int int2 = sum.Toplama.sum(6113, 5192);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11305 + "'", int2 == 11305);
    }

    @Test
    public void test8018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8018");
        int int2 = sum.Toplama.sum(51978, 34223);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 86201 + "'", int2 == 86201);
    }

    @Test
    public void test8019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8019");
        int int2 = sum.Toplama.sum(88574, 23019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 111593 + "'", int2 == 111593);
    }

    @Test
    public void test8020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8020");
        int int2 = sum.Toplama.sum(40019, 27297);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67316 + "'", int2 == 67316);
    }

    @Test
    public void test8021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8021");
        int int2 = sum.Toplama.sum(42501, 32837);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 75338 + "'", int2 == 75338);
    }

    @Test
    public void test8022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8022");
        int int2 = sum.Toplama.sum(23025, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23025 + "'", int2 == 23025);
    }

    @Test
    public void test8023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8023");
        int int2 = sum.Toplama.sum(97824, 50546);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 148370 + "'", int2 == 148370);
    }

    @Test
    public void test8024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8024");
        int int2 = sum.Toplama.sum(30673, 16613);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47286 + "'", int2 == 47286);
    }

    @Test
    public void test8025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8025");
        int int2 = sum.Toplama.sum(20422, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20422 + "'", int2 == 20422);
    }

    @Test
    public void test8026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8026");
        int int2 = sum.Toplama.sum(6903, 8556);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15459 + "'", int2 == 15459);
    }

    @Test
    public void test8027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8027");
        int int2 = sum.Toplama.sum(48981, 1539);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50520 + "'", int2 == 50520);
    }

    @Test
    public void test8028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8028");
        int int2 = sum.Toplama.sum(23031, 4725);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27756 + "'", int2 == 27756);
    }

    @Test
    public void test8029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8029");
        int int2 = sum.Toplama.sum(12820, 4312);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17132 + "'", int2 == 17132);
    }

    @Test
    public void test8030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8030");
        int int2 = sum.Toplama.sum(24648, 5092);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29740 + "'", int2 == 29740);
    }

    @Test
    public void test8031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8031");
        int int2 = sum.Toplama.sum(4080, 1703);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5783 + "'", int2 == 5783);
    }

    @Test
    public void test8032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8032");
        int int2 = sum.Toplama.sum(9607, 14566);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24173 + "'", int2 == 24173);
    }

    @Test
    public void test8033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8033");
        int int2 = sum.Toplama.sum(38459, 16274);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54733 + "'", int2 == 54733);
    }

    @Test
    public void test8034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8034");
        int int2 = sum.Toplama.sum(12053, 32799);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44852 + "'", int2 == 44852);
    }

    @Test
    public void test8035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8035");
        int int2 = sum.Toplama.sum(87552, 39892);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 127444 + "'", int2 == 127444);
    }

    @Test
    public void test8036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8036");
        int int2 = sum.Toplama.sum(27484, 8942);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36426 + "'", int2 == 36426);
    }

    @Test
    public void test8037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8037");
        int int2 = sum.Toplama.sum(42315, 20924);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63239 + "'", int2 == 63239);
    }

    @Test
    public void test8038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8038");
        int int2 = sum.Toplama.sum(9148, 294);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9442 + "'", int2 == 9442);
    }

    @Test
    public void test8039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8039");
        int int2 = sum.Toplama.sum(81858, 2958);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 84816 + "'", int2 == 84816);
    }

    @Test
    public void test8040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8040");
        int int2 = sum.Toplama.sum(12310, 1167);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13477 + "'", int2 == 13477);
    }

    @Test
    public void test8041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8041");
        int int2 = sum.Toplama.sum(10199, 18129);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28328 + "'", int2 == 28328);
    }

    @Test
    public void test8042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8042");
        int int2 = sum.Toplama.sum(14327, 13874);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28201 + "'", int2 == 28201);
    }

    @Test
    public void test8043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8043");
        int int2 = sum.Toplama.sum(56729, 4137);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60866 + "'", int2 == 60866);
    }

    @Test
    public void test8044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8044");
        int int2 = sum.Toplama.sum(27473, 241);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27714 + "'", int2 == 27714);
    }

    @Test
    public void test8045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8045");
        int int2 = sum.Toplama.sum(76758, 1051);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 77809 + "'", int2 == 77809);
    }

    @Test
    public void test8046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8046");
        int int2 = sum.Toplama.sum(35330, 36249);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 71579 + "'", int2 == 71579);
    }

    @Test
    public void test8047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8047");
        int int2 = sum.Toplama.sum(6962, 7832);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14794 + "'", int2 == 14794);
    }

    @Test
    public void test8048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8048");
        int int2 = sum.Toplama.sum(63217, 26425);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 89642 + "'", int2 == 89642);
    }

    @Test
    public void test8049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8049");
        int int2 = sum.Toplama.sum(62188, 29116);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 91304 + "'", int2 == 91304);
    }

    @Test
    public void test8050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8050");
        int int2 = sum.Toplama.sum(54831, 152440);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 207271 + "'", int2 == 207271);
    }

    @Test
    public void test8051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8051");
        int int2 = sum.Toplama.sum(99684, 2843);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 102527 + "'", int2 == 102527);
    }

    @Test
    public void test8052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8052");
        int int2 = sum.Toplama.sum(22705, 10611);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33316 + "'", int2 == 33316);
    }

    @Test
    public void test8053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8053");
        int int2 = sum.Toplama.sum(1018, 72510);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 73528 + "'", int2 == 73528);
    }

    @Test
    public void test8054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8054");
        int int2 = sum.Toplama.sum(14152, 63652);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 77804 + "'", int2 == 77804);
    }

    @Test
    public void test8055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8055");
        int int2 = sum.Toplama.sum(18598, 21349);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39947 + "'", int2 == 39947);
    }

    @Test
    public void test8056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8056");
        int int2 = sum.Toplama.sum(14621, 33052);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47673 + "'", int2 == 47673);
    }

    @Test
    public void test8057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8057");
        int int2 = sum.Toplama.sum(56640, 75234);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 131874 + "'", int2 == 131874);
    }

    @Test
    public void test8058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8058");
        int int2 = sum.Toplama.sum(19002, 3045);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22047 + "'", int2 == 22047);
    }

    @Test
    public void test8059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8059");
        int int2 = sum.Toplama.sum(45639, 64770);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 110409 + "'", int2 == 110409);
    }

    @Test
    public void test8060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8060");
        int int2 = sum.Toplama.sum(49372, 39969);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 89341 + "'", int2 == 89341);
    }

    @Test
    public void test8061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8061");
        int int2 = sum.Toplama.sum(22661, 16059);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38720 + "'", int2 == 38720);
    }

    @Test
    public void test8062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8062");
        int int2 = sum.Toplama.sum(3026, 23468);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26494 + "'", int2 == 26494);
    }

    @Test
    public void test8063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8063");
        int int2 = sum.Toplama.sum(51587, 6219);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57806 + "'", int2 == 57806);
    }

    @Test
    public void test8064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8064");
        int int2 = sum.Toplama.sum(29485, 18995);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48480 + "'", int2 == 48480);
    }

    @Test
    public void test8065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8065");
        int int2 = sum.Toplama.sum(14487, 41812);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56299 + "'", int2 == 56299);
    }

    @Test
    public void test8066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8066");
        int int2 = sum.Toplama.sum(39495, 36069);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 75564 + "'", int2 == 75564);
    }

    @Test
    public void test8067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8067");
        int int2 = sum.Toplama.sum(71900, 23468);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 95368 + "'", int2 == 95368);
    }

    @Test
    public void test8068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8068");
        int int2 = sum.Toplama.sum(40782, 98069);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 138851 + "'", int2 == 138851);
    }

    @Test
    public void test8069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8069");
        int int2 = sum.Toplama.sum(22769, 7488);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30257 + "'", int2 == 30257);
    }

    @Test
    public void test8070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8070");
        int int2 = sum.Toplama.sum(8969, 37396);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46365 + "'", int2 == 46365);
    }

    @Test
    public void test8071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8071");
        int int2 = sum.Toplama.sum(12151, 195349);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 207500 + "'", int2 == 207500);
    }

    @Test
    public void test8072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8072");
        int int2 = sum.Toplama.sum(10939, 17280);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28219 + "'", int2 == 28219);
    }

    @Test
    public void test8073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8073");
        int int2 = sum.Toplama.sum(1727, 6659);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8386 + "'", int2 == 8386);
    }

    @Test
    public void test8074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8074");
        int int2 = sum.Toplama.sum(6528, 59780);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 66308 + "'", int2 == 66308);
    }

    @Test
    public void test8075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8075");
        int int2 = sum.Toplama.sum(26930, 5764);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32694 + "'", int2 == 32694);
    }

    @Test
    public void test8076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8076");
        int int2 = sum.Toplama.sum(12777, 33396);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46173 + "'", int2 == 46173);
    }

    @Test
    public void test8077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8077");
        int int2 = sum.Toplama.sum(19121, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19121 + "'", int2 == 19121);
    }

    @Test
    public void test8078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8078");
        int int2 = sum.Toplama.sum(8740, 25627);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34367 + "'", int2 == 34367);
    }

    @Test
    public void test8079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8079");
        int int2 = sum.Toplama.sum(27898, 8895);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36793 + "'", int2 == 36793);
    }

    @Test
    public void test8080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8080");
        int int2 = sum.Toplama.sum(57734, 38986);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96720 + "'", int2 == 96720);
    }

    @Test
    public void test8081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8081");
        int int2 = sum.Toplama.sum(7669, 1398);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9067 + "'", int2 == 9067);
    }

    @Test
    public void test8082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8082");
        int int2 = sum.Toplama.sum(121018, 24228);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 145246 + "'", int2 == 145246);
    }

    @Test
    public void test8083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8083");
        int int2 = sum.Toplama.sum(31301, 2952);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34253 + "'", int2 == 34253);
    }

    @Test
    public void test8084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8084");
        int int2 = sum.Toplama.sum(8912, 1249);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10161 + "'", int2 == 10161);
    }

    @Test
    public void test8085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8085");
        int int2 = sum.Toplama.sum(7083, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7083 + "'", int2 == 7083);
    }

    @Test
    public void test8086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8086");
        int int2 = sum.Toplama.sum(59275, 65088);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 124363 + "'", int2 == 124363);
    }

    @Test
    public void test8087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8087");
        int int2 = sum.Toplama.sum(13874, 13929);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27803 + "'", int2 == 27803);
    }

    @Test
    public void test8088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8088");
        int int2 = sum.Toplama.sum(6677, 449);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7126 + "'", int2 == 7126);
    }

    @Test
    public void test8089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8089");
        int int2 = sum.Toplama.sum(40564, 26121);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 66685 + "'", int2 == 66685);
    }

    @Test
    public void test8090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8090");
        int int2 = sum.Toplama.sum(112907, 42476);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 155383 + "'", int2 == 155383);
    }

    @Test
    public void test8091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8091");
        int int2 = sum.Toplama.sum(27704, 42080);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69784 + "'", int2 == 69784);
    }

    @Test
    public void test8092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8092");
        int int2 = sum.Toplama.sum(22797, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22797 + "'", int2 == 22797);
    }

    @Test
    public void test8093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8093");
        int int2 = sum.Toplama.sum(51795, 8228);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60023 + "'", int2 == 60023);
    }

    @Test
    public void test8094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8094");
        int int2 = sum.Toplama.sum(207271, 25825);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 233096 + "'", int2 == 233096);
    }

    @Test
    public void test8095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8095");
        int int2 = sum.Toplama.sum(4527, 28460);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32987 + "'", int2 == 32987);
    }

    @Test
    public void test8096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8096");
        int int2 = sum.Toplama.sum(97193, 5670);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 102863 + "'", int2 == 102863);
    }

    @Test
    public void test8097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8097");
        int int2 = sum.Toplama.sum(138851, 55189);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 194040 + "'", int2 == 194040);
    }

    @Test
    public void test8098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8098");
        int int2 = sum.Toplama.sum(10940, 7053);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17993 + "'", int2 == 17993);
    }

    @Test
    public void test8099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8099");
        int int2 = sum.Toplama.sum(27650, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27650 + "'", int2 == 27650);
    }

    @Test
    public void test8100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8100");
        int int2 = sum.Toplama.sum(55074, 22140);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 77214 + "'", int2 == 77214);
    }

    @Test
    public void test8101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8101");
        int int2 = sum.Toplama.sum(0, 17870);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17870 + "'", int2 == 17870);
    }

    @Test
    public void test8102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8102");
        int int2 = sum.Toplama.sum(75338, 54791);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 130129 + "'", int2 == 130129);
    }

    @Test
    public void test8103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8103");
        int int2 = sum.Toplama.sum(18893, 15824);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34717 + "'", int2 == 34717);
    }

    @Test
    public void test8104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8104");
        int int2 = sum.Toplama.sum(26288, 31832);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58120 + "'", int2 == 58120);
    }

    @Test
    public void test8105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8105");
        int int2 = sum.Toplama.sum(10663, 5116);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15779 + "'", int2 == 15779);
    }

    @Test
    public void test8106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8106");
        int int2 = sum.Toplama.sum(543, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 543 + "'", int2 == 543);
    }

    @Test
    public void test8107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8107");
        int int2 = sum.Toplama.sum(10166, 36360);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46526 + "'", int2 == 46526);
    }

    @Test
    public void test8108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8108");
        int int2 = sum.Toplama.sum(30781, 10079);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40860 + "'", int2 == 40860);
    }

    @Test
    public void test8109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8109");
        int int2 = sum.Toplama.sum(39969, 4504);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44473 + "'", int2 == 44473);
    }

    @Test
    public void test8110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8110");
        int int2 = sum.Toplama.sum(16855, 1768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18623 + "'", int2 == 18623);
    }

    @Test
    public void test8111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8111");
        int int2 = sum.Toplama.sum(56323, 4582);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60905 + "'", int2 == 60905);
    }

    @Test
    public void test8112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8112");
        int int2 = sum.Toplama.sum(23778, 37079);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60857 + "'", int2 == 60857);
    }

    @Test
    public void test8113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8113");
        int int2 = sum.Toplama.sum(8901, 12004);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20905 + "'", int2 == 20905);
    }

    @Test
    public void test8114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8114");
        int int2 = sum.Toplama.sum(5107, 31856);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36963 + "'", int2 == 36963);
    }

    @Test
    public void test8115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8115");
        int int2 = sum.Toplama.sum(3692, 58480);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62172 + "'", int2 == 62172);
    }

    @Test
    public void test8116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8116");
        int int2 = sum.Toplama.sum(7215, 45165);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52380 + "'", int2 == 52380);
    }

    @Test
    public void test8117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8117");
        int int2 = sum.Toplama.sum(1010, 56747);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57757 + "'", int2 == 57757);
    }

    @Test
    public void test8118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8118");
        int int2 = sum.Toplama.sum(12475, 53327);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 65802 + "'", int2 == 65802);
    }

    @Test
    public void test8119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8119");
        int int2 = sum.Toplama.sum(24365, 67258);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 91623 + "'", int2 == 91623);
    }

    @Test
    public void test8120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8120");
        int int2 = sum.Toplama.sum(40897, 37070);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 77967 + "'", int2 == 77967);
    }

    @Test
    public void test8121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8121");
        int int2 = sum.Toplama.sum(35859, 7072);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42931 + "'", int2 == 42931);
    }

    @Test
    public void test8122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8122");
        int int2 = sum.Toplama.sum(20585, 51123);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 71708 + "'", int2 == 71708);
    }

    @Test
    public void test8123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8123");
        int int2 = sum.Toplama.sum(25879, 35028);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60907 + "'", int2 == 60907);
    }

    @Test
    public void test8124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8124");
        int int2 = sum.Toplama.sum(252, 62967);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63219 + "'", int2 == 63219);
    }

    @Test
    public void test8125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8125");
        int int2 = sum.Toplama.sum(24632, 20750);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45382 + "'", int2 == 45382);
    }

    @Test
    public void test8126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8126");
        int int2 = sum.Toplama.sum(11444, 41689);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53133 + "'", int2 == 53133);
    }

    @Test
    public void test8127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8127");
        int int2 = sum.Toplama.sum(2973, 1342);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4315 + "'", int2 == 4315);
    }

    @Test
    public void test8128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8128");
        int int2 = sum.Toplama.sum(49278, 2741);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52019 + "'", int2 == 52019);
    }

    @Test
    public void test8129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8129");
        int int2 = sum.Toplama.sum(33773, 1270);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35043 + "'", int2 == 35043);
    }

    @Test
    public void test8130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8130");
        int int2 = sum.Toplama.sum(16101, 14477);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30578 + "'", int2 == 30578);
    }

    @Test
    public void test8131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8131");
        int int2 = sum.Toplama.sum(25958, 45879);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 71837 + "'", int2 == 71837);
    }

    @Test
    public void test8132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8132");
        int int2 = sum.Toplama.sum(6586, 6843);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13429 + "'", int2 == 13429);
    }

    @Test
    public void test8133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8133");
        int int2 = sum.Toplama.sum(22140, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22140 + "'", int2 == 22140);
    }

    @Test
    public void test8134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8134");
        int int2 = sum.Toplama.sum(4445, 40535);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44980 + "'", int2 == 44980);
    }

    @Test
    public void test8135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8135");
        int int2 = sum.Toplama.sum(45502, 27286);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72788 + "'", int2 == 72788);
    }

    @Test
    public void test8136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8136");
        int int2 = sum.Toplama.sum(2788, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2788 + "'", int2 == 2788);
    }

    @Test
    public void test8137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8137");
        int int2 = sum.Toplama.sum(4738, 10813);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15551 + "'", int2 == 15551);
    }

    @Test
    public void test8138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8138");
        int int2 = sum.Toplama.sum(12345, 9308);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21653 + "'", int2 == 21653);
    }

    @Test
    public void test8139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8139");
        int int2 = sum.Toplama.sum(29816, 19121);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48937 + "'", int2 == 48937);
    }

    @Test
    public void test8140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8140");
        int int2 = sum.Toplama.sum(9127, 4640);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13767 + "'", int2 == 13767);
    }

    @Test
    public void test8141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8141");
        int int2 = sum.Toplama.sum(39677, 33956);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 73633 + "'", int2 == 73633);
    }

    @Test
    public void test8142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8142");
        int int2 = sum.Toplama.sum(6080, 45954);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52034 + "'", int2 == 52034);
    }

    @Test
    public void test8143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8143");
        int int2 = sum.Toplama.sum(0, 999);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 999 + "'", int2 == 999);
    }

    @Test
    public void test8144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8144");
        int int2 = sum.Toplama.sum(38294, 12427);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50721 + "'", int2 == 50721);
    }

    @Test
    public void test8145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8145");
        int int2 = sum.Toplama.sum(889, 30401);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31290 + "'", int2 == 31290);
    }

    @Test
    public void test8146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8146");
        int int2 = sum.Toplama.sum(19320, 24729);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44049 + "'", int2 == 44049);
    }

    @Test
    public void test8147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8147");
        int int2 = sum.Toplama.sum(21007, 43116);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64123 + "'", int2 == 64123);
    }

    @Test
    public void test8148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8148");
        int int2 = sum.Toplama.sum(28871, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28871 + "'", int2 == 28871);
    }

    @Test
    public void test8149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8149");
        int int2 = sum.Toplama.sum(31284, 27349);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58633 + "'", int2 == 58633);
    }

    @Test
    public void test8150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8150");
        int int2 = sum.Toplama.sum(5670, 21893);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27563 + "'", int2 == 27563);
    }

    @Test
    public void test8151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8151");
        int int2 = sum.Toplama.sum(30434, 20098);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50532 + "'", int2 == 50532);
    }

    @Test
    public void test8152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8152");
        int int2 = sum.Toplama.sum(72134, 58041);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 130175 + "'", int2 == 130175);
    }

    @Test
    public void test8153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8153");
        int int2 = sum.Toplama.sum(61662, 67743);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 129405 + "'", int2 == 129405);
    }

    @Test
    public void test8154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8154");
        int int2 = sum.Toplama.sum(18503, 91485);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 109988 + "'", int2 == 109988);
    }

    @Test
    public void test8155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8155");
        int int2 = sum.Toplama.sum(13811, 3036);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16847 + "'", int2 == 16847);
    }

    @Test
    public void test8156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8156");
        int int2 = sum.Toplama.sum(6725, 18312);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25037 + "'", int2 == 25037);
    }

    @Test
    public void test8157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8157");
        int int2 = sum.Toplama.sum(24376, 427);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24803 + "'", int2 == 24803);
    }

    @Test
    public void test8158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8158");
        int int2 = sum.Toplama.sum(14576, 35270);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49846 + "'", int2 == 49846);
    }

    @Test
    public void test8159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8159");
        int int2 = sum.Toplama.sum(2616, 6141);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8757 + "'", int2 == 8757);
    }

    @Test
    public void test8160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8160");
        int int2 = sum.Toplama.sum(32019, 4327);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36346 + "'", int2 == 36346);
    }

    @Test
    public void test8161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8161");
        int int2 = sum.Toplama.sum(41541, 21485);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63026 + "'", int2 == 63026);
    }

    @Test
    public void test8162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8162");
        int int2 = sum.Toplama.sum(10694, 1387);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12081 + "'", int2 == 12081);
    }

    @Test
    public void test8163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8163");
        int int2 = sum.Toplama.sum(21381, 65088);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 86469 + "'", int2 == 86469);
    }

    @Test
    public void test8164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8164");
        int int2 = sum.Toplama.sum(18622, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18622 + "'", int2 == 18622);
    }

    @Test
    public void test8165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8165");
        int int2 = sum.Toplama.sum(4659, 11126);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15785 + "'", int2 == 15785);
    }

    @Test
    public void test8166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8166");
        int int2 = sum.Toplama.sum(6874, 6017);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12891 + "'", int2 == 12891);
    }

    @Test
    public void test8167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8167");
        int int2 = sum.Toplama.sum(86716, 4453);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 91169 + "'", int2 == 91169);
    }

    @Test
    public void test8168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8168");
        int int2 = sum.Toplama.sum(42315, 35642);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 77957 + "'", int2 == 77957);
    }

    @Test
    public void test8169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8169");
        int int2 = sum.Toplama.sum(24205, 34115);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58320 + "'", int2 == 58320);
    }

    @Test
    public void test8170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8170");
        int int2 = sum.Toplama.sum(34322, 2792);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37114 + "'", int2 == 37114);
    }

    @Test
    public void test8171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8171");
        int int2 = sum.Toplama.sum(36270, 332);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36602 + "'", int2 == 36602);
    }

    @Test
    public void test8172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8172");
        int int2 = sum.Toplama.sum(39909, 761);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40670 + "'", int2 == 40670);
    }

    @Test
    public void test8173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8173");
        int int2 = sum.Toplama.sum(88739, 10415);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99154 + "'", int2 == 99154);
    }

    @Test
    public void test8174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8174");
        int int2 = sum.Toplama.sum(11416, 2660);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14076 + "'", int2 == 14076);
    }

    @Test
    public void test8175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8175");
        int int2 = sum.Toplama.sum(10105, 9156);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19261 + "'", int2 == 19261);
    }

    @Test
    public void test8176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8176");
        int int2 = sum.Toplama.sum(7024, 20356);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27380 + "'", int2 == 27380);
    }

    @Test
    public void test8177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8177");
        int int2 = sum.Toplama.sum(31644, 38412);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70056 + "'", int2 == 70056);
    }

    @Test
    public void test8178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8178");
        int int2 = sum.Toplama.sum(33716, 999);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34715 + "'", int2 == 34715);
    }

    @Test
    public void test8179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8179");
        int int2 = sum.Toplama.sum(650, 6092);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6742 + "'", int2 == 6742);
    }

    @Test
    public void test8180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8180");
        int int2 = sum.Toplama.sum(27591, 14171);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41762 + "'", int2 == 41762);
    }

    @Test
    public void test8181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8181");
        int int2 = sum.Toplama.sum(2932, 55144);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58076 + "'", int2 == 58076);
    }

    @Test
    public void test8182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8182");
        int int2 = sum.Toplama.sum(3431, 2994);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6425 + "'", int2 == 6425);
    }

    @Test
    public void test8183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8183");
        int int2 = sum.Toplama.sum(6556, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6556 + "'", int2 == 6556);
    }

    @Test
    public void test8184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8184");
        int int2 = sum.Toplama.sum(25253, 8028);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33281 + "'", int2 == 33281);
    }

    @Test
    public void test8185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8185");
        int int2 = sum.Toplama.sum(40019, 17445);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57464 + "'", int2 == 57464);
    }

    @Test
    public void test8186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8186");
        int int2 = sum.Toplama.sum(29634, 9868);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39502 + "'", int2 == 39502);
    }

    @Test
    public void test8187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8187");
        int int2 = sum.Toplama.sum(28604, 42263);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70867 + "'", int2 == 70867);
    }

    @Test
    public void test8188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8188");
        int int2 = sum.Toplama.sum(15673, 86818);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 102491 + "'", int2 == 102491);
    }

    @Test
    public void test8189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8189");
        int int2 = sum.Toplama.sum(26409, 28734);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55143 + "'", int2 == 55143);
    }

    @Test
    public void test8190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8190");
        int int2 = sum.Toplama.sum(65220, 61853);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 127073 + "'", int2 == 127073);
    }

    @Test
    public void test8191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8191");
        int int2 = sum.Toplama.sum(9664, 28371);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38035 + "'", int2 == 38035);
    }

    @Test
    public void test8192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8192");
        int int2 = sum.Toplama.sum(14809, 2950);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17759 + "'", int2 == 17759);
    }

    @Test
    public void test8193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8193");
        int int2 = sum.Toplama.sum(84999, 52274);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 137273 + "'", int2 == 137273);
    }

    @Test
    public void test8194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8194");
        int int2 = sum.Toplama.sum(6905, 51870);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58775 + "'", int2 == 58775);
    }

    @Test
    public void test8195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8195");
        int int2 = sum.Toplama.sum(5780, 13340);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19120 + "'", int2 == 19120);
    }

    @Test
    public void test8196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8196");
        int int2 = sum.Toplama.sum(20004, 6051);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26055 + "'", int2 == 26055);
    }

    @Test
    public void test8197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8197");
        int int2 = sum.Toplama.sum(8740, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8740 + "'", int2 == 8740);
    }

    @Test
    public void test8198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8198");
        int int2 = sum.Toplama.sum(57379, 14253);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 71632 + "'", int2 == 71632);
    }

    @Test
    public void test8199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8199");
        int int2 = sum.Toplama.sum(5382, 30470);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35852 + "'", int2 == 35852);
    }

    @Test
    public void test8200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8200");
        int int2 = sum.Toplama.sum(32881, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32881 + "'", int2 == 32881);
    }

    @Test
    public void test8201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8201");
        int int2 = sum.Toplama.sum(59792, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59792 + "'", int2 == 59792);
    }

    @Test
    public void test8202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8202");
        int int2 = sum.Toplama.sum(31406, 6278);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37684 + "'", int2 == 37684);
    }

    @Test
    public void test8203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8203");
        int int2 = sum.Toplama.sum(60884, 46177);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 107061 + "'", int2 == 107061);
    }

    @Test
    public void test8204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8204");
        int int2 = sum.Toplama.sum(30757, 45204);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 75961 + "'", int2 == 75961);
    }

    @Test
    public void test8205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8205");
        int int2 = sum.Toplama.sum(23833, 27803);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51636 + "'", int2 == 51636);
    }

    @Test
    public void test8206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8206");
        int int2 = sum.Toplama.sum(10074, 43543);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53617 + "'", int2 == 53617);
    }

    @Test
    public void test8207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8207");
        int int2 = sum.Toplama.sum(8556, 14002);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22558 + "'", int2 == 22558);
    }

    @Test
    public void test8208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8208");
        int int2 = sum.Toplama.sum(25316, 9590);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34906 + "'", int2 == 34906);
    }

    @Test
    public void test8209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8209");
        int int2 = sum.Toplama.sum(3277, 31403);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34680 + "'", int2 == 34680);
    }

    @Test
    public void test8210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8210");
        int int2 = sum.Toplama.sum(40897, 55848);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96745 + "'", int2 == 96745);
    }

    @Test
    public void test8211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8211");
        int int2 = sum.Toplama.sum(54710, 26496);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 81206 + "'", int2 == 81206);
    }

    @Test
    public void test8212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8212");
        int int2 = sum.Toplama.sum(13372, 3431);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16803 + "'", int2 == 16803);
    }

    @Test
    public void test8213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8213");
        int int2 = sum.Toplama.sum(12927, 902);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13829 + "'", int2 == 13829);
    }

    @Test
    public void test8214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8214");
        int int2 = sum.Toplama.sum(1378, 39892);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41270 + "'", int2 == 41270);
    }

    @Test
    public void test8215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8215");
        int int2 = sum.Toplama.sum(32713, 6808);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39521 + "'", int2 == 39521);
    }

    @Test
    public void test8216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8216");
        int int2 = sum.Toplama.sum(46419, 3409);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49828 + "'", int2 == 49828);
    }

    @Test
    public void test8217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8217");
        int int2 = sum.Toplama.sum(7745, 18525);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26270 + "'", int2 == 26270);
    }

    @Test
    public void test8218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8218");
        int int2 = sum.Toplama.sum(47725, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47725 + "'", int2 == 47725);
    }

    @Test
    public void test8219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8219");
        int int2 = sum.Toplama.sum(45278, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45278 + "'", int2 == 45278);
    }

    @Test
    public void test8220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8220");
        int int2 = sum.Toplama.sum(19607, 2150);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21757 + "'", int2 == 21757);
    }

    @Test
    public void test8221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8221");
        int int2 = sum.Toplama.sum(10888, 20865);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31753 + "'", int2 == 31753);
    }

    @Test
    public void test8222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8222");
        int int2 = sum.Toplama.sum(31841, 18353);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50194 + "'", int2 == 50194);
    }

    @Test
    public void test8223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8223");
        int int2 = sum.Toplama.sum(40897, 30280);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 71177 + "'", int2 == 71177);
    }

    @Test
    public void test8224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8224");
        int int2 = sum.Toplama.sum(3593, 2735);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6328 + "'", int2 == 6328);
    }

    @Test
    public void test8225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8225");
        int int2 = sum.Toplama.sum(475, 51291);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51766 + "'", int2 == 51766);
    }

    @Test
    public void test8226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8226");
        int int2 = sum.Toplama.sum(1995, 17613);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19608 + "'", int2 == 19608);
    }

    @Test
    public void test8227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8227");
        int int2 = sum.Toplama.sum(145246, 13150);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 158396 + "'", int2 == 158396);
    }

    @Test
    public void test8228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8228");
        int int2 = sum.Toplama.sum(60667, 22475);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 83142 + "'", int2 == 83142);
    }

    @Test
    public void test8229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8229");
        int int2 = sum.Toplama.sum(1238, 28672);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29910 + "'", int2 == 29910);
    }

    @Test
    public void test8230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8230");
        int int2 = sum.Toplama.sum(30720, 24228);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54948 + "'", int2 == 54948);
    }

    @Test
    public void test8231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8231");
        int int2 = sum.Toplama.sum(34758, 107061);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 141819 + "'", int2 == 141819);
    }

    @Test
    public void test8232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8232");
        int int2 = sum.Toplama.sum(11922, 6882);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18804 + "'", int2 == 18804);
    }

    @Test
    public void test8233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8233");
        int int2 = sum.Toplama.sum(43116, 55414);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 98530 + "'", int2 == 98530);
    }

    @Test
    public void test8234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8234");
        int int2 = sum.Toplama.sum(25266, 1270);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26536 + "'", int2 == 26536);
    }

    @Test
    public void test8235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8235");
        int int2 = sum.Toplama.sum(11572, 91623);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 103195 + "'", int2 == 103195);
    }

    @Test
    public void test8236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8236");
        int int2 = sum.Toplama.sum(45093, 57503);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 102596 + "'", int2 == 102596);
    }

    @Test
    public void test8237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8237");
        int int2 = sum.Toplama.sum(508, 3262);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3770 + "'", int2 == 3770);
    }

    @Test
    public void test8238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8238");
        int int2 = sum.Toplama.sum(623, 40854);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41477 + "'", int2 == 41477);
    }

    @Test
    public void test8239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8239");
        int int2 = sum.Toplama.sum(21694, 11055);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32749 + "'", int2 == 32749);
    }

    @Test
    public void test8240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8240");
        int int2 = sum.Toplama.sum(38256, 37590);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 75846 + "'", int2 == 75846);
    }

    @Test
    public void test8241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8241");
        int int2 = sum.Toplama.sum(51782, 28980);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80762 + "'", int2 == 80762);
    }

    @Test
    public void test8242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8242");
        int int2 = sum.Toplama.sum(31249, 2949);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34198 + "'", int2 == 34198);
    }

    @Test
    public void test8243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8243");
        int int2 = sum.Toplama.sum(21067, 7376);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28443 + "'", int2 == 28443);
    }

    @Test
    public void test8244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8244");
        int int2 = sum.Toplama.sum(15180, 13466);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28646 + "'", int2 == 28646);
    }

    @Test
    public void test8245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8245");
        int int2 = sum.Toplama.sum(642, 7053);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7695 + "'", int2 == 7695);
    }

    @Test
    public void test8246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8246");
        int int2 = sum.Toplama.sum(691, 11734);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12425 + "'", int2 == 12425);
    }

    @Test
    public void test8247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8247");
        int int2 = sum.Toplama.sum(6659, 6275);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12934 + "'", int2 == 12934);
    }

    @Test
    public void test8248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8248");
        int int2 = sum.Toplama.sum(26936, 29952);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56888 + "'", int2 == 56888);
    }

    @Test
    public void test8249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8249");
        int int2 = sum.Toplama.sum(3026, 12081);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15107 + "'", int2 == 15107);
    }

    @Test
    public void test8250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8250");
        int int2 = sum.Toplama.sum(29758, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29758 + "'", int2 == 29758);
    }

    @Test
    public void test8251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8251");
        int int2 = sum.Toplama.sum(78739, 16579);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 95318 + "'", int2 == 95318);
    }

    @Test
    public void test8252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8252");
        int int2 = sum.Toplama.sum(3844, 6954);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10798 + "'", int2 == 10798);
    }

    @Test
    public void test8253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8253");
        int int2 = sum.Toplama.sum(28373, 1468);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29841 + "'", int2 == 29841);
    }

    @Test
    public void test8254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8254");
        int int2 = sum.Toplama.sum(54358, 12309);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 66667 + "'", int2 == 66667);
    }

    @Test
    public void test8255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8255");
        int int2 = sum.Toplama.sum(45254, 7296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52550 + "'", int2 == 52550);
    }

    @Test
    public void test8256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8256");
        int int2 = sum.Toplama.sum(4527, 1954);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6481 + "'", int2 == 6481);
    }

    @Test
    public void test8257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8257");
        int int2 = sum.Toplama.sum(25037, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25037 + "'", int2 == 25037);
    }

    @Test
    public void test8258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8258");
        int int2 = sum.Toplama.sum(0, 21067);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21067 + "'", int2 == 21067);
    }

    @Test
    public void test8259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8259");
        int int2 = sum.Toplama.sum(394, 71918);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72312 + "'", int2 == 72312);
    }

    @Test
    public void test8260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8260");
        int int2 = sum.Toplama.sum(19130, 5807);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24937 + "'", int2 == 24937);
    }

    @Test
    public void test8261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8261");
        int int2 = sum.Toplama.sum(15920, 1271);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17191 + "'", int2 == 17191);
    }

    @Test
    public void test8262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8262");
        int int2 = sum.Toplama.sum(10565, 50425);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60990 + "'", int2 == 60990);
    }

    @Test
    public void test8263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8263");
        int int2 = sum.Toplama.sum(1331, 30230);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31561 + "'", int2 == 31561);
    }

    @Test
    public void test8264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8264");
        int int2 = sum.Toplama.sum(20132, 7337);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27469 + "'", int2 == 27469);
    }

    @Test
    public void test8265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8265");
        int int2 = sum.Toplama.sum(27757, 70476);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 98233 + "'", int2 == 98233);
    }

    @Test
    public void test8266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8266");
        int int2 = sum.Toplama.sum(36376, 12290);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48666 + "'", int2 == 48666);
    }

    @Test
    public void test8267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8267");
        int int2 = sum.Toplama.sum(1631, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1631 + "'", int2 == 1631);
    }

    @Test
    public void test8268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8268");
        int int2 = sum.Toplama.sum(233096, 22251);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255347 + "'", int2 == 255347);
    }

    @Test
    public void test8269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8269");
        int int2 = sum.Toplama.sum(39365, 8445);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47810 + "'", int2 == 47810);
    }

    @Test
    public void test8270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8270");
        int int2 = sum.Toplama.sum(100309, 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100320 + "'", int2 == 100320);
    }

    @Test
    public void test8271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8271");
        int int2 = sum.Toplama.sum(93782, 34494);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 128276 + "'", int2 == 128276);
    }

    @Test
    public void test8272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8272");
        int int2 = sum.Toplama.sum(6142, 7022);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13164 + "'", int2 == 13164);
    }

    @Test
    public void test8273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8273");
        int int2 = sum.Toplama.sum(54286, 35320);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 89606 + "'", int2 == 89606);
    }

    @Test
    public void test8274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8274");
        int int2 = sum.Toplama.sum(21117, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21117 + "'", int2 == 21117);
    }

    @Test
    public void test8275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8275");
        int int2 = sum.Toplama.sum(13593, 20088);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33681 + "'", int2 == 33681);
    }

    @Test
    public void test8276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8276");
        int int2 = sum.Toplama.sum(9396, 42536);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51932 + "'", int2 == 51932);
    }

    @Test
    public void test8277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8277");
        int int2 = sum.Toplama.sum(27198, 1006);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28204 + "'", int2 == 28204);
    }

    @Test
    public void test8278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8278");
        int int2 = sum.Toplama.sum(497, 61522);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62019 + "'", int2 == 62019);
    }

    @Test
    public void test8279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8279");
        int int2 = sum.Toplama.sum(30734, 130977);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 161711 + "'", int2 == 161711);
    }

    @Test
    public void test8280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8280");
        int int2 = sum.Toplama.sum(29844, 18251);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48095 + "'", int2 == 48095);
    }

    @Test
    public void test8281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8281");
        int int2 = sum.Toplama.sum(48480, 8448);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56928 + "'", int2 == 56928);
    }

    @Test
    public void test8282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8282");
        int int2 = sum.Toplama.sum(10558, 42895);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53453 + "'", int2 == 53453);
    }

    @Test
    public void test8283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8283");
        int int2 = sum.Toplama.sum(4808, 45639);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50447 + "'", int2 == 50447);
    }

    @Test
    public void test8284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8284");
        int int2 = sum.Toplama.sum(51123, 15182);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 66305 + "'", int2 == 66305);
    }

    @Test
    public void test8285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8285");
        int int2 = sum.Toplama.sum(806, 25476);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26282 + "'", int2 == 26282);
    }

    @Test
    public void test8286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8286");
        int int2 = sum.Toplama.sum(3990, 89573);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 93563 + "'", int2 == 93563);
    }

    @Test
    public void test8287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8287");
        int int2 = sum.Toplama.sum(8532, 15141);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23673 + "'", int2 == 23673);
    }

    @Test
    public void test8288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8288");
        int int2 = sum.Toplama.sum(34809, 20808);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55617 + "'", int2 == 55617);
    }

    @Test
    public void test8289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8289");
        int int2 = sum.Toplama.sum(11383, 90039);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 101422 + "'", int2 == 101422);
    }

    @Test
    public void test8290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8290");
        int int2 = sum.Toplama.sum(112975, 6638);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 119613 + "'", int2 == 119613);
    }

    @Test
    public void test8291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8291");
        int int2 = sum.Toplama.sum(11524, 9224);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20748 + "'", int2 == 20748);
    }

    @Test
    public void test8292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8292");
        int int2 = sum.Toplama.sum(6243, 74243);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80486 + "'", int2 == 80486);
    }

    @Test
    public void test8293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8293");
        int int2 = sum.Toplama.sum(159579, 91485);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 251064 + "'", int2 == 251064);
    }

    @Test
    public void test8294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8294");
        int int2 = sum.Toplama.sum(3716, 5089);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8805 + "'", int2 == 8805);
    }

    @Test
    public void test8295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8295");
        int int2 = sum.Toplama.sum(17118, 9396);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26514 + "'", int2 == 26514);
    }

    @Test
    public void test8296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8296");
        int int2 = sum.Toplama.sum(2862, 58706);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61568 + "'", int2 == 61568);
    }

    @Test
    public void test8297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8297");
        int int2 = sum.Toplama.sum(0, 15575);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15575 + "'", int2 == 15575);
    }

    @Test
    public void test8298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8298");
        int int2 = sum.Toplama.sum(38005, 7495);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45500 + "'", int2 == 45500);
    }

    @Test
    public void test8299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8299");
        int int2 = sum.Toplama.sum(17945, 18207);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36152 + "'", int2 == 36152);
    }

    @Test
    public void test8300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8300");
        int int2 = sum.Toplama.sum(81071, 76386);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 157457 + "'", int2 == 157457);
    }

    @Test
    public void test8301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8301");
        int int2 = sum.Toplama.sum(4539, 10611);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15150 + "'", int2 == 15150);
    }

    @Test
    public void test8302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8302");
        int int2 = sum.Toplama.sum(8153, 27527);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35680 + "'", int2 == 35680);
    }

    @Test
    public void test8303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8303");
        int int2 = sum.Toplama.sum(13949, 33789);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47738 + "'", int2 == 47738);
    }

    @Test
    public void test8304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8304");
        int int2 = sum.Toplama.sum(60085, 39294);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99379 + "'", int2 == 99379);
    }

    @Test
    public void test8305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8305");
        int int2 = sum.Toplama.sum(1265, 49289);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50554 + "'", int2 == 50554);
    }

    @Test
    public void test8306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8306");
        int int2 = sum.Toplama.sum(25704, 2459);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28163 + "'", int2 == 28163);
    }

    @Test
    public void test8307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8307");
        int int2 = sum.Toplama.sum(44582, 14730);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59312 + "'", int2 == 59312);
    }

    @Test
    public void test8308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8308");
        int int2 = sum.Toplama.sum(1955, 31622);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33577 + "'", int2 == 33577);
    }

    @Test
    public void test8309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8309");
        int int2 = sum.Toplama.sum(10990, 65487);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 76477 + "'", int2 == 76477);
    }

    @Test
    public void test8310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8310");
        int int2 = sum.Toplama.sum(41165, 3740);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44905 + "'", int2 == 44905);
    }

    @Test
    public void test8311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8311");
        int int2 = sum.Toplama.sum(17662, 6957);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24619 + "'", int2 == 24619);
    }

    @Test
    public void test8312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8312");
        int int2 = sum.Toplama.sum(18864, 14791);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33655 + "'", int2 == 33655);
    }

    @Test
    public void test8313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8313");
        int int2 = sum.Toplama.sum(31157, 5299);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36456 + "'", int2 == 36456);
    }

    @Test
    public void test8314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8314");
        int int2 = sum.Toplama.sum(544, 36602);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37146 + "'", int2 == 37146);
    }

    @Test
    public void test8315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8315");
        int int2 = sum.Toplama.sum(49114, 39521);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 88635 + "'", int2 == 88635);
    }

    @Test
    public void test8316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8316");
        int int2 = sum.Toplama.sum(0, 148889);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 148889 + "'", int2 == 148889);
    }

    @Test
    public void test8317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8317");
        int int2 = sum.Toplama.sum(63217, 26874);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90091 + "'", int2 == 90091);
    }

    @Test
    public void test8318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8318");
        int int2 = sum.Toplama.sum(7125, 39077);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46202 + "'", int2 == 46202);
    }

    @Test
    public void test8319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8319");
        int int2 = sum.Toplama.sum(105966, 11680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 117646 + "'", int2 == 117646);
    }

    @Test
    public void test8320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8320");
        int int2 = sum.Toplama.sum(11572, 51587);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63159 + "'", int2 == 63159);
    }

    @Test
    public void test8321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8321");
        int int2 = sum.Toplama.sum(11921, 36321);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48242 + "'", int2 == 48242);
    }

    @Test
    public void test8322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8322");
        int int2 = sum.Toplama.sum(73364, 23263);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96627 + "'", int2 == 96627);
    }

    @Test
    public void test8323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8323");
        int int2 = sum.Toplama.sum(2986, 15492);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18478 + "'", int2 == 18478);
    }

    @Test
    public void test8324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8324");
        int int2 = sum.Toplama.sum(21278, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21278 + "'", int2 == 21278);
    }

    @Test
    public void test8325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8325");
        int int2 = sum.Toplama.sum(29414, 20917);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50331 + "'", int2 == 50331);
    }

    @Test
    public void test8326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8326");
        int int2 = sum.Toplama.sum(1, 24591);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24592 + "'", int2 == 24592);
    }

    @Test
    public void test8327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8327");
        int int2 = sum.Toplama.sum(22613, 9989);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32602 + "'", int2 == 32602);
    }

    @Test
    public void test8328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8328");
        int int2 = sum.Toplama.sum(0, 20548);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20548 + "'", int2 == 20548);
    }

    @Test
    public void test8329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8329");
        int int2 = sum.Toplama.sum(940, 50881);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51821 + "'", int2 == 51821);
    }

    @Test
    public void test8330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8330");
        int int2 = sum.Toplama.sum(19294, 1265);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20559 + "'", int2 == 20559);
    }

    @Test
    public void test8331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8331");
        int int2 = sum.Toplama.sum(41332, 97437);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 138769 + "'", int2 == 138769);
    }

    @Test
    public void test8332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8332");
        int int2 = sum.Toplama.sum(509, 1101);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1610 + "'", int2 == 1610);
    }

    @Test
    public void test8333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8333");
        int int2 = sum.Toplama.sum(1536, 3959);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5495 + "'", int2 == 5495);
    }

    @Test
    public void test8334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8334");
        int int2 = sum.Toplama.sum(47676, 33680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 81356 + "'", int2 == 81356);
    }

    @Test
    public void test8335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8335");
        int int2 = sum.Toplama.sum(12290, 7585);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19875 + "'", int2 == 19875);
    }

    @Test
    public void test8336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8336");
        int int2 = sum.Toplama.sum(11793, 38970);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50763 + "'", int2 == 50763);
    }

    @Test
    public void test8337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8337");
        int int2 = sum.Toplama.sum(26409, 25759);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52168 + "'", int2 == 52168);
    }

    @Test
    public void test8338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8338");
        int int2 = sum.Toplama.sum(0, 21699);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21699 + "'", int2 == 21699);
    }

    @Test
    public void test8339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8339");
        int int2 = sum.Toplama.sum(28253, 8943);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37196 + "'", int2 == 37196);
    }

    @Test
    public void test8340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8340");
        int int2 = sum.Toplama.sum(5276, 47768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53044 + "'", int2 == 53044);
    }

    @Test
    public void test8341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8341");
        int int2 = sum.Toplama.sum(45837, 11174);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57011 + "'", int2 == 57011);
    }

    @Test
    public void test8342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8342");
        int int2 = sum.Toplama.sum(15967, 1832);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17799 + "'", int2 == 17799);
    }

    @Test
    public void test8343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8343");
        int int2 = sum.Toplama.sum(46030, 47286);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 93316 + "'", int2 == 93316);
    }

    @Test
    public void test8344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8344");
        int int2 = sum.Toplama.sum(127153, 3532);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 130685 + "'", int2 == 130685);
    }

    @Test
    public void test8345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8345");
        int int2 = sum.Toplama.sum(9209, 15367);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24576 + "'", int2 == 24576);
    }

    @Test
    public void test8346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8346");
        int int2 = sum.Toplama.sum(10023, 24962);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34985 + "'", int2 == 34985);
    }

    @Test
    public void test8347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8347");
        int int2 = sum.Toplama.sum(29996, 15796);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45792 + "'", int2 == 45792);
    }

    @Test
    public void test8348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8348");
        int int2 = sum.Toplama.sum(877, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 877 + "'", int2 == 877);
    }

    @Test
    public void test8349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8349");
        int int2 = sum.Toplama.sum(28654, 230);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28884 + "'", int2 == 28884);
    }

    @Test
    public void test8350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8350");
        int int2 = sum.Toplama.sum(99684, 6542);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 106226 + "'", int2 == 106226);
    }

    @Test
    public void test8351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8351");
        int int2 = sum.Toplama.sum(7713, 10850);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18563 + "'", int2 == 18563);
    }

    @Test
    public void test8352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8352");
        int int2 = sum.Toplama.sum(16883, 207500);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 224383 + "'", int2 == 224383);
    }

    @Test
    public void test8353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8353");
        int int2 = sum.Toplama.sum(12000, 46419);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58419 + "'", int2 == 58419);
    }

    @Test
    public void test8354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8354");
        int int2 = sum.Toplama.sum(32531, 17960);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50491 + "'", int2 == 50491);
    }

    @Test
    public void test8355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8355");
        int int2 = sum.Toplama.sum(6440, 18841);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25281 + "'", int2 == 25281);
    }

    @Test
    public void test8356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8356");
        int int2 = sum.Toplama.sum(1601, 13869);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15470 + "'", int2 == 15470);
    }

    @Test
    public void test8357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8357");
        int int2 = sum.Toplama.sum(9035, 6345);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15380 + "'", int2 == 15380);
    }

    @Test
    public void test8358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8358");
        int int2 = sum.Toplama.sum(12133, 1950);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14083 + "'", int2 == 14083);
    }

    @Test
    public void test8359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8359");
        int int2 = sum.Toplama.sum(6983, 42411);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49394 + "'", int2 == 49394);
    }

    @Test
    public void test8360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8360");
        int int2 = sum.Toplama.sum(6133, 17102);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23235 + "'", int2 == 23235);
    }

    @Test
    public void test8361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8361");
        int int2 = sum.Toplama.sum(11317, 2661);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13978 + "'", int2 == 13978);
    }

    @Test
    public void test8362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8362");
        int int2 = sum.Toplama.sum(33663, 65867);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99530 + "'", int2 == 99530);
    }

    @Test
    public void test8363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8363");
        int int2 = sum.Toplama.sum(2843, 610);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3453 + "'", int2 == 3453);
    }

    @Test
    public void test8364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8364");
        int int2 = sum.Toplama.sum(10253, 2797);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13050 + "'", int2 == 13050);
    }

    @Test
    public void test8365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8365");
        int int2 = sum.Toplama.sum(23023, 707);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23730 + "'", int2 == 23730);
    }

    @Test
    public void test8366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8366");
        int int2 = sum.Toplama.sum(0, 10199);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10199 + "'", int2 == 10199);
    }

    @Test
    public void test8367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8367");
        int int2 = sum.Toplama.sum(4613, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4613 + "'", int2 == 4613);
    }

    @Test
    public void test8368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8368");
        int int2 = sum.Toplama.sum(2978, 65303);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68281 + "'", int2 == 68281);
    }

    @Test
    public void test8369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8369");
        int int2 = sum.Toplama.sum(34316, 54338);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 88654 + "'", int2 == 88654);
    }

    @Test
    public void test8370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8370");
        int int2 = sum.Toplama.sum(18251, 24319);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42570 + "'", int2 == 42570);
    }

    @Test
    public void test8371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8371");
        int int2 = sum.Toplama.sum(50841, 15566);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 66407 + "'", int2 == 66407);
    }

    @Test
    public void test8372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8372");
        int int2 = sum.Toplama.sum(26546, 51291);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 77837 + "'", int2 == 77837);
    }

    @Test
    public void test8373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8373");
        int int2 = sum.Toplama.sum(29222, 33211);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62433 + "'", int2 == 62433);
    }

    @Test
    public void test8374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8374");
        int int2 = sum.Toplama.sum(20777, 7383);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28160 + "'", int2 == 28160);
    }

    @Test
    public void test8375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8375");
        int int2 = sum.Toplama.sum(12726, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12726 + "'", int2 == 12726);
    }

    @Test
    public void test8376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8376");
        int int2 = sum.Toplama.sum(16187, 45502);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61689 + "'", int2 == 61689);
    }

    @Test
    public void test8377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8377");
        int int2 = sum.Toplama.sum(5382, 1070);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6452 + "'", int2 == 6452);
    }

    @Test
    public void test8378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8378");
        int int2 = sum.Toplama.sum(17055, 34655);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51710 + "'", int2 == 51710);
    }

    @Test
    public void test8379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8379");
        int int2 = sum.Toplama.sum(44581, 16753);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61334 + "'", int2 == 61334);
    }

    @Test
    public void test8380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8380");
        int int2 = sum.Toplama.sum(6843, 2445);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9288 + "'", int2 == 9288);
    }

    @Test
    public void test8381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8381");
        int int2 = sum.Toplama.sum(15597, 33681);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49278 + "'", int2 == 49278);
    }

    @Test
    public void test8382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8382");
        int int2 = sum.Toplama.sum(32680, 26400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59080 + "'", int2 == 59080);
    }

    @Test
    public void test8383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8383");
        int int2 = sum.Toplama.sum(52950, 97985);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 150935 + "'", int2 == 150935);
    }

    @Test
    public void test8384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8384");
        int int2 = sum.Toplama.sum(42182, 369);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42551 + "'", int2 == 42551);
    }

    @Test
    public void test8385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8385");
        int int2 = sum.Toplama.sum(92597, 10889);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 103486 + "'", int2 == 103486);
    }

    @Test
    public void test8386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8386");
        int int2 = sum.Toplama.sum(88770, 22509);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 111279 + "'", int2 == 111279);
    }

    @Test
    public void test8387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8387");
        int int2 = sum.Toplama.sum(17108, 113727);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 130835 + "'", int2 == 130835);
    }

    @Test
    public void test8388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8388");
        int int2 = sum.Toplama.sum(4571, 24824);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29395 + "'", int2 == 29395);
    }

    @Test
    public void test8389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8389");
        int int2 = sum.Toplama.sum(26465, 29816);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56281 + "'", int2 == 56281);
    }

    @Test
    public void test8390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8390");
        int int2 = sum.Toplama.sum(3684, 77957);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 81641 + "'", int2 == 81641);
    }

    @Test
    public void test8391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8391");
        int int2 = sum.Toplama.sum(68554, 14576);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 83130 + "'", int2 == 83130);
    }

    @Test
    public void test8392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8392");
        int int2 = sum.Toplama.sum(3026, 38113);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41139 + "'", int2 == 41139);
    }

    @Test
    public void test8393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8393");
        int int2 = sum.Toplama.sum(7569, 58480);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 66049 + "'", int2 == 66049);
    }

    @Test
    public void test8394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8394");
        int int2 = sum.Toplama.sum(5382, 16244);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21626 + "'", int2 == 21626);
    }

    @Test
    public void test8395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8395");
        int int2 = sum.Toplama.sum(93812, 28281);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 122093 + "'", int2 == 122093);
    }

    @Test
    public void test8396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8396");
        int int2 = sum.Toplama.sum(11292, 477);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11769 + "'", int2 == 11769);
    }

    @Test
    public void test8397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8397");
        int int2 = sum.Toplama.sum(24461, 5384);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29845 + "'", int2 == 29845);
    }

    @Test
    public void test8398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8398");
        int int2 = sum.Toplama.sum(42046, 50847);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 92893 + "'", int2 == 92893);
    }

    @Test
    public void test8399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8399");
        int int2 = sum.Toplama.sum(67487, 18995);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 86482 + "'", int2 == 86482);
    }

    @Test
    public void test8400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8400");
        int int2 = sum.Toplama.sum(8470, 12227);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20697 + "'", int2 == 20697);
    }

    @Test
    public void test8401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8401");
        int int2 = sum.Toplama.sum(25969, 83525);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 109494 + "'", int2 == 109494);
    }

    @Test
    public void test8402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8402");
        int int2 = sum.Toplama.sum(63159, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63159 + "'", int2 == 63159);
    }

    @Test
    public void test8403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8403");
        int int2 = sum.Toplama.sum(30185, 46131);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 76316 + "'", int2 == 76316);
    }

    @Test
    public void test8404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8404");
        int int2 = sum.Toplama.sum(25033, 10161);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35194 + "'", int2 == 35194);
    }

    @Test
    public void test8405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8405");
        int int2 = sum.Toplama.sum(34223, 115512);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 149735 + "'", int2 == 149735);
    }

    @Test
    public void test8406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8406");
        int int2 = sum.Toplama.sum(71140, 42054);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 113194 + "'", int2 == 113194);
    }

    @Test
    public void test8407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8407");
        int int2 = sum.Toplama.sum(0, 85676);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 85676 + "'", int2 == 85676);
    }

    @Test
    public void test8408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8408");
        int int2 = sum.Toplama.sum(9068, 7568);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16636 + "'", int2 == 16636);
    }

    @Test
    public void test8409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8409");
        int int2 = sum.Toplama.sum(0, 1385);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1385 + "'", int2 == 1385);
    }

    @Test
    public void test8410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8410");
        int int2 = sum.Toplama.sum(13118, 33894);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47012 + "'", int2 == 47012);
    }

    @Test
    public void test8411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8411");
        int int2 = sum.Toplama.sum(737, 14209);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14946 + "'", int2 == 14946);
    }

    @Test
    public void test8412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8412");
        int int2 = sum.Toplama.sum(11550, 32947);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44497 + "'", int2 == 44497);
    }

    @Test
    public void test8413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8413");
        int int2 = sum.Toplama.sum(14386, 41645);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56031 + "'", int2 == 56031);
    }

    @Test
    public void test8414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8414");
        int int2 = sum.Toplama.sum(7866, 19724);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27590 + "'", int2 == 27590);
    }

    @Test
    public void test8415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8415");
        int int2 = sum.Toplama.sum(1570, 1703);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3273 + "'", int2 == 3273);
    }

    @Test
    public void test8416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8416");
        int int2 = sum.Toplama.sum(20799, 15890);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36689 + "'", int2 == 36689);
    }

    @Test
    public void test8417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8417");
        int int2 = sum.Toplama.sum(6187, 10267);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16454 + "'", int2 == 16454);
    }

    @Test
    public void test8418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8418");
        int int2 = sum.Toplama.sum(11593, 151);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11744 + "'", int2 == 11744);
    }

    @Test
    public void test8419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8419");
        int int2 = sum.Toplama.sum(57379, 85266);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 142645 + "'", int2 == 142645);
    }

    @Test
    public void test8420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8420");
        int int2 = sum.Toplama.sum(59778, 4093);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63871 + "'", int2 == 63871);
    }

    @Test
    public void test8421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8421");
        int int2 = sum.Toplama.sum(9434, 54429);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63863 + "'", int2 == 63863);
    }

    @Test
    public void test8422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8422");
        int int2 = sum.Toplama.sum(57689, 43252);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100941 + "'", int2 == 100941);
    }

    @Test
    public void test8423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8423");
        int int2 = sum.Toplama.sum(2933, 32392);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35325 + "'", int2 == 35325);
    }

    @Test
    public void test8424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8424");
        int int2 = sum.Toplama.sum(5182, 33187);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38369 + "'", int2 == 38369);
    }

    @Test
    public void test8425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8425");
        int int2 = sum.Toplama.sum(34078, 7513);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41591 + "'", int2 == 41591);
    }

    @Test
    public void test8426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8426");
        int int2 = sum.Toplama.sum(43508, 4090);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47598 + "'", int2 == 47598);
    }

    @Test
    public void test8427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8427");
        int int2 = sum.Toplama.sum(10272, 69524);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 79796 + "'", int2 == 79796);
    }

    @Test
    public void test8428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8428");
        int int2 = sum.Toplama.sum(110, 9221);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9331 + "'", int2 == 9331);
    }

    @Test
    public void test8429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8429");
        int int2 = sum.Toplama.sum(13804, 29435);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43239 + "'", int2 == 43239);
    }

    @Test
    public void test8430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8430");
        int int2 = sum.Toplama.sum(68749, 11278);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80027 + "'", int2 == 80027);
    }

    @Test
    public void test8431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8431");
        int int2 = sum.Toplama.sum(217, 4902);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5119 + "'", int2 == 5119);
    }

    @Test
    public void test8432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8432");
        int int2 = sum.Toplama.sum(29316, 6466);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35782 + "'", int2 == 35782);
    }

    @Test
    public void test8433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8433");
        int int2 = sum.Toplama.sum(7642, 50546);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58188 + "'", int2 == 58188);
    }

    @Test
    public void test8434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8434");
        int int2 = sum.Toplama.sum(0, 33337);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33337 + "'", int2 == 33337);
    }

    @Test
    public void test8435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8435");
        int int2 = sum.Toplama.sum(76691, 24692);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 101383 + "'", int2 == 101383);
    }

    @Test
    public void test8436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8436");
        int int2 = sum.Toplama.sum(0, 4582);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4582 + "'", int2 == 4582);
    }

    @Test
    public void test8437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8437");
        int int2 = sum.Toplama.sum(37396, 19346);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56742 + "'", int2 == 56742);
    }

    @Test
    public void test8438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8438");
        int int2 = sum.Toplama.sum(38186, 13430);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51616 + "'", int2 == 51616);
    }

    @Test
    public void test8439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8439");
        int int2 = sum.Toplama.sum(33586, 20924);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54510 + "'", int2 == 54510);
    }

    @Test
    public void test8440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8440");
        int int2 = sum.Toplama.sum(9050, 25590);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34640 + "'", int2 == 34640);
    }

    @Test
    public void test8441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8441");
        int int2 = sum.Toplama.sum(34062, 42338);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 76400 + "'", int2 == 76400);
    }

    @Test
    public void test8442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8442");
        int int2 = sum.Toplama.sum(491, 36985);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37476 + "'", int2 == 37476);
    }

    @Test
    public void test8443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8443");
        int int2 = sum.Toplama.sum(24458, 1680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26138 + "'", int2 == 26138);
    }

    @Test
    public void test8444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8444");
        int int2 = sum.Toplama.sum(16939, 24443);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41382 + "'", int2 == 41382);
    }

    @Test
    public void test8445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8445");
        int int2 = sum.Toplama.sum(0, 41583);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41583 + "'", int2 == 41583);
    }

    @Test
    public void test8446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8446");
        int int2 = sum.Toplama.sum(37742, 56803);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 94545 + "'", int2 == 94545);
    }

    @Test
    public void test8447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8447");
        int int2 = sum.Toplama.sum(73319, 48887);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 122206 + "'", int2 == 122206);
    }

    @Test
    public void test8448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8448");
        int int2 = sum.Toplama.sum(9984, 68991);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78975 + "'", int2 == 78975);
    }

    @Test
    public void test8449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8449");
        int int2 = sum.Toplama.sum(37983, 13376);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51359 + "'", int2 == 51359);
    }

    @Test
    public void test8450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8450");
        int int2 = sum.Toplama.sum(33595, 1161);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34756 + "'", int2 == 34756);
    }

    @Test
    public void test8451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8451");
        int int2 = sum.Toplama.sum(117549, 229);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 117778 + "'", int2 == 117778);
    }

    @Test
    public void test8452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8452");
        int int2 = sum.Toplama.sum(64321, 20917);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 85238 + "'", int2 == 85238);
    }

    @Test
    public void test8453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8453");
        int int2 = sum.Toplama.sum(31781, 23563);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55344 + "'", int2 == 55344);
    }

    @Test
    public void test8454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8454");
        int int2 = sum.Toplama.sum(39038, 42731);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 81769 + "'", int2 == 81769);
    }

    @Test
    public void test8455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8455");
        int int2 = sum.Toplama.sum(27821, 12363);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40184 + "'", int2 == 40184);
    }

    @Test
    public void test8456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8456");
        int int2 = sum.Toplama.sum(11682, 16335);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28017 + "'", int2 == 28017);
    }

    @Test
    public void test8457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8457");
        int int2 = sum.Toplama.sum(14798, 20382);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35180 + "'", int2 == 35180);
    }

    @Test
    public void test8458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8458");
        int int2 = sum.Toplama.sum(12290, 26094);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38384 + "'", int2 == 38384);
    }

    @Test
    public void test8459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8459");
        int int2 = sum.Toplama.sum(15468, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15468 + "'", int2 == 15468);
    }

    @Test
    public void test8460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8460");
        int int2 = sum.Toplama.sum(59789, 87440);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 147229 + "'", int2 == 147229);
    }

    @Test
    public void test8461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8461");
        int int2 = sum.Toplama.sum(24121, 11103);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35224 + "'", int2 == 35224);
    }

    @Test
    public void test8462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8462");
        int int2 = sum.Toplama.sum(12245, 50721);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62966 + "'", int2 == 62966);
    }

    @Test
    public void test8463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8463");
        int int2 = sum.Toplama.sum(13649, 5299);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18948 + "'", int2 == 18948);
    }

    @Test
    public void test8464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8464");
        int int2 = sum.Toplama.sum(33767, 124022);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 157789 + "'", int2 == 157789);
    }

    @Test
    public void test8465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8465");
        int int2 = sum.Toplama.sum(23845, 10687);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34532 + "'", int2 == 34532);
    }

    @Test
    public void test8466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8466");
        int int2 = sum.Toplama.sum(31020, 9748);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40768 + "'", int2 == 40768);
    }

    @Test
    public void test8467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8467");
        int int2 = sum.Toplama.sum(4504, 28052);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32556 + "'", int2 == 32556);
    }

    @Test
    public void test8468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8468");
        int int2 = sum.Toplama.sum(57264, 29032);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 86296 + "'", int2 == 86296);
    }

    @Test
    public void test8469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8469");
        int int2 = sum.Toplama.sum(17873, 19875);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37748 + "'", int2 == 37748);
    }

    @Test
    public void test8470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8470");
        int int2 = sum.Toplama.sum(28569, 15400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43969 + "'", int2 == 43969);
    }

    @Test
    public void test8471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8471");
        int int2 = sum.Toplama.sum(909, 13150);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14059 + "'", int2 == 14059);
    }

    @Test
    public void test8472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8472");
        int int2 = sum.Toplama.sum(9029, 96720);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 105749 + "'", int2 == 105749);
    }

    @Test
    public void test8473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8473");
        int int2 = sum.Toplama.sum(25774, 32229);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58003 + "'", int2 == 58003);
    }

    @Test
    public void test8474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8474");
        int int2 = sum.Toplama.sum(3740, 34115);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37855 + "'", int2 == 37855);
    }

    @Test
    public void test8475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8475");
        int int2 = sum.Toplama.sum(5188, 261);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5449 + "'", int2 == 5449);
    }

    @Test
    public void test8476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8476");
        int int2 = sum.Toplama.sum(52872, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52872 + "'", int2 == 52872);
    }

    @Test
    public void test8477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8477");
        int int2 = sum.Toplama.sum(41382, 3487);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44869 + "'", int2 == 44869);
    }

    @Test
    public void test8478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8478");
        int int2 = sum.Toplama.sum(30709, 85251);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 115960 + "'", int2 == 115960);
    }

    @Test
    public void test8479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8479");
        int int2 = sum.Toplama.sum(3570, 34282);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37852 + "'", int2 == 37852);
    }

    @Test
    public void test8480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8480");
        int int2 = sum.Toplama.sum(4571, 38035);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42606 + "'", int2 == 42606);
    }

    @Test
    public void test8481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8481");
        int int2 = sum.Toplama.sum(1958, 30734);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32692 + "'", int2 == 32692);
    }

    @Test
    public void test8482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8482");
        int int2 = sum.Toplama.sum(50403, 6063);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56466 + "'", int2 == 56466);
    }

    @Test
    public void test8483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8483");
        int int2 = sum.Toplama.sum(7569, 17366);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24935 + "'", int2 == 24935);
    }

    @Test
    public void test8484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8484");
        int int2 = sum.Toplama.sum(0, 13584);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13584 + "'", int2 == 13584);
    }

    @Test
    public void test8485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8485");
        int int2 = sum.Toplama.sum(707, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 707 + "'", int2 == 707);
    }

    @Test
    public void test8486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8486");
        int int2 = sum.Toplama.sum(1639, 13767);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15406 + "'", int2 == 15406);
    }

    @Test
    public void test8487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8487");
        int int2 = sum.Toplama.sum(24033, 26735);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50768 + "'", int2 == 50768);
    }

    @Test
    public void test8488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8488");
        int int2 = sum.Toplama.sum(23794, 1465);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25259 + "'", int2 == 25259);
    }

    @Test
    public void test8489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8489");
        int int2 = sum.Toplama.sum(6623, 3113);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9736 + "'", int2 == 9736);
    }

    @Test
    public void test8490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8490");
        int int2 = sum.Toplama.sum(3766, 161);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3927 + "'", int2 == 3927);
    }

    @Test
    public void test8491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8491");
        int int2 = sum.Toplama.sum(46764, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46764 + "'", int2 == 46764);
    }

    @Test
    public void test8492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8492");
        int int2 = sum.Toplama.sum(0, 47676);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47676 + "'", int2 == 47676);
    }

    @Test
    public void test8493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8493");
        int int2 = sum.Toplama.sum(0, 34717);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34717 + "'", int2 == 34717);
    }

    @Test
    public void test8494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8494");
        int int2 = sum.Toplama.sum(1784, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1784 + "'", int2 == 1784);
    }

    @Test
    public void test8495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8495");
        int int2 = sum.Toplama.sum(0, 5808);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5808 + "'", int2 == 5808);
    }

    @Test
    public void test8496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8496");
        int int2 = sum.Toplama.sum(2241, 16510);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18751 + "'", int2 == 18751);
    }

    @Test
    public void test8497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8497");
        int int2 = sum.Toplama.sum(80239, 17910);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 98149 + "'", int2 == 98149);
    }

    @Test
    public void test8498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8498");
        int int2 = sum.Toplama.sum(4370, 35616);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39986 + "'", int2 == 39986);
    }

    @Test
    public void test8499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8499");
        int int2 = sum.Toplama.sum(22617, 2536);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25153 + "'", int2 == 25153);
    }

    @Test
    public void test8500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test8500");
        int int2 = sum.Toplama.sum(24803, 113926);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 138729 + "'", int2 == 138729);
    }
}

