import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest18 {

    public static boolean debug = false;

    @Test
    public void test9001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9001");
        int int2 = sum.Toplama.sum(54017, 46526);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100543 + "'", int2 == 100543);
    }

    @Test
    public void test9002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9002");
        int int2 = sum.Toplama.sum(118029, 8782);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 126811 + "'", int2 == 126811);
    }

    @Test
    public void test9003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9003");
        int int2 = sum.Toplama.sum(154875, 21326);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 176201 + "'", int2 == 176201);
    }

    @Test
    public void test9004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9004");
        int int2 = sum.Toplama.sum(28281, 12056);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40337 + "'", int2 == 40337);
    }

    @Test
    public void test9005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9005");
        int int2 = sum.Toplama.sum(13410, 112784);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 126194 + "'", int2 == 126194);
    }

    @Test
    public void test9006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9006");
        int int2 = sum.Toplama.sum(27430, 1041);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28471 + "'", int2 == 28471);
    }

    @Test
    public void test9007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9007");
        int int2 = sum.Toplama.sum(2146, 26951);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29097 + "'", int2 == 29097);
    }

    @Test
    public void test9008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9008");
        int int2 = sum.Toplama.sum(39294, 9473);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48767 + "'", int2 == 48767);
    }

    @Test
    public void test9009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9009");
        int int2 = sum.Toplama.sum(31145, 84965);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 116110 + "'", int2 == 116110);
    }

    @Test
    public void test9010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9010");
        int int2 = sum.Toplama.sum(105158, 43570);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 148728 + "'", int2 == 148728);
    }

    @Test
    public void test9011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9011");
        int int2 = sum.Toplama.sum(5952, 623);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6575 + "'", int2 == 6575);
    }

    @Test
    public void test9012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9012");
        int int2 = sum.Toplama.sum(23129, 18504);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41633 + "'", int2 == 41633);
    }

    @Test
    public void test9013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9013");
        int int2 = sum.Toplama.sum(22218, 49174);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 71392 + "'", int2 == 71392);
    }

    @Test
    public void test9014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9014");
        int int2 = sum.Toplama.sum(40992, 29245);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70237 + "'", int2 == 70237);
    }

    @Test
    public void test9015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9015");
        int int2 = sum.Toplama.sum(40452, 9526);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49978 + "'", int2 == 49978);
    }

    @Test
    public void test9016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9016");
        int int2 = sum.Toplama.sum(0, 11397);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11397 + "'", int2 == 11397);
    }

    @Test
    public void test9017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9017");
        int int2 = sum.Toplama.sum(22485, 39212);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61697 + "'", int2 == 61697);
    }

    @Test
    public void test9018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9018");
        int int2 = sum.Toplama.sum(11186, 4847);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16033 + "'", int2 == 16033);
    }

    @Test
    public void test9019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9019");
        int int2 = sum.Toplama.sum(1002, 34008);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35010 + "'", int2 == 35010);
    }

    @Test
    public void test9020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9020");
        int int2 = sum.Toplama.sum(27385, 4090);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31475 + "'", int2 == 31475);
    }

    @Test
    public void test9021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9021");
        int int2 = sum.Toplama.sum(4403, 11069);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15472 + "'", int2 == 15472);
    }

    @Test
    public void test9022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9022");
        int int2 = sum.Toplama.sum(28980, 56364);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 85344 + "'", int2 == 85344);
    }

    @Test
    public void test9023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9023");
        int int2 = sum.Toplama.sum(85955, 8483);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 94438 + "'", int2 == 94438);
    }

    @Test
    public void test9024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9024");
        int int2 = sum.Toplama.sum(15721, 7996);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23717 + "'", int2 == 23717);
    }

    @Test
    public void test9025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9025");
        int int2 = sum.Toplama.sum(45733, 21365);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67098 + "'", int2 == 67098);
    }

    @Test
    public void test9026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9026");
        int int2 = sum.Toplama.sum(10063, 16205);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26268 + "'", int2 == 26268);
    }

    @Test
    public void test9027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9027");
        int int2 = sum.Toplama.sum(75916, 12685);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 88601 + "'", int2 == 88601);
    }

    @Test
    public void test9028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9028");
        int int2 = sum.Toplama.sum(23684, 63669);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 87353 + "'", int2 == 87353);
    }

    @Test
    public void test9029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9029");
        int int2 = sum.Toplama.sum(46287, 5969);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52256 + "'", int2 == 52256);
    }

    @Test
    public void test9030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9030");
        int int2 = sum.Toplama.sum(34207, 30865);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 65072 + "'", int2 == 65072);
    }

    @Test
    public void test9031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9031");
        int int2 = sum.Toplama.sum(27531, 30401);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57932 + "'", int2 == 57932);
    }

    @Test
    public void test9032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9032");
        int int2 = sum.Toplama.sum(58628, 51210);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 109838 + "'", int2 == 109838);
    }

    @Test
    public void test9033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9033");
        int int2 = sum.Toplama.sum(51208, 83334);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 134542 + "'", int2 == 134542);
    }

    @Test
    public void test9034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9034");
        int int2 = sum.Toplama.sum(8740, 59275);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68015 + "'", int2 == 68015);
    }

    @Test
    public void test9035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9035");
        int int2 = sum.Toplama.sum(19589, 14088);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33677 + "'", int2 == 33677);
    }

    @Test
    public void test9036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9036");
        int int2 = sum.Toplama.sum(100309, 32837);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 133146 + "'", int2 == 133146);
    }

    @Test
    public void test9037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9037");
        int int2 = sum.Toplama.sum(68254, 252);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68506 + "'", int2 == 68506);
    }

    @Test
    public void test9038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9038");
        int int2 = sum.Toplama.sum(41810, 116196);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 158006 + "'", int2 == 158006);
    }

    @Test
    public void test9039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9039");
        int int2 = sum.Toplama.sum(11379, 27726);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39105 + "'", int2 == 39105);
    }

    @Test
    public void test9040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9040");
        int int2 = sum.Toplama.sum(17337, 36275);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53612 + "'", int2 == 53612);
    }

    @Test
    public void test9041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9041");
        int int2 = sum.Toplama.sum(10552, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10552 + "'", int2 == 10552);
    }

    @Test
    public void test9042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9042");
        int int2 = sum.Toplama.sum(1903, 4069);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5972 + "'", int2 == 5972);
    }

    @Test
    public void test9043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9043");
        int int2 = sum.Toplama.sum(0, 24443);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24443 + "'", int2 == 24443);
    }

    @Test
    public void test9044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9044");
        int int2 = sum.Toplama.sum(30771, 1839);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32610 + "'", int2 == 32610);
    }

    @Test
    public void test9045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9045");
        int int2 = sum.Toplama.sum(36152, 8744);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44896 + "'", int2 == 44896);
    }

    @Test
    public void test9046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9046");
        int int2 = sum.Toplama.sum(14386, 2810);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17196 + "'", int2 == 17196);
    }

    @Test
    public void test9047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9047");
        int int2 = sum.Toplama.sum(29774, 15923);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45697 + "'", int2 == 45697);
    }

    @Test
    public void test9048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9048");
        int int2 = sum.Toplama.sum(23104, 30470);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53574 + "'", int2 == 53574);
    }

    @Test
    public void test9049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9049");
        int int2 = sum.Toplama.sum(42993, 46082);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 89075 + "'", int2 == 89075);
    }

    @Test
    public void test9050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9050");
        int int2 = sum.Toplama.sum(17846, 31403);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49249 + "'", int2 == 49249);
    }

    @Test
    public void test9051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9051");
        int int2 = sum.Toplama.sum(16914, 9093);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26007 + "'", int2 == 26007);
    }

    @Test
    public void test9052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9052");
        int int2 = sum.Toplama.sum(3233, 77592);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80825 + "'", int2 == 80825);
    }

    @Test
    public void test9053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9053");
        int int2 = sum.Toplama.sum(6305, 113659);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 119964 + "'", int2 == 119964);
    }

    @Test
    public void test9054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9054");
        int int2 = sum.Toplama.sum(3871, 25570);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29441 + "'", int2 == 29441);
    }

    @Test
    public void test9055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9055");
        int int2 = sum.Toplama.sum(6158, 15367);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21525 + "'", int2 == 21525);
    }

    @Test
    public void test9056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9056");
        int int2 = sum.Toplama.sum(26055, 13300);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39355 + "'", int2 == 39355);
    }

    @Test
    public void test9057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9057");
        int int2 = sum.Toplama.sum(21080, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21080 + "'", int2 == 21080);
    }

    @Test
    public void test9058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9058");
        int int2 = sum.Toplama.sum(112975, 34198);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 147173 + "'", int2 == 147173);
    }

    @Test
    public void test9059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9059");
        int int2 = sum.Toplama.sum(10772, 15129);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25901 + "'", int2 == 25901);
    }

    @Test
    public void test9060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9060");
        int int2 = sum.Toplama.sum(88739, 21522);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 110261 + "'", int2 == 110261);
    }

    @Test
    public void test9061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9061");
        int int2 = sum.Toplama.sum(86142, 75807);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 161949 + "'", int2 == 161949);
    }

    @Test
    public void test9062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9062");
        int int2 = sum.Toplama.sum(41073, 23192);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64265 + "'", int2 == 64265);
    }

    @Test
    public void test9063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9063");
        int int2 = sum.Toplama.sum(14802, 8924);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23726 + "'", int2 == 23726);
    }

    @Test
    public void test9064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9064");
        int int2 = sum.Toplama.sum(48937, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48937 + "'", int2 == 48937);
    }

    @Test
    public void test9065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9065");
        int int2 = sum.Toplama.sum(125807, 374);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 126181 + "'", int2 == 126181);
    }

    @Test
    public void test9066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9066");
        int int2 = sum.Toplama.sum(259, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 259 + "'", int2 == 259);
    }

    @Test
    public void test9067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9067");
        int int2 = sum.Toplama.sum(576, 30578);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31154 + "'", int2 == 31154);
    }

    @Test
    public void test9068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9068");
        int int2 = sum.Toplama.sum(74852, 91145);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 165997 + "'", int2 == 165997);
    }

    @Test
    public void test9069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9069");
        int int2 = sum.Toplama.sum(9565, 32610);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42175 + "'", int2 == 42175);
    }

    @Test
    public void test9070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9070");
        int int2 = sum.Toplama.sum(21748, 61970);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 83718 + "'", int2 == 83718);
    }

    @Test
    public void test9071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9071");
        int int2 = sum.Toplama.sum(33716, 5780);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39496 + "'", int2 == 39496);
    }

    @Test
    public void test9072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9072");
        int int2 = sum.Toplama.sum(57379, 93099);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 150478 + "'", int2 == 150478);
    }

    @Test
    public void test9073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9073");
        int int2 = sum.Toplama.sum(449, 53);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 502 + "'", int2 == 502);
    }

    @Test
    public void test9074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9074");
        int int2 = sum.Toplama.sum(3124, 55785);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58909 + "'", int2 == 58909);
    }

    @Test
    public void test9075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9075");
        int int2 = sum.Toplama.sum(34717, 22048);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56765 + "'", int2 == 56765);
    }

    @Test
    public void test9076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9076");
        int int2 = sum.Toplama.sum(16881, 7513);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24394 + "'", int2 == 24394);
    }

    @Test
    public void test9077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9077");
        int int2 = sum.Toplama.sum(48583, 19309);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67892 + "'", int2 == 67892);
    }

    @Test
    public void test9078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9078");
        int int2 = sum.Toplama.sum(1719, 83186);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 84905 + "'", int2 == 84905);
    }

    @Test
    public void test9079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9079");
        int int2 = sum.Toplama.sum(0, 6903);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6903 + "'", int2 == 6903);
    }

    @Test
    public void test9080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9080");
        int int2 = sum.Toplama.sum(1422, 3048);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4470 + "'", int2 == 4470);
    }

    @Test
    public void test9081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9081");
        int int2 = sum.Toplama.sum(4931, 3448);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8379 + "'", int2 == 8379);
    }

    @Test
    public void test9082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9082");
        int int2 = sum.Toplama.sum(100014, 4266);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 104280 + "'", int2 == 104280);
    }

    @Test
    public void test9083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9083");
        int int2 = sum.Toplama.sum(1835, 42902);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44737 + "'", int2 == 44737);
    }

    @Test
    public void test9084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9084");
        int int2 = sum.Toplama.sum(0, 7866);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7866 + "'", int2 == 7866);
    }

    @Test
    public void test9085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9085");
        int int2 = sum.Toplama.sum(24541, 3595);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28136 + "'", int2 == 28136);
    }

    @Test
    public void test9086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9086");
        int int2 = sum.Toplama.sum(39032, 11391);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50423 + "'", int2 == 50423);
    }

    @Test
    public void test9087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9087");
        java.lang.Object obj0 = new java.lang.Object();
        java.lang.Class<?> wildcardClass1 = obj0.getClass();
        java.lang.Class<?> wildcardClass2 = obj0.getClass();
        java.lang.Class<?> wildcardClass3 = obj0.getClass();
        java.lang.Class<?> wildcardClass4 = obj0.getClass();
        java.lang.Class<?> wildcardClass5 = obj0.getClass();
        java.lang.Class<?> wildcardClass6 = obj0.getClass();
        java.lang.Class<?> wildcardClass7 = obj0.getClass();
        java.lang.Class<?> wildcardClass8 = obj0.getClass();
        java.lang.Class<?> wildcardClass9 = obj0.getClass();
        java.lang.Class<?> wildcardClass10 = obj0.getClass();
        java.lang.Class<?> wildcardClass11 = obj0.getClass();
        java.lang.Class<?> wildcardClass12 = obj0.getClass();
        java.lang.Class<?> wildcardClass13 = obj0.getClass();
        java.lang.Class<?> wildcardClass14 = obj0.getClass();
        java.lang.Class<?> wildcardClass15 = obj0.getClass();
        java.lang.Class<?> wildcardClass16 = obj0.getClass();
        java.lang.Class<?> wildcardClass17 = obj0.getClass();
        java.lang.Class<?> wildcardClass18 = obj0.getClass();
        java.lang.Class<?> wildcardClass19 = obj0.getClass();
        java.lang.Class<?> wildcardClass20 = obj0.getClass();
        java.lang.Class<?> wildcardClass21 = obj0.getClass();
        java.lang.Class<?> wildcardClass22 = obj0.getClass();
        java.lang.Class<?> wildcardClass23 = obj0.getClass();
        java.lang.Class<?> wildcardClass24 = obj0.getClass();
        java.lang.Class<?> wildcardClass25 = obj0.getClass();
        java.lang.Class<?> wildcardClass26 = obj0.getClass();
        java.lang.Class<?> wildcardClass27 = obj0.getClass();
        java.lang.Class<?> wildcardClass28 = obj0.getClass();
        java.lang.Class<?> wildcardClass29 = obj0.getClass();
        java.lang.Class<?> wildcardClass30 = obj0.getClass();
        java.lang.Class<?> wildcardClass31 = obj0.getClass();
        java.lang.Class<?> wildcardClass32 = obj0.getClass();
        java.lang.Class<?> wildcardClass33 = obj0.getClass();
        java.lang.Class<?> wildcardClass34 = obj0.getClass();
        java.lang.Class<?> wildcardClass35 = obj0.getClass();
        java.lang.Class<?> wildcardClass36 = obj0.getClass();
        java.lang.Class<?> wildcardClass37 = obj0.getClass();
        java.lang.Class<?> wildcardClass38 = obj0.getClass();
        java.lang.Class<?> wildcardClass39 = obj0.getClass();
        java.lang.Class<?> wildcardClass40 = obj0.getClass();
        java.lang.Class<?> wildcardClass41 = obj0.getClass();
        java.lang.Class<?> wildcardClass42 = obj0.getClass();
        java.lang.Class<?> wildcardClass43 = obj0.getClass();
        java.lang.Class<?> wildcardClass44 = obj0.getClass();
        java.lang.Class<?> wildcardClass45 = obj0.getClass();
        java.lang.Class<?> wildcardClass46 = obj0.getClass();
        java.lang.Class<?> wildcardClass47 = obj0.getClass();
        java.lang.Class<?> wildcardClass48 = obj0.getClass();
        java.lang.Class<?> wildcardClass49 = obj0.getClass();
        java.lang.Class<?> wildcardClass50 = obj0.getClass();
        java.lang.Class<?> wildcardClass51 = obj0.getClass();
        java.lang.Class<?> wildcardClass52 = obj0.getClass();
        java.lang.Class<?> wildcardClass53 = obj0.getClass();
        java.lang.Class<?> wildcardClass54 = obj0.getClass();
        java.lang.Class<?> wildcardClass55 = obj0.getClass();
        java.lang.Class<?> wildcardClass56 = obj0.getClass();
        java.lang.Class<?> wildcardClass57 = obj0.getClass();
        java.lang.Class<?> wildcardClass58 = obj0.getClass();
        java.lang.Class<?> wildcardClass59 = obj0.getClass();
        java.lang.Class<?> wildcardClass60 = obj0.getClass();
        java.lang.Class<?> wildcardClass61 = obj0.getClass();
        java.lang.Class<?> wildcardClass62 = obj0.getClass();
        java.lang.Class<?> wildcardClass63 = obj0.getClass();
        java.lang.Class<?> wildcardClass64 = obj0.getClass();
        java.lang.Class<?> wildcardClass65 = obj0.getClass();
        java.lang.Class<?> wildcardClass66 = obj0.getClass();
        java.lang.Class<?> wildcardClass67 = obj0.getClass();
        java.lang.Class<?> wildcardClass68 = obj0.getClass();
        java.lang.Class<?> wildcardClass69 = obj0.getClass();
        java.lang.Class<?> wildcardClass70 = obj0.getClass();
        java.lang.Class<?> wildcardClass71 = obj0.getClass();
        java.lang.Class<?> wildcardClass72 = obj0.getClass();
        java.lang.Class<?> wildcardClass73 = obj0.getClass();
        java.lang.Class<?> wildcardClass74 = obj0.getClass();
        java.lang.Class<?> wildcardClass75 = obj0.getClass();
        java.lang.Class<?> wildcardClass76 = obj0.getClass();
        java.lang.Class<?> wildcardClass77 = obj0.getClass();
        java.lang.Class<?> wildcardClass78 = obj0.getClass();
        java.lang.Class<?> wildcardClass79 = obj0.getClass();
        java.lang.Class<?> wildcardClass80 = obj0.getClass();
        java.lang.Class<?> wildcardClass81 = obj0.getClass();
        java.lang.Class<?> wildcardClass82 = obj0.getClass();
        java.lang.Class<?> wildcardClass83 = obj0.getClass();
        java.lang.Class<?> wildcardClass84 = obj0.getClass();
        java.lang.Class<?> wildcardClass85 = obj0.getClass();
        java.lang.Class<?> wildcardClass86 = obj0.getClass();
        java.lang.Class<?> wildcardClass87 = obj0.getClass();
        java.lang.Class<?> wildcardClass88 = obj0.getClass();
        java.lang.Class<?> wildcardClass89 = obj0.getClass();
        java.lang.Class<?> wildcardClass90 = obj0.getClass();
        java.lang.Class<?> wildcardClass91 = obj0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertNotNull(wildcardClass68);
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertNotNull(wildcardClass71);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertNotNull(wildcardClass75);
        org.junit.Assert.assertNotNull(wildcardClass76);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertNotNull(wildcardClass78);
        org.junit.Assert.assertNotNull(wildcardClass79);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertNotNull(wildcardClass81);
        org.junit.Assert.assertNotNull(wildcardClass82);
        org.junit.Assert.assertNotNull(wildcardClass83);
        org.junit.Assert.assertNotNull(wildcardClass84);
        org.junit.Assert.assertNotNull(wildcardClass85);
        org.junit.Assert.assertNotNull(wildcardClass86);
        org.junit.Assert.assertNotNull(wildcardClass87);
        org.junit.Assert.assertNotNull(wildcardClass88);
        org.junit.Assert.assertNotNull(wildcardClass89);
        org.junit.Assert.assertNotNull(wildcardClass90);
        org.junit.Assert.assertNotNull(wildcardClass91);
    }

    @Test
    public void test9088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9088");
        int int2 = sum.Toplama.sum(32949, 5177);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38126 + "'", int2 == 38126);
    }

    @Test
    public void test9089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9089");
        int int2 = sum.Toplama.sum(25337, 30201);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55538 + "'", int2 == 55538);
    }

    @Test
    public void test9090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9090");
        int int2 = sum.Toplama.sum(14963, 23434);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38397 + "'", int2 == 38397);
    }

    @Test
    public void test9091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9091");
        int int2 = sum.Toplama.sum(0, 28097);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28097 + "'", int2 == 28097);
    }

    @Test
    public void test9092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9092");
        int int2 = sum.Toplama.sum(14956, 51078);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 66034 + "'", int2 == 66034);
    }

    @Test
    public void test9093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9093");
        int int2 = sum.Toplama.sum(32112, 152);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32264 + "'", int2 == 32264);
    }

    @Test
    public void test9094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9094");
        int int2 = sum.Toplama.sum(44842, 58628);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 103470 + "'", int2 == 103470);
    }

    @Test
    public void test9095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9095");
        int int2 = sum.Toplama.sum(11063, 9986);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21049 + "'", int2 == 21049);
    }

    @Test
    public void test9096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9096");
        int int2 = sum.Toplama.sum(9473, 29866);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39339 + "'", int2 == 39339);
    }

    @Test
    public void test9097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9097");
        int int2 = sum.Toplama.sum(130175, 17955);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 148130 + "'", int2 == 148130);
    }

    @Test
    public void test9098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9098");
        int int2 = sum.Toplama.sum(38978, 2598);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41576 + "'", int2 == 41576);
    }

    @Test
    public void test9099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9099");
        int int2 = sum.Toplama.sum(22363, 70103);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 92466 + "'", int2 == 92466);
    }

    @Test
    public void test9100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9100");
        int int2 = sum.Toplama.sum(57019, 12420);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69439 + "'", int2 == 69439);
    }

    @Test
    public void test9101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9101");
        int int2 = sum.Toplama.sum(1476, 37789);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39265 + "'", int2 == 39265);
    }

    @Test
    public void test9102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9102");
        int int2 = sum.Toplama.sum(2215, 23572);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25787 + "'", int2 == 25787);
    }

    @Test
    public void test9103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9103");
        int int2 = sum.Toplama.sum(59420, 8148);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67568 + "'", int2 == 67568);
    }

    @Test
    public void test9104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9104");
        int int2 = sum.Toplama.sum(28136, 60457);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 88593 + "'", int2 == 88593);
    }

    @Test
    public void test9105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9105");
        int int2 = sum.Toplama.sum(4313, 61443);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 65756 + "'", int2 == 65756);
    }

    @Test
    public void test9106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9106");
        int int2 = sum.Toplama.sum(8054, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8054 + "'", int2 == 8054);
    }

    @Test
    public void test9107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9107");
        int int2 = sum.Toplama.sum(4682, 15076);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19758 + "'", int2 == 19758);
    }

    @Test
    public void test9108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9108");
        int int2 = sum.Toplama.sum(6327, 9498);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15825 + "'", int2 == 15825);
    }

    @Test
    public void test9109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9109");
        int int2 = sum.Toplama.sum(0, 57379);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57379 + "'", int2 == 57379);
    }

    @Test
    public void test9110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9110");
        int int2 = sum.Toplama.sum(6649, 54652);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61301 + "'", int2 == 61301);
    }

    @Test
    public void test9111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9111");
        int int2 = sum.Toplama.sum(2253, 32947);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35200 + "'", int2 == 35200);
    }

    @Test
    public void test9112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9112");
        int int2 = sum.Toplama.sum(29758, 138851);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 168609 + "'", int2 == 168609);
    }

    @Test
    public void test9113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9113");
        int int2 = sum.Toplama.sum(32154, 13648);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45802 + "'", int2 == 45802);
    }

    @Test
    public void test9114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9114");
        int int2 = sum.Toplama.sum(19492, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19492 + "'", int2 == 19492);
    }

    @Test
    public void test9115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9115");
        int int2 = sum.Toplama.sum(113494, 30872);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 144366 + "'", int2 == 144366);
    }

    @Test
    public void test9116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9116");
        int int2 = sum.Toplama.sum(59338, 7866);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67204 + "'", int2 == 67204);
    }

    @Test
    public void test9117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9117");
        int int2 = sum.Toplama.sum(88640, 19247);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 107887 + "'", int2 == 107887);
    }

    @Test
    public void test9118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9118");
        int int2 = sum.Toplama.sum(1207, 13780);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14987 + "'", int2 == 14987);
    }

    @Test
    public void test9119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9119");
        int int2 = sum.Toplama.sum(7033, 22310);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29343 + "'", int2 == 29343);
    }

    @Test
    public void test9120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9120");
        int int2 = sum.Toplama.sum(18166, 26288);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44454 + "'", int2 == 44454);
    }

    @Test
    public void test9121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9121");
        int int2 = sum.Toplama.sum(31804, 5812);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37616 + "'", int2 == 37616);
    }

    @Test
    public void test9122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9122");
        sum.Toplama toplama0 = new sum.Toplama();
        java.lang.Class<?> wildcardClass1 = toplama0.getClass();
        java.lang.Class<?> wildcardClass2 = toplama0.getClass();
        java.lang.Class<?> wildcardClass3 = toplama0.getClass();
        java.lang.Class<?> wildcardClass4 = toplama0.getClass();
        java.lang.Class<?> wildcardClass5 = toplama0.getClass();
        java.lang.Class<?> wildcardClass6 = toplama0.getClass();
        java.lang.Class<?> wildcardClass7 = toplama0.getClass();
        java.lang.Class<?> wildcardClass8 = toplama0.getClass();
        java.lang.Class<?> wildcardClass9 = toplama0.getClass();
        java.lang.Class<?> wildcardClass10 = toplama0.getClass();
        java.lang.Class<?> wildcardClass11 = toplama0.getClass();
        java.lang.Class<?> wildcardClass12 = toplama0.getClass();
        java.lang.Class<?> wildcardClass13 = toplama0.getClass();
        java.lang.Class<?> wildcardClass14 = toplama0.getClass();
        java.lang.Class<?> wildcardClass15 = toplama0.getClass();
        java.lang.Class<?> wildcardClass16 = toplama0.getClass();
        java.lang.Class<?> wildcardClass17 = toplama0.getClass();
        java.lang.Class<?> wildcardClass18 = toplama0.getClass();
        java.lang.Class<?> wildcardClass19 = toplama0.getClass();
        java.lang.Class<?> wildcardClass20 = toplama0.getClass();
        java.lang.Class<?> wildcardClass21 = toplama0.getClass();
        java.lang.Class<?> wildcardClass22 = toplama0.getClass();
        java.lang.Class<?> wildcardClass23 = toplama0.getClass();
        java.lang.Class<?> wildcardClass24 = toplama0.getClass();
        java.lang.Class<?> wildcardClass25 = toplama0.getClass();
        java.lang.Class<?> wildcardClass26 = toplama0.getClass();
        java.lang.Class<?> wildcardClass27 = toplama0.getClass();
        java.lang.Class<?> wildcardClass28 = toplama0.getClass();
        java.lang.Class<?> wildcardClass29 = toplama0.getClass();
        java.lang.Class<?> wildcardClass30 = toplama0.getClass();
        java.lang.Class<?> wildcardClass31 = toplama0.getClass();
        java.lang.Class<?> wildcardClass32 = toplama0.getClass();
        java.lang.Class<?> wildcardClass33 = toplama0.getClass();
        java.lang.Class<?> wildcardClass34 = toplama0.getClass();
        java.lang.Class<?> wildcardClass35 = toplama0.getClass();
        java.lang.Class<?> wildcardClass36 = toplama0.getClass();
        java.lang.Class<?> wildcardClass37 = toplama0.getClass();
        java.lang.Class<?> wildcardClass38 = toplama0.getClass();
        java.lang.Class<?> wildcardClass39 = toplama0.getClass();
        java.lang.Class<?> wildcardClass40 = toplama0.getClass();
        java.lang.Class<?> wildcardClass41 = toplama0.getClass();
        java.lang.Class<?> wildcardClass42 = toplama0.getClass();
        java.lang.Class<?> wildcardClass43 = toplama0.getClass();
        java.lang.Class<?> wildcardClass44 = toplama0.getClass();
        java.lang.Class<?> wildcardClass45 = toplama0.getClass();
        java.lang.Class<?> wildcardClass46 = toplama0.getClass();
        java.lang.Class<?> wildcardClass47 = toplama0.getClass();
        java.lang.Class<?> wildcardClass48 = toplama0.getClass();
        java.lang.Class<?> wildcardClass49 = toplama0.getClass();
        java.lang.Class<?> wildcardClass50 = toplama0.getClass();
        java.lang.Class<?> wildcardClass51 = toplama0.getClass();
        java.lang.Class<?> wildcardClass52 = toplama0.getClass();
        java.lang.Class<?> wildcardClass53 = toplama0.getClass();
        java.lang.Class<?> wildcardClass54 = toplama0.getClass();
        java.lang.Class<?> wildcardClass55 = toplama0.getClass();
        java.lang.Class<?> wildcardClass56 = toplama0.getClass();
        java.lang.Class<?> wildcardClass57 = toplama0.getClass();
        java.lang.Class<?> wildcardClass58 = toplama0.getClass();
        java.lang.Class<?> wildcardClass59 = toplama0.getClass();
        java.lang.Class<?> wildcardClass60 = toplama0.getClass();
        java.lang.Class<?> wildcardClass61 = toplama0.getClass();
        java.lang.Class<?> wildcardClass62 = toplama0.getClass();
        java.lang.Class<?> wildcardClass63 = toplama0.getClass();
        java.lang.Class<?> wildcardClass64 = toplama0.getClass();
        java.lang.Class<?> wildcardClass65 = toplama0.getClass();
        java.lang.Class<?> wildcardClass66 = toplama0.getClass();
        java.lang.Class<?> wildcardClass67 = toplama0.getClass();
        java.lang.Class<?> wildcardClass68 = toplama0.getClass();
        java.lang.Class<?> wildcardClass69 = toplama0.getClass();
        java.lang.Class<?> wildcardClass70 = toplama0.getClass();
        java.lang.Class<?> wildcardClass71 = toplama0.getClass();
        java.lang.Class<?> wildcardClass72 = toplama0.getClass();
        java.lang.Class<?> wildcardClass73 = toplama0.getClass();
        java.lang.Class<?> wildcardClass74 = toplama0.getClass();
        java.lang.Class<?> wildcardClass75 = toplama0.getClass();
        java.lang.Class<?> wildcardClass76 = toplama0.getClass();
        java.lang.Class<?> wildcardClass77 = toplama0.getClass();
        java.lang.Class<?> wildcardClass78 = toplama0.getClass();
        java.lang.Class<?> wildcardClass79 = toplama0.getClass();
        java.lang.Class<?> wildcardClass80 = toplama0.getClass();
        java.lang.Class<?> wildcardClass81 = toplama0.getClass();
        java.lang.Class<?> wildcardClass82 = toplama0.getClass();
        java.lang.Class<?> wildcardClass83 = toplama0.getClass();
        java.lang.Class<?> wildcardClass84 = toplama0.getClass();
        java.lang.Class<?> wildcardClass85 = toplama0.getClass();
        java.lang.Class<?> wildcardClass86 = toplama0.getClass();
        java.lang.Class<?> wildcardClass87 = toplama0.getClass();
        java.lang.Class<?> wildcardClass88 = toplama0.getClass();
        java.lang.Class<?> wildcardClass89 = toplama0.getClass();
        java.lang.Class<?> wildcardClass90 = toplama0.getClass();
        java.lang.Class<?> wildcardClass91 = toplama0.getClass();
        java.lang.Class<?> wildcardClass92 = toplama0.getClass();
        java.lang.Class<?> wildcardClass93 = toplama0.getClass();
        java.lang.Class<?> wildcardClass94 = toplama0.getClass();
        java.lang.Class<?> wildcardClass95 = toplama0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertNotNull(wildcardClass68);
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertNotNull(wildcardClass71);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertNotNull(wildcardClass75);
        org.junit.Assert.assertNotNull(wildcardClass76);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertNotNull(wildcardClass78);
        org.junit.Assert.assertNotNull(wildcardClass79);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertNotNull(wildcardClass81);
        org.junit.Assert.assertNotNull(wildcardClass82);
        org.junit.Assert.assertNotNull(wildcardClass83);
        org.junit.Assert.assertNotNull(wildcardClass84);
        org.junit.Assert.assertNotNull(wildcardClass85);
        org.junit.Assert.assertNotNull(wildcardClass86);
        org.junit.Assert.assertNotNull(wildcardClass87);
        org.junit.Assert.assertNotNull(wildcardClass88);
        org.junit.Assert.assertNotNull(wildcardClass89);
        org.junit.Assert.assertNotNull(wildcardClass90);
        org.junit.Assert.assertNotNull(wildcardClass91);
        org.junit.Assert.assertNotNull(wildcardClass92);
        org.junit.Assert.assertNotNull(wildcardClass93);
        org.junit.Assert.assertNotNull(wildcardClass94);
        org.junit.Assert.assertNotNull(wildcardClass95);
    }

    @Test
    public void test9123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9123");
        int int2 = sum.Toplama.sum(9675, 56513);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 66188 + "'", int2 == 66188);
    }

    @Test
    public void test9124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9124");
        int int2 = sum.Toplama.sum(6019, 23563);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29582 + "'", int2 == 29582);
    }

    @Test
    public void test9125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9125");
        int int2 = sum.Toplama.sum(3368, 45697);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49065 + "'", int2 == 49065);
    }

    @Test
    public void test9126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9126");
        int int2 = sum.Toplama.sum(68028, 8386);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 76414 + "'", int2 == 76414);
    }

    @Test
    public void test9127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9127");
        int int2 = sum.Toplama.sum(141486, 9050);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 150536 + "'", int2 == 150536);
    }

    @Test
    public void test9128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9128");
        int int2 = sum.Toplama.sum(32766, 6768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39534 + "'", int2 == 39534);
    }

    @Test
    public void test9129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9129");
        int int2 = sum.Toplama.sum(30609, 12599);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43208 + "'", int2 == 43208);
    }

    @Test
    public void test9130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9130");
        int int2 = sum.Toplama.sum(381, 86201);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 86582 + "'", int2 == 86582);
    }

    @Test
    public void test9131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9131");
        int int2 = sum.Toplama.sum(80027, 45736);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 125763 + "'", int2 == 125763);
    }

    @Test
    public void test9132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9132");
        int int2 = sum.Toplama.sum(3165, 17452);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20617 + "'", int2 == 20617);
    }

    @Test
    public void test9133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9133");
        int int2 = sum.Toplama.sum(7079, 66872);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 73951 + "'", int2 == 73951);
    }

    @Test
    public void test9134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9134");
        int int2 = sum.Toplama.sum(77692, 51963);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 129655 + "'", int2 == 129655);
    }

    @Test
    public void test9135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9135");
        int int2 = sum.Toplama.sum(114143, 46272);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 160415 + "'", int2 == 160415);
    }

    @Test
    public void test9136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9136");
        int int2 = sum.Toplama.sum(0, 38969);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38969 + "'", int2 == 38969);
    }

    @Test
    public void test9137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9137");
        int int2 = sum.Toplama.sum(3871, 95695);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99566 + "'", int2 == 99566);
    }

    @Test
    public void test9138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9138");
        int int2 = sum.Toplama.sum(21058, 14941);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35999 + "'", int2 == 35999);
    }

    @Test
    public void test9139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9139");
        int int2 = sum.Toplama.sum(41786, 17945);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59731 + "'", int2 == 59731);
    }

    @Test
    public void test9140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9140");
        int int2 = sum.Toplama.sum(33793, 3092);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36885 + "'", int2 == 36885);
    }

    @Test
    public void test9141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9141");
        int int2 = sum.Toplama.sum(251064, 40527);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 291591 + "'", int2 == 291591);
    }

    @Test
    public void test9142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9142");
        int int2 = sum.Toplama.sum(61662, 13466);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 75128 + "'", int2 == 75128);
    }

    @Test
    public void test9143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9143");
        int int2 = sum.Toplama.sum(17384, 6214);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23598 + "'", int2 == 23598);
    }

    @Test
    public void test9144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9144");
        int int2 = sum.Toplama.sum(12576, 2735);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15311 + "'", int2 == 15311);
    }

    @Test
    public void test9145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9145");
        int int2 = sum.Toplama.sum(101409, 17152);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 118561 + "'", int2 == 118561);
    }

    @Test
    public void test9146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9146");
        int int2 = sum.Toplama.sum(21365, 35340);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56705 + "'", int2 == 56705);
    }

    @Test
    public void test9147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9147");
        int int2 = sum.Toplama.sum(39528, 19343);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58871 + "'", int2 == 58871);
    }

    @Test
    public void test9148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9148");
        int int2 = sum.Toplama.sum(75824, 81356);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 157180 + "'", int2 == 157180);
    }

    @Test
    public void test9149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9149");
        int int2 = sum.Toplama.sum(66550, 64039);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 130589 + "'", int2 == 130589);
    }

    @Test
    public void test9150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9150");
        int int2 = sum.Toplama.sum(80027, 93464);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 173491 + "'", int2 == 173491);
    }

    @Test
    public void test9151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9151");
        int int2 = sum.Toplama.sum(39405, 40900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80305 + "'", int2 == 80305);
    }

    @Test
    public void test9152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9152");
        int int2 = sum.Toplama.sum(3770, 23104);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26874 + "'", int2 == 26874);
    }

    @Test
    public void test9153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9153");
        int int2 = sum.Toplama.sum(5422, 19875);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25297 + "'", int2 == 25297);
    }

    @Test
    public void test9154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9154");
        int int2 = sum.Toplama.sum(45697, 13066);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58763 + "'", int2 == 58763);
    }

    @Test
    public void test9155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9155");
        int int2 = sum.Toplama.sum(19277, 19136);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38413 + "'", int2 == 38413);
    }

    @Test
    public void test9156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9156");
        int int2 = sum.Toplama.sum(61853, 18251);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80104 + "'", int2 == 80104);
    }

    @Test
    public void test9157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9157");
        int int2 = sum.Toplama.sum(86816, 3090);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 89906 + "'", int2 == 89906);
    }

    @Test
    public void test9158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9158");
        int int2 = sum.Toplama.sum(11199, 29740);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40939 + "'", int2 == 40939);
    }

    @Test
    public void test9159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9159");
        int int2 = sum.Toplama.sum(70057, 10988);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 81045 + "'", int2 == 81045);
    }

    @Test
    public void test9160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9160");
        int int2 = sum.Toplama.sum(56467, 37806);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 94273 + "'", int2 == 94273);
    }

    @Test
    public void test9161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9161");
        int int2 = sum.Toplama.sum(51400, 6051);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57451 + "'", int2 == 57451);
    }

    @Test
    public void test9162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9162");
        int int2 = sum.Toplama.sum(88640, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 88640 + "'", int2 == 88640);
    }

    @Test
    public void test9163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9163");
        int int2 = sum.Toplama.sum(13164, 8465);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21629 + "'", int2 == 21629);
    }

    @Test
    public void test9164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9164");
        int int2 = sum.Toplama.sum(22541, 30578);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53119 + "'", int2 == 53119);
    }

    @Test
    public void test9165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9165");
        int int2 = sum.Toplama.sum(37534, 10638);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48172 + "'", int2 == 48172);
    }

    @Test
    public void test9166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9166");
        int int2 = sum.Toplama.sum(27297, 13423);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40720 + "'", int2 == 40720);
    }

    @Test
    public void test9167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9167");
        int int2 = sum.Toplama.sum(10850, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10850 + "'", int2 == 10850);
    }

    @Test
    public void test9168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9168");
        int int2 = sum.Toplama.sum(32445, 46202);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78647 + "'", int2 == 78647);
    }

    @Test
    public void test9169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9169");
        int int2 = sum.Toplama.sum(10243, 23488);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33731 + "'", int2 == 33731);
    }

    @Test
    public void test9170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9170");
        int int2 = sum.Toplama.sum(59377, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59377 + "'", int2 == 59377);
    }

    @Test
    public void test9171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9171");
        int int2 = sum.Toplama.sum(12420, 7428);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19848 + "'", int2 == 19848);
    }

    @Test
    public void test9172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9172");
        int int2 = sum.Toplama.sum(54057, 86296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 140353 + "'", int2 == 140353);
    }

    @Test
    public void test9173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9173");
        int int2 = sum.Toplama.sum(33785, 103986);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 137771 + "'", int2 == 137771);
    }

    @Test
    public void test9174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9174");
        int int2 = sum.Toplama.sum(29910, 125864);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 155774 + "'", int2 == 155774);
    }

    @Test
    public void test9175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9175");
        int int2 = sum.Toplama.sum(69815, 42835);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 112650 + "'", int2 == 112650);
    }

    @Test
    public void test9176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9176");
        int int2 = sum.Toplama.sum(16803, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16803 + "'", int2 == 16803);
    }

    @Test
    public void test9177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9177");
        int int2 = sum.Toplama.sum(17649, 28788);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46437 + "'", int2 == 46437);
    }

    @Test
    public void test9178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9178");
        int int2 = sum.Toplama.sum(61225, 11772);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72997 + "'", int2 == 72997);
    }

    @Test
    public void test9179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9179");
        int int2 = sum.Toplama.sum(49828, 432);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50260 + "'", int2 == 50260);
    }

    @Test
    public void test9180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9180");
        int int2 = sum.Toplama.sum(39026, 7105);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46131 + "'", int2 == 46131);
    }

    @Test
    public void test9181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9181");
        int int2 = sum.Toplama.sum(547, 10199);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10746 + "'", int2 == 10746);
    }

    @Test
    public void test9182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9182");
        int int2 = sum.Toplama.sum(57762, 34078);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 91840 + "'", int2 == 91840);
    }

    @Test
    public void test9183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9183");
        int int2 = sum.Toplama.sum(31753, 21606);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53359 + "'", int2 == 53359);
    }

    @Test
    public void test9184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9184");
        int int2 = sum.Toplama.sum(137771, 41344);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 179115 + "'", int2 == 179115);
    }

    @Test
    public void test9185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9185");
        int int2 = sum.Toplama.sum(32806, 15976);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48782 + "'", int2 == 48782);
    }

    @Test
    public void test9186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9186");
        int int2 = sum.Toplama.sum(0, 38268);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38268 + "'", int2 == 38268);
    }

    @Test
    public void test9187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9187");
        int int2 = sum.Toplama.sum(23794, 6409);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30203 + "'", int2 == 30203);
    }

    @Test
    public void test9188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9188");
        int int2 = sum.Toplama.sum(3570, 32692);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36262 + "'", int2 == 36262);
    }

    @Test
    public void test9189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9189");
        int int2 = sum.Toplama.sum(97717, 19294);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 117011 + "'", int2 == 117011);
    }

    @Test
    public void test9190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9190");
        int int2 = sum.Toplama.sum(101766, 29616);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 131382 + "'", int2 == 131382);
    }

    @Test
    public void test9191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9191");
        int int2 = sum.Toplama.sum(0, 65829);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 65829 + "'", int2 == 65829);
    }

    @Test
    public void test9192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9192");
        int int2 = sum.Toplama.sum(12342, 42990);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55332 + "'", int2 == 55332);
    }

    @Test
    public void test9193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9193");
        int int2 = sum.Toplama.sum(30369, 46126);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 76495 + "'", int2 == 76495);
    }

    @Test
    public void test9194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9194");
        int int2 = sum.Toplama.sum(74391, 5780);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80171 + "'", int2 == 80171);
    }

    @Test
    public void test9195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9195");
        int int2 = sum.Toplama.sum(65971, 49828);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 115799 + "'", int2 == 115799);
    }

    @Test
    public void test9196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9196");
        int int2 = sum.Toplama.sum(194040, 80762);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 274802 + "'", int2 == 274802);
    }

    @Test
    public void test9197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9197");
        int int2 = sum.Toplama.sum(41982, 26988);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68970 + "'", int2 == 68970);
    }

    @Test
    public void test9198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9198");
        int int2 = sum.Toplama.sum(0, 10053);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10053 + "'", int2 == 10053);
    }

    @Test
    public void test9199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9199");
        int int2 = sum.Toplama.sum(4493, 46802);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51295 + "'", int2 == 51295);
    }

    @Test
    public void test9200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9200");
        int int2 = sum.Toplama.sum(11578, 25033);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36611 + "'", int2 == 36611);
    }

    @Test
    public void test9201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9201");
        int int2 = sum.Toplama.sum(23025, 10454);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33479 + "'", int2 == 33479);
    }

    @Test
    public void test9202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9202");
        int int2 = sum.Toplama.sum(3921, 112650);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 116571 + "'", int2 == 116571);
    }

    @Test
    public void test9203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9203");
        int int2 = sum.Toplama.sum(395, 17788);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18183 + "'", int2 == 18183);
    }

    @Test
    public void test9204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9204");
        int int2 = sum.Toplama.sum(0, 15923);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15923 + "'", int2 == 15923);
    }

    @Test
    public void test9205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9205");
        int int2 = sum.Toplama.sum(38292, 42316);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80608 + "'", int2 == 80608);
    }

    @Test
    public void test9206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9206");
        int int2 = sum.Toplama.sum(143529, 1843);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 145372 + "'", int2 == 145372);
    }

    @Test
    public void test9207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9207");
        int int2 = sum.Toplama.sum(15184, 12323);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27507 + "'", int2 == 27507);
    }

    @Test
    public void test9208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9208");
        int int2 = sum.Toplama.sum(20924, 75240);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96164 + "'", int2 == 96164);
    }

    @Test
    public void test9209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9209");
        int int2 = sum.Toplama.sum(7316, 23488);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30804 + "'", int2 == 30804);
    }

    @Test
    public void test9210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9210");
        int int2 = sum.Toplama.sum(8698, 40289);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48987 + "'", int2 == 48987);
    }

    @Test
    public void test9211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9211");
        int int2 = sum.Toplama.sum(10071, 48525);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58596 + "'", int2 == 58596);
    }

    @Test
    public void test9212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9212");
        int int2 = sum.Toplama.sum(55165, 28678);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 83843 + "'", int2 == 83843);
    }

    @Test
    public void test9213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9213");
        int int2 = sum.Toplama.sum(40946, 29382);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70328 + "'", int2 == 70328);
    }

    @Test
    public void test9214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9214");
        int int2 = sum.Toplama.sum(16533, 28382);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44915 + "'", int2 == 44915);
    }

    @Test
    public void test9215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9215");
        int int2 = sum.Toplama.sum(0, 30036);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30036 + "'", int2 == 30036);
    }

    @Test
    public void test9216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9216");
        int int2 = sum.Toplama.sum(63720, 35680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99400 + "'", int2 == 99400);
    }

    @Test
    public void test9217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9217");
        int int2 = sum.Toplama.sum(72867, 11428);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 84295 + "'", int2 == 84295);
    }

    @Test
    public void test9218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9218");
        int int2 = sum.Toplama.sum(26395, 4115);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30510 + "'", int2 == 30510);
    }

    @Test
    public void test9219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9219");
        int int2 = sum.Toplama.sum(29319, 8808);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38127 + "'", int2 == 38127);
    }

    @Test
    public void test9220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9220");
        int int2 = sum.Toplama.sum(109988, 26055);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 136043 + "'", int2 == 136043);
    }

    @Test
    public void test9221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9221");
        int int2 = sum.Toplama.sum(16109, 19320);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35429 + "'", int2 == 35429);
    }

    @Test
    public void test9222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9222");
        int int2 = sum.Toplama.sum(127655, 57475);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 185130 + "'", int2 == 185130);
    }

    @Test
    public void test9223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9223");
        int int2 = sum.Toplama.sum(28199, 73590);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 101789 + "'", int2 == 101789);
    }

    @Test
    public void test9224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9224");
        int int2 = sum.Toplama.sum(26159, 32112);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58271 + "'", int2 == 58271);
    }

    @Test
    public void test9225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9225");
        int int2 = sum.Toplama.sum(20004, 47286);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67290 + "'", int2 == 67290);
    }

    @Test
    public void test9226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9226");
        int int2 = sum.Toplama.sum(1060, 1662);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2722 + "'", int2 == 2722);
    }

    @Test
    public void test9227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9227");
        int int2 = sum.Toplama.sum(22041, 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22140 + "'", int2 == 22140);
    }

    @Test
    public void test9228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9228");
        int int2 = sum.Toplama.sum(29739, 16721);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46460 + "'", int2 == 46460);
    }

    @Test
    public void test9229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9229");
        int int2 = sum.Toplama.sum(23489, 69148);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 92637 + "'", int2 == 92637);
    }

    @Test
    public void test9230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9230");
        int int2 = sum.Toplama.sum(8054, 6160);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14214 + "'", int2 == 14214);
    }

    @Test
    public void test9231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9231");
        int int2 = sum.Toplama.sum(100682, 3824);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 104506 + "'", int2 == 104506);
    }

    @Test
    public void test9232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9232");
        int int2 = sum.Toplama.sum(5659, 19010);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24669 + "'", int2 == 24669);
    }

    @Test
    public void test9233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9233");
        int int2 = sum.Toplama.sum(28219, 1672);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29891 + "'", int2 == 29891);
    }

    @Test
    public void test9234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9234");
        int int2 = sum.Toplama.sum(37230, 20005);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57235 + "'", int2 == 57235);
    }

    @Test
    public void test9235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9235");
        int int2 = sum.Toplama.sum(2000, 47668);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49668 + "'", int2 == 49668);
    }

    @Test
    public void test9236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9236");
        int int2 = sum.Toplama.sum(5116, 15352);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20468 + "'", int2 == 20468);
    }

    @Test
    public void test9237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9237");
        int int2 = sum.Toplama.sum(24382, 282);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24664 + "'", int2 == 24664);
    }

    @Test
    public void test9238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9238");
        int int2 = sum.Toplama.sum(40840, 11558);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52398 + "'", int2 == 52398);
    }

    @Test
    public void test9239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9239");
        int int2 = sum.Toplama.sum(38537, 2835);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41372 + "'", int2 == 41372);
    }

    @Test
    public void test9240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9240");
        int int2 = sum.Toplama.sum(54740, 6229);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60969 + "'", int2 == 60969);
    }

    @Test
    public void test9241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9241");
        int int2 = sum.Toplama.sum(75696, 5774);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 81470 + "'", int2 == 81470);
    }

    @Test
    public void test9242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9242");
        int int2 = sum.Toplama.sum(17187, 6893);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24080 + "'", int2 == 24080);
    }

    @Test
    public void test9243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9243");
        int int2 = sum.Toplama.sum(9026, 3220);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12246 + "'", int2 == 12246);
    }

    @Test
    public void test9244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9244");
        int int2 = sum.Toplama.sum(25055, 143530);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 168585 + "'", int2 == 168585);
    }

    @Test
    public void test9245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9245");
        int int2 = sum.Toplama.sum(38894, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38894 + "'", int2 == 38894);
    }

    @Test
    public void test9246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9246");
        int int2 = sum.Toplama.sum(3281, 62776);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 66057 + "'", int2 == 66057);
    }

    @Test
    public void test9247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9247");
        int int2 = sum.Toplama.sum(9652, 28578);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38230 + "'", int2 == 38230);
    }

    @Test
    public void test9248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9248");
        int int2 = sum.Toplama.sum(49752, 1936);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51688 + "'", int2 == 51688);
    }

    @Test
    public void test9249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9249");
        int int2 = sum.Toplama.sum(12635, 77592);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90227 + "'", int2 == 90227);
    }

    @Test
    public void test9250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9250");
        int int2 = sum.Toplama.sum(35852, 9156);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45008 + "'", int2 == 45008);
    }

    @Test
    public void test9251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9251");
        int int2 = sum.Toplama.sum(0, 37142);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37142 + "'", int2 == 37142);
    }

    @Test
    public void test9252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9252");
        int int2 = sum.Toplama.sum(22320, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22320 + "'", int2 == 22320);
    }

    @Test
    public void test9253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9253");
        int int2 = sum.Toplama.sum(7963, 1070);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9033 + "'", int2 == 9033);
    }

    @Test
    public void test9254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9254");
        int int2 = sum.Toplama.sum(0, 18874);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18874 + "'", int2 == 18874);
    }

    @Test
    public void test9255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9255");
        int int2 = sum.Toplama.sum(3266, 10020);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13286 + "'", int2 == 13286);
    }

    @Test
    public void test9256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9256");
        int int2 = sum.Toplama.sum(25570, 676);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26246 + "'", int2 == 26246);
    }

    @Test
    public void test9257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9257");
        int int2 = sum.Toplama.sum(23129, 70057);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 93186 + "'", int2 == 93186);
    }

    @Test
    public void test9258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9258");
        int int2 = sum.Toplama.sum(14525, 18184);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32709 + "'", int2 == 32709);
    }

    @Test
    public void test9259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9259");
        int int2 = sum.Toplama.sum(31117, 40644);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 71761 + "'", int2 == 71761);
    }

    @Test
    public void test9260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9260");
        int int2 = sum.Toplama.sum(13367, 34732);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48099 + "'", int2 == 48099);
    }

    @Test
    public void test9261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9261");
        int int2 = sum.Toplama.sum(4730, 50549);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55279 + "'", int2 == 55279);
    }

    @Test
    public void test9262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9262");
        int int2 = sum.Toplama.sum(36152, 53796);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 89948 + "'", int2 == 89948);
    }

    @Test
    public void test9263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9263");
        int int2 = sum.Toplama.sum(54840, 38384);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 93224 + "'", int2 == 93224);
    }

    @Test
    public void test9264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9264");
        int int2 = sum.Toplama.sum(20799, 12348);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33147 + "'", int2 == 33147);
    }

    @Test
    public void test9265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9265");
        int int2 = sum.Toplama.sum(38537, 2994);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41531 + "'", int2 == 41531);
    }

    @Test
    public void test9266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9266");
        int int2 = sum.Toplama.sum(39502, 67045);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 106547 + "'", int2 == 106547);
    }

    @Test
    public void test9267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9267");
        int int2 = sum.Toplama.sum(1662, 50244);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51906 + "'", int2 == 51906);
    }

    @Test
    public void test9268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9268");
        int int2 = sum.Toplama.sum(12968, 71491);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 84459 + "'", int2 == 84459);
    }

    @Test
    public void test9269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9269");
        int int2 = sum.Toplama.sum(58351, 8457);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 66808 + "'", int2 == 66808);
    }

    @Test
    public void test9270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9270");
        int int2 = sum.Toplama.sum(1265, 14723);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15988 + "'", int2 == 15988);
    }

    @Test
    public void test9271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9271");
        int int2 = sum.Toplama.sum(3212, 30838);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34050 + "'", int2 == 34050);
    }

    @Test
    public void test9272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9272");
        int int2 = sum.Toplama.sum(50077, 32766);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 82843 + "'", int2 == 82843);
    }

    @Test
    public void test9273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9273");
        int int2 = sum.Toplama.sum(58206, 2065);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60271 + "'", int2 == 60271);
    }

    @Test
    public void test9274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9274");
        int int2 = sum.Toplama.sum(6409, 2895);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9304 + "'", int2 == 9304);
    }

    @Test
    public void test9275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9275");
        int int2 = sum.Toplama.sum(18653, 21526);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40179 + "'", int2 == 40179);
    }

    @Test
    public void test9276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test9276");
        int int2 = sum.Toplama.sum(37528, 3861);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41389 + "'", int2 == 41389);
    }
}

