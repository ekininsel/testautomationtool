import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test3501() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3501");
        int int2 = sum.Toplama.sum(0, 7996);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7996 + "'", int2 == 7996);
    }

    @Test
    public void test3502() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3502");
        int int2 = sum.Toplama.sum(24495, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24495 + "'", int2 == 24495);
    }

    @Test
    public void test3503() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3503");
        int int2 = sum.Toplama.sum(0, 28913);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28913 + "'", int2 == 28913);
    }

    @Test
    public void test3504() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3504");
        int int2 = sum.Toplama.sum(8808, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8808 + "'", int2 == 8808);
    }

    @Test
    public void test3505() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3505");
        int int2 = sum.Toplama.sum(19036, 37396);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56432 + "'", int2 == 56432);
    }

    @Test
    public void test3506() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3506");
        int int2 = sum.Toplama.sum(24991, 1585);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26576 + "'", int2 == 26576);
    }

    @Test
    public void test3507() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3507");
        int int2 = sum.Toplama.sum(12175, 12578);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24753 + "'", int2 == 24753);
    }

    @Test
    public void test3508() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3508");
        int int2 = sum.Toplama.sum(1970, 9212);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11182 + "'", int2 == 11182);
    }

    @Test
    public void test3509() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3509");
        int int2 = sum.Toplama.sum(8245, 10108);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18353 + "'", int2 == 18353);
    }

    @Test
    public void test3510() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3510");
        int int2 = sum.Toplama.sum(48527, 527);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49054 + "'", int2 == 49054);
    }

    @Test
    public void test3511() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3511");
        int int2 = sum.Toplama.sum(13955, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13987 + "'", int2 == 13987);
    }

    @Test
    public void test3512() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3512");
        int int2 = sum.Toplama.sum(1277, 1370);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2647 + "'", int2 == 2647);
    }

    @Test
    public void test3513() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3513");
        int int2 = sum.Toplama.sum(5368, 8709);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14077 + "'", int2 == 14077);
    }

    @Test
    public void test3514() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3514");
        int int2 = sum.Toplama.sum(12439, 6454);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18893 + "'", int2 == 18893);
    }

    @Test
    public void test3515() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3515");
        int int2 = sum.Toplama.sum(24224, 5067);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29291 + "'", int2 == 29291);
    }

    @Test
    public void test3516() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3516");
        int int2 = sum.Toplama.sum(20969, 27774);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48743 + "'", int2 == 48743);
    }

    @Test
    public void test3517() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3517");
        int int2 = sum.Toplama.sum(1747, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1747 + "'", int2 == 1747);
    }

    @Test
    public void test3518() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3518");
        int int2 = sum.Toplama.sum(4754, 6585);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11339 + "'", int2 == 11339);
    }

    @Test
    public void test3519() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3519");
        int int2 = sum.Toplama.sum(1780, 44099);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45879 + "'", int2 == 45879);
    }

    @Test
    public void test3520() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3520");
        int int2 = sum.Toplama.sum(6239, 5967);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12206 + "'", int2 == 12206);
    }

    @Test
    public void test3521() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3521");
        int int2 = sum.Toplama.sum(26159, 2347);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28506 + "'", int2 == 28506);
    }

    @Test
    public void test3522() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3522");
        int int2 = sum.Toplama.sum(2932, 2701);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5633 + "'", int2 == 5633);
    }

    @Test
    public void test3523() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3523");
        int int2 = sum.Toplama.sum(2895, 7790);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10685 + "'", int2 == 10685);
    }

    @Test
    public void test3524() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3524");
        int int2 = sum.Toplama.sum(4215, 39421);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43636 + "'", int2 == 43636);
    }

    @Test
    public void test3525() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3525");
        int int2 = sum.Toplama.sum(12345, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12345 + "'", int2 == 12345);
    }

    @Test
    public void test3526() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3526");
        int int2 = sum.Toplama.sum(548, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 548 + "'", int2 == 548);
    }

    @Test
    public void test3527() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3527");
        int int2 = sum.Toplama.sum(12130, 3698);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15828 + "'", int2 == 15828);
    }

    @Test
    public void test3528() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3528");
        int int2 = sum.Toplama.sum(0, 22868);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22868 + "'", int2 == 22868);
    }

    @Test
    public void test3529() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3529");
        int int2 = sum.Toplama.sum(7666, 46272);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53938 + "'", int2 == 53938);
    }

    @Test
    public void test3530() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3530");
        int int2 = sum.Toplama.sum(33675, 2871);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36546 + "'", int2 == 36546);
    }

    @Test
    public void test3531() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3531");
        int int2 = sum.Toplama.sum(19834, 1772);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21606 + "'", int2 == 21606);
    }

    @Test
    public void test3532() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3532");
        int int2 = sum.Toplama.sum(14250, 5111);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19361 + "'", int2 == 19361);
    }

    @Test
    public void test3533() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3533");
        int int2 = sum.Toplama.sum(3911, 3440);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7351 + "'", int2 == 7351);
    }

    @Test
    public void test3534() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3534");
        int int2 = sum.Toplama.sum(13199, 19308);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32507 + "'", int2 == 32507);
    }

    @Test
    public void test3535() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3535");
        int int2 = sum.Toplama.sum(28307, 11641);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39948 + "'", int2 == 39948);
    }

    @Test
    public void test3536() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3536");
        int int2 = sum.Toplama.sum(25983, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25983 + "'", int2 == 25983);
    }

    @Test
    public void test3537() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3537");
        int int2 = sum.Toplama.sum(5236, 18038);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23274 + "'", int2 == 23274);
    }

    @Test
    public void test3538() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3538");
        int int2 = sum.Toplama.sum(10270, 9870);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20140 + "'", int2 == 20140);
    }

    @Test
    public void test3539() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3539");
        int int2 = sum.Toplama.sum(2048, 8738);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10786 + "'", int2 == 10786);
    }

    @Test
    public void test3540() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3540");
        int int2 = sum.Toplama.sum(21280, 1105);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22385 + "'", int2 == 22385);
    }

    @Test
    public void test3541() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3541");
        int int2 = sum.Toplama.sum(4089, 20287);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24376 + "'", int2 == 24376);
    }

    @Test
    public void test3542() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3542");
        int int2 = sum.Toplama.sum(2804, 9089);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11893 + "'", int2 == 11893);
    }

    @Test
    public void test3543() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3543");
        int int2 = sum.Toplama.sum(11685, 9573);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21258 + "'", int2 == 21258);
    }

    @Test
    public void test3544() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3544");
        int int2 = sum.Toplama.sum(2223, 6986);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9209 + "'", int2 == 9209);
    }

    @Test
    public void test3545() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3545");
        int int2 = sum.Toplama.sum(2602, 4103);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6705 + "'", int2 == 6705);
    }

    @Test
    public void test3546() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3546");
        int int2 = sum.Toplama.sum(34970, 17152);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52122 + "'", int2 == 52122);
    }

    @Test
    public void test3547() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3547");
        int int2 = sum.Toplama.sum(23356, 4857);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28213 + "'", int2 == 28213);
    }

    @Test
    public void test3548() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3548");
        int int2 = sum.Toplama.sum(15117, 1903);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17020 + "'", int2 == 17020);
    }

    @Test
    public void test3549() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3549");
        int int2 = sum.Toplama.sum(16266, 1041);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17307 + "'", int2 == 17307);
    }

    @Test
    public void test3550() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3550");
        int int2 = sum.Toplama.sum(12600, 21344);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33944 + "'", int2 == 33944);
    }

    @Test
    public void test3551() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3551");
        int int2 = sum.Toplama.sum(19703, 4945);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24648 + "'", int2 == 24648);
    }

    @Test
    public void test3552() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3552");
        int int2 = sum.Toplama.sum(13869, 20643);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34512 + "'", int2 == 34512);
    }

    @Test
    public void test3553() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3553");
        int int2 = sum.Toplama.sum(0, 1747);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1747 + "'", int2 == 1747);
    }

    @Test
    public void test3554() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3554");
        int int2 = sum.Toplama.sum(2535, 3627);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6162 + "'", int2 == 6162);
    }

    @Test
    public void test3555() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3555");
        int int2 = sum.Toplama.sum(5089, 20278);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25367 + "'", int2 == 25367);
    }

    @Test
    public void test3556() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3556");
        int int2 = sum.Toplama.sum(8827, 8028);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16855 + "'", int2 == 16855);
    }

    @Test
    public void test3557() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3557");
        int int2 = sum.Toplama.sum(12378, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12378 + "'", int2 == 12378);
    }

    @Test
    public void test3558() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3558");
        int int2 = sum.Toplama.sum(1199, 29535);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30734 + "'", int2 == 30734);
    }

    @Test
    public void test3559() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3559");
        int int2 = sum.Toplama.sum(12600, 9618);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22218 + "'", int2 == 22218);
    }

    @Test
    public void test3560() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3560");
        int int2 = sum.Toplama.sum(161, 10900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11061 + "'", int2 == 11061);
    }

    @Test
    public void test3561() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3561");
        int int2 = sum.Toplama.sum(4446, 14294);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18740 + "'", int2 == 18740);
    }

    @Test
    public void test3562() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3562");
        int int2 = sum.Toplama.sum(17646, 24495);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42141 + "'", int2 == 42141);
    }

    @Test
    public void test3563() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3563");
        int int2 = sum.Toplama.sum(31119, 13816);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44935 + "'", int2 == 44935);
    }

    @Test
    public void test3564() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3564");
        int int2 = sum.Toplama.sum(12080, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12080 + "'", int2 == 12080);
    }

    @Test
    public void test3565() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3565");
        int int2 = sum.Toplama.sum(12849, 2947);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15796 + "'", int2 == 15796);
    }

    @Test
    public void test3566() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3566");
        int int2 = sum.Toplama.sum(8357, 44099);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52456 + "'", int2 == 52456);
    }

    @Test
    public void test3567() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3567");
        int int2 = sum.Toplama.sum(4407, 6623);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11030 + "'", int2 == 11030);
    }

    @Test
    public void test3568() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3568");
        int int2 = sum.Toplama.sum(7376, 6692);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14068 + "'", int2 == 14068);
    }

    @Test
    public void test3569() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3569");
        int int2 = sum.Toplama.sum(10897, 15704);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26601 + "'", int2 == 26601);
    }

    @Test
    public void test3570() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3570");
        int int2 = sum.Toplama.sum(19442, 18740);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38182 + "'", int2 == 38182);
    }

    @Test
    public void test3571() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3571");
        int int2 = sum.Toplama.sum(10762, 6149);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16911 + "'", int2 == 16911);
    }

    @Test
    public void test3572() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3572");
        int int2 = sum.Toplama.sum(5268, 10468);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15736 + "'", int2 == 15736);
    }

    @Test
    public void test3573() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3573");
        int int2 = sum.Toplama.sum(10004, 5571);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15575 + "'", int2 == 15575);
    }

    @Test
    public void test3574() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3574");
        int int2 = sum.Toplama.sum(44034, 1468);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45502 + "'", int2 == 45502);
    }

    @Test
    public void test3575() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3575");
        int int2 = sum.Toplama.sum((int) (short) 10, 15900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15910 + "'", int2 == 15910);
    }

    @Test
    public void test3576() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3576");
        int int2 = sum.Toplama.sum(4313, 3061);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7374 + "'", int2 == 7374);
    }

    @Test
    public void test3577() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3577");
        int int2 = sum.Toplama.sum(1652, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1652 + "'", int2 == 1652);
    }

    @Test
    public void test3578() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3578");
        int int2 = sum.Toplama.sum(6162, 1171);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7333 + "'", int2 == 7333);
    }

    @Test
    public void test3579() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3579");
        int int2 = sum.Toplama.sum(29291, 36203);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 65494 + "'", int2 == 65494);
    }

    @Test
    public void test3580() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3580");
        int int2 = sum.Toplama.sum(13663, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13663 + "'", int2 == 13663);
    }

    @Test
    public void test3581() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3581");
        int int2 = sum.Toplama.sum(4215, 18549);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22764 + "'", int2 == 22764);
    }

    @Test
    public void test3582() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3582");
        int int2 = sum.Toplama.sum(3363, 508);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3871 + "'", int2 == 3871);
    }

    @Test
    public void test3583() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3583");
        int int2 = sum.Toplama.sum(12576, 9297);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21873 + "'", int2 == 21873);
    }

    @Test
    public void test3584() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3584");
        int int2 = sum.Toplama.sum(5305, 8952);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14257 + "'", int2 == 14257);
    }

    @Test
    public void test3585() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3585");
        int int2 = sum.Toplama.sum(857, 16980);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17837 + "'", int2 == 17837);
    }

    @Test
    public void test3586() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3586");
        int int2 = sum.Toplama.sum(1784, 6983);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8767 + "'", int2 == 8767);
    }

    @Test
    public void test3587() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3587");
        int int2 = sum.Toplama.sum(14701, 16332);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31033 + "'", int2 == 31033);
    }

    @Test
    public void test3588() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3588");
        int int2 = sum.Toplama.sum(0, 16713);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16713 + "'", int2 == 16713);
    }

    @Test
    public void test3589() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3589");
        int int2 = sum.Toplama.sum(15251, 11962);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27213 + "'", int2 == 27213);
    }

    @Test
    public void test3590() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3590");
        int int2 = sum.Toplama.sum(3670, 2841);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6511 + "'", int2 == 6511);
    }

    @Test
    public void test3591() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3591");
        int int2 = sum.Toplama.sum(6330, 2474);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8804 + "'", int2 == 8804);
    }

    @Test
    public void test3592() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3592");
        int int2 = sum.Toplama.sum(12998, 432);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13430 + "'", int2 == 13430);
    }

    @Test
    public void test3593() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3593");
        int int2 = sum.Toplama.sum(7954, 4577);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12531 + "'", int2 == 12531);
    }

    @Test
    public void test3594() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3594");
        int int2 = sum.Toplama.sum(7376, 21275);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28651 + "'", int2 == 28651);
    }

    @Test
    public void test3595() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3595");
        int int2 = sum.Toplama.sum(1665, 3696);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5361 + "'", int2 == 5361);
    }

    @Test
    public void test3596() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3596");
        int int2 = sum.Toplama.sum(45623, 4265);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49888 + "'", int2 == 49888);
    }

    @Test
    public void test3597() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3597");
        int int2 = sum.Toplama.sum(18228, 7651);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25879 + "'", int2 == 25879);
    }

    @Test
    public void test3598() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3598");
        int int2 = sum.Toplama.sum(1897, 24224);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26121 + "'", int2 == 26121);
    }

    @Test
    public void test3599() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3599");
        int int2 = sum.Toplama.sum(22363, 1932);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24295 + "'", int2 == 24295);
    }

    @Test
    public void test3600() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3600");
        int int2 = sum.Toplama.sum(3262, 931);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4193 + "'", int2 == 4193);
    }

    @Test
    public void test3601() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3601");
        int int2 = sum.Toplama.sum(20557, 31396);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51953 + "'", int2 == 51953);
    }

    @Test
    public void test3602() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3602");
        int int2 = sum.Toplama.sum(1973, 12166);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14139 + "'", int2 == 14139);
    }

    @Test
    public void test3603() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3603");
        int int2 = sum.Toplama.sum(6729, 20758);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27487 + "'", int2 == 27487);
    }

    @Test
    public void test3604() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3604");
        int int2 = sum.Toplama.sum(1807, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1807 + "'", int2 == 1807);
    }

    @Test
    public void test3605() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3605");
        int int2 = sum.Toplama.sum(0, 1744);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1744 + "'", int2 == 1744);
    }

    @Test
    public void test3606() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3606");
        int int2 = sum.Toplama.sum(23019, 39948);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62967 + "'", int2 == 62967);
    }

    @Test
    public void test3607() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3607");
        int int2 = sum.Toplama.sum(12191, 22661);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34852 + "'", int2 == 34852);
    }

    @Test
    public void test3608() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3608");
        int int2 = sum.Toplama.sum(21275, 2488);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23763 + "'", int2 == 23763);
    }

    @Test
    public void test3609() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3609");
        int int2 = sum.Toplama.sum(8925, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8925 + "'", int2 == 8925);
    }

    @Test
    public void test3610() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3610");
        int int2 = sum.Toplama.sum(3644, 17896);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21540 + "'", int2 == 21540);
    }

    @Test
    public void test3611() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3611");
        int int2 = sum.Toplama.sum(51210, 10000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61210 + "'", int2 == 61210);
    }

    @Test
    public void test3612() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3612");
        int int2 = sum.Toplama.sum(3570, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3570 + "'", int2 == 3570);
    }

    @Test
    public void test3613() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3613");
        int int2 = sum.Toplama.sum(9275, 3595);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12870 + "'", int2 == 12870);
    }

    @Test
    public void test3614() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3614");
        int int2 = sum.Toplama.sum(9204, 2502);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11706 + "'", int2 == 11706);
    }

    @Test
    public void test3615() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3615");
        int int2 = sum.Toplama.sum(15575, 25088);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40663 + "'", int2 == 40663);
    }

    @Test
    public void test3616() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3616");
        int int2 = sum.Toplama.sum(0, 1446);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1446 + "'", int2 == 1446);
    }

    @Test
    public void test3617() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3617");
        int int2 = sum.Toplama.sum(4493, 2844);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7337 + "'", int2 == 7337);
    }

    @Test
    public void test3618() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3618");
        int int2 = sum.Toplama.sum(13741, 29134);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42875 + "'", int2 == 42875);
    }

    @Test
    public void test3619() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3619");
        int int2 = sum.Toplama.sum(20969, 9310);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30279 + "'", int2 == 30279);
    }

    @Test
    public void test3620() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3620");
        int int2 = sum.Toplama.sum(3737, 922);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4659 + "'", int2 == 4659);
    }

    @Test
    public void test3621() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3621");
        int int2 = sum.Toplama.sum(5997, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5997 + "'", int2 == 5997);
    }

    @Test
    public void test3622() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3622");
        int int2 = sum.Toplama.sum(4108, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4108 + "'", int2 == 4108);
    }

    @Test
    public void test3623() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3623");
        int int2 = sum.Toplama.sum(5055, 27258);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32313 + "'", int2 == 32313);
    }

    @Test
    public void test3624() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3624");
        int int2 = sum.Toplama.sum(11792, 3078);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14870 + "'", int2 == 14870);
    }

    @Test
    public void test3625() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3625");
        int int2 = sum.Toplama.sum(2897, 1342);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4239 + "'", int2 == 4239);
    }

    @Test
    public void test3626() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3626");
        int int2 = sum.Toplama.sum(1060, 13663);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14723 + "'", int2 == 14723);
    }

    @Test
    public void test3627() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3627");
        int int2 = sum.Toplama.sum(1427, 13079);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14506 + "'", int2 == 14506);
    }

    @Test
    public void test3628() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3628");
        int int2 = sum.Toplama.sum(15113, 10039);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25152 + "'", int2 == 25152);
    }

    @Test
    public void test3629() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3629");
        int int2 = sum.Toplama.sum(6511, 11442);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17953 + "'", int2 == 17953);
    }

    @Test
    public void test3630() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3630");
        int int2 = sum.Toplama.sum(720, 7720);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8440 + "'", int2 == 8440);
    }

    @Test
    public void test3631() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3631");
        int int2 = sum.Toplama.sum(9748, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9748 + "'", int2 == 9748);
    }

    @Test
    public void test3632() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3632");
        int int2 = sum.Toplama.sum(26536, 19724);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46260 + "'", int2 == 46260);
    }

    @Test
    public void test3633() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3633");
        int int2 = sum.Toplama.sum(14929, 25853);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40782 + "'", int2 == 40782);
    }

    @Test
    public void test3634() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3634");
        int int2 = sum.Toplama.sum(1958, 1998);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3956 + "'", int2 == 3956);
    }

    @Test
    public void test3635() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3635");
        int int2 = sum.Toplama.sum(3113, 30033);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33146 + "'", int2 == 33146);
    }

    @Test
    public void test3636() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3636");
        int int2 = sum.Toplama.sum(0, 10332);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10332 + "'", int2 == 10332);
    }

    @Test
    public void test3637() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3637");
        int int2 = sum.Toplama.sum(9475, 2835);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12310 + "'", int2 == 12310);
    }

    @Test
    public void test3638() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3638");
        int int2 = sum.Toplama.sum(4754, 1864);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6618 + "'", int2 == 6618);
    }

    @Test
    public void test3639() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3639");
        int int2 = sum.Toplama.sum(6885, 8515);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15400 + "'", int2 == 15400);
    }

    @Test
    public void test3640() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3640");
        int int2 = sum.Toplama.sum(313, 33083);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33396 + "'", int2 == 33396);
    }

    @Test
    public void test3641() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3641");
        int int2 = sum.Toplama.sum(50226, 4817);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55043 + "'", int2 == 55043);
    }

    @Test
    public void test3642() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3642");
        int int2 = sum.Toplama.sum(746, 4730);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5476 + "'", int2 == 5476);
    }

    @Test
    public void test3643() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3643");
        int int2 = sum.Toplama.sum(0, 28330);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28330 + "'", int2 == 28330);
    }

    @Test
    public void test3644() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3644");
        int int2 = sum.Toplama.sum(11235, 8011);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19246 + "'", int2 == 19246);
    }

    @Test
    public void test3645() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3645");
        int int2 = sum.Toplama.sum(33913, 6891);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40804 + "'", int2 == 40804);
    }

    @Test
    public void test3646() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3646");
        int int2 = sum.Toplama.sum(24484, 28232);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52716 + "'", int2 == 52716);
    }

    @Test
    public void test3647() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3647");
        int int2 = sum.Toplama.sum(12394, 8730);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21124 + "'", int2 == 21124);
    }

    @Test
    public void test3648() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3648");
        int int2 = sum.Toplama.sum(20755, 15235);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35990 + "'", int2 == 35990);
    }

    @Test
    public void test3649() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3649");
        int int2 = sum.Toplama.sum(4786, 2146);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6932 + "'", int2 == 6932);
    }

    @Test
    public void test3650() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3650");
        int int2 = sum.Toplama.sum(13566, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13566 + "'", int2 == 13566);
    }

    @Test
    public void test3651() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3651");
        int int2 = sum.Toplama.sum(1203, 16041);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17244 + "'", int2 == 17244);
    }

    @Test
    public void test3652() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3652");
        int int2 = sum.Toplama.sum(5633, 1862);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7495 + "'", int2 == 7495);
    }

    @Test
    public void test3653() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3653");
        int int2 = sum.Toplama.sum(640, 63080);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63720 + "'", int2 == 63720);
    }

    @Test
    public void test3654() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3654");
        int int2 = sum.Toplama.sum(1427, 7224);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8651 + "'", int2 == 8651);
    }

    @Test
    public void test3655() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3655");
        int int2 = sum.Toplama.sum((int) '4', 33956);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34008 + "'", int2 == 34008);
    }

    @Test
    public void test3656() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3656");
        int int2 = sum.Toplama.sum(423, 2352);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2775 + "'", int2 == 2775);
    }

    @Test
    public void test3657() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3657");
        int int2 = sum.Toplama.sum(5125, 39307);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44432 + "'", int2 == 44432);
    }

    @Test
    public void test3658() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3658");
        int int2 = sum.Toplama.sum(3124, 14136);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17260 + "'", int2 == 17260);
    }

    @Test
    public void test3659() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3659");
        int int2 = sum.Toplama.sum(26159, 13246);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39405 + "'", int2 == 39405);
    }

    @Test
    public void test3660() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3660");
        int int2 = sum.Toplama.sum(3135, 10990);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14125 + "'", int2 == 14125);
    }

    @Test
    public void test3661() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3661");
        int int2 = sum.Toplama.sum(8148, 33675);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41823 + "'", int2 == 41823);
    }

    @Test
    public void test3662() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3662");
        int int2 = sum.Toplama.sum(260, 20758);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21018 + "'", int2 == 21018);
    }

    @Test
    public void test3663() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3663");
        int int2 = sum.Toplama.sum(756, 34846);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35602 + "'", int2 == 35602);
    }

    @Test
    public void test3664() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3664");
        int int2 = sum.Toplama.sum(8709, 9136);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17845 + "'", int2 == 17845);
    }

    @Test
    public void test3665() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3665");
        int int2 = sum.Toplama.sum(42366, 2598);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44964 + "'", int2 == 44964);
    }

    @Test
    public void test3666() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3666");
        int int2 = sum.Toplama.sum(1201, 197);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1398 + "'", int2 == 1398);
    }

    @Test
    public void test3667() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3667");
        int int2 = sum.Toplama.sum(1932, 22759);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24691 + "'", int2 == 24691);
    }

    @Test
    public void test3668() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3668");
        int int2 = sum.Toplama.sum(269, 18166);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18435 + "'", int2 == 18435);
    }

    @Test
    public void test3669() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3669");
        int int2 = sum.Toplama.sum(12279, 17040);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29319 + "'", int2 == 29319);
    }

    @Test
    public void test3670() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3670");
        int int2 = sum.Toplama.sum(6327, 30931);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37258 + "'", int2 == 37258);
    }

    @Test
    public void test3671() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3671");
        int int2 = sum.Toplama.sum(1976, 1472);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3448 + "'", int2 == 3448);
    }

    @Test
    public void test3672() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3672");
        int int2 = sum.Toplama.sum(5829, 5268);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11097 + "'", int2 == 11097);
    }

    @Test
    public void test3673() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3673");
        int int2 = sum.Toplama.sum(8709, 23263);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31972 + "'", int2 == 31972);
    }

    @Test
    public void test3674() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3674");
        int int2 = sum.Toplama.sum(8219, 20854);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29073 + "'", int2 == 29073);
    }

    @Test
    public void test3675() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3675");
        int int2 = sum.Toplama.sum(9526, 34008);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43534 + "'", int2 == 43534);
    }

    @Test
    public void test3676() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3676");
        int int2 = sum.Toplama.sum(22120, 16774);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38894 + "'", int2 == 38894);
    }

    @Test
    public void test3677() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3677");
        int int2 = sum.Toplama.sum(9991, 15796);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25787 + "'", int2 == 25787);
    }

    @Test
    public void test3678() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3678");
        int int2 = sum.Toplama.sum(15906, 32313);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48219 + "'", int2 == 48219);
    }

    @Test
    public void test3679() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3679");
        int int2 = sum.Toplama.sum(11225, 1185);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12410 + "'", int2 == 12410);
    }

    @Test
    public void test3680() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3680");
        int int2 = sum.Toplama.sum(10199, 992);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11191 + "'", int2 == 11191);
    }

    @Test
    public void test3681() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3681");
        int int2 = sum.Toplama.sum(15486, 23019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38505 + "'", int2 == 38505);
    }

    @Test
    public void test3682() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3682");
        int int2 = sum.Toplama.sum(1005, 53142);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54147 + "'", int2 == 54147);
    }

    @Test
    public void test3683() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3683");
        int int2 = sum.Toplama.sum(9035, 5541);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14576 + "'", int2 == 14576);
    }

    @Test
    public void test3684() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3684");
        int int2 = sum.Toplama.sum(6337, 2536);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8873 + "'", int2 == 8873);
    }

    @Test
    public void test3685() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3685");
        int int2 = sum.Toplama.sum(0, 22413);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22413 + "'", int2 == 22413);
    }

    @Test
    public void test3686() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3686");
        int int2 = sum.Toplama.sum(2282, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2282 + "'", int2 == 2282);
    }

    @Test
    public void test3687() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3687");
        int int2 = sum.Toplama.sum(19026, 27188);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46214 + "'", int2 == 46214);
    }

    @Test
    public void test3688() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3688");
        int int2 = sum.Toplama.sum(5673, 6767);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12440 + "'", int2 == 12440);
    }

    @Test
    public void test3689() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3689");
        int int2 = sum.Toplama.sum(7528, 11045);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18573 + "'", int2 == 18573);
    }

    @Test
    public void test3690() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3690");
        int int2 = sum.Toplama.sum(3211, 27836);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31047 + "'", int2 == 31047);
    }

    @Test
    public void test3691() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3691");
        int int2 = sum.Toplama.sum(0, 7615);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7615 + "'", int2 == 7615);
    }

    @Test
    public void test3692() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3692");
        int int2 = sum.Toplama.sum(12342, 1337);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13679 + "'", int2 == 13679);
    }

    @Test
    public void test3693() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3693");
        int int2 = sum.Toplama.sum(12393, 1343);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13736 + "'", int2 == 13736);
    }

    @Test
    public void test3694() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3694");
        int int2 = sum.Toplama.sum(20428, 1829);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22257 + "'", int2 == 22257);
    }

    @Test
    public void test3695() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3695");
        int int2 = sum.Toplama.sum(45623, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45623 + "'", int2 == 45623);
    }

    @Test
    public void test3696() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3696");
        int int2 = sum.Toplama.sum(18656, 11816);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30472 + "'", int2 == 30472);
    }

    @Test
    public void test3697() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3697");
        int int2 = sum.Toplama.sum(3281, 2192);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5473 + "'", int2 == 5473);
    }

    @Test
    public void test3698() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3698");
        int int2 = sum.Toplama.sum(3445, 22186);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25631 + "'", int2 == 25631);
    }

    @Test
    public void test3699() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3699");
        int int2 = sum.Toplama.sum(0, 15796);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15796 + "'", int2 == 15796);
    }

    @Test
    public void test3700() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3700");
        int int2 = sum.Toplama.sum(13785, 19871);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33656 + "'", int2 == 33656);
    }

    @Test
    public void test3701() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3701");
        int int2 = sum.Toplama.sum(18850, 10939);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29789 + "'", int2 == 29789);
    }

    @Test
    public void test3702() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3702");
        int int2 = sum.Toplama.sum(1000, 14566);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15566 + "'", int2 == 15566);
    }

    @Test
    public void test3703() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3703");
        int int2 = sum.Toplama.sum(18226, 25450);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43676 + "'", int2 == 43676);
    }

    @Test
    public void test3704() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3704");
        int int2 = sum.Toplama.sum(9297, 30673);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39970 + "'", int2 == 39970);
    }

    @Test
    public void test3705() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3705");
        int int2 = sum.Toplama.sum(11685, 49092);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60777 + "'", int2 == 60777);
    }

    @Test
    public void test3706() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3706");
        int int2 = sum.Toplama.sum(23872, 2602);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26474 + "'", int2 == 26474);
    }

    @Test
    public void test3707() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3707");
        int int2 = sum.Toplama.sum(13679, 25288);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38967 + "'", int2 == 38967);
    }

    @Test
    public void test3708() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3708");
        int int2 = sum.Toplama.sum(0, 17466);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17466 + "'", int2 == 17466);
    }

    @Test
    public void test3709() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3709");
        int int2 = sum.Toplama.sum(3256, 396);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3652 + "'", int2 == 3652);
    }

    @Test
    public void test3710() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3710");
        int int2 = sum.Toplama.sum(34852, 19130);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53982 + "'", int2 == 53982);
    }

    @Test
    public void test3711() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3711");
        int int2 = sum.Toplama.sum(30838, 24484);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55322 + "'", int2 == 55322);
    }

    @Test
    public void test3712() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3712");
        int int2 = sum.Toplama.sum(1213, 2000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3213 + "'", int2 == 3213);
    }

    @Test
    public void test3713() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3713");
        int int2 = sum.Toplama.sum(20287, 12826);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33113 + "'", int2 == 33113);
    }

    @Test
    public void test3714() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3714");
        int int2 = sum.Toplama.sum(2410, 2645);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5055 + "'", int2 == 5055);
    }

    @Test
    public void test3715() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3715");
        int int2 = sum.Toplama.sum(14709, 17583);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32292 + "'", int2 == 32292);
    }

    @Test
    public void test3716() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3716");
        int int2 = sum.Toplama.sum(3627, 28651);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32278 + "'", int2 == 32278);
    }

    @Test
    public void test3717() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3717");
        int int2 = sum.Toplama.sum(29777, 9209);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38986 + "'", int2 == 38986);
    }

    @Test
    public void test3718() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3718");
        int int2 = sum.Toplama.sum(21220, 1744);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22964 + "'", int2 == 22964);
    }

    @Test
    public void test3719() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3719");
        int int2 = sum.Toplama.sum(52716, 2735);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55451 + "'", int2 == 55451);
    }

    @Test
    public void test3720() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3720");
        int int2 = sum.Toplama.sum(10022, 3950);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13972 + "'", int2 == 13972);
    }

    @Test
    public void test3721() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3721");
        int int2 = sum.Toplama.sum(46508, 14620);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61128 + "'", int2 == 61128);
    }

    @Test
    public void test3722() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3722");
        int int2 = sum.Toplama.sum(3982, 38894);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42876 + "'", int2 == 42876);
    }

    @Test
    public void test3723() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3723");
        int int2 = sum.Toplama.sum(7817, 30033);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37850 + "'", int2 == 37850);
    }

    @Test
    public void test3724() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3724");
        int int2 = sum.Toplama.sum(31119, 1666);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32785 + "'", int2 == 32785);
    }

    @Test
    public void test3725() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3725");
        int int2 = sum.Toplama.sum(6861, 6876);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13737 + "'", int2 == 13737);
    }

    @Test
    public void test3726() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3726");
        int int2 = sum.Toplama.sum(10396, 32785);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43181 + "'", int2 == 43181);
    }

    @Test
    public void test3727() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3727");
        int int2 = sum.Toplama.sum(6143, 18129);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24272 + "'", int2 == 24272);
    }

    @Test
    public void test3728() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3728");
        int int2 = sum.Toplama.sum(1903, 17443);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19346 + "'", int2 == 19346);
    }

    @Test
    public void test3729() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3729");
        int int2 = sum.Toplama.sum(33513, 78531);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 112044 + "'", int2 == 112044);
    }

    @Test
    public void test3730() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3730");
        int int2 = sum.Toplama.sum(880, 8963);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9843 + "'", int2 == 9843);
    }

    @Test
    public void test3731() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3731");
        int int2 = sum.Toplama.sum(6585, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6585 + "'", int2 == 6585);
    }

    @Test
    public void test3732() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3732");
        int int2 = sum.Toplama.sum(1465, 27406);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28871 + "'", int2 == 28871);
    }

    @Test
    public void test3733() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3733");
        int int2 = sum.Toplama.sum(7472, 25922);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33394 + "'", int2 == 33394);
    }

    @Test
    public void test3734() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3734");
        int int2 = sum.Toplama.sum(8271, 6610);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14881 + "'", int2 == 14881);
    }

    @Test
    public void test3735() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3735");
        int int2 = sum.Toplama.sum(1000, 4611);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5611 + "'", int2 == 5611);
    }

    @Test
    public void test3736() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3736");
        int int2 = sum.Toplama.sum(20730, 20224);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40954 + "'", int2 == 40954);
    }

    @Test
    public void test3737() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3737");
        int int2 = sum.Toplama.sum(14437, 25476);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39913 + "'", int2 == 39913);
    }

    @Test
    public void test3738() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3738");
        int int2 = sum.Toplama.sum(25253, 216);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25469 + "'", int2 == 25469);
    }

    @Test
    public void test3739() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3739");
        int int2 = sum.Toplama.sum(24731, 21913);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46644 + "'", int2 == 46644);
    }

    @Test
    public void test3740() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3740");
        int int2 = sum.Toplama.sum(36295, 3241);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39536 + "'", int2 == 39536);
    }

    @Test
    public void test3741() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3741");
        int int2 = sum.Toplama.sum(21540, 14730);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36270 + "'", int2 == 36270);
    }

    @Test
    public void test3742() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3742");
        int int2 = sum.Toplama.sum(1037, 24579);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25616 + "'", int2 == 25616);
    }

    @Test
    public void test3743() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3743");
        int int2 = sum.Toplama.sum(14631, 19020);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33651 + "'", int2 == 33651);
    }

    @Test
    public void test3744() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3744");
        int int2 = sum.Toplama.sum(23968, 25086);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49054 + "'", int2 == 49054);
    }

    @Test
    public void test3745() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3745");
        int int2 = sum.Toplama.sum(44992, 21704);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 66696 + "'", int2 == 66696);
    }

    @Test
    public void test3746() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3746");
        int int2 = sum.Toplama.sum(37864, 18149);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56013 + "'", int2 == 56013);
    }

    @Test
    public void test3747() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3747");
        int int2 = sum.Toplama.sum(27430, 3623);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31053 + "'", int2 == 31053);
    }

    @Test
    public void test3748() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3748");
        int int2 = sum.Toplama.sum(21504, 5208);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26712 + "'", int2 == 26712);
    }

    @Test
    public void test3749() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3749");
        int int2 = sum.Toplama.sum(3101, 25879);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28980 + "'", int2 == 28980);
    }

    @Test
    public void test3750() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3750");
        int int2 = sum.Toplama.sum(25842, 1864);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27706 + "'", int2 == 27706);
    }

    @Test
    public void test3751() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3751");
        int int2 = sum.Toplama.sum(23034, 19442);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42476 + "'", int2 == 42476);
    }

    @Test
    public void test3752() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3752");
        int int2 = sum.Toplama.sum(15251, 78531);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 93782 + "'", int2 == 93782);
    }

    @Test
    public void test3753() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3753");
        int int2 = sum.Toplama.sum(11442, 3742);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15184 + "'", int2 == 15184);
    }

    @Test
    public void test3754() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3754");
        int int2 = sum.Toplama.sum(35479, 11401);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46880 + "'", int2 == 46880);
    }

    @Test
    public void test3755() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3755");
        int int2 = sum.Toplama.sum(6241, 7642);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13883 + "'", int2 == 13883);
    }

    @Test
    public void test3756() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3756");
        int int2 = sum.Toplama.sum(626, 3777);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4403 + "'", int2 == 4403);
    }

    @Test
    public void test3757() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3757");
        int int2 = sum.Toplama.sum(2741, 8263);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11004 + "'", int2 == 11004);
    }

    @Test
    public void test3758() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3758");
        int int2 = sum.Toplama.sum(42476, 48218);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90694 + "'", int2 == 90694);
    }

    @Test
    public void test3759() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3759");
        int int2 = sum.Toplama.sum(24344, 3447);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27791 + "'", int2 == 27791);
    }

    @Test
    public void test3760() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3760");
        int int2 = sum.Toplama.sum(5639, 17066);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22705 + "'", int2 == 22705);
    }

    @Test
    public void test3761() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3761");
        int int2 = sum.Toplama.sum(61210, 7860);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69070 + "'", int2 == 69070);
    }

    @Test
    public void test3762() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3762");
        int int2 = sum.Toplama.sum(1365, 394);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1759 + "'", int2 == 1759);
    }

    @Test
    public void test3763() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3763");
        int int2 = sum.Toplama.sum(17853, 2923);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20776 + "'", int2 == 20776);
    }

    @Test
    public void test3764() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3764");
        int int2 = sum.Toplama.sum(4327, 11593);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15920 + "'", int2 == 15920);
    }

    @Test
    public void test3765() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3765");
        int int2 = sum.Toplama.sum(24579, 6239);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30818 + "'", int2 == 30818);
    }

    @Test
    public void test3766() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3766");
        int int2 = sum.Toplama.sum(746, 7714);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8460 + "'", int2 == 8460);
    }

    @Test
    public void test3767() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3767");
        int int2 = sum.Toplama.sum(36546, 4453);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40999 + "'", int2 == 40999);
    }

    @Test
    public void test3768() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3768");
        int int2 = sum.Toplama.sum(13700, 22837);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36537 + "'", int2 == 36537);
    }

    @Test
    public void test3769() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3769");
        int int2 = sum.Toplama.sum(0, 3511);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3511 + "'", int2 == 3511);
    }

    @Test
    public void test3770() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3770");
        int int2 = sum.Toplama.sum(0, 34115);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34115 + "'", int2 == 34115);
    }

    @Test
    public void test3771() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3771");
        int int2 = sum.Toplama.sum(9916, 11510);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21426 + "'", int2 == 21426);
    }

    @Test
    public void test3772() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3772");
        int int2 = sum.Toplama.sum(4419, 44935);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49354 + "'", int2 == 49354);
    }

    @Test
    public void test3773() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3773");
        int int2 = sum.Toplama.sum(16774, 10063);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26837 + "'", int2 == 26837);
    }

    @Test
    public void test3774() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3774");
        int int2 = sum.Toplama.sum(17331, 5041);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22372 + "'", int2 == 22372);
    }

    @Test
    public void test3775() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3775");
        int int2 = sum.Toplama.sum(28913, 14467);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43380 + "'", int2 == 43380);
    }

    @Test
    public void test3776() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3776");
        int int2 = sum.Toplama.sum(19309, 32278);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51587 + "'", int2 == 51587);
    }

    @Test
    public void test3777() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3777");
        int int2 = sum.Toplama.sum(27851, 44602);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72453 + "'", int2 == 72453);
    }

    @Test
    public void test3778() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3778");
        int int2 = sum.Toplama.sum(9148, 1579);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10727 + "'", int2 == 10727);
    }

    @Test
    public void test3779() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3779");
        int int2 = sum.Toplama.sum(4542, 20191);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24733 + "'", int2 == 24733);
    }

    @Test
    public void test3780() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3780");
        int int2 = sum.Toplama.sum(1601, 6869);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8470 + "'", int2 == 8470);
    }

    @Test
    public void test3781() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3781");
        int int2 = sum.Toplama.sum(22012, 20356);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42368 + "'", int2 == 42368);
    }

    @Test
    public void test3782() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3782");
        int int2 = sum.Toplama.sum(5139, 6679);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11818 + "'", int2 == 11818);
    }

    @Test
    public void test3783() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3783");
        int int2 = sum.Toplama.sum(543, 18014);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18557 + "'", int2 == 18557);
    }

    @Test
    public void test3784() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3784");
        int int2 = sum.Toplama.sum(8483, 39970);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48453 + "'", int2 == 48453);
    }

    @Test
    public void test3785() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3785");
        int int2 = sum.Toplama.sum(20924, 814);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21738 + "'", int2 == 21738);
    }

    @Test
    public void test3786() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3786");
        int int2 = sum.Toplama.sum(8804, 2063);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10867 + "'", int2 == 10867);
    }

    @Test
    public void test3787() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3787");
        int int2 = sum.Toplama.sum(31119, 7316);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38435 + "'", int2 == 38435);
    }

    @Test
    public void test3788() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3788");
        int int2 = sum.Toplama.sum(1064, 18435);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19499 + "'", int2 == 19499);
    }

    @Test
    public void test3789() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3789");
        int int2 = sum.Toplama.sum(25467, 358);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25825 + "'", int2 == 25825);
    }

    @Test
    public void test3790() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3790");
        int int2 = sum.Toplama.sum(38129, 11045);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49174 + "'", int2 == 49174);
    }

    @Test
    public void test3791() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3791");
        int int2 = sum.Toplama.sum(13182, 1932);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15114 + "'", int2 == 15114);
    }

    @Test
    public void test3792() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3792");
        int int2 = sum.Toplama.sum(39542, 910);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40452 + "'", int2 == 40452);
    }

    @Test
    public void test3793() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3793");
        int int2 = sum.Toplama.sum(18177, 11184);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29361 + "'", int2 == 29361);
    }

    @Test
    public void test3794() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3794");
        int int2 = sum.Toplama.sum(11593, 4093);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15686 + "'", int2 == 15686);
    }

    @Test
    public void test3795() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3795");
        int int2 = sum.Toplama.sum(29319, 32278);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61597 + "'", int2 == 61597);
    }

    @Test
    public void test3796() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3796");
        int int2 = sum.Toplama.sum(15307, 38881);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54188 + "'", int2 == 54188);
    }

    @Test
    public void test3797() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3797");
        int int2 = sum.Toplama.sum(14567, 8440);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23007 + "'", int2 == 23007);
    }

    @Test
    public void test3798() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3798");
        int int2 = sum.Toplama.sum(22210, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22210 + "'", int2 == 22210);
    }

    @Test
    public void test3799() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3799");
        int int2 = sum.Toplama.sum(4945, 2740);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7685 + "'", int2 == 7685);
    }

    @Test
    public void test3800() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3800");
        int int2 = sum.Toplama.sum(0, 1387);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1387 + "'", int2 == 1387);
    }

    @Test
    public void test3801() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3801");
        int int2 = sum.Toplama.sum(53080, 1943);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55023 + "'", int2 == 55023);
    }

    @Test
    public void test3802() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3802");
        int int2 = sum.Toplama.sum(8357, 9902);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18259 + "'", int2 == 18259);
    }

    @Test
    public void test3803() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3803");
        int int2 = sum.Toplama.sum(1572, 5973);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7545 + "'", int2 == 7545);
    }

    @Test
    public void test3804() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3804");
        int int2 = sum.Toplama.sum(39913, 12566);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52479 + "'", int2 == 52479);
    }

    @Test
    public void test3805() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3805");
        int int2 = sum.Toplama.sum(29816, 17452);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47268 + "'", int2 == 47268);
    }

    @Test
    public void test3806() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3806");
        int int2 = sum.Toplama.sum(4239, 1683);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5922 + "'", int2 == 5922);
    }

    @Test
    public void test3807() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3807");
        int int2 = sum.Toplama.sum(9978, 11706);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21684 + "'", int2 == 21684);
    }

    @Test
    public void test3808() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3808");
        int int2 = sum.Toplama.sum(7612, 29361);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36973 + "'", int2 == 36973);
    }

    @Test
    public void test3809() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3809");
        int int2 = sum.Toplama.sum(6586, 27706);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34292 + "'", int2 == 34292);
    }

    @Test
    public void test3810() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3810");
        int int2 = sum.Toplama.sum(1255, 10165);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11420 + "'", int2 == 11420);
    }

    @Test
    public void test3811() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3811");
        int int2 = sum.Toplama.sum(5621, 18234);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23855 + "'", int2 == 23855);
    }

    @Test
    public void test3812() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3812");
        int int2 = sum.Toplama.sum((int) (short) -1, 1415);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1414 + "'", int2 == 1414);
    }

    @Test
    public void test3813() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3813");
        int int2 = sum.Toplama.sum(188, 8515);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8703 + "'", int2 == 8703);
    }

    @Test
    public void test3814() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3814");
        int int2 = sum.Toplama.sum(30786, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30786 + "'", int2 == 30786);
    }

    @Test
    public void test3815() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3815");
        int int2 = sum.Toplama.sum(4410, 4372);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8782 + "'", int2 == 8782);
    }

    @Test
    public void test3816() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3816");
        int int2 = sum.Toplama.sum(7105, 10683);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17788 + "'", int2 == 17788);
    }

    @Test
    public void test3817() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3817");
        int int2 = sum.Toplama.sum(3628, 21936);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25564 + "'", int2 == 25564);
    }

    @Test
    public void test3818() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3818");
        int int2 = sum.Toplama.sum(6932, 875);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7807 + "'", int2 == 7807);
    }

    @Test
    public void test3819() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3819");
        int int2 = sum.Toplama.sum(5163, 11397);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16560 + "'", int2 == 16560);
    }

    @Test
    public void test3820() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3820");
        int int2 = sum.Toplama.sum(16606, 4916);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21522 + "'", int2 == 21522);
    }

    @Test
    public void test3821() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3821");
        int int2 = sum.Toplama.sum(5814, 28080);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33894 + "'", int2 == 33894);
    }

    @Test
    public void test3822() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3822");
        int int2 = sum.Toplama.sum(25388, 2111);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27499 + "'", int2 == 27499);
    }

    @Test
    public void test3823() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3823");
        int int2 = sum.Toplama.sum(31047, 51633);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 82680 + "'", int2 == 82680);
    }

    @Test
    public void test3824() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3824");
        int int2 = sum.Toplama.sum(9761, 17912);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27673 + "'", int2 == 27673);
    }

    @Test
    public void test3825() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3825");
        int int2 = sum.Toplama.sum(8360, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8360 + "'", int2 == 8360);
    }

    @Test
    public void test3826() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3826");
        int int2 = sum.Toplama.sum(12610, 14050);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26660 + "'", int2 == 26660);
    }

    @Test
    public void test3827() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3827");
        int int2 = sum.Toplama.sum((int) (byte) 100, 31301);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31401 + "'", int2 == 31401);
    }

    @Test
    public void test3828() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3828");
        int int2 = sum.Toplama.sum(9733, 14719);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24452 + "'", int2 == 24452);
    }

    @Test
    public void test3829() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3829");
        int int2 = sum.Toplama.sum(19193, 9275);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28468 + "'", int2 == 28468);
    }

    @Test
    public void test3830() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3830");
        int int2 = sum.Toplama.sum(20428, 8730);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29158 + "'", int2 == 29158);
    }

    @Test
    public void test3831() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3831");
        int int2 = sum.Toplama.sum(2994, 3807);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6801 + "'", int2 == 6801);
    }

    @Test
    public void test3832() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3832");
        int int2 = sum.Toplama.sum(1536, 37070);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38606 + "'", int2 == 38606);
    }

    @Test
    public void test3833() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3833");
        int int2 = sum.Toplama.sum(8065, 36321);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44386 + "'", int2 == 44386);
    }

    @Test
    public void test3834() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3834");
        int int2 = sum.Toplama.sum(6954, 15007);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21961 + "'", int2 == 21961);
    }

    @Test
    public void test3835() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3835");
        int int2 = sum.Toplama.sum(28892, 7030);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35922 + "'", int2 == 35922);
    }

    @Test
    public void test3836() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3836");
        int int2 = sum.Toplama.sum(6914, 30496);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37410 + "'", int2 == 37410);
    }

    @Test
    public void test3837() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3837");
        int int2 = sum.Toplama.sum(4476, 16109);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20585 + "'", int2 == 20585);
    }

    @Test
    public void test3838() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3838");
        int int2 = sum.Toplama.sum(5512, 1357);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6869 + "'", int2 == 6869);
    }

    @Test
    public void test3839() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3839");
        int int2 = sum.Toplama.sum(26562, 23190);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49752 + "'", int2 == 49752);
    }

    @Test
    public void test3840() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3840");
        int int2 = sum.Toplama.sum(6957, 6999);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13956 + "'", int2 == 13956);
    }

    @Test
    public void test3841() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3841");
        int int2 = sum.Toplama.sum(27479, 32313);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59792 + "'", int2 == 59792);
    }

    @Test
    public void test3842() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3842");
        int int2 = sum.Toplama.sum(7528, 4403);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11931 + "'", int2 == 11931);
    }

    @Test
    public void test3843() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3843");
        int int2 = sum.Toplama.sum(735, 21808);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22543 + "'", int2 == 22543);
    }

    @Test
    public void test3844() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3844");
        int int2 = sum.Toplama.sum(9745, 1540);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11285 + "'", int2 == 11285);
    }

    @Test
    public void test3845() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3845");
        int int2 = sum.Toplama.sum(56513, 1995);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58508 + "'", int2 == 58508);
    }

    @Test
    public void test3846() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3846");
        int int2 = sum.Toplama.sum(8709, 3283);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11992 + "'", int2 == 11992);
    }

    @Test
    public void test3847() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3847");
        int int2 = sum.Toplama.sum(18926, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18926 + "'", int2 == 18926);
    }

    @Test
    public void test3848() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3848");
        int int2 = sum.Toplama.sum(12649, 1238);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13887 + "'", int2 == 13887);
    }

    @Test
    public void test3849() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3849");
        int int2 = sum.Toplama.sum(6293, 26576);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32869 + "'", int2 == 32869);
    }

    @Test
    public void test3850() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3850");
        int int2 = sum.Toplama.sum(2088, 2990);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5078 + "'", int2 == 5078);
    }

    @Test
    public void test3851() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3851");
        int int2 = sum.Toplama.sum(16776, 49393);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 66169 + "'", int2 == 66169);
    }

    @Test
    public void test3852() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3852");
        int int2 = sum.Toplama.sum(7675, 10270);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17945 + "'", int2 == 17945);
    }

    @Test
    public void test3853() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3853");
        int int2 = sum.Toplama.sum(8493, 2609);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11102 + "'", int2 == 11102);
    }

    @Test
    public void test3854() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3854");
        int int2 = sum.Toplama.sum(10267, 68028);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78295 + "'", int2 == 78295);
    }

    @Test
    public void test3855() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3855");
        int int2 = sum.Toplama.sum(11683, 17933);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29616 + "'", int2 == 29616);
    }

    @Test
    public void test3856() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3856");
        int int2 = sum.Toplama.sum(21866, 5342);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27208 + "'", int2 == 27208);
    }

    @Test
    public void test3857() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3857");
        int int2 = sum.Toplama.sum(2968, 1177);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4145 + "'", int2 == 4145);
    }

    @Test
    public void test3858() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3858");
        int int2 = sum.Toplama.sum(24758, 17704);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42462 + "'", int2 == 42462);
    }

    @Test
    public void test3859() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3859");
        int int2 = sum.Toplama.sum(78531, 16821);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 95352 + "'", int2 == 95352);
    }

    @Test
    public void test3860() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3860");
        int int2 = sum.Toplama.sum(7306, 19777);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27083 + "'", int2 == 27083);
    }

    @Test
    public void test3861() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3861");
        int int2 = sum.Toplama.sum(11225, 22560);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33785 + "'", int2 == 33785);
    }

    @Test
    public void test3862() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3862");
        int int2 = sum.Toplama.sum(1536, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1536 + "'", int2 == 1536);
    }

    @Test
    public void test3863() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3863");
        int int2 = sum.Toplama.sum(11381, 31841);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43222 + "'", int2 == 43222);
    }

    @Test
    public void test3864() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3864");
        int int2 = sum.Toplama.sum(5107, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5107 + "'", int2 == 5107);
    }

    @Test
    public void test3865() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3865");
        int int2 = sum.Toplama.sum(8354, 12393);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20747 + "'", int2 == 20747);
    }

    @Test
    public void test3866() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3866");
        int int2 = sum.Toplama.sum(35870, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35870 + "'", int2 == 35870);
    }

    @Test
    public void test3867() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3867");
        int int2 = sum.Toplama.sum(2735, 21349);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24084 + "'", int2 == 24084);
    }

    @Test
    public void test3868() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3868");
        int int2 = sum.Toplama.sum(14386, 5399);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19785 + "'", int2 == 19785);
    }

    @Test
    public void test3869() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3869");
        int int2 = sum.Toplama.sum(19094, 11199);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30293 + "'", int2 == 30293);
    }

    @Test
    public void test3870() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3870");
        int int2 = sum.Toplama.sum(1803, 5721);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7524 + "'", int2 == 7524);
    }

    @Test
    public void test3871() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3871");
        int int2 = sum.Toplama.sum(23274, 11126);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34400 + "'", int2 == 34400);
    }

    @Test
    public void test3872() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3872");
        int int2 = sum.Toplama.sum(4561, 10786);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15347 + "'", int2 == 15347);
    }

    @Test
    public void test3873() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3873");
        int int2 = sum.Toplama.sum(558, 25825);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26383 + "'", int2 == 26383);
    }

    @Test
    public void test3874() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3874");
        int int2 = sum.Toplama.sum(29158, 859);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30017 + "'", int2 == 30017);
    }

    @Test
    public void test3875() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3875");
        int int2 = sum.Toplama.sum(0, 7126);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7126 + "'", int2 == 7126);
    }

    @Test
    public void test3876() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3876");
        int int2 = sum.Toplama.sum(38459, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38459 + "'", int2 == 38459);
    }

    @Test
    public void test3877() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3877");
        int int2 = sum.Toplama.sum(9191, 16774);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25965 + "'", int2 == 25965);
    }

    @Test
    public void test3878() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3878");
        int int2 = sum.Toplama.sum(4613, 27092);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31705 + "'", int2 == 31705);
    }

    @Test
    public void test3879() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3879");
        int int2 = sum.Toplama.sum(3241, 35320);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38561 + "'", int2 == 38561);
    }

    @Test
    public void test3880() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3880");
        int int2 = sum.Toplama.sum(20237, 3101);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23338 + "'", int2 == 23338);
    }

    @Test
    public void test3881() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3881");
        int int2 = sum.Toplama.sum(4754, 2352);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7106 + "'", int2 == 7106);
    }

    @Test
    public void test3882() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3882");
        int int2 = sum.Toplama.sum(1190, 1472);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2662 + "'", int2 == 2662);
    }

    @Test
    public void test3883() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3883");
        int int2 = sum.Toplama.sum(42222, 10351);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52573 + "'", int2 == 52573);
    }

    @Test
    public void test3884() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3884");
        int int2 = sum.Toplama.sum(0, 40080);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40080 + "'", int2 == 40080);
    }

    @Test
    public void test3885() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3885");
        int int2 = sum.Toplama.sum(4222, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4222 + "'", int2 == 4222);
    }

    @Test
    public void test3886() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3886");
        int int2 = sum.Toplama.sum(0, 8851);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8851 + "'", int2 == 8851);
    }

    @Test
    public void test3887() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3887");
        int int2 = sum.Toplama.sum(4546, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4546 + "'", int2 == 4546);
    }

    @Test
    public void test3888() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3888");
        int int2 = sum.Toplama.sum(1606, 20801);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22407 + "'", int2 == 22407);
    }

    @Test
    public void test3889() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3889");
        int int2 = sum.Toplama.sum(5080, 3036);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8116 + "'", int2 == 8116);
    }

    @Test
    public void test3890() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3890");
        int int2 = sum.Toplama.sum(0, 70699);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70699 + "'", int2 == 70699);
    }

    @Test
    public void test3891() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3891");
        int int2 = sum.Toplama.sum(12652, 8943);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21595 + "'", int2 == 21595);
    }

    @Test
    public void test3892() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3892");
        int int2 = sum.Toplama.sum(41105, 7685);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48790 + "'", int2 == 48790);
    }

    @Test
    public void test3893() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3893");
        int int2 = sum.Toplama.sum(23263, 1357);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24620 + "'", int2 == 24620);
    }

    @Test
    public void test3894() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3894");
        int int2 = sum.Toplama.sum(6531, 20730);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27261 + "'", int2 == 27261);
    }

    @Test
    public void test3895() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3895");
        int int2 = sum.Toplama.sum(51932, 11287);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63219 + "'", int2 == 63219);
    }

    @Test
    public void test3896() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3896");
        int int2 = sum.Toplama.sum(3995, 44386);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48381 + "'", int2 == 48381);
    }

    @Test
    public void test3897() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3897");
        int int2 = sum.Toplama.sum(13808, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13808 + "'", int2 == 13808);
    }

    @Test
    public void test3898() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3898");
        int int2 = sum.Toplama.sum(2241, 1365);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3606 + "'", int2 == 3606);
    }

    @Test
    public void test3899() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3899");
        int int2 = sum.Toplama.sum(16083, 21082);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37165 + "'", int2 == 37165);
    }

    @Test
    public void test3900() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3900");
        int int2 = sum.Toplama.sum(15475, 11071);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26546 + "'", int2 == 26546);
    }

    @Test
    public void test3901() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3901");
        int int2 = sum.Toplama.sum(730, 1710);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2440 + "'", int2 == 2440);
    }

    @Test
    public void test3902() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3902");
        int int2 = sum.Toplama.sum(2452, 7484);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9936 + "'", int2 == 9936);
    }

    @Test
    public void test3903() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3903");
        int int2 = sum.Toplama.sum(6739, 82680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 89419 + "'", int2 == 89419);
    }

    @Test
    public void test3904() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3904");
        int int2 = sum.Toplama.sum(29241, 7222);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36463 + "'", int2 == 36463);
    }

    @Test
    public void test3905() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3905");
        int int2 = sum.Toplama.sum(39948, 487);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40435 + "'", int2 == 40435);
    }

    @Test
    public void test3906() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3906");
        int int2 = sum.Toplama.sum(6625, 12916);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19541 + "'", int2 == 19541);
    }

    @Test
    public void test3907() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3907");
        int int2 = sum.Toplama.sum(6158, 7860);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14018 + "'", int2 == 14018);
    }

    @Test
    public void test3908() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3908");
        int int2 = sum.Toplama.sum(13652, 20969);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34621 + "'", int2 == 34621);
    }

    @Test
    public void test3909() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3909");
        int int2 = sum.Toplama.sum(6560, 48079);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54639 + "'", int2 == 54639);
    }

    @Test
    public void test3910() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3910");
        int int2 = sum.Toplama.sum(51291, 18195);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69486 + "'", int2 == 69486);
    }

    @Test
    public void test3911() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3911");
        int int2 = sum.Toplama.sum(8943, 14709);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23652 + "'", int2 == 23652);
    }

    @Test
    public void test3912() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3912");
        int int2 = sum.Toplama.sum(3908, 5950);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9858 + "'", int2 == 9858);
    }

    @Test
    public void test3913() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3913");
        int int2 = sum.Toplama.sum(3742, 4682);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8424 + "'", int2 == 8424);
    }

    @Test
    public void test3914() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3914");
        int int2 = sum.Toplama.sum(24824, 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24833 + "'", int2 == 24833);
    }

    @Test
    public void test3915() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3915");
        int int2 = sum.Toplama.sum(11141, 5334);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16475 + "'", int2 == 16475);
    }

    @Test
    public void test3916() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3916");
        int int2 = sum.Toplama.sum(18748, 7318);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26066 + "'", int2 == 26066);
    }

    @Test
    public void test3917() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3917");
        int int2 = sum.Toplama.sum(4472, 2950);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7422 + "'", int2 == 7422);
    }

    @Test
    public void test3918() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3918");
        int int2 = sum.Toplama.sum(10200, 6377);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16577 + "'", int2 == 16577);
    }

    @Test
    public void test3919() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3919");
        int int2 = sum.Toplama.sum(3091, 14815);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17906 + "'", int2 == 17906);
    }

    @Test
    public void test3920() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3920");
        int int2 = sum.Toplama.sum(423, 216);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 639 + "'", int2 == 639);
    }

    @Test
    public void test3921() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3921");
        int int2 = sum.Toplama.sum(8440, 61);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8501 + "'", int2 == 8501);
    }

    @Test
    public void test3922() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3922");
        int int2 = sum.Toplama.sum(3124, 23192);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26316 + "'", int2 == 26316);
    }

    @Test
    public void test3923() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3923");
        int int2 = sum.Toplama.sum(2862, 4276);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7138 + "'", int2 == 7138);
    }

    @Test
    public void test3924() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3924");
        int int2 = sum.Toplama.sum(5824, 5969);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11793 + "'", int2 == 11793);
    }

    @Test
    public void test3925() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3925");
        int int2 = sum.Toplama.sum(13657, 790);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14447 + "'", int2 == 14447);
    }

    @Test
    public void test3926() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3926");
        int int2 = sum.Toplama.sum(6593, 4470);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11063 + "'", int2 == 11063);
    }

    @Test
    public void test3927() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3927");
        int int2 = sum.Toplama.sum(1288, 3692);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4980 + "'", int2 == 4980);
    }

    @Test
    public void test3928() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3928");
        int int2 = sum.Toplama.sum(11801, 1596);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13397 + "'", int2 == 13397);
    }

    @Test
    public void test3929() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3929");
        int int2 = sum.Toplama.sum(7126, 21552);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28678 + "'", int2 == 28678);
    }

    @Test
    public void test3930() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3930");
        int int2 = sum.Toplama.sum(26660, 4847);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31507 + "'", int2 == 31507);
    }

    @Test
    public void test3931() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3931");
        int int2 = sum.Toplama.sum(753, 37734);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38487 + "'", int2 == 38487);
    }

    @Test
    public void test3932() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3932");
        int int2 = sum.Toplama.sum(9733, 2134);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11867 + "'", int2 == 11867);
    }

    @Test
    public void test3933() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3933");
        int int2 = sum.Toplama.sum(0, 1667);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1667 + "'", int2 == 1667);
    }

    @Test
    public void test3934() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3934");
        int int2 = sum.Toplama.sum(10951, 1287);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12238 + "'", int2 == 12238);
    }

    @Test
    public void test3935() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3935");
        int int2 = sum.Toplama.sum(4980, 6726);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11706 + "'", int2 == 11706);
    }

    @Test
    public void test3936() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3936");
        int int2 = sum.Toplama.sum(13545, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13545 + "'", int2 == 13545);
    }

    @Test
    public void test3937() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3937");
        int int2 = sum.Toplama.sum(5361, 1233);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6594 + "'", int2 == 6594);
    }

    @Test
    public void test3938() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3938");
        int int2 = sum.Toplama.sum(1441, 11667);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13108 + "'", int2 == 13108);
    }

    @Test
    public void test3939() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3939");
        int int2 = sum.Toplama.sum(90694, 939);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 91633 + "'", int2 == 91633);
    }

    @Test
    public void test3940() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3940");
        int int2 = sum.Toplama.sum(3595, 9059);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12654 + "'", int2 == 12654);
    }

    @Test
    public void test3941() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3941");
        int int2 = sum.Toplama.sum(33656, 3274);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36930 + "'", int2 == 36930);
    }

    @Test
    public void test3942() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3942");
        int int2 = sum.Toplama.sum(7348, 32163);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39511 + "'", int2 == 39511);
    }

    @Test
    public void test3943() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3943");
        int int2 = sum.Toplama.sum(9779, 15906);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25685 + "'", int2 == 25685);
    }

    @Test
    public void test3944() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3944");
        int int2 = sum.Toplama.sum(4980, 2482);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7462 + "'", int2 == 7462);
    }

    @Test
    public void test3945() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3945");
        int int2 = sum.Toplama.sum(7033, 16307);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23340 + "'", int2 == 23340);
    }

    @Test
    public void test3946() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3946");
        int int2 = sum.Toplama.sum(106, 2022);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2128 + "'", int2 == 2128);
    }

    @Test
    public void test3947() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3947");
        int int2 = sum.Toplama.sum(33113, 622);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33735 + "'", int2 == 33735);
    }

    @Test
    public void test3948() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3948");
        int int2 = sum.Toplama.sum(9, 3305);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3314 + "'", int2 == 3314);
    }

    @Test
    public void test3949() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3949");
        int int2 = sum.Toplama.sum(15486, 10939);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26425 + "'", int2 == 26425);
    }

    @Test
    public void test3950() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3950");
        int int2 = sum.Toplama.sum(4856, 4665);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9521 + "'", int2 == 9521);
    }

    @Test
    public void test3951() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3951");
        int int2 = sum.Toplama.sum(51123, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51123 + "'", int2 == 51123);
    }

    @Test
    public void test3952() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3952");
        int int2 = sum.Toplama.sum(1666, 1051);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2717 + "'", int2 == 2717);
    }

    @Test
    public void test3953() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3953");
        int int2 = sum.Toplama.sum(35464, 2405);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37869 + "'", int2 == 37869);
    }

    @Test
    public void test3954() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3954");
        int int2 = sum.Toplama.sum(0, 1803);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1803 + "'", int2 == 1803);
    }

    @Test
    public void test3955() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3955");
        int int2 = sum.Toplama.sum(12599, 3275);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15874 + "'", int2 == 15874);
    }

    @Test
    public void test3956() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3956");
        int int2 = sum.Toplama.sum(4239, 149);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4388 + "'", int2 == 4388);
    }

    @Test
    public void test3957() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3957");
        int int2 = sum.Toplama.sum(35957, 1185);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37142 + "'", int2 == 37142);
    }

    @Test
    public void test3958() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3958");
        int int2 = sum.Toplama.sum(2735, 17196);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19931 + "'", int2 == 19931);
    }

    @Test
    public void test3959() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3959");
        int int2 = sum.Toplama.sum(20777, 4882);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25659 + "'", int2 == 25659);
    }

    @Test
    public void test3960() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3960");
        int int2 = sum.Toplama.sum(18573, 13129);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31702 + "'", int2 == 31702);
    }

    @Test
    public void test3961() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3961");
        int int2 = sum.Toplama.sum(25412, 14557);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39969 + "'", int2 == 39969);
    }

    @Test
    public void test3962() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3962");
        int int2 = sum.Toplama.sum(21349, 7932);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29281 + "'", int2 == 29281);
    }

    @Test
    public void test3963() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3963");
        int int2 = sum.Toplama.sum(16442, 3136);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19578 + "'", int2 == 19578);
    }

    @Test
    public void test3964() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3964");
        int int2 = sum.Toplama.sum(6243, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6243 + "'", int2 == 6243);
    }

    @Test
    public void test3965() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3965");
        int int2 = sum.Toplama.sum(3078, 22098);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25176 + "'", int2 == 25176);
    }

    @Test
    public void test3966() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3966");
        int int2 = sum.Toplama.sum(0, 13518);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13518 + "'", int2 == 13518);
    }

    @Test
    public void test3967() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3967");
        int int2 = sum.Toplama.sum(756, 474);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1230 + "'", int2 == 1230);
    }

    @Test
    public void test3968() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3968");
        int int2 = sum.Toplama.sum(0, 20969);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20969 + "'", int2 == 20969);
    }

    @Test
    public void test3969() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3969");
        int int2 = sum.Toplama.sum(100615, 5248);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 105863 + "'", int2 == 105863);
    }

    @Test
    public void test3970() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3970");
        int int2 = sum.Toplama.sum(776, 40435);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41211 + "'", int2 == 41211);
    }

    @Test
    public void test3971() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3971");
        int int2 = sum.Toplama.sum(5897, 39344);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45241 + "'", int2 == 45241);
    }

    @Test
    public void test3972() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3972");
        int int2 = sum.Toplama.sum(3331, 11225);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14556 + "'", int2 == 14556);
    }

    @Test
    public void test3973() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3973");
        int int2 = sum.Toplama.sum(14726, 2118);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16844 + "'", int2 == 16844);
    }

    @Test
    public void test3974() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3974");
        int int2 = sum.Toplama.sum(6764, 1233);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7997 + "'", int2 == 7997);
    }

    @Test
    public void test3975() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3975");
        int int2 = sum.Toplama.sum(23371, 17533);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40904 + "'", int2 == 40904);
    }

    @Test
    public void test3976() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3976");
        int int2 = sum.Toplama.sum(49752, 6466);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56218 + "'", int2 == 56218);
    }

    @Test
    public void test3977() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3977");
        int int2 = sum.Toplama.sum(11186, 52479);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63665 + "'", int2 == 63665);
    }

    @Test
    public void test3978() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3978");
        int int2 = sum.Toplama.sum(109, 40954);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41063 + "'", int2 == 41063);
    }

    @Test
    public void test3979() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3979");
        int int2 = sum.Toplama.sum(27486, 10104);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37590 + "'", int2 == 37590);
    }

    @Test
    public void test3980() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3980");
        int int2 = sum.Toplama.sum(27673, 20917);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48590 + "'", int2 == 48590);
    }

    @Test
    public void test3981() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3981");
        int int2 = sum.Toplama.sum(0, 37258);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37258 + "'", int2 == 37258);
    }

    @Test
    public void test3982() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3982");
        int int2 = sum.Toplama.sum(5012, 11836);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16848 + "'", int2 == 16848);
    }

    @Test
    public void test3983() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3983");
        int int2 = sum.Toplama.sum(6626, 5302);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11928 + "'", int2 == 11928);
    }

    @Test
    public void test3984() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3984");
        int int2 = sum.Toplama.sum(17490, 55322);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72812 + "'", int2 == 72812);
    }

    @Test
    public void test3985() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3985");
        int int2 = sum.Toplama.sum(5897, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5997 + "'", int2 == 5997);
    }

    @Test
    public void test3986() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3986");
        int int2 = sum.Toplama.sum(1411, 26305);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27716 + "'", int2 == 27716);
    }

    @Test
    public void test3987() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3987");
        int int2 = sum.Toplama.sum(2253, 3256);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5509 + "'", int2 == 5509);
    }

    @Test
    public void test3988() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3988");
        int int2 = sum.Toplama.sum(6651, 5832);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12483 + "'", int2 == 12483);
    }

    @Test
    public void test3989() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3989");
        int int2 = sum.Toplama.sum(10039, 12337);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22376 + "'", int2 == 22376);
    }

    @Test
    public void test3990() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3990");
        int int2 = sum.Toplama.sum(9089, 8738);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17827 + "'", int2 == 17827);
    }

    @Test
    public void test3991() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3991");
        int int2 = sum.Toplama.sum(3314, 9952);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13266 + "'", int2 == 13266);
    }

    @Test
    public void test3992() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3992");
        int int2 = sum.Toplama.sum(0, 5342);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5342 + "'", int2 == 5342);
    }

    @Test
    public void test3993() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3993");
        int int2 = sum.Toplama.sum(47668, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47668 + "'", int2 == 47668);
    }

    @Test
    public void test3994() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3994");
        int int2 = sum.Toplama.sum(7272, 43591);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50863 + "'", int2 == 50863);
    }

    @Test
    public void test3995() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3995");
        int int2 = sum.Toplama.sum(5732, 2365);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8097 + "'", int2 == 8097);
    }

    @Test
    public void test3996() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3996");
        int int2 = sum.Toplama.sum(6453, 1342);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7795 + "'", int2 == 7795);
    }

    @Test
    public void test3997() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3997");
        int int2 = sum.Toplama.sum(58434, 13741);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72175 + "'", int2 == 72175);
    }

    @Test
    public void test3998() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3998");
        int int2 = sum.Toplama.sum(6465, 9779);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16244 + "'", int2 == 16244);
    }

    @Test
    public void test3999() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3999");
        int int2 = sum.Toplama.sum(20801, 10658);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31459 + "'", int2 == 31459);
    }

    @Test
    public void test4000() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test4000");
        int int2 = sum.Toplama.sum(5301, 5764);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11065 + "'", int2 == 11065);
    }
}

