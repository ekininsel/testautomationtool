import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test3001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3001");
        int int2 = sum.Toplama.sum(17012, 17433);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34445 + "'", int2 == 34445);
    }

    @Test
    public void test3002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3002");
        int int2 = sum.Toplama.sum(55034, 20923);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 75957 + "'", int2 == 75957);
    }

    @Test
    public void test3003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3003");
        int int2 = sum.Toplama.sum(5783, 16878);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22661 + "'", int2 == 22661);
    }

    @Test
    public void test3004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3004");
        int int2 = sum.Toplama.sum(742, 18616);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19358 + "'", int2 == 19358);
    }

    @Test
    public void test3005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3005");
        int int2 = sum.Toplama.sum(4882, 6244);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11126 + "'", int2 == 11126);
    }

    @Test
    public void test3006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3006");
        int int2 = sum.Toplama.sum(32163, 35464);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67627 + "'", int2 == 67627);
    }

    @Test
    public void test3007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3007");
        int int2 = sum.Toplama.sum(13349, 35929);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49278 + "'", int2 == 49278);
    }

    @Test
    public void test3008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3008");
        int int2 = sum.Toplama.sum(17114, 10945);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28059 + "'", int2 == 28059);
    }

    @Test
    public void test3009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3009");
        int int2 = sum.Toplama.sum(1917, 16212);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18129 + "'", int2 == 18129);
    }

    @Test
    public void test3010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3010");
        int int2 = sum.Toplama.sum(23034, 624);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23658 + "'", int2 == 23658);
    }

    @Test
    public void test3011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3011");
        int int2 = sum.Toplama.sum(1268, 4546);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5814 + "'", int2 == 5814);
    }

    @Test
    public void test3012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3012");
        int int2 = sum.Toplama.sum(19905, 7232);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27137 + "'", int2 == 27137);
    }

    @Test
    public void test3013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3013");
        int int2 = sum.Toplama.sum(1488, 24495);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25983 + "'", int2 == 25983);
    }

    @Test
    public void test3014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3014");
        int int2 = sum.Toplama.sum(1639, 20854);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22493 + "'", int2 == 22493);
    }

    @Test
    public void test3015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3015");
        int int2 = sum.Toplama.sum(16759, 7412);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24171 + "'", int2 == 24171);
    }

    @Test
    public void test3016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3016");
        int int2 = sum.Toplama.sum(2022, 17114);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19136 + "'", int2 == 19136);
    }

    @Test
    public void test3017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3017");
        int int2 = sum.Toplama.sum(7285, 25853);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33138 + "'", int2 == 33138);
    }

    @Test
    public void test3018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3018");
        int int2 = sum.Toplama.sum(11784, 11045);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22829 + "'", int2 == 22829);
    }

    @Test
    public void test3019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3019");
        int int2 = sum.Toplama.sum(3695, 15467);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19162 + "'", int2 == 19162);
    }

    @Test
    public void test3020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3020");
        int int2 = sum.Toplama.sum(12927, 31778);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44705 + "'", int2 == 44705);
    }

    @Test
    public void test3021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3021");
        int int2 = sum.Toplama.sum(1478, 4242);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5720 + "'", int2 == 5720);
    }

    @Test
    public void test3022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3022");
        int int2 = sum.Toplama.sum(11858, 4682);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16540 + "'", int2 == 16540);
    }

    @Test
    public void test3023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3023");
        int int2 = sum.Toplama.sum(197, 31462);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31659 + "'", int2 == 31659);
    }

    @Test
    public void test3024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3024");
        int int2 = sum.Toplama.sum(3942, 1161);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5103 + "'", int2 == 5103);
    }

    @Test
    public void test3025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3025");
        int int2 = sum.Toplama.sum(33112, 6232);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39344 + "'", int2 == 39344);
    }

    @Test
    public void test3026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3026");
        int int2 = sum.Toplama.sum(5409, 15115);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20524 + "'", int2 == 20524);
    }

    @Test
    public void test3027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3027");
        int int2 = sum.Toplama.sum(100, 14631);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14731 + "'", int2 == 14731);
    }

    @Test
    public void test3028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3028");
        int int2 = sum.Toplama.sum(1585, 27406);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28991 + "'", int2 == 28991);
    }

    @Test
    public void test3029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3029");
        int int2 = sum.Toplama.sum(13566, 20730);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34296 + "'", int2 == 34296);
    }

    @Test
    public void test3030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3030");
        int int2 = sum.Toplama.sum(3509, 25775);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29284 + "'", int2 == 29284);
    }

    @Test
    public void test3031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3031");
        int int2 = sum.Toplama.sum(16776, 5780);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22556 + "'", int2 == 22556);
    }

    @Test
    public void test3032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3032");
        int int2 = sum.Toplama.sum(8831, 10070);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18901 + "'", int2 == 18901);
    }

    @Test
    public void test3033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3033");
        int int2 = sum.Toplama.sum(1723, 4246);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5969 + "'", int2 == 5969);
    }

    @Test
    public void test3034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3034");
        int int2 = sum.Toplama.sum(25476, 11007);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36483 + "'", int2 == 36483);
    }

    @Test
    public void test3035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3035");
        int int2 = sum.Toplama.sum(24489, 24579);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49068 + "'", int2 == 49068);
    }

    @Test
    public void test3036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3036");
        int int2 = sum.Toplama.sum(31659, 7222);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38881 + "'", int2 == 38881);
    }

    @Test
    public void test3037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3037");
        int int2 = sum.Toplama.sum(1829, 393);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2222 + "'", int2 == 2222);
    }

    @Test
    public void test3038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3038");
        int int2 = sum.Toplama.sum(10908, 6625);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17533 + "'", int2 == 17533);
    }

    @Test
    public void test3039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3039");
        int int2 = sum.Toplama.sum(11263, 17306);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28569 + "'", int2 == 28569);
    }

    @Test
    public void test3040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3040");
        int int2 = sum.Toplama.sum(23038, 15421);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38459 + "'", int2 == 38459);
    }

    @Test
    public void test3041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3041");
        int int2 = sum.Toplama.sum(6586, 305);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6891 + "'", int2 == 6891);
    }

    @Test
    public void test3042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3042");
        int int2 = sum.Toplama.sum(9803, 23034);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32837 + "'", int2 == 32837);
    }

    @Test
    public void test3043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3043");
        int int2 = sum.Toplama.sum(3091, 16274);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19365 + "'", int2 == 19365);
    }

    @Test
    public void test3044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3044");
        int int2 = sum.Toplama.sum(9563, 6188);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15751 + "'", int2 == 15751);
    }

    @Test
    public void test3045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3045");
        int int2 = sum.Toplama.sum(0, 1977);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1977 + "'", int2 == 1977);
    }

    @Test
    public void test3046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3046");
        int int2 = sum.Toplama.sum(805, 862);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1667 + "'", int2 == 1667);
    }

    @Test
    public void test3047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3047");
        int int2 = sum.Toplama.sum(5012, 36775);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41787 + "'", int2 == 41787);
    }

    @Test
    public void test3048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3048");
        int int2 = sum.Toplama.sum(27913, 1292);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29205 + "'", int2 == 29205);
    }

    @Test
    public void test3049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3049");
        int int2 = sum.Toplama.sum(0, 28232);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28232 + "'", int2 == 28232);
    }

    @Test
    public void test3050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3050");
        int int2 = sum.Toplama.sum(3942, 37163);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41105 + "'", int2 == 41105);
    }

    @Test
    public void test3051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3051");
        int int2 = sum.Toplama.sum(8354, 16338);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24692 + "'", int2 == 24692);
    }

    @Test
    public void test3052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3052");
        int int2 = sum.Toplama.sum(7967, 23034);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31001 + "'", int2 == 31001);
    }

    @Test
    public void test3053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3053");
        int int2 = sum.Toplama.sum(12166, 623);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12789 + "'", int2 == 12789);
    }

    @Test
    public void test3054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3054");
        int int2 = sum.Toplama.sum(970, 17533);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18503 + "'", int2 == 18503);
    }

    @Test
    public void test3055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3055");
        int int2 = sum.Toplama.sum(100, 1521);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1621 + "'", int2 == 1621);
    }

    @Test
    public void test3056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3056");
        int int2 = sum.Toplama.sum(2659, 31419);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34078 + "'", int2 == 34078);
    }

    @Test
    public void test3057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3057");
        int int2 = sum.Toplama.sum(12011, 7860);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19871 + "'", int2 == 19871);
    }

    @Test
    public void test3058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3058");
        int int2 = sum.Toplama.sum(4545, 54099);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58644 + "'", int2 == 58644);
    }

    @Test
    public void test3059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3059");
        int int2 = sum.Toplama.sum(13204, 3509);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16713 + "'", int2 == 16713);
    }

    @Test
    public void test3060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3060");
        int int2 = sum.Toplama.sum(6113, 8474);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14587 + "'", int2 == 14587);
    }

    @Test
    public void test3061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3061");
        int int2 = sum.Toplama.sum(0, 2048);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2048 + "'", int2 == 2048);
    }

    @Test
    public void test3062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3062");
        int int2 = sum.Toplama.sum(14770, 6199);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20969 + "'", int2 == 20969);
    }

    @Test
    public void test3063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3063");
        int int2 = sum.Toplama.sum(5659, 4626);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10285 + "'", int2 == 10285);
    }

    @Test
    public void test3064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3064");
        int int2 = sum.Toplama.sum(15362, 897);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16259 + "'", int2 == 16259);
    }

    @Test
    public void test3065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3065");
        int int2 = sum.Toplama.sum(817, 9187);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10004 + "'", int2 == 10004);
    }

    @Test
    public void test3066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3066");
        int int2 = sum.Toplama.sum(449, 19703);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20152 + "'", int2 == 20152);
    }

    @Test
    public void test3067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3067");
        int int2 = sum.Toplama.sum(9475, 792);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10267 + "'", int2 == 10267);
    }

    @Test
    public void test3068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3068");
        int int2 = sum.Toplama.sum(8866, 27479);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36345 + "'", int2 == 36345);
    }

    @Test
    public void test3069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3069");
        int int2 = sum.Toplama.sum(6853, 7412);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14265 + "'", int2 == 14265);
    }

    @Test
    public void test3070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3070");
        int int2 = sum.Toplama.sum(4582, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4582 + "'", int2 == 4582);
    }

    @Test
    public void test3071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3071");
        int int2 = sum.Toplama.sum(11651, 776);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12427 + "'", int2 == 12427);
    }

    @Test
    public void test3072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3072");
        int int2 = sum.Toplama.sum(1631, 5939);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7570 + "'", int2 == 7570);
    }

    @Test
    public void test3073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3073");
        int int2 = sum.Toplama.sum(11372, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11372 + "'", int2 == 11372);
    }

    @Test
    public void test3074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3074");
        int int2 = sum.Toplama.sum(2249, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2249 + "'", int2 == 2249);
    }

    @Test
    public void test3075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3075");
        int int2 = sum.Toplama.sum(8925, 3448);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12373 + "'", int2 == 12373);
    }

    @Test
    public void test3076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3076");
        int int2 = sum.Toplama.sum(9043, 10889);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19932 + "'", int2 == 19932);
    }

    @Test
    public void test3077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3077");
        int int2 = sum.Toplama.sum(8738, 1532);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10270 + "'", int2 == 10270);
    }

    @Test
    public void test3078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3078");
        int int2 = sum.Toplama.sum(2851, 5236);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8087 + "'", int2 == 8087);
    }

    @Test
    public void test3079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3079");
        int int2 = sum.Toplama.sum(394, 12998);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13392 + "'", int2 == 13392);
    }

    @Test
    public void test3080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3080");
        int int2 = sum.Toplama.sum(931, 47805);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48736 + "'", int2 == 48736);
    }

    @Test
    public void test3081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3081");
        int int2 = sum.Toplama.sum(7568, 1631);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9199 + "'", int2 == 9199);
    }

    @Test
    public void test3082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3082");
        int int2 = sum.Toplama.sum(6552, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6649 + "'", int2 == 6649);
    }

    @Test
    public void test3083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3083");
        int int2 = sum.Toplama.sum(27774, 1342);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29116 + "'", int2 == 29116);
    }

    @Test
    public void test3084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3084");
        int int2 = sum.Toplama.sum(44858, 6119);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50977 + "'", int2 == 50977);
    }

    @Test
    public void test3085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3085");
        int int2 = sum.Toplama.sum(640, 2411);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3051 + "'", int2 == 3051);
    }

    @Test
    public void test3086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3086");
        int int2 = sum.Toplama.sum(794, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 794 + "'", int2 == 794);
    }

    @Test
    public void test3087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3087");
        int int2 = sum.Toplama.sum(29019, 17253);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46272 + "'", int2 == 46272);
    }

    @Test
    public void test3088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3088");
        int int2 = sum.Toplama.sum(1697, 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1708 + "'", int2 == 1708);
    }

    @Test
    public void test3089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3089");
        int int2 = sum.Toplama.sum(6063, 10272);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16335 + "'", int2 == 16335);
    }

    @Test
    public void test3090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3090");
        int int2 = sum.Toplama.sum(19308, 6080);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25388 + "'", int2 == 25388);
    }

    @Test
    public void test3091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3091");
        int int2 = sum.Toplama.sum(1292, 427);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1719 + "'", int2 == 1719);
    }

    @Test
    public void test3092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3092");
        int int2 = sum.Toplama.sum(32122, 1343);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33465 + "'", int2 == 33465);
    }

    @Test
    public void test3093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3093");
        int int2 = sum.Toplama.sum(2582, 18195);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20777 + "'", int2 == 20777);
    }

    @Test
    public void test3094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3094");
        int int2 = sum.Toplama.sum(7072, 4281);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11353 + "'", int2 == 11353);
    }

    @Test
    public void test3095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3095");
        int int2 = sum.Toplama.sum(421, 8975);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9396 + "'", int2 == 9396);
    }

    @Test
    public void test3096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3096");
        int int2 = sum.Toplama.sum(9526, 1085);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10611 + "'", int2 == 10611);
    }

    @Test
    public void test3097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3097");
        int int2 = sum.Toplama.sum(13410, 3959);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17369 + "'", int2 == 17369);
    }

    @Test
    public void test3098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3098");
        int int2 = sum.Toplama.sum(2316, 4553);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6869 + "'", int2 == 6869);
    }

    @Test
    public void test3099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3099");
        int int2 = sum.Toplama.sum(654, 10108);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10762 + "'", int2 == 10762);
    }

    @Test
    public void test3100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3100");
        int int2 = sum.Toplama.sum(2792, 9399);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12191 + "'", int2 == 12191);
    }

    @Test
    public void test3101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3101");
        int int2 = sum.Toplama.sum(23190, 1896);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25086 + "'", int2 == 25086);
    }

    @Test
    public void test3102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3102");
        int int2 = sum.Toplama.sum(14189, 19724);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33913 + "'", int2 == 33913);
    }

    @Test
    public void test3103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3103");
        int int2 = sum.Toplama.sum(13545, 18684);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32229 + "'", int2 == 32229);
    }

    @Test
    public void test3104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3104");
        int int2 = sum.Toplama.sum(2982, 18228);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21210 + "'", int2 == 21210);
    }

    @Test
    public void test3105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3105");
        int int2 = sum.Toplama.sum(1683, 11174);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12857 + "'", int2 == 12857);
    }

    @Test
    public void test3106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3106");
        int int2 = sum.Toplama.sum(34970, 10022);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44992 + "'", int2 == 44992);
    }

    @Test
    public void test3107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3107");
        int int2 = sum.Toplama.sum(1448, 29853);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31301 + "'", int2 == 31301);
    }

    @Test
    public void test3108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3108");
        int int2 = sum.Toplama.sum(10272, 30247);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40519 + "'", int2 == 40519);
    }

    @Test
    public void test3109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3109");
        int int2 = sum.Toplama.sum(14294, 20778);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35072 + "'", int2 == 35072);
    }

    @Test
    public void test3110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3110");
        int int2 = sum.Toplama.sum(21894, 46171);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68065 + "'", int2 == 68065);
    }

    @Test
    public void test3111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3111");
        int int2 = sum.Toplama.sum(1238, 29435);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30673 + "'", int2 == 30673);
    }

    @Test
    public void test3112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3112");
        int int2 = sum.Toplama.sum(1491, 9349);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10840 + "'", int2 == 10840);
    }

    @Test
    public void test3113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3113");
        int int2 = sum.Toplama.sum(2240, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2240 + "'", int2 == 2240);
    }

    @Test
    public void test3114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3114");
        int int2 = sum.Toplama.sum(0, 16325);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16325 + "'", int2 == 16325);
    }

    @Test
    public void test3115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3115");
        int int2 = sum.Toplama.sum(19053, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19053 + "'", int2 == 19053);
    }

    @Test
    public void test3116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3116");
        int int2 = sum.Toplama.sum(9035, 4265);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13300 + "'", int2 == 13300);
    }

    @Test
    public void test3117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3117");
        int int2 = sum.Toplama.sum(0, 9644);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9644 + "'", int2 == 9644);
    }

    @Test
    public void test3118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3118");
        int int2 = sum.Toplama.sum(8168, 25086);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33254 + "'", int2 == 33254);
    }

    @Test
    public void test3119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3119");
        int int2 = sum.Toplama.sum(3431, 8358);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11789 + "'", int2 == 11789);
    }

    @Test
    public void test3120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3120");
        int int2 = sum.Toplama.sum(10918, 10191);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21109 + "'", int2 == 21109);
    }

    @Test
    public void test3121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3121");
        int int2 = sum.Toplama.sum(28560, 11792);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40352 + "'", int2 == 40352);
    }

    @Test
    public void test3122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3122");
        int int2 = sum.Toplama.sum(1, 2063);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2064 + "'", int2 == 2064);
    }

    @Test
    public void test3123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3123");
        int int2 = sum.Toplama.sum(5855, 14809);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20664 + "'", int2 == 20664);
    }

    @Test
    public void test3124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3124");
        int int2 = sum.Toplama.sum(6879, 24238);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31117 + "'", int2 == 31117);
    }

    @Test
    public void test3125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3125");
        int int2 = sum.Toplama.sum(8873, 18115);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26988 + "'", int2 == 26988);
    }

    @Test
    public void test3126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3126");
        int int2 = sum.Toplama.sum(2030, 1491);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3521 + "'", int2 == 3521);
    }

    @Test
    public void test3127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3127");
        int int2 = sum.Toplama.sum(0, 737);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 737 + "'", int2 == 737);
    }

    @Test
    public void test3128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3128");
        int int2 = sum.Toplama.sum(13237, 2968);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16205 + "'", int2 == 16205);
    }

    @Test
    public void test3129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3129");
        int int2 = sum.Toplama.sum(0, 491);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 491 + "'", int2 == 491);
    }

    @Test
    public void test3130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3130");
        int int2 = sum.Toplama.sum(7322, 10786);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18108 + "'", int2 == 18108);
    }

    @Test
    public void test3131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3131");
        int int2 = sum.Toplama.sum(10754, 8001);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18755 + "'", int2 == 18755);
    }

    @Test
    public void test3132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3132");
        int int2 = sum.Toplama.sum(24280, 31001);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55281 + "'", int2 == 55281);
    }

    @Test
    public void test3133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3133");
        int int2 = sum.Toplama.sum(22755, 4949);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27704 + "'", int2 == 27704);
    }

    @Test
    public void test3134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3134");
        int int2 = sum.Toplama.sum(13526, 15458);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28984 + "'", int2 == 28984);
    }

    @Test
    public void test3135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3135");
        int int2 = sum.Toplama.sum(16259, 24887);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41146 + "'", int2 == 41146);
    }

    @Test
    public void test3136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3136");
        int int2 = sum.Toplama.sum(33913, 1357);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35270 + "'", int2 == 35270);
    }

    @Test
    public void test3137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3137");
        int int2 = sum.Toplama.sum(20004, 33138);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53142 + "'", int2 == 53142);
    }

    @Test
    public void test3138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3138");
        int int2 = sum.Toplama.sum(31397, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31396 + "'", int2 == 31396);
    }

    @Test
    public void test3139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3139");
        int int2 = sum.Toplama.sum(15287, 11436);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26723 + "'", int2 == 26723);
    }

    @Test
    public void test3140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3140");
        int int2 = sum.Toplama.sum(1087, 14579);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15666 + "'", int2 == 15666);
    }

    @Test
    public void test3141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3141");
        int int2 = sum.Toplama.sum(940, 1010);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1950 + "'", int2 == 1950);
    }

    @Test
    public void test3142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3142");
        int int2 = sum.Toplama.sum(17623, 11534);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29157 + "'", int2 == 29157);
    }

    @Test
    public void test3143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3143");
        int int2 = sum.Toplama.sum(27430, 2386);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29816 + "'", int2 == 29816);
    }

    @Test
    public void test3144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3144");
        int int2 = sum.Toplama.sum(11713, 8942);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20655 + "'", int2 == 20655);
    }

    @Test
    public void test3145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3145");
        int int2 = sum.Toplama.sum(4553, 7296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11849 + "'", int2 == 11849);
    }

    @Test
    public void test3146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3146");
        int int2 = sum.Toplama.sum(3281, 888);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4169 + "'", int2 == 4169);
    }

    @Test
    public void test3147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3147");
        int int2 = sum.Toplama.sum(7225, 5368);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12593 + "'", int2 == 12593);
    }

    @Test
    public void test3148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3148");
        int int2 = sum.Toplama.sum(3833, 1085);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4918 + "'", int2 == 4918);
    }

    @Test
    public void test3149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3149");
        int int2 = sum.Toplama.sum(1271, 870);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2141 + "'", int2 == 2141);
    }

    @Test
    public void test3150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3150");
        int int2 = sum.Toplama.sum(1465, 3569);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5034 + "'", int2 == 5034);
    }

    @Test
    public void test3151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3151");
        int int2 = sum.Toplama.sum(488, 3042);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3530 + "'", int2 == 3530);
    }

    @Test
    public void test3152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3152");
        int int2 = sum.Toplama.sum(4563, 1095);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5658 + "'", int2 == 5658);
    }

    @Test
    public void test3153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3153");
        int int2 = sum.Toplama.sum(4307, 5859);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10166 + "'", int2 == 10166);
    }

    @Test
    public void test3154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3154");
        int int2 = sum.Toplama.sum(4932, 344);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5276 + "'", int2 == 5276);
    }

    @Test
    public void test3155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3155");
        int int2 = sum.Toplama.sum(28832, 13390);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42222 + "'", int2 == 42222);
    }

    @Test
    public void test3156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3156");
        int int2 = sum.Toplama.sum(855, 440);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1295 + "'", int2 == 1295);
    }

    @Test
    public void test3157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3157");
        int int2 = sum.Toplama.sum(0, 1784);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1784 + "'", int2 == 1784);
    }

    @Test
    public void test3158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3158");
        int int2 = sum.Toplama.sum(1185, 3091);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4276 + "'", int2 == 4276);
    }

    @Test
    public void test3159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3159");
        int int2 = sum.Toplama.sum(16212, 42222);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58434 + "'", int2 == 58434);
    }

    @Test
    public void test3160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3160");
        int int2 = sum.Toplama.sum(3414, 7896);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11310 + "'", int2 == 11310);
    }

    @Test
    public void test3161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3161");
        int int2 = sum.Toplama.sum(23038, 2645);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25683 + "'", int2 == 25683);
    }

    @Test
    public void test3162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3162");
        int int2 = sum.Toplama.sum(7484, 12898);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20382 + "'", int2 == 20382);
    }

    @Test
    public void test3163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3163");
        int int2 = sum.Toplama.sum(2064, 4229);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6293 + "'", int2 == 6293);
    }

    @Test
    public void test3164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3164");
        int int2 = sum.Toplama.sum(13532, 3051);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16583 + "'", int2 == 16583);
    }

    @Test
    public void test3165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3165");
        int int2 = sum.Toplama.sum(5111, 5829);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10940 + "'", int2 == 10940);
    }

    @Test
    public void test3166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3166");
        int int2 = sum.Toplama.sum(16881, 13297);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30178 + "'", int2 == 30178);
    }

    @Test
    public void test3167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3167");
        int int2 = sum.Toplama.sum(19064, 2088);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21152 + "'", int2 == 21152);
    }

    @Test
    public void test3168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3168");
        int int2 = sum.Toplama.sum(2146, 4307);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6453 + "'", int2 == 6453);
    }

    @Test
    public void test3169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3169");
        int int2 = sum.Toplama.sum(4561, 5041);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9602 + "'", int2 == 9602);
    }

    @Test
    public void test3170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3170");
        int int2 = sum.Toplama.sum(30838, 22661);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53499 + "'", int2 == 53499);
    }

    @Test
    public void test3171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3171");
        int int2 = sum.Toplama.sum(3742, 10069);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13811 + "'", int2 == 13811);
    }

    @Test
    public void test3172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3172");
        int int2 = sum.Toplama.sum(0, 100615);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100615 + "'", int2 == 100615);
    }

    @Test
    public void test3173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3173");
        int int2 = sum.Toplama.sum(3305, 1433);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4738 + "'", int2 == 4738);
    }

    @Test
    public void test3174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3174");
        int int2 = sum.Toplama.sum(2332, 7483);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9815 + "'", int2 == 9815);
    }

    @Test
    public void test3175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3175");
        int int2 = sum.Toplama.sum(11875, 756);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12631 + "'", int2 == 12631);
    }

    @Test
    public void test3176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3176");
        int int2 = sum.Toplama.sum(67627, 1977);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69604 + "'", int2 == 69604);
    }

    @Test
    public void test3177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3177");
        int int2 = sum.Toplama.sum(3414, 5224);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8638 + "'", int2 == 8638);
    }

    @Test
    public void test3178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3178");
        int int2 = sum.Toplama.sum(14779, 4085);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18864 + "'", int2 == 18864);
    }

    @Test
    public void test3179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3179");
        int int2 = sum.Toplama.sum(2340, 3044);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5384 + "'", int2 == 5384);
    }

    @Test
    public void test3180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3180");
        int int2 = sum.Toplama.sum(9815, 26490);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36305 + "'", int2 == 36305);
    }

    @Test
    public void test3181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3181");
        int int2 = sum.Toplama.sum(17056, 817);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17873 + "'", int2 == 17873);
    }

    @Test
    public void test3182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3182");
        int int2 = sum.Toplama.sum(1422, 12439);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13861 + "'", int2 == 13861);
    }

    @Test
    public void test3183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3183");
        int int2 = sum.Toplama.sum(13199, 11792);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24991 + "'", int2 == 24991);
    }

    @Test
    public void test3184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3184");
        int int2 = sum.Toplama.sum(3913, 1652);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5565 + "'", int2 == 5565);
    }

    @Test
    public void test3185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3185");
        int int2 = sum.Toplama.sum(2838, 39344);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42182 + "'", int2 == 42182);
    }

    @Test
    public void test3186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3186");
        int int2 = sum.Toplama.sum(0, 976);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 976 + "'", int2 == 976);
    }

    @Test
    public void test3187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3187");
        int int2 = sum.Toplama.sum(49068, 1335);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50403 + "'", int2 == 50403);
    }

    @Test
    public void test3188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3188");
        int int2 = sum.Toplama.sum(54099, 9755);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63854 + "'", int2 == 63854);
    }

    @Test
    public void test3189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3189");
        int int2 = sum.Toplama.sum(0, 12887);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12887 + "'", int2 == 12887);
    }

    @Test
    public void test3190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3190");
        int int2 = sum.Toplama.sum(18850, 2854);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21704 + "'", int2 == 21704);
    }

    @Test
    public void test3191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3191");
        int int2 = sum.Toplama.sum(1006, 15117);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16123 + "'", int2 == 16123);
    }

    @Test
    public void test3192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3192");
        int int2 = sum.Toplama.sum(512, 14097);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14609 + "'", int2 == 14609);
    }

    @Test
    public void test3193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3193");
        int int2 = sum.Toplama.sum(13869, 13604);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27473 + "'", int2 == 27473);
    }

    @Test
    public void test3194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3194");
        int int2 = sum.Toplama.sum(2314, 520);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2834 + "'", int2 == 2834);
    }

    @Test
    public void test3195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3195");
        int int2 = sum.Toplama.sum(13390, 2986);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16376 + "'", int2 == 16376);
    }

    @Test
    public void test3196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3196");
        int int2 = sum.Toplama.sum(1203, 3040);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4243 + "'", int2 == 4243);
    }

    @Test
    public void test3197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3197");
        int int2 = sum.Toplama.sum(14473, 10939);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25412 + "'", int2 == 25412);
    }

    @Test
    public void test3198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3198");
        int int2 = sum.Toplama.sum(43787, 7650);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51437 + "'", int2 == 51437);
    }

    @Test
    public void test3199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3199");
        int int2 = sum.Toplama.sum(9187, 15901);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25088 + "'", int2 == 25088);
    }

    @Test
    public void test3200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3200");
        int int2 = sum.Toplama.sum(14701, 3281);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17982 + "'", int2 == 17982);
    }

    @Test
    public void test3201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3201");
        int int2 = sum.Toplama.sum(10201, 260);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10461 + "'", int2 == 10461);
    }

    @Test
    public void test3202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3202");
        int int2 = sum.Toplama.sum(12887, 22755);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35642 + "'", int2 == 35642);
    }

    @Test
    public void test3203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3203");
        int int2 = sum.Toplama.sum(9156, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9156 + "'", int2 == 9156);
    }

    @Test
    public void test3204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3204");
        int int2 = sum.Toplama.sum(13576, 26951);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40527 + "'", int2 == 40527);
    }

    @Test
    public void test3205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3205");
        int int2 = sum.Toplama.sum(21874, 6085);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27959 + "'", int2 == 27959);
    }

    @Test
    public void test3206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3206");
        int int2 = sum.Toplama.sum(7335, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7335 + "'", int2 == 7335);
    }

    @Test
    public void test3207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3207");
        int int2 = sum.Toplama.sum(0, 2223);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2223 + "'", int2 == 2223);
    }

    @Test
    public void test3208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3208");
        int int2 = sum.Toplama.sum(626, 294);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 920 + "'", int2 == 920);
    }

    @Test
    public void test3209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3209");
        int int2 = sum.Toplama.sum(1532, 39365);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40897 + "'", int2 == 40897);
    }

    @Test
    public void test3210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3210");
        int int2 = sum.Toplama.sum(1877, 3833);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5710 + "'", int2 == 5710);
    }

    @Test
    public void test3211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3211");
        int int2 = sum.Toplama.sum(1147, 10020);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11167 + "'", int2 == 11167);
    }

    @Test
    public void test3212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3212");
        int int2 = sum.Toplama.sum(38129, 22755);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60884 + "'", int2 == 60884);
    }

    @Test
    public void test3213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3213");
        int int2 = sum.Toplama.sum(12610, 1643);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14253 + "'", int2 == 14253);
    }

    @Test
    public void test3214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3214");
        int int2 = sum.Toplama.sum(17401, 2723);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20124 + "'", int2 == 20124);
    }

    @Test
    public void test3215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3215");
        int int2 = sum.Toplama.sum(2314, 3991);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6305 + "'", int2 == 6305);
    }

    @Test
    public void test3216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3216");
        int int2 = sum.Toplama.sum(16510, 4169);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20679 + "'", int2 == 20679);
    }

    @Test
    public void test3217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3217");
        int int2 = sum.Toplama.sum(7996, 39365);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47361 + "'", int2 == 47361);
    }

    @Test
    public void test3218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3218");
        int int2 = sum.Toplama.sum(2222, 22665);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24887 + "'", int2 == 24887);
    }

    @Test
    public void test3219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3219");
        int int2 = sum.Toplama.sum(24224, 1411);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25635 + "'", int2 == 25635);
    }

    @Test
    public void test3220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3220");
        int int2 = sum.Toplama.sum(7840, 31311);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39151 + "'", int2 == 39151);
    }

    @Test
    public void test3221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3221");
        int int2 = sum.Toplama.sum(2311, 3530);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5841 + "'", int2 == 5841);
    }

    @Test
    public void test3222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3222");
        int int2 = sum.Toplama.sum(5767, 10565);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16332 + "'", int2 == 16332);
    }

    @Test
    public void test3223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3223");
        int int2 = sum.Toplama.sum(23371, 10939);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34310 + "'", int2 == 34310);
    }

    @Test
    public void test3224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3224");
        int int2 = sum.Toplama.sum(1460, 24382);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25842 + "'", int2 == 25842);
    }

    @Test
    public void test3225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3225");
        int int2 = sum.Toplama.sum(20758, 4317);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25075 + "'", int2 == 25075);
    }

    @Test
    public void test3226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3226");
        int int2 = sum.Toplama.sum(7666, 18926);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26592 + "'", int2 == 26592);
    }

    @Test
    public void test3227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3227");
        int int2 = sum.Toplama.sum(17853, 6631);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24484 + "'", int2 == 24484);
    }

    @Test
    public void test3228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3228");
        int int2 = sum.Toplama.sum(12080, 395);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12475 + "'", int2 == 12475);
    }

    @Test
    public void test3229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3229");
        int int2 = sum.Toplama.sum(3135, 7030);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10165 + "'", int2 == 10165);
    }

    @Test
    public void test3230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3230");
        int int2 = sum.Toplama.sum(15113, 8666);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23779 + "'", int2 == 23779);
    }

    @Test
    public void test3231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3231");
        int int2 = sum.Toplama.sum(0, 28059);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28059 + "'", int2 == 28059);
    }

    @Test
    public void test3232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3232");
        int int2 = sum.Toplama.sum(14250, 9068);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23318 + "'", int2 == 23318);
    }

    @Test
    public void test3233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3233");
        int int2 = sum.Toplama.sum(1165, 1536);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2701 + "'", int2 == 2701);
    }

    @Test
    public void test3234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3234");
        int int2 = sum.Toplama.sum(7258, 6643);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13901 + "'", int2 == 13901);
    }

    @Test
    public void test3235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3235");
        int int2 = sum.Toplama.sum(1897, 16759);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18656 + "'", int2 == 18656);
    }

    @Test
    public void test3236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3236");
        int int2 = sum.Toplama.sum(1639, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1639 + "'", int2 == 1639);
    }

    @Test
    public void test3237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3237");
        int int2 = sum.Toplama.sum(11682, 25388);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37070 + "'", int2 == 37070);
    }

    @Test
    public void test3238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3238");
        int int2 = sum.Toplama.sum(24887, 23192);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48079 + "'", int2 == 48079);
    }

    @Test
    public void test3239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3239");
        int int2 = sum.Toplama.sum(8898, 17856);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26754 + "'", int2 == 26754);
    }

    @Test
    public void test3240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3240");
        int int2 = sum.Toplama.sum(15352, 3274);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18626 + "'", int2 == 18626);
    }

    @Test
    public void test3241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3241");
        int int2 = sum.Toplama.sum(27872, 9563);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37435 + "'", int2 == 37435);
    }

    @Test
    public void test3242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3242");
        int int2 = sum.Toplama.sum(2325, 23014);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25339 + "'", int2 == 25339);
    }

    @Test
    public void test3243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3243");
        int int2 = sum.Toplama.sum(5558, 5125);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10683 + "'", int2 == 10683);
    }

    @Test
    public void test3244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3244");
        int int2 = sum.Toplama.sum(7731, 5565);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13296 + "'", int2 == 13296);
    }

    @Test
    public void test3245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3245");
        int int2 = sum.Toplama.sum(315, 5354);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5669 + "'", int2 == 5669);
    }

    @Test
    public void test3246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3246");
        int int2 = sum.Toplama.sum(8925, 4315);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13240 + "'", int2 == 13240);
    }

    @Test
    public void test3247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3247");
        int int2 = sum.Toplama.sum(447, 21913);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22360 + "'", int2 == 22360);
    }

    @Test
    public void test3248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3248");
        int int2 = sum.Toplama.sum(53080, 10000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63080 + "'", int2 == 63080);
    }

    @Test
    public void test3249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3249");
        int int2 = sum.Toplama.sum(630, 9349);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9979 + "'", int2 == 9979);
    }

    @Test
    public void test3250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3250");
        int int2 = sum.Toplama.sum(4609, 13887);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18496 + "'", int2 == 18496);
    }

    @Test
    public void test3251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3251");
        int int2 = sum.Toplama.sum(6839, 4368);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11207 + "'", int2 == 11207);
    }

    @Test
    public void test3252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3252");
        int int2 = sum.Toplama.sum(0, 38024);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38024 + "'", int2 == 38024);
    }

    @Test
    public void test3253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3253");
        int int2 = sum.Toplama.sum(7903, 44992);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52895 + "'", int2 == 52895);
    }

    @Test
    public void test3254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3254");
        int int2 = sum.Toplama.sum(17152, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17152 + "'", int2 == 17152);
    }

    @Test
    public void test3255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3255");
        int int2 = sum.Toplama.sum(2102, 21866);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23968 + "'", int2 == 23968);
    }

    @Test
    public void test3256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3256");
        int int2 = sum.Toplama.sum(12857, 6585);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19442 + "'", int2 == 19442);
    }

    @Test
    public void test3257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3257");
        int int2 = sum.Toplama.sum(6819, 1532);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8351 + "'", int2 == 8351);
    }

    @Test
    public void test3258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3258");
        int int2 = sum.Toplama.sum(5342, 22509);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27851 + "'", int2 == 27851);
    }

    @Test
    public void test3259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3259");
        int int2 = sum.Toplama.sum(4493, 4653);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9146 + "'", int2 == 9146);
    }

    @Test
    public void test3260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3260");
        int int2 = sum.Toplama.sum(20664, 6586);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27250 + "'", int2 == 27250);
    }

    @Test
    public void test3261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3261");
        int int2 = sum.Toplama.sum(2897, 5814);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8711 + "'", int2 == 8711);
    }

    @Test
    public void test3262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3262");
        int int2 = sum.Toplama.sum(1374, 11225);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12599 + "'", int2 == 12599);
    }

    @Test
    public void test3263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3263");
        int int2 = sum.Toplama.sum(14683, 21274);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35957 + "'", int2 == 35957);
    }

    @Test
    public void test3264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3264");
        int int2 = sum.Toplama.sum(6748, 10448);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17196 + "'", int2 == 17196);
    }

    @Test
    public void test3265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3265");
        int int2 = sum.Toplama.sum(11578, 1572);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13150 + "'", int2 == 13150);
    }

    @Test
    public void test3266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3266");
        int int2 = sum.Toplama.sum(11, 7180);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7191 + "'", int2 == 7191);
    }

    @Test
    public void test3267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3267");
        int int2 = sum.Toplama.sum(6124, 35072);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41196 + "'", int2 == 41196);
    }

    @Test
    public void test3268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3268");
        int int2 = sum.Toplama.sum(30366, 23031);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53397 + "'", int2 == 53397);
    }

    @Test
    public void test3269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3269");
        int int2 = sum.Toplama.sum(6543, 1685);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8228 + "'", int2 == 8228);
    }

    @Test
    public void test3270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3270");
        int int2 = sum.Toplama.sum(19036, 6723);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25759 + "'", int2 == 25759);
    }

    @Test
    public void test3271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3271");
        int int2 = sum.Toplama.sum(9004, 33254);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42258 + "'", int2 == 42258);
    }

    @Test
    public void test3272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3272");
        int int2 = sum.Toplama.sum(4247, 5996);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10243 + "'", int2 == 10243);
    }

    @Test
    public void test3273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3273");
        int int2 = sum.Toplama.sum(3247, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3247 + "'", int2 == 3247);
    }

    @Test
    public void test3274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3274");
        int int2 = sum.Toplama.sum(4857, 4169);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9026 + "'", int2 == 9026);
    }

    @Test
    public void test3275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3275");
        int int2 = sum.Toplama.sum(4653, 6485);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11138 + "'", int2 == 11138);
    }

    @Test
    public void test3276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3276");
        int int2 = sum.Toplama.sum(2103, 5215);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7318 + "'", int2 == 7318);
    }

    @Test
    public void test3277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3277");
        int int2 = sum.Toplama.sum(8676, 9748);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18424 + "'", int2 == 18424);
    }

    @Test
    public void test3278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3278");
        int int2 = sum.Toplama.sum(188, 10683);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10871 + "'", int2 == 10871);
    }

    @Test
    public void test3279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3279");
        int int2 = sum.Toplama.sum(3469, 251);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3720 + "'", int2 == 3720);
    }

    @Test
    public void test3280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3280");
        int int2 = sum.Toplama.sum(3078, 7745);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10823 + "'", int2 == 10823);
    }

    @Test
    public void test3281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3281");
        int int2 = sum.Toplama.sum(19270, 8383);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27653 + "'", int2 == 27653);
    }

    @Test
    public void test3282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3282");
        int int2 = sum.Toplama.sum(36091, 3959);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40050 + "'", int2 == 40050);
    }

    @Test
    public void test3283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3283");
        int int2 = sum.Toplama.sum(12175, 15251);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27426 + "'", int2 == 27426);
    }

    @Test
    public void test3284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3284");
        int int2 = sum.Toplama.sum(8759, 29116);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37875 + "'", int2 == 37875);
    }

    @Test
    public void test3285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3285");
        int int2 = sum.Toplama.sum(4377, 15999);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20376 + "'", int2 == 20376);
    }

    @Test
    public void test3286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3286");
        int int2 = sum.Toplama.sum(5919, 2148);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8067 + "'", int2 == 8067);
    }

    @Test
    public void test3287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3287");
        int int2 = sum.Toplama.sum(29044, 10000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39044 + "'", int2 == 39044);
    }

    @Test
    public void test3288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3288");
        int int2 = sum.Toplama.sum(3669, 44858);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48527 + "'", int2 == 48527);
    }

    @Test
    public void test3289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3289");
        int int2 = sum.Toplama.sum(2844, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2844 + "'", int2 == 2844);
    }

    @Test
    public void test3290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3290");
        int int2 = sum.Toplama.sum(3169, 3051);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6220 + "'", int2 == 6220);
    }

    @Test
    public void test3291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3291");
        int int2 = sum.Toplama.sum(6019, 866);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6885 + "'", int2 == 6885);
    }

    @Test
    public void test3292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3292");
        int int2 = sum.Toplama.sum(8221, 12786);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21007 + "'", int2 == 21007);
    }

    @Test
    public void test3293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3293");
        int int2 = sum.Toplama.sum(36483, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36483 + "'", int2 == 36483);
    }

    @Test
    public void test3294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3294");
        int int2 = sum.Toplama.sum(16787, 1330);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18117 + "'", int2 == 18117);
    }

    @Test
    public void test3295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3295");
        int int2 = sum.Toplama.sum(24443, 10877);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35320 + "'", int2 == 35320);
    }

    @Test
    public void test3296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3296");
        int int2 = sum.Toplama.sum(10931, 859);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11790 + "'", int2 == 11790);
    }

    @Test
    public void test3297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3297");
        int int2 = sum.Toplama.sum(4738, 41787);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46525 + "'", int2 == 46525);
    }

    @Test
    public void test3298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3298");
        int int2 = sum.Toplama.sum(3110, 4247);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7357 + "'", int2 == 7357);
    }

    @Test
    public void test3299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3299");
        int int2 = sum.Toplama.sum(29845, 1274);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31119 + "'", int2 == 31119);
    }

    @Test
    public void test3300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3300");
        int int2 = sum.Toplama.sum(1954, 5828);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7782 + "'", int2 == 7782);
    }

    @Test
    public void test3301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3301");
        int int2 = sum.Toplama.sum(3199, 11436);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14635 + "'", int2 == 14635);
    }

    @Test
    public void test3302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3302");
        int int2 = sum.Toplama.sum(394, 11534);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11928 + "'", int2 == 11928);
    }

    @Test
    public void test3303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3303");
        int int2 = sum.Toplama.sum(2587, 4180);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6767 + "'", int2 == 6767);
    }

    @Test
    public void test3304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3304");
        int int2 = sum.Toplama.sum(8221, 4025);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12246 + "'", int2 == 12246);
    }

    @Test
    public void test3305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3305");
        int int2 = sum.Toplama.sum(28991, 1839);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30830 + "'", int2 == 30830);
    }

    @Test
    public void test3306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3306");
        int int2 = sum.Toplama.sum(3503, 10850);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14353 + "'", int2 == 14353);
    }

    @Test
    public void test3307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3307");
        int int2 = sum.Toplama.sum(27774, 1118);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28892 + "'", int2 == 28892);
    }

    @Test
    public void test3308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3308");
        int int2 = sum.Toplama.sum(491, 7963);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8454 + "'", int2 == 8454);
    }

    @Test
    public void test3309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3309");
        int int2 = sum.Toplama.sum(17799, 3281);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21080 + "'", int2 == 21080);
    }

    @Test
    public void test3310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3310");
        int int2 = sum.Toplama.sum(0, 7582);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7582 + "'", int2 == 7582);
    }

    @Test
    public void test3311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3311");
        int int2 = sum.Toplama.sum(2102, 4521);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6623 + "'", int2 == 6623);
    }

    @Test
    public void test3312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3312");
        int int2 = sum.Toplama.sum(55034, 1936);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56970 + "'", int2 == 56970);
    }

    @Test
    public void test3313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3313");
        int int2 = sum.Toplama.sum(1378, 7030);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8408 + "'", int2 == 8408);
    }

    @Test
    public void test3314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3314");
        int int2 = sum.Toplama.sum(5978, 4354);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10332 + "'", int2 == 10332);
    }

    @Test
    public void test3315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3315");
        int int2 = sum.Toplama.sum(4640, 15917);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20557 + "'", int2 == 20557);
    }

    @Test
    public void test3316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3316");
        int int2 = sum.Toplama.sum(17873, 50403);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68276 + "'", int2 == 68276);
    }

    @Test
    public void test3317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3317");
        int int2 = sum.Toplama.sum(2109, 22357);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24466 + "'", int2 == 24466);
    }

    @Test
    public void test3318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3318");
        int int2 = sum.Toplama.sum(16804, 1744);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18548 + "'", int2 == 18548);
    }

    @Test
    public void test3319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3319");
        int int2 = sum.Toplama.sum(3342, 17433);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20775 + "'", int2 == 20775);
    }

    @Test
    public void test3320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3320");
        int int2 = sum.Toplama.sum(18983, 3487);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22470 + "'", int2 == 22470);
    }

    @Test
    public void test3321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3321");
        int int2 = sum.Toplama.sum(3135, 9088);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12223 + "'", int2 == 12223);
    }

    @Test
    public void test3322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3322");
        int int2 = sum.Toplama.sum(16443, 34680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51123 + "'", int2 == 51123);
    }

    @Test
    public void test3323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3323");
        int int2 = sum.Toplama.sum(52, 24499);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24551 + "'", int2 == 24551);
    }

    @Test
    public void test3324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3324");
        int int2 = sum.Toplama.sum(6666, 6454);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13120 + "'", int2 == 13120);
    }

    @Test
    public void test3325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3325");
        int int2 = sum.Toplama.sum(1460, 25473);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26933 + "'", int2 == 26933);
    }

    @Test
    public void test3326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3326");
        int int2 = sum.Toplama.sum(43179, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43179 + "'", int2 == 43179);
    }

    @Test
    public void test3327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3327");
        int int2 = sum.Toplama.sum(8793, 7860);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16653 + "'", int2 == 16653);
    }

    @Test
    public void test3328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3328");
        int int2 = sum.Toplama.sum(100, 6141);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6241 + "'", int2 == 6241);
    }

    @Test
    public void test3329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3329");
        int int2 = sum.Toplama.sum(0, 12554);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12554 + "'", int2 == 12554);
    }

    @Test
    public void test3330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3330");
        int int2 = sum.Toplama.sum(9059, 3283);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12342 + "'", int2 == 12342);
    }

    @Test
    public void test3331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3331");
        int int2 = sum.Toplama.sum((int) 'a', 1965);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2062 + "'", int2 == 2062);
    }

    @Test
    public void test3332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3332");
        int int2 = sum.Toplama.sum(36321, 7713);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44034 + "'", int2 == 44034);
    }

    @Test
    public void test3333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3333");
        int int2 = sum.Toplama.sum(877, 4545);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5422 + "'", int2 == 5422);
    }

    @Test
    public void test3334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3334");
        int int2 = sum.Toplama.sum(2952, 6219);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9171 + "'", int2 == 9171);
    }

    @Test
    public void test3335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3335");
        int int2 = sum.Toplama.sum(12927, 1085);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14012 + "'", int2 == 14012);
    }

    @Test
    public void test3336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3336");
        int int2 = sum.Toplama.sum(1085, 395);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1480 + "'", int2 == 1480);
    }

    @Test
    public void test3337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3337");
        int int2 = sum.Toplama.sum(508, 1835);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2343 + "'", int2 == 2343);
    }

    @Test
    public void test3338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3338");
        int int2 = sum.Toplama.sum(8483, 13901);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22384 + "'", int2 == 22384);
    }

    @Test
    public void test3339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3339");
        int int2 = sum.Toplama.sum(8668, 8607);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17275 + "'", int2 == 17275);
    }

    @Test
    public void test3340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3340");
        int int2 = sum.Toplama.sum(18308, 2314);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20622 + "'", int2 == 20622);
    }

    @Test
    public void test3341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3341");
        int int2 = sum.Toplama.sum(3766, 33913);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37679 + "'", int2 == 37679);
    }

    @Test
    public void test3342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3342");
        int int2 = sum.Toplama.sum(8041, 14557);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22598 + "'", int2 == 22598);
    }

    @Test
    public void test3343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3343");
        int int2 = sum.Toplama.sum(1521, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1521 + "'", int2 == 1521);
    }

    @Test
    public void test3344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3344");
        int int2 = sum.Toplama.sum(13120, 14782);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27902 + "'", int2 == 27902);
    }

    @Test
    public void test3345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3345");
        int int2 = sum.Toplama.sum(1185, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1185 + "'", int2 == 1185);
    }

    @Test
    public void test3346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3346");
        int int2 = sum.Toplama.sum((int) (short) -1, 3503);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3502 + "'", int2 == 3502);
    }

    @Test
    public void test3347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3347");
        int int2 = sum.Toplama.sum(7258, 5541);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12799 + "'", int2 == 12799);
    }

    @Test
    public void test3348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3348");
        int int2 = sum.Toplama.sum(1232, 3798);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5030 + "'", int2 == 5030);
    }

    @Test
    public void test3349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3349");
        int int2 = sum.Toplama.sum(2202, 3256);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5458 + "'", int2 == 5458);
    }

    @Test
    public void test3350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3350");
        int int2 = sum.Toplama.sum(4247, 24301);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28548 + "'", int2 == 28548);
    }

    @Test
    public void test3351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3351");
        int int2 = sum.Toplama.sum(18983, 4310);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23293 + "'", int2 == 23293);
    }

    @Test
    public void test3352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3352");
        int int2 = sum.Toplama.sum(4817, 6869);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11686 + "'", int2 == 11686);
    }

    @Test
    public void test3353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3353");
        int int2 = sum.Toplama.sum(48736, 106);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48842 + "'", int2 == 48842);
    }

    @Test
    public void test3354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3354");
        int int2 = sum.Toplama.sum(17361, 4387);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21748 + "'", int2 == 21748);
    }

    @Test
    public void test3355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3355");
        int int2 = sum.Toplama.sum(9526, 6345);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15871 + "'", int2 == 15871);
    }

    @Test
    public void test3356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3356");
        int int2 = sum.Toplama.sum(22556, 5643);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28199 + "'", int2 == 28199);
    }

    @Test
    public void test3357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3357");
        int int2 = sum.Toplama.sum(1408, 1539);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2947 + "'", int2 == 2947);
    }

    @Test
    public void test3358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3358");
        int int2 = sum.Toplama.sum(440, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 440 + "'", int2 == 440);
    }

    @Test
    public void test3359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3359");
        int int2 = sum.Toplama.sum(41787, 14353);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56140 + "'", int2 == 56140);
    }

    @Test
    public void test3360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3360");
        int int2 = sum.Toplama.sum(88, 344);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 432 + "'", int2 == 432);
    }

    @Test
    public void test3361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3361");
        int int2 = sum.Toplama.sum(2978, 9006);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11984 + "'", int2 == 11984);
    }

    @Test
    public void test3362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3362");
        int int2 = sum.Toplama.sum(5530, 30673);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36203 + "'", int2 == 36203);
    }

    @Test
    public void test3363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3363");
        int int2 = sum.Toplama.sum(10201, 5840);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16041 + "'", int2 == 16041);
    }

    @Test
    public void test3364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3364");
        int int2 = sum.Toplama.sum(2314, 13526);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15840 + "'", int2 == 15840);
    }

    @Test
    public void test3365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3365");
        int int2 = sum.Toplama.sum(2214, 4820);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7034 + "'", int2 == 7034);
    }

    @Test
    public void test3366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3366");
        int int2 = sum.Toplama.sum(1643, 1315);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2958 + "'", int2 == 2958);
    }

    @Test
    public void test3367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3367");
        int int2 = sum.Toplama.sum(12922, 6621);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19543 + "'", int2 == 19543);
    }

    @Test
    public void test3368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3368");
        int int2 = sum.Toplama.sum(13538, 34680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48218 + "'", int2 == 48218);
    }

    @Test
    public void test3369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3369");
        int int2 = sum.Toplama.sum(2343, 31157);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33500 + "'", int2 == 33500);
    }

    @Test
    public void test3370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3370");
        int int2 = sum.Toplama.sum(2660, 20161);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22821 + "'", int2 == 22821);
    }

    @Test
    public void test3371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3371");
        int int2 = sum.Toplama.sum(23968, 4311);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28279 + "'", int2 == 28279);
    }

    @Test
    public void test3372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3372");
        int int2 = sum.Toplama.sum(0, 36483);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36483 + "'", int2 == 36483);
    }

    @Test
    public void test3373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3373");
        int int2 = sum.Toplama.sum(6440, 4572);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11012 + "'", int2 == 11012);
    }

    @Test
    public void test3374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3374");
        int int2 = sum.Toplama.sum(4978, 4246);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9224 + "'", int2 == 9224);
    }

    @Test
    public void test3375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3375");
        int int2 = sum.Toplama.sum(24219, 11651);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35870 + "'", int2 == 35870);
    }

    @Test
    public void test3376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3376");
        int int2 = sum.Toplama.sum(14077, 7782);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21859 + "'", int2 == 21859);
    }

    @Test
    public void test3377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3377");
        int int2 = sum.Toplama.sum(3208, 51);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3259 + "'", int2 == 3259);
    }

    @Test
    public void test3378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3378");
        int int2 = sum.Toplama.sum(10894, 24443);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35337 + "'", int2 == 35337);
    }

    @Test
    public void test3379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3379");
        int int2 = sum.Toplama.sum(1601, 8666);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10267 + "'", int2 == 10267);
    }

    @Test
    public void test3380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3380");
        int int2 = sum.Toplama.sum(4197, 13208);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17405 + "'", int2 == 17405);
    }

    @Test
    public void test3381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3381");
        int int2 = sum.Toplama.sum(36305, 1963);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38268 + "'", int2 == 38268);
    }

    @Test
    public void test3382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3382");
        int int2 = sum.Toplama.sum(8823, 2405);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11228 + "'", int2 == 11228);
    }

    @Test
    public void test3383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3383");
        int int2 = sum.Toplama.sum(0, 5635);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5635 + "'", int2 == 5635);
    }

    @Test
    public void test3384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3384");
        int int2 = sum.Toplama.sum(4283, 11174);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15457 + "'", int2 == 15457);
    }

    @Test
    public void test3385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3385");
        int int2 = sum.Toplama.sum(26305, 3136);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29441 + "'", int2 == 29441);
    }

    @Test
    public void test3386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3386");
        int int2 = sum.Toplama.sum(3742, 794);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4536 + "'", int2 == 4536);
    }

    @Test
    public void test3387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3387");
        int int2 = sum.Toplama.sum(10396, 1005);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11401 + "'", int2 == 11401);
    }

    @Test
    public void test3388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3388");
        int int2 = sum.Toplama.sum(55281, 1232);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56513 + "'", int2 == 56513);
    }

    @Test
    public void test3389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3389");
        int int2 = sum.Toplama.sum(6278, 6638);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12916 + "'", int2 == 12916);
    }

    @Test
    public void test3390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3390");
        int int2 = sum.Toplama.sum(18014, 9846);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27860 + "'", int2 == 27860);
    }

    @Test
    public void test3391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3391");
        int int2 = sum.Toplama.sum(5422, 10885);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16307 + "'", int2 == 16307);
    }

    @Test
    public void test3392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3392");
        int int2 = sum.Toplama.sum(6999, 55034);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62033 + "'", int2 == 62033);
    }

    @Test
    public void test3393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3393");
        int int2 = sum.Toplama.sum(20529, 6160);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26689 + "'", int2 == 26689);
    }

    @Test
    public void test3394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3394");
        int int2 = sum.Toplama.sum(15514, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15514 + "'", int2 == 15514);
    }

    @Test
    public void test3395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3395");
        int int2 = sum.Toplama.sum(15421, 616);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16037 + "'", int2 == 16037);
    }

    @Test
    public void test3396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3396");
        int int2 = sum.Toplama.sum(8263, 293);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8556 + "'", int2 == 8556);
    }

    @Test
    public void test3397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3397");
        int int2 = sum.Toplama.sum(6382, 17490);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23872 + "'", int2 == 23872);
    }

    @Test
    public void test3398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3398");
        int int2 = sum.Toplama.sum(6030, 7949);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13979 + "'", int2 == 13979);
    }

    @Test
    public void test3399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3399");
        int int2 = sum.Toplama.sum(1278, 11012);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12290 + "'", int2 == 12290);
    }

    @Test
    public void test3400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3400");
        int int2 = sum.Toplama.sum(12373, 32229);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44602 + "'", int2 == 44602);
    }

    @Test
    public void test3401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3401");
        int int2 = sum.Toplama.sum(9396, 15467);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24863 + "'", int2 == 24863);
    }

    @Test
    public void test3402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3402");
        int int2 = sum.Toplama.sum(11174, 5670);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16844 + "'", int2 == 16844);
    }

    @Test
    public void test3403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3403");
        int int2 = sum.Toplama.sum(1339, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1339 + "'", int2 == 1339);
    }

    @Test
    public void test3404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3404");
        int int2 = sum.Toplama.sum(17114, 486);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17600 + "'", int2 == 17600);
    }

    @Test
    public void test3405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3405");
        int int2 = sum.Toplama.sum(5814, 14473);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20287 + "'", int2 == 20287);
    }

    @Test
    public void test3406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3406");
        int int2 = sum.Toplama.sum(3176, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3176 + "'", int2 == 3176);
    }

    @Test
    public void test3407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3407");
        int int2 = sum.Toplama.sum(15871, 10658);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26529 + "'", int2 == 26529);
    }

    @Test
    public void test3408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3408");
        int int2 = sum.Toplama.sum(6931, 1199);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8130 + "'", int2 == 8130);
    }

    @Test
    public void test3409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3409");
        int int2 = sum.Toplama.sum(19358, 1027);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20385 + "'", int2 == 20385);
    }

    @Test
    public void test3410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3410");
        int int2 = sum.Toplama.sum(30496, 2824);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33320 + "'", int2 == 33320);
    }

    @Test
    public void test3411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3411");
        int int2 = sum.Toplama.sum(14500, 16109);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30609 + "'", int2 == 30609);
    }

    @Test
    public void test3412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3412");
        int int2 = sum.Toplama.sum(10270, 7832);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18102 + "'", int2 == 18102);
    }

    @Test
    public void test3413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3413");
        int int2 = sum.Toplama.sum(3850, 13480);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17330 + "'", int2 == 17330);
    }

    @Test
    public void test3414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3414");
        int int2 = sum.Toplama.sum(423, 2835);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3258 + "'", int2 == 3258);
    }

    @Test
    public void test3415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3415");
        int int2 = sum.Toplama.sum(15352, 5565);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20917 + "'", int2 == 20917);
    }

    @Test
    public void test3416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3416");
        int int2 = sum.Toplama.sum(22509, 11603);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34112 + "'", int2 == 34112);
    }

    @Test
    public void test3417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3417");
        int int2 = sum.Toplama.sum(11789, 6542);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18331 + "'", int2 == 18331);
    }

    @Test
    public void test3418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3418");
        int int2 = sum.Toplama.sum(5268, 1014);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6282 + "'", int2 == 6282);
    }

    @Test
    public void test3419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3419");
        int int2 = sum.Toplama.sum(164, 7814);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7978 + "'", int2 == 7978);
    }

    @Test
    public void test3420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3420");
        int int2 = sum.Toplama.sum(10272, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10272 + "'", int2 == 10272);
    }

    @Test
    public void test3421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3421");
        int int2 = sum.Toplama.sum(6326, 1491);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7817 + "'", int2 == 7817);
    }

    @Test
    public void test3422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3422");
        int int2 = sum.Toplama.sum(2940, 20559);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23499 + "'", int2 == 23499);
    }

    @Test
    public void test3423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3423");
        int int2 = sum.Toplama.sum(8228, 217);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8445 + "'", int2 == 8445);
    }

    @Test
    public void test3424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3424");
        int int2 = sum.Toplama.sum(19441, 17955);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37396 + "'", int2 == 37396);
    }

    @Test
    public void test3425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3425");
        int int2 = sum.Toplama.sum(875, 5268);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6143 + "'", int2 == 6143);
    }

    @Test
    public void test3426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3426");
        int int2 = sum.Toplama.sum(18656, 21065);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39721 + "'", int2 == 39721);
    }

    @Test
    public void test3427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3427");
        int int2 = sum.Toplama.sum(0, 6220);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6220 + "'", int2 == 6220);
    }

    @Test
    public void test3428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3428");
        int int2 = sum.Toplama.sum(14132, 6723);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20855 + "'", int2 == 20855);
    }

    @Test
    public void test3429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3429");
        int int2 = sum.Toplama.sum(19871, 2414);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22285 + "'", int2 == 22285);
    }

    @Test
    public void test3430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3430");
        int int2 = sum.Toplama.sum(1797, 3519);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5316 + "'", int2 == 5316);
    }

    @Test
    public void test3431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3431");
        int int2 = sum.Toplama.sum(1060, 1292);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2352 + "'", int2 == 2352);
    }

    @Test
    public void test3432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3432");
        int int2 = sum.Toplama.sum(8148, 20655);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28803 + "'", int2 == 28803);
    }

    @Test
    public void test3433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3433");
        int int2 = sum.Toplama.sum(17189, 8898);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26087 + "'", int2 == 26087);
    }

    @Test
    public void test3434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3434");
        int int2 = sum.Toplama.sum(3442, 7576);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11018 + "'", int2 == 11018);
    }

    @Test
    public void test3435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3435");
        int int2 = sum.Toplama.sum(21913, 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22012 + "'", int2 == 22012);
    }

    @Test
    public void test3436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3436");
        int int2 = sum.Toplama.sum(1954, 8477);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10431 + "'", int2 == 10431);
    }

    @Test
    public void test3437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3437");
        int int2 = sum.Toplama.sum(5103, 25450);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30553 + "'", int2 == 30553);
    }

    @Test
    public void test3438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3438");
        int int2 = sum.Toplama.sum(20664, 30830);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51494 + "'", int2 == 51494);
    }

    @Test
    public void test3439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3439");
        int int2 = sum.Toplama.sum(15467, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15467 + "'", int2 == 15467);
    }

    @Test
    public void test3440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3440");
        int int2 = sum.Toplama.sum(57084, 6133);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63217 + "'", int2 == 63217);
    }

    @Test
    public void test3441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3441");
        int int2 = sum.Toplama.sum(9803, 18504);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28307 + "'", int2 == 28307);
    }

    @Test
    public void test3442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3442");
        int int2 = sum.Toplama.sum(13518, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13518 + "'", int2 == 13518);
    }

    @Test
    public void test3443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3443");
        int int2 = sum.Toplama.sum(8845, 13518);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22363 + "'", int2 == 22363);
    }

    @Test
    public void test3444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3444");
        int int2 = sum.Toplama.sum(8827, 38421);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47248 + "'", int2 == 47248);
    }

    @Test
    public void test3445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3445");
        int int2 = sum.Toplama.sum(4242, 4215);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8457 + "'", int2 == 8457);
    }

    @Test
    public void test3446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3446");
        int int2 = sum.Toplama.sum(2355, 18108);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20463 + "'", int2 == 20463);
    }

    @Test
    public void test3447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3447");
        int int2 = sum.Toplama.sum(595, 14412);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15007 + "'", int2 == 15007);
    }

    @Test
    public void test3448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3448");
        int int2 = sum.Toplama.sum(8457, 5236);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13693 + "'", int2 == 13693);
    }

    @Test
    public void test3449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3449");
        int int2 = sum.Toplama.sum(0, 13296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13296 + "'", int2 == 13296);
    }

    @Test
    public void test3450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3450");
        int int2 = sum.Toplama.sum(25704, 7882);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33586 + "'", int2 == 33586);
    }

    @Test
    public void test3451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3451");
        int int2 = sum.Toplama.sum(22611, 909);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23520 + "'", int2 == 23520);
    }

    @Test
    public void test3452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3452");
        int int2 = sum.Toplama.sum(47668, 23031);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70699 + "'", int2 == 70699);
    }

    @Test
    public void test3453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3453");
        int int2 = sum.Toplama.sum(0, 14016);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14016 + "'", int2 == 14016);
    }

    @Test
    public void test3454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3454");
        int int2 = sum.Toplama.sum(7316, 11710);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19026 + "'", int2 == 19026);
    }

    @Test
    public void test3455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3455");
        int int2 = sum.Toplama.sum(4283, 13929);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18212 + "'", int2 == 18212);
    }

    @Test
    public void test3456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3456");
        int int2 = sum.Toplama.sum(1584, 14779);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16363 + "'", int2 == 16363);
    }

    @Test
    public void test3457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3457");
        int int2 = sum.Toplama.sum(35562, 5881);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41443 + "'", int2 == 41443);
    }

    @Test
    public void test3458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3458");
        int int2 = sum.Toplama.sum(13992, 1315);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15307 + "'", int2 == 15307);
    }

    @Test
    public void test3459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3459");
        int int2 = sum.Toplama.sum(1584, 3532);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5116 + "'", int2 == 5116);
    }

    @Test
    public void test3460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3460");
        int int2 = sum.Toplama.sum(18899, 854);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19753 + "'", int2 == 19753);
    }

    @Test
    public void test3461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3461");
        int int2 = sum.Toplama.sum(5089, 9870);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14959 + "'", int2 == 14959);
    }

    @Test
    public void test3462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3462");
        int int2 = sum.Toplama.sum(16274, 650);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16924 + "'", int2 == 16924);
    }

    @Test
    public void test3463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3463");
        int int2 = sum.Toplama.sum(2598, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2598 + "'", int2 == 2598);
    }

    @Test
    public void test3464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3464");
        int int2 = sum.Toplama.sum(11550, 21414);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32964 + "'", int2 == 32964);
    }

    @Test
    public void test3465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3465");
        int int2 = sum.Toplama.sum(21901, 6158);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28059 + "'", int2 == 28059);
    }

    @Test
    public void test3466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3466");
        int int2 = sum.Toplama.sum(16878, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16878 + "'", int2 == 16878);
    }

    @Test
    public void test3467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3467");
        int int2 = sum.Toplama.sum(8113, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8113 + "'", int2 == 8113);
    }

    @Test
    public void test3468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3468");
        int int2 = sum.Toplama.sum(7625, 11875);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19500 + "'", int2 == 19500);
    }

    @Test
    public void test3469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3469");
        int int2 = sum.Toplama.sum(5159, 11207);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16366 + "'", int2 == 16366);
    }

    @Test
    public void test3470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3470");
        int int2 = sum.Toplama.sum(7268, 23657);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30925 + "'", int2 == 30925);
    }

    @Test
    public void test3471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3471");
        int int2 = sum.Toplama.sum(14181, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14180 + "'", int2 == 14180);
    }

    @Test
    public void test3472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3472");
        int int2 = sum.Toplama.sum(25737, 2648);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28385 + "'", int2 == 28385);
    }

    @Test
    public void test3473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3473");
        int int2 = sum.Toplama.sum(691, 1807);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2498 + "'", int2 == 2498);
    }

    @Test
    public void test3474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3474");
        int int2 = sum.Toplama.sum(0, 36775);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36775 + "'", int2 == 36775);
    }

    @Test
    public void test3475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3475");
        int int2 = sum.Toplama.sum(5570, 8087);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13657 + "'", int2 == 13657);
    }

    @Test
    public void test3476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3476");
        int int2 = sum.Toplama.sum(49949, 5030);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54979 + "'", int2 == 54979);
    }

    @Test
    public void test3477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3477");
        int int2 = sum.Toplama.sum(8354, 7125);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15479 + "'", int2 == 15479);
    }

    @Test
    public void test3478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3478");
        int int2 = sum.Toplama.sum(12665, 1719);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14384 + "'", int2 == 14384);
    }

    @Test
    public void test3479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3479");
        int int2 = sum.Toplama.sum(8483, 1095);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9578 + "'", int2 == 9578);
    }

    @Test
    public void test3480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3480");
        int int2 = sum.Toplama.sum(13777, 23190);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36967 + "'", int2 == 36967);
    }

    @Test
    public void test3481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3481");
        int int2 = sum.Toplama.sum(21901, 1903);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23804 + "'", int2 == 23804);
    }

    @Test
    public void test3482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3482");
        int int2 = sum.Toplama.sum(27959, 5997);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33956 + "'", int2 == 33956);
    }

    @Test
    public void test3483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3483");
        int int2 = sum.Toplama.sum(9573, 22560);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32133 + "'", int2 == 32133);
    }

    @Test
    public void test3484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3484");
        int int2 = sum.Toplama.sum(0, 6503);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6503 + "'", int2 == 6503);
    }

    @Test
    public void test3485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3485");
        int int2 = sum.Toplama.sum(34494, 2492);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36986 + "'", int2 == 36986);
    }

    @Test
    public void test3486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3486");
        int int2 = sum.Toplama.sum(344, 21866);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22210 + "'", int2 == 22210);
    }

    @Test
    public void test3487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3487");
        int int2 = sum.Toplama.sum(554, 18755);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19309 + "'", int2 == 19309);
    }

    @Test
    public void test3488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3488");
        int int2 = sum.Toplama.sum(8451, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8451 + "'", int2 == 8451);
    }

    @Test
    public void test3489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3489");
        int int2 = sum.Toplama.sum(7790, 12566);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20356 + "'", int2 == 20356);
    }

    @Test
    public void test3490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3490");
        int int2 = sum.Toplama.sum(15180, 3054);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18234 + "'", int2 == 18234);
    }

    @Test
    public void test3491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3491");
        int int2 = sum.Toplama.sum(23499, 17253);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40752 + "'", int2 == 40752);
    }

    @Test
    public void test3492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3492");
        int int2 = sum.Toplama.sum(11684, 6914);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18598 + "'", int2 == 18598);
    }

    @Test
    public void test3493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3493");
        int int2 = sum.Toplama.sum(12080, 4986);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17066 + "'", int2 == 17066);
    }

    @Test
    public void test3494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3494");
        int int2 = sum.Toplama.sum(6001, 985);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6986 + "'", int2 == 6986);
    }

    @Test
    public void test3495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3495");
        int int2 = sum.Toplama.sum(20505, 2004);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22509 + "'", int2 == 22509);
    }

    @Test
    public void test3496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3496");
        int int2 = sum.Toplama.sum(9396, 1803);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11199 + "'", int2 == 11199);
    }

    @Test
    public void test3497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3497");
        int int2 = sum.Toplama.sum(47668, 1357);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49025 + "'", int2 == 49025);
    }

    @Test
    public void test3498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3498");
        int int2 = sum.Toplama.sum(4242, 4214);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8456 + "'", int2 == 8456);
    }

    @Test
    public void test3499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3499");
        int int2 = sum.Toplama.sum(29157, 3124);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32281 + "'", int2 == 32281);
    }

    @Test
    public void test3500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3500");
        int int2 = sum.Toplama.sum(5673, 26159);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31832 + "'", int2 == 31832);
    }
}

