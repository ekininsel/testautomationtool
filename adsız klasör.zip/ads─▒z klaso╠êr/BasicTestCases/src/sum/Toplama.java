package sum;

public class Toplama {
	
	


	public static int sum(int a, int b) {
		return a+b;
		}
}


