import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest15 {

    public static boolean debug = false;

    @Test
    public void test7501() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7501");
        int int2 = sum.Toplama.sum(13648, 20287);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33935 + "'", int2 == 33935);
    }

    @Test
    public void test7502() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7502");
        int int2 = sum.Toplama.sum(793, 5359);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6152 + "'", int2 == 6152);
    }

    @Test
    public void test7503() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7503");
        int int2 = sum.Toplama.sum(21684, 45502);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67186 + "'", int2 == 67186);
    }

    @Test
    public void test7504() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7504");
        int int2 = sum.Toplama.sum(58285, 12830);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 71115 + "'", int2 == 71115);
    }

    @Test
    public void test7505() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7505");
        int int2 = sum.Toplama.sum(8966, 7655);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16621 + "'", int2 == 16621);
    }

    @Test
    public void test7506() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7506");
        int int2 = sum.Toplama.sum(6839, 52716);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59555 + "'", int2 == 59555);
    }

    @Test
    public void test7507() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7507");
        int int2 = sum.Toplama.sum(1966, 42316);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44282 + "'", int2 == 44282);
    }

    @Test
    public void test7508() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7508");
        int int2 = sum.Toplama.sum(2022, 16854);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18876 + "'", int2 == 18876);
    }

    @Test
    public void test7509() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7509");
        int int2 = sum.Toplama.sum(20882, 2735);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23617 + "'", int2 == 23617);
    }

    @Test
    public void test7510() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7510");
        int int2 = sum.Toplama.sum(9803, 18851);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28654 + "'", int2 == 28654);
    }

    @Test
    public void test7511() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7511");
        int int2 = sum.Toplama.sum(38796, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38796 + "'", int2 == 38796);
    }

    @Test
    public void test7512() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7512");
        int int2 = sum.Toplama.sum(6876, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6876 + "'", int2 == 6876);
    }

    @Test
    public void test7513() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7513");
        int int2 = sum.Toplama.sum(23192, 14631);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37823 + "'", int2 == 37823);
    }

    @Test
    public void test7514() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7514");
        int int2 = sum.Toplama.sum(6643, 16219);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22862 + "'", int2 == 22862);
    }

    @Test
    public void test7515() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7515");
        int int2 = sum.Toplama.sum(59275, 42462);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 101737 + "'", int2 == 101737);
    }

    @Test
    public void test7516() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7516");
        int int2 = sum.Toplama.sum(806, 54173);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54979 + "'", int2 == 54979);
    }

    @Test
    public void test7517() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7517");
        int int2 = sum.Toplama.sum(4396, 16266);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20662 + "'", int2 == 20662);
    }

    @Test
    public void test7518() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7518");
        int int2 = sum.Toplama.sum(7335, 639);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7974 + "'", int2 == 7974);
    }

    @Test
    public void test7519() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7519");
        int int2 = sum.Toplama.sum(259, 28792);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29051 + "'", int2 == 29051);
    }

    @Test
    public void test7520() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7520");
        int int2 = sum.Toplama.sum(18026, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18026 + "'", int2 == 18026);
    }

    @Test
    public void test7521() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7521");
        int int2 = sum.Toplama.sum(37850, 25863);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63713 + "'", int2 == 63713);
    }

    @Test
    public void test7522() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7522");
        int int2 = sum.Toplama.sum(25073, 47841);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72914 + "'", int2 == 72914);
    }

    @Test
    public void test7523() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7523");
        int int2 = sum.Toplama.sum(41915, 7090);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49005 + "'", int2 == 49005);
    }

    @Test
    public void test7524() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7524");
        int int2 = sum.Toplama.sum(39541, 20237);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59778 + "'", int2 == 59778);
    }

    @Test
    public void test7525() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7525");
        int int2 = sum.Toplama.sum(10089, 8168);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18257 + "'", int2 == 18257);
    }

    @Test
    public void test7526() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7526");
        int int2 = sum.Toplama.sum(805, 2436);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3241 + "'", int2 == 3241);
    }

    @Test
    public void test7527() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7527");
        int int2 = sum.Toplama.sum(22440, 15686);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38126 + "'", int2 == 38126);
    }

    @Test
    public void test7528() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7528");
        int int2 = sum.Toplama.sum(42355, 5853);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48208 + "'", int2 == 48208);
    }

    @Test
    public void test7529() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7529");
        int int2 = sum.Toplama.sum(4828, 86716);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 91544 + "'", int2 == 91544);
    }

    @Test
    public void test7530() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7530");
        int int2 = sum.Toplama.sum(14403, 6019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20422 + "'", int2 == 20422);
    }

    @Test
    public void test7531() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7531");
        int int2 = sum.Toplama.sum(11813, 22764);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34577 + "'", int2 == 34577);
    }

    @Test
    public void test7532() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7532");
        int int2 = sum.Toplama.sum(464, 63031);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63495 + "'", int2 == 63495);
    }

    @Test
    public void test7533() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7533");
        int int2 = sum.Toplama.sum(66293, 6574);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72867 + "'", int2 == 72867);
    }

    @Test
    public void test7534() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7534");
        int int2 = sum.Toplama.sum(6136, 6336);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12472 + "'", int2 == 12472);
    }

    @Test
    public void test7535() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7535");
        int int2 = sum.Toplama.sum(28506, 2498);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31004 + "'", int2 == 31004);
    }

    @Test
    public void test7536() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7536");
        int int2 = sum.Toplama.sum(2582, 12735);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15317 + "'", int2 == 15317);
    }

    @Test
    public void test7537() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7537");
        int int2 = sum.Toplama.sum(17343, 25088);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42431 + "'", int2 == 42431);
    }

    @Test
    public void test7538() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7538");
        int int2 = sum.Toplama.sum(794, 82680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 83474 + "'", int2 == 83474);
    }

    @Test
    public void test7539() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7539");
        int int2 = sum.Toplama.sum(26712, 9664);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36376 + "'", int2 == 36376);
    }

    @Test
    public void test7540() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7540");
        int int2 = sum.Toplama.sum(29661, 37968);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67629 + "'", int2 == 67629);
    }

    @Test
    public void test7541() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7541");
        int int2 = sum.Toplama.sum(33675, 12502);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46177 + "'", int2 == 46177);
    }

    @Test
    public void test7542() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7542");
        int int2 = sum.Toplama.sum(25759, 7428);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33187 + "'", int2 == 33187);
    }

    @Test
    public void test7543() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7543");
        int int2 = sum.Toplama.sum(24683, 10332);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35015 + "'", int2 == 35015);
    }

    @Test
    public void test7544() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7544");
        int int2 = sum.Toplama.sum(9024, 42355);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51379 + "'", int2 == 51379);
    }

    @Test
    public void test7545() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7545");
        int int2 = sum.Toplama.sum(2445, 32108);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34553 + "'", int2 == 34553);
    }

    @Test
    public void test7546() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7546");
        int int2 = sum.Toplama.sum(20124, 13204);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33328 + "'", int2 == 33328);
    }

    @Test
    public void test7547() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7547");
        int int2 = sum.Toplama.sum(46661, 24603);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 71264 + "'", int2 == 71264);
    }

    @Test
    public void test7548() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7548");
        int int2 = sum.Toplama.sum(3492, 4563);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8055 + "'", int2 == 8055);
    }

    @Test
    public void test7549() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7549");
        int int2 = sum.Toplama.sum(7860, 18236);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26096 + "'", int2 == 26096);
    }

    @Test
    public void test7550() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7550");
        int int2 = sum.Toplama.sum(6107, 50222);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56329 + "'", int2 == 56329);
    }

    @Test
    public void test7551() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7551");
        int int2 = sum.Toplama.sum(5368, 35479);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40847 + "'", int2 == 40847);
    }

    @Test
    public void test7552() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7552");
        int int2 = sum.Toplama.sum(9221, 7249);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16470 + "'", int2 == 16470);
    }

    @Test
    public void test7553() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7553");
        int int2 = sum.Toplama.sum(29952, 32260);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62212 + "'", int2 == 62212);
    }

    @Test
    public void test7554() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7554");
        int int2 = sum.Toplama.sum(49054, 26753);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 75807 + "'", int2 == 75807);
    }

    @Test
    public void test7555() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7555");
        int int2 = sum.Toplama.sum(53287, 8901);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62188 + "'", int2 == 62188);
    }

    @Test
    public void test7556() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7556");
        int int2 = sum.Toplama.sum(18952, 4536);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23488 + "'", int2 == 23488);
    }

    @Test
    public void test7557() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7557");
        int int2 = sum.Toplama.sum(12514, 26939);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39453 + "'", int2 == 39453);
    }

    @Test
    public void test7558() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7558");
        int int2 = sum.Toplama.sum(33723, 17613);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51336 + "'", int2 == 51336);
    }

    @Test
    public void test7559() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7559");
        int int2 = sum.Toplama.sum(26366, 12245);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38611 + "'", int2 == 38611);
    }

    @Test
    public void test7560() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7560");
        int int2 = sum.Toplama.sum(11654, 104930);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 116584 + "'", int2 == 116584);
    }

    @Test
    public void test7561() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7561");
        int int2 = sum.Toplama.sum(31131, 69524);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100655 + "'", int2 == 100655);
    }

    @Test
    public void test7562() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7562");
        int int2 = sum.Toplama.sum(61703, 48381);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 110084 + "'", int2 == 110084);
    }

    @Test
    public void test7563() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7563");
        int int2 = sum.Toplama.sum(6843, 117834);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 124677 + "'", int2 == 124677);
    }

    @Test
    public void test7564() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7564");
        int int2 = sum.Toplama.sum(4552, 58258);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62810 + "'", int2 == 62810);
    }

    @Test
    public void test7565() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7565");
        int int2 = sum.Toplama.sum(42676, 102474);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 145150 + "'", int2 == 145150);
    }

    @Test
    public void test7566() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7566");
        int int2 = sum.Toplama.sum(3695, 51062);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54757 + "'", int2 == 54757);
    }

    @Test
    public void test7567() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7567");
        int int2 = sum.Toplama.sum(17996, 25178);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43174 + "'", int2 == 43174);
    }

    @Test
    public void test7568() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7568");
        int int2 = sum.Toplama.sum(1829, 67182);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69011 + "'", int2 == 69011);
    }

    @Test
    public void test7569() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7569");
        int int2 = sum.Toplama.sum(59756, 31119);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90875 + "'", int2 == 90875);
    }

    @Test
    public void test7570() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7570");
        int int2 = sum.Toplama.sum(948, 295);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1243 + "'", int2 == 1243);
    }

    @Test
    public void test7571() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7571");
        int int2 = sum.Toplama.sum(0, 31180);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31180 + "'", int2 == 31180);
    }

    @Test
    public void test7572() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7572");
        int int2 = sum.Toplama.sum(3258, 82936);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 86194 + "'", int2 == 86194);
    }

    @Test
    public void test7573() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7573");
        int int2 = sum.Toplama.sum(19639, 3130);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22769 + "'", int2 == 22769);
    }

    @Test
    public void test7574() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7574");
        int int2 = sum.Toplama.sum(16776, 25635);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42411 + "'", int2 == 42411);
    }

    @Test
    public void test7575() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7575");
        int int2 = sum.Toplama.sum(11401, 26498);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37899 + "'", int2 == 37899);
    }

    @Test
    public void test7576() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7576");
        int int2 = sum.Toplama.sum(23522, 28752);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52274 + "'", int2 == 52274);
    }

    @Test
    public void test7577() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7577");
        int int2 = sum.Toplama.sum(35225, 63428);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 98653 + "'", int2 == 98653);
    }

    @Test
    public void test7578() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7578");
        int int2 = sum.Toplama.sum(3165, 11650);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14815 + "'", int2 == 14815);
    }

    @Test
    public void test7579() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7579");
        int int2 = sum.Toplama.sum(44582, 4782);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49364 + "'", int2 == 49364);
    }

    @Test
    public void test7580() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7580");
        int int2 = sum.Toplama.sum(5653, 756);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6409 + "'", int2 == 6409);
    }

    @Test
    public void test7581() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7581");
        int int2 = sum.Toplama.sum(63442, 12432);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 75874 + "'", int2 == 75874);
    }

    @Test
    public void test7582() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7582");
        int int2 = sum.Toplama.sum(42875, 1733);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44608 + "'", int2 == 44608);
    }

    @Test
    public void test7583() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7583");
        int int2 = sum.Toplama.sum(52952, 6739);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59691 + "'", int2 == 59691);
    }

    @Test
    public void test7584() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7584");
        int int2 = sum.Toplama.sum(27134, 7033);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34167 + "'", int2 == 34167);
    }

    @Test
    public void test7585() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7585");
        int int2 = sum.Toplama.sum(43787, 48455);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 92242 + "'", int2 == 92242);
    }

    @Test
    public void test7586() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7586");
        int int2 = sum.Toplama.sum(8671, 27958);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36629 + "'", int2 == 36629);
    }

    @Test
    public void test7587() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7587");
        int int2 = sum.Toplama.sum(42182, 17445);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59627 + "'", int2 == 59627);
    }

    @Test
    public void test7588() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7588");
        int int2 = sum.Toplama.sum(1913, 34900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36813 + "'", int2 == 36813);
    }

    @Test
    public void test7589() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7589");
        int int2 = sum.Toplama.sum(164648, 71140);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 235788 + "'", int2 == 235788);
    }

    @Test
    public void test7590() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7590");
        int int2 = sum.Toplama.sum(44432, 6776);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51208 + "'", int2 == 51208);
    }

    @Test
    public void test7591() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7591");
        int int2 = sum.Toplama.sum(54639, 10000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64639 + "'", int2 == 64639);
    }

    @Test
    public void test7592() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7592");
        int int2 = sum.Toplama.sum(72016, 30889);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 102905 + "'", int2 == 102905);
    }

    @Test
    public void test7593() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7593");
        int int2 = sum.Toplama.sum(23705, 5440);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29145 + "'", int2 == 29145);
    }

    @Test
    public void test7594() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7594");
        int int2 = sum.Toplama.sum(2128, 2016);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4144 + "'", int2 == 4144);
    }

    @Test
    public void test7595() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7595");
        int int2 = sum.Toplama.sum(59613, 27222);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 86835 + "'", int2 == 86835);
    }

    @Test
    public void test7596() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7596");
        int int2 = sum.Toplama.sum(32154, 7655);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39809 + "'", int2 == 39809);
    }

    @Test
    public void test7597() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7597");
        int int2 = sum.Toplama.sum(21595, 27426);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49021 + "'", int2 == 49021);
    }

    @Test
    public void test7598() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7598");
        int int2 = sum.Toplama.sum(16219, 10077);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26296 + "'", int2 == 26296);
    }

    @Test
    public void test7599() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7599");
        int int2 = sum.Toplama.sum(37518, 80030);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 117548 + "'", int2 == 117548);
    }

    @Test
    public void test7600() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7600");
        int int2 = sum.Toplama.sum(105544, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 105544 + "'", int2 == 105544);
    }

    @Test
    public void test7601() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7601");
        int int2 = sum.Toplama.sum(1829, 30660);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32489 + "'", int2 == 32489);
    }

    @Test
    public void test7602() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7602");
        int int2 = sum.Toplama.sum(3911, 72594);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 76505 + "'", int2 == 76505);
    }

    @Test
    public void test7603() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7603");
        int int2 = sum.Toplama.sum(71689, 71491);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 143180 + "'", int2 == 143180);
    }

    @Test
    public void test7604() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7604");
        int int2 = sum.Toplama.sum(24452, 1343);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25795 + "'", int2 == 25795);
    }

    @Test
    public void test7605() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7605");
        int int2 = sum.Toplama.sum(39493, 50546);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90039 + "'", int2 == 90039);
    }

    @Test
    public void test7606() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7606");
        int int2 = sum.Toplama.sum(29032, 42423);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 71455 + "'", int2 == 71455);
    }

    @Test
    public void test7607() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7607");
        int int2 = sum.Toplama.sum(10020, 57448);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67468 + "'", int2 == 67468);
    }

    @Test
    public void test7608() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7608");
        int int2 = sum.Toplama.sum(66022, 8087);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 74109 + "'", int2 == 74109);
    }

    @Test
    public void test7609() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7609");
        int int2 = sum.Toplama.sum(1287, 49005);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50292 + "'", int2 == 50292);
    }

    @Test
    public void test7610() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7610");
        int int2 = sum.Toplama.sum(30036, 11071);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41107 + "'", int2 == 41107);
    }

    @Test
    public void test7611() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7611");
        int int2 = sum.Toplama.sum(52255, 2148);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54403 + "'", int2 == 54403);
    }

    @Test
    public void test7612() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7612");
        int int2 = sum.Toplama.sum(27297, 3848);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31145 + "'", int2 == 31145);
    }

    @Test
    public void test7613() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7613");
        int int2 = sum.Toplama.sum(33254, 22379);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55633 + "'", int2 == 55633);
    }

    @Test
    public void test7614() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7614");
        int int2 = sum.Toplama.sum(3026, 25609);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28635 + "'", int2 == 28635);
    }

    @Test
    public void test7615() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7615");
        int int2 = sum.Toplama.sum(7807, 54791);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62598 + "'", int2 == 62598);
    }

    @Test
    public void test7616() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7616");
        int int2 = sum.Toplama.sum(0, 30472);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30472 + "'", int2 == 30472);
    }

    @Test
    public void test7617() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7617");
        int int2 = sum.Toplama.sum(44347, 45747);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90094 + "'", int2 == 90094);
    }

    @Test
    public void test7618() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7618");
        int int2 = sum.Toplama.sum(18430, 1433);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19863 + "'", int2 == 19863);
    }

    @Test
    public void test7619() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7619");
        int int2 = sum.Toplama.sum(10938, 27083);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38021 + "'", int2 == 38021);
    }

    @Test
    public void test7620() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7620");
        int int2 = sum.Toplama.sum(27286, 18780);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46066 + "'", int2 == 46066);
    }

    @Test
    public void test7621() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7621");
        int int2 = sum.Toplama.sum(67518, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67518 + "'", int2 == 67518);
    }

    @Test
    public void test7622() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7622");
        int int2 = sum.Toplama.sum(27297, 50998);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78295 + "'", int2 == 78295);
    }

    @Test
    public void test7623() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7623");
        int int2 = sum.Toplama.sum(33680, 20385);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54065 + "'", int2 == 54065);
    }

    @Test
    public void test7624() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7624");
        int int2 = sum.Toplama.sum(724, 3197);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3921 + "'", int2 == 3921);
    }

    @Test
    public void test7625() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7625");
        int int2 = sum.Toplama.sum(27353, 78806);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 106159 + "'", int2 == 106159);
    }

    @Test
    public void test7626() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7626");
        int int2 = sum.Toplama.sum(0, 10505);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10505 + "'", int2 == 10505);
    }

    @Test
    public void test7627() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7627");
        int int2 = sum.Toplama.sum(4668, 30279);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34947 + "'", int2 == 34947);
    }

    @Test
    public void test7628() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7628");
        int int2 = sum.Toplama.sum(30369, 5409);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35778 + "'", int2 == 35778);
    }

    @Test
    public void test7629() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7629");
        int int2 = sum.Toplama.sum(87273, 3670);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90943 + "'", int2 == 90943);
    }

    @Test
    public void test7630() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7630");
        int int2 = sum.Toplama.sum(11790, 26215);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38005 + "'", int2 == 38005);
    }

    @Test
    public void test7631() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7631");
        int int2 = sum.Toplama.sum(35870, 9058);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44928 + "'", int2 == 44928);
    }

    @Test
    public void test7632() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7632");
        int int2 = sum.Toplama.sum(40328, 11007);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51335 + "'", int2 == 51335);
    }

    @Test
    public void test7633() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7633");
        int int2 = sum.Toplama.sum(52348, 45502);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97850 + "'", int2 == 97850);
    }

    @Test
    public void test7634() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7634");
        int int2 = sum.Toplama.sum(11388, 14963);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26351 + "'", int2 == 26351);
    }

    @Test
    public void test7635() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7635");
        int int2 = sum.Toplama.sum(6152, 449);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6601 + "'", int2 == 6601);
    }

    @Test
    public void test7636() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7636");
        int int2 = sum.Toplama.sum(25055, 6954);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32009 + "'", int2 == 32009);
    }

    @Test
    public void test7637() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7637");
        int int2 = sum.Toplama.sum(5305, 48455);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53760 + "'", int2 == 53760);
    }

    @Test
    public void test7638() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7638");
        int int2 = sum.Toplama.sum(14500, 17945);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32445 + "'", int2 == 32445);
    }

    @Test
    public void test7639() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7639");
        int int2 = sum.Toplama.sum(22705, 18440);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41145 + "'", int2 == 41145);
    }

    @Test
    public void test7640() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7640");
        int int2 = sum.Toplama.sum(18820, 5032);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23852 + "'", int2 == 23852);
    }

    @Test
    public void test7641() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7641");
        int int2 = sum.Toplama.sum(19915, 26884);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46799 + "'", int2 == 46799);
    }

    @Test
    public void test7642() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7642");
        int int2 = sum.Toplama.sum(28667, 36987);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 65654 + "'", int2 == 65654);
    }

    @Test
    public void test7643() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7643");
        int int2 = sum.Toplama.sum(10904, 44475);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55379 + "'", int2 == 55379);
    }

    @Test
    public void test7644() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7644");
        int int2 = sum.Toplama.sum(38597, 9171);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47768 + "'", int2 == 47768);
    }

    @Test
    public void test7645() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7645");
        int int2 = sum.Toplama.sum(26714, 3593);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30307 + "'", int2 == 30307);
    }

    @Test
    public void test7646() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7646");
        int int2 = sum.Toplama.sum(16848, 8952);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25800 + "'", int2 == 25800);
    }

    @Test
    public void test7647() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7647");
        int int2 = sum.Toplama.sum(48049, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48049 + "'", int2 == 48049);
    }

    @Test
    public void test7648() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7648");
        int int2 = sum.Toplama.sum(22549, 6239);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28788 + "'", int2 == 28788);
    }

    @Test
    public void test7649() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7649");
        int int2 = sum.Toplama.sum(0, 29634);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29634 + "'", int2 == 29634);
    }

    @Test
    public void test7650() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7650");
        int int2 = sum.Toplama.sum(21379, 26490);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47869 + "'", int2 == 47869);
    }

    @Test
    public void test7651() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7651");
        int int2 = sum.Toplama.sum(34316, 26351);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60667 + "'", int2 == 60667);
    }

    @Test
    public void test7652() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7652");
        int int2 = sum.Toplama.sum(29250, 9473);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38723 + "'", int2 == 38723);
    }

    @Test
    public void test7653() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7653");
        int int2 = sum.Toplama.sum(18876, 62982);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 81858 + "'", int2 == 81858);
    }

    @Test
    public void test7654() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7654");
        int int2 = sum.Toplama.sum(9670, 45040);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54710 + "'", int2 == 54710);
    }

    @Test
    public void test7655() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7655");
        int int2 = sum.Toplama.sum(4229, 4704);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8933 + "'", int2 == 8933);
    }

    @Test
    public void test7656() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7656");
        int int2 = sum.Toplama.sum(40010, 17073);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57083 + "'", int2 == 57083);
    }

    @Test
    public void test7657() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7657");
        int int2 = sum.Toplama.sum(127445, 8767);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 136212 + "'", int2 == 136212);
    }

    @Test
    public void test7658() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7658");
        int int2 = sum.Toplama.sum(25546, 18166);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43712 + "'", int2 == 43712);
    }

    @Test
    public void test7659() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7659");
        int int2 = sum.Toplama.sum(54017, 37588);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 91605 + "'", int2 == 91605);
    }

    @Test
    public void test7660() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7660");
        int int2 = sum.Toplama.sum(34321, 1958);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36279 + "'", int2 == 36279);
    }

    @Test
    public void test7661() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7661");
        int int2 = sum.Toplama.sum(27555, 17530);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45085 + "'", int2 == 45085);
    }

    @Test
    public void test7662() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7662");
        int int2 = sum.Toplama.sum(34537, 1005);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35542 + "'", int2 == 35542);
    }

    @Test
    public void test7663() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7663");
        int int2 = sum.Toplama.sum(7224, 82936);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90160 + "'", int2 == 90160);
    }

    @Test
    public void test7664() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7664");
        int int2 = sum.Toplama.sum(44095, 40904);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 84999 + "'", int2 == 84999);
    }

    @Test
    public void test7665() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7665");
        int int2 = sum.Toplama.sum(31087, 39294);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70381 + "'", int2 == 70381);
    }

    @Test
    public void test7666() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7666");
        int int2 = sum.Toplama.sum(20132, 13657);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33789 + "'", int2 == 33789);
    }

    @Test
    public void test7667() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7667");
        int int2 = sum.Toplama.sum(118627, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 118627 + "'", int2 == 118627);
    }

    @Test
    public void test7668() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7668");
        int int2 = sum.Toplama.sum(46676, 148673);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 195349 + "'", int2 == 195349);
    }

    @Test
    public void test7669() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7669");
        int int2 = sum.Toplama.sum(15180, 13088);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28268 + "'", int2 == 28268);
    }

    @Test
    public void test7670() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7670");
        int int2 = sum.Toplama.sum(3310, 1171);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4481 + "'", int2 == 4481);
    }

    @Test
    public void test7671() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7671");
        int int2 = sum.Toplama.sum(24033, 25740);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49773 + "'", int2 == 49773);
    }

    @Test
    public void test7672() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7672");
        int int2 = sum.Toplama.sum(17361, 8424);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25785 + "'", int2 == 25785);
    }

    @Test
    public void test7673() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7673");
        int int2 = sum.Toplama.sum(14340, 1943);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16283 + "'", int2 == 16283);
    }

    @Test
    public void test7674() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7674");
        int int2 = sum.Toplama.sum(51045, 12994);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64039 + "'", int2 == 64039);
    }

    @Test
    public void test7675() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7675");
        int int2 = sum.Toplama.sum(8532, 27198);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35730 + "'", int2 == 35730);
    }

    @Test
    public void test7676() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7676");
        int int2 = sum.Toplama.sum(369, 39523);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39892 + "'", int2 == 39892);
    }

    @Test
    public void test7677() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7677");
        int int2 = sum.Toplama.sum(0, 51423);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51423 + "'", int2 == 51423);
    }

    @Test
    public void test7678() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7678");
        int int2 = sum.Toplama.sum(21540, 13652);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35192 + "'", int2 == 35192);
    }

    @Test
    public void test7679() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7679");
        int int2 = sum.Toplama.sum(464, 31601);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32065 + "'", int2 == 32065);
    }

    @Test
    public void test7680() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7680");
        int int2 = sum.Toplama.sum(8402, 5807);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14209 + "'", int2 == 14209);
    }

    @Test
    public void test7681() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7681");
        int int2 = sum.Toplama.sum(20161, 9607);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29768 + "'", int2 == 29768);
    }

    @Test
    public void test7682() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7682");
        int int2 = sum.Toplama.sum(59789, 21031);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80820 + "'", int2 == 80820);
    }

    @Test
    public void test7683() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7683");
        int int2 = sum.Toplama.sum(16914, 1960);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18874 + "'", int2 == 18874);
    }

    @Test
    public void test7684() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7684");
        int int2 = sum.Toplama.sum(12635, 13389);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26024 + "'", int2 == 26024);
    }

    @Test
    public void test7685() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7685");
        int int2 = sum.Toplama.sum(6768, 17343);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24111 + "'", int2 == 24111);
    }

    @Test
    public void test7686() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7686");
        int int2 = sum.Toplama.sum(6038, 6931);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12969 + "'", int2 == 12969);
    }

    @Test
    public void test7687() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7687");
        int int2 = sum.Toplama.sum(49174, 21574);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70748 + "'", int2 == 70748);
    }

    @Test
    public void test7688() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7688");
        int int2 = sum.Toplama.sum(34977, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34977 + "'", int2 == 34977);
    }

    @Test
    public void test7689() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7689");
        int int2 = sum.Toplama.sum(40519, 1005);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41524 + "'", int2 == 41524);
    }

    @Test
    public void test7690() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7690");
        int int2 = sum.Toplama.sum(5030, 7397);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12427 + "'", int2 == 12427);
    }

    @Test
    public void test7691() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7691");
        int int2 = sum.Toplama.sum(41794, 32449);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 74243 + "'", int2 == 74243);
    }

    @Test
    public void test7692() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7692");
        int int2 = sum.Toplama.sum(5125, 2897);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8022 + "'", int2 == 8022);
    }

    @Test
    public void test7693() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7693");
        int int2 = sum.Toplama.sum(40194, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40194 + "'", int2 == 40194);
    }

    @Test
    public void test7694() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7694");
        int int2 = sum.Toplama.sum(657, 413);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1070 + "'", int2 == 1070);
    }

    @Test
    public void test7695() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7695");
        int int2 = sum.Toplama.sum(94265, 74852);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 169117 + "'", int2 == 169117);
    }

    @Test
    public void test7696() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7696");
        int int2 = sum.Toplama.sum(44842, 1203);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46045 + "'", int2 == 46045);
    }

    @Test
    public void test7697() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7697");
        int int2 = sum.Toplama.sum(10696, 6453);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17149 + "'", int2 == 17149);
    }

    @Test
    public void test7698() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7698");
        int int2 = sum.Toplama.sum(0, 50556);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50556 + "'", int2 == 50556);
    }

    @Test
    public void test7699() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7699");
        int int2 = sum.Toplama.sum(4246, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4246 + "'", int2 == 4246);
    }

    @Test
    public void test7700() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7700");
        int int2 = sum.Toplama.sum(17480, 24887);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42367 + "'", int2 == 42367);
    }

    @Test
    public void test7701() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7701");
        int int2 = sum.Toplama.sum(22667, 73634);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96301 + "'", int2 == 96301);
    }

    @Test
    public void test7702() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7702");
        int int2 = sum.Toplama.sum(99053, 18496);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 117549 + "'", int2 == 117549);
    }

    @Test
    public void test7703() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7703");
        int int2 = sum.Toplama.sum(32587, 49155);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 81742 + "'", int2 == 81742);
    }

    @Test
    public void test7704() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7704");
        int int2 = sum.Toplama.sum(8752, 14500);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23252 + "'", int2 == 23252);
    }

    @Test
    public void test7705() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7705");
        int int2 = sum.Toplama.sum(0, 57629);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57629 + "'", int2 == 57629);
    }

    @Test
    public void test7706() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7706");
        int int2 = sum.Toplama.sum(0, 24238);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24238 + "'", int2 == 24238);
    }

    @Test
    public void test7707() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7707");
        int int2 = sum.Toplama.sum(88606, 40229);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 128835 + "'", int2 == 128835);
    }

    @Test
    public void test7708() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7708");
        int int2 = sum.Toplama.sum(21496, 9745);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31241 + "'", int2 == 31241);
    }

    @Test
    public void test7709() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7709");
        int int2 = sum.Toplama.sum(48523, 87106);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 135629 + "'", int2 == 135629);
    }

    @Test
    public void test7710() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7710");
        int int2 = sum.Toplama.sum(5901, 2741);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8642 + "'", int2 == 8642);
    }

    @Test
    public void test7711() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7711");
        int int2 = sum.Toplama.sum(14487, 11992);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26479 + "'", int2 == 26479);
    }

    @Test
    public void test7712() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7712");
        int int2 = sum.Toplama.sum(3051, 149);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3200 + "'", int2 == 3200);
    }

    @Test
    public void test7713() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7713");
        int int2 = sum.Toplama.sum(12245, 4564);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16809 + "'", int2 == 16809);
    }

    @Test
    public void test7714() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7714");
        int int2 = sum.Toplama.sum(21058, 54508);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 75566 + "'", int2 == 75566);
    }

    @Test
    public void test7715() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7715");
        int int2 = sum.Toplama.sum(22134, 41044);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63178 + "'", int2 == 63178);
    }

    @Test
    public void test7716() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7716");
        int int2 = sum.Toplama.sum(4827, 24489);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29316 + "'", int2 == 29316);
    }

    @Test
    public void test7717() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7717");
        int int2 = sum.Toplama.sum(35859, 18656);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54515 + "'", int2 == 54515);
    }

    @Test
    public void test7718() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7718");
        int int2 = sum.Toplama.sum(11364, 51953);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63317 + "'", int2 == 63317);
    }

    @Test
    public void test7719() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7719");
        int int2 = sum.Toplama.sum(61210, 10332);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 71542 + "'", int2 == 71542);
    }

    @Test
    public void test7720() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7720");
        int int2 = sum.Toplama.sum(23655, 10305);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33960 + "'", int2 == 33960);
    }

    @Test
    public void test7721() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7721");
        int int2 = sum.Toplama.sum(35990, 148344);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 184334 + "'", int2 == 184334);
    }

    @Test
    public void test7722() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7722");
        int int2 = sum.Toplama.sum(26383, 34768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61151 + "'", int2 == 61151);
    }

    @Test
    public void test7723() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7723");
        int int2 = sum.Toplama.sum(2932, 122742);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 125674 + "'", int2 == 125674);
    }

    @Test
    public void test7724() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7724");
        int int2 = sum.Toplama.sum(17401, 84768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 102169 + "'", int2 == 102169);
    }

    @Test
    public void test7725() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7725");
        int int2 = sum.Toplama.sum(282, 6971);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7253 + "'", int2 == 7253);
    }

    @Test
    public void test7726() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7726");
        int int2 = sum.Toplama.sum(48218, 293);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48511 + "'", int2 == 48511);
    }

    @Test
    public void test7727() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7727");
        int int2 = sum.Toplama.sum(20088, 63317);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 83405 + "'", int2 == 83405);
    }

    @Test
    public void test7728() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7728");
        int int2 = sum.Toplama.sum(5069, 8922);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13991 + "'", int2 == 13991);
    }

    @Test
    public void test7729() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7729");
        int int2 = sum.Toplama.sum(13182, 27821);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41003 + "'", int2 == 41003);
    }

    @Test
    public void test7730() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7730");
        int int2 = sum.Toplama.sum(7272, 17307);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24579 + "'", int2 == 24579);
    }

    @Test
    public void test7731() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7731");
        int int2 = sum.Toplama.sum(3027, 43174);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46201 + "'", int2 == 46201);
    }

    @Test
    public void test7732() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7732");
        int int2 = sum.Toplama.sum(17384, 41810);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59194 + "'", int2 == 59194);
    }

    @Test
    public void test7733() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7733");
        int int2 = sum.Toplama.sum(12472, 23766);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36238 + "'", int2 == 36238);
    }

    @Test
    public void test7734() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7734");
        int int2 = sum.Toplama.sum(2343, 12328);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14671 + "'", int2 == 14671);
    }

    @Test
    public void test7735() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7735");
        int int2 = sum.Toplama.sum(6124, 11836);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17960 + "'", int2 == 17960);
    }

    @Test
    public void test7736() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7736");
        int int2 = sum.Toplama.sum(33513, 15601);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49114 + "'", int2 == 49114);
    }

    @Test
    public void test7737() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7737");
        int int2 = sum.Toplama.sum(31047, 43222);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 74269 + "'", int2 == 74269);
    }

    @Test
    public void test7738() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7738");
        int int2 = sum.Toplama.sum(11650, 11824);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23474 + "'", int2 == 23474);
    }

    @Test
    public void test7739() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7739");
        int int2 = sum.Toplama.sum(0, 26367);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26367 + "'", int2 == 26367);
    }

    @Test
    public void test7740() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7740");
        int int2 = sum.Toplama.sum(45165, 28762);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 73927 + "'", int2 == 73927);
    }

    @Test
    public void test7741() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7741");
        int int2 = sum.Toplama.sum(0, 33785);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33785 + "'", int2 == 33785);
    }

    @Test
    public void test7742() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7742");
        int int2 = sum.Toplama.sum(0, 9120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9120 + "'", int2 == 9120);
    }

    @Test
    public void test7743() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7743");
        int int2 = sum.Toplama.sum(8464, 77692);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 86156 + "'", int2 == 86156);
    }

    @Test
    public void test7744() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7744");
        int int2 = sum.Toplama.sum(31301, 1412);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32713 + "'", int2 == 32713);
    }

    @Test
    public void test7745() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7745");
        int int2 = sum.Toplama.sum(3038, 33631);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36669 + "'", int2 == 36669);
    }

    @Test
    public void test7746() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7746");
        int int2 = sum.Toplama.sum(9026, 654);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9680 + "'", int2 == 9680);
    }

    @Test
    public void test7747() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7747");
        int int2 = sum.Toplama.sum(53479, 21808);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 75287 + "'", int2 == 75287);
    }

    @Test
    public void test7748() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7748");
        int int2 = sum.Toplama.sum(19731, 459);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20190 + "'", int2 == 20190);
    }

    @Test
    public void test7749() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7749");
        int int2 = sum.Toplama.sum(13657, 23473);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37130 + "'", int2 == 37130);
    }

    @Test
    public void test7750() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7750");
        int int2 = sum.Toplama.sum(54594, 67258);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 121852 + "'", int2 == 121852);
    }

    @Test
    public void test7751() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7751");
        int int2 = sum.Toplama.sum(9310, 55993);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 65303 + "'", int2 == 65303);
    }

    @Test
    public void test7752() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7752");
        int int2 = sum.Toplama.sum(28560, 3258);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31818 + "'", int2 == 31818);
    }

    @Test
    public void test7753() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7753");
        int int2 = sum.Toplama.sum(12663, 34475);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47138 + "'", int2 == 47138);
    }

    @Test
    public void test7754() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7754");
        int int2 = sum.Toplama.sum(10762, 25473);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36235 + "'", int2 == 36235);
    }

    @Test
    public void test7755() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7755");
        int int2 = sum.Toplama.sum(0, 107183);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 107183 + "'", int2 == 107183);
    }

    @Test
    public void test7756() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7756");
        int int2 = sum.Toplama.sum(4653, 41734);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46387 + "'", int2 == 46387);
    }

    @Test
    public void test7757() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7757");
        int int2 = sum.Toplama.sum(31636, 37686);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69322 + "'", int2 == 69322);
    }

    @Test
    public void test7758() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7758");
        int int2 = sum.Toplama.sum(5808, 2932);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8740 + "'", int2 == 8740);
    }

    @Test
    public void test7759() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7759");
        int int2 = sum.Toplama.sum(20777, 22314);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43091 + "'", int2 == 43091);
    }

    @Test
    public void test7760() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7760");
        int int2 = sum.Toplama.sum(78091, 10952);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 89043 + "'", int2 == 89043);
    }

    @Test
    public void test7761() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7761");
        int int2 = sum.Toplama.sum(6659, 36772);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43431 + "'", int2 == 43431);
    }

    @Test
    public void test7762() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7762");
        int int2 = sum.Toplama.sum(10020, 13992);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24012 + "'", int2 == 24012);
    }

    @Test
    public void test7763() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7763");
        int int2 = sum.Toplama.sum(44347, 23473);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67820 + "'", int2 == 67820);
    }

    @Test
    public void test7764() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7764");
        int int2 = sum.Toplama.sum(108038, 5621);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 113659 + "'", int2 == 113659);
    }

    @Test
    public void test7765() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7765");
        int int2 = sum.Toplama.sum(33701, 34424);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68125 + "'", int2 == 68125);
    }

    @Test
    public void test7766() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7766");
        int int2 = sum.Toplama.sum(28828, 8219);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37047 + "'", int2 == 37047);
    }

    @Test
    public void test7767() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7767");
        int int2 = sum.Toplama.sum(2527, 16195);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18722 + "'", int2 == 18722);
    }

    @Test
    public void test7768() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7768");
        int int2 = sum.Toplama.sum(39969, 65998);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 105967 + "'", int2 == 105967);
    }

    @Test
    public void test7769() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7769");
        int int2 = sum.Toplama.sum(28678, 4337);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33015 + "'", int2 == 33015);
    }

    @Test
    public void test7770() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7770");
        int int2 = sum.Toplama.sum(6058, 34480);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40538 + "'", int2 == 40538);
    }

    @Test
    public void test7771() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7771");
        int int2 = sum.Toplama.sum(13389, 22219);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35608 + "'", int2 == 35608);
    }

    @Test
    public void test7772() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7772");
        int int2 = sum.Toplama.sum(1139, 18780);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19919 + "'", int2 == 19919);
    }

    @Test
    public void test7773() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7773");
        int int2 = sum.Toplama.sum(4179, 3791);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7970 + "'", int2 == 7970);
    }

    @Test
    public void test7774() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7774");
        int int2 = sum.Toplama.sum(9577, 197);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9774 + "'", int2 == 9774);
    }

    @Test
    public void test7775() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7775");
        int int2 = sum.Toplama.sum(7642, 38292);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45934 + "'", int2 == 45934);
    }

    @Test
    public void test7776() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7776");
        int int2 = sum.Toplama.sum(21207, 10950);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32157 + "'", int2 == 32157);
    }

    @Test
    public void test7777() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7777");
        int int2 = sum.Toplama.sum(8002, 34310);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42312 + "'", int2 == 42312);
    }

    @Test
    public void test7778() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7778");
        int int2 = sum.Toplama.sum(10270, 63495);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 73765 + "'", int2 == 73765);
    }

    @Test
    public void test7779() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7779");
        int int2 = sum.Toplama.sum(6017, 11263);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17280 + "'", int2 == 17280);
    }

    @Test
    public void test7780() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7780");
        int int2 = sum.Toplama.sum(43508, 13780);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57288 + "'", int2 == 57288);
    }

    @Test
    public void test7781() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7781");
        int int2 = sum.Toplama.sum(1476, 9952);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11428 + "'", int2 == 11428);
    }

    @Test
    public void test7782() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7782");
        int int2 = sum.Toplama.sum(102678, 10701);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 113379 + "'", int2 == 113379);
    }

    @Test
    public void test7783() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7783");
        int int2 = sum.Toplama.sum(13199, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13199 + "'", int2 == 13199);
    }

    @Test
    public void test7784() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7784");
        int int2 = sum.Toplama.sum(11184, 44155);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55339 + "'", int2 == 55339);
    }

    @Test
    public void test7785() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7785");
        int int2 = sum.Toplama.sum(6635, 485);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7120 + "'", int2 == 7120);
    }

    @Test
    public void test7786() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7786");
        int int2 = sum.Toplama.sum(13722, 20422);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34144 + "'", int2 == 34144);
    }

    @Test
    public void test7787() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7787");
        int int2 = sum.Toplama.sum(56032, 82425);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 138457 + "'", int2 == 138457);
    }

    @Test
    public void test7788() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7788");
        int int2 = sum.Toplama.sum(38155, 9205);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47360 + "'", int2 == 47360);
    }

    @Test
    public void test7789() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7789");
        int int2 = sum.Toplama.sum(19595, 14068);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33663 + "'", int2 == 33663);
    }

    @Test
    public void test7790() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7790");
        int int2 = sum.Toplama.sum(32713, 36345);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69058 + "'", int2 == 69058);
    }

    @Test
    public void test7791() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7791");
        int int2 = sum.Toplama.sum(14566, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14566 + "'", int2 == 14566);
    }

    @Test
    public void test7792() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7792");
        int int2 = sum.Toplama.sum(51339, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51339 + "'", int2 == 51339);
    }

    @Test
    public void test7793() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7793");
        int int2 = sum.Toplama.sum(10940, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10940 + "'", int2 == 10940);
    }

    @Test
    public void test7794() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7794");
        int int2 = sum.Toplama.sum(51208, 5732);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56940 + "'", int2 == 56940);
    }

    @Test
    public void test7795() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7795");
        int int2 = sum.Toplama.sum(5530, 24466);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29996 + "'", int2 == 29996);
    }

    @Test
    public void test7796() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7796");
        int int2 = sum.Toplama.sum(2103, 41742);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43845 + "'", int2 == 43845);
    }

    @Test
    public void test7797() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7797");
        int int2 = sum.Toplama.sum(12227, 21065);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33292 + "'", int2 == 33292);
    }

    @Test
    public void test7798() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7798");
        int int2 = sum.Toplama.sum(29485, 45471);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 74956 + "'", int2 == 74956);
    }

    @Test
    public void test7799() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7799");
        int int2 = sum.Toplama.sum(44703, 49764);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 94467 + "'", int2 == 94467);
    }

    @Test
    public void test7800() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7800");
        int int2 = sum.Toplama.sum(3669, 8673);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12342 + "'", int2 == 12342);
    }

    @Test
    public void test7801() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7801");
        int int2 = sum.Toplama.sum(10821, 9603);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20424 + "'", int2 == 20424);
    }

    @Test
    public void test7802() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7802");
        int int2 = sum.Toplama.sum(8351, 8228);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16579 + "'", int2 == 16579);
    }

    @Test
    public void test7803() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7803");
        int int2 = sum.Toplama.sum(369, 23572);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23941 + "'", int2 == 23941);
    }

    @Test
    public void test7804() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7804");
        int int2 = sum.Toplama.sum(4847, 49321);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54168 + "'", int2 == 54168);
    }

    @Test
    public void test7805() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7805");
        int int2 = sum.Toplama.sum(63097, 36949);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100046 + "'", int2 == 100046);
    }

    @Test
    public void test7806() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7806");
        int int2 = sum.Toplama.sum(64477, 11219);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 75696 + "'", int2 == 75696);
    }

    @Test
    public void test7807() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7807");
        int int2 = sum.Toplama.sum(36061, 18115);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54176 + "'", int2 == 54176);
    }

    @Test
    public void test7808() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7808");
        int int2 = sum.Toplama.sum(20869, 1570);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22439 + "'", int2 == 22439);
    }

    @Test
    public void test7809() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7809");
        int int2 = sum.Toplama.sum(5305, 37590);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42895 + "'", int2 == 42895);
    }

    @Test
    public void test7810() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7810");
        int int2 = sum.Toplama.sum(7817, 40680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48497 + "'", int2 == 48497);
    }

    @Test
    public void test7811() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7811");
        int int2 = sum.Toplama.sum(25913, 19808);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45721 + "'", int2 == 45721);
    }

    @Test
    public void test7812() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7812");
        int int2 = sum.Toplama.sum(25473, 6861);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32334 + "'", int2 == 32334);
    }

    @Test
    public void test7813() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7813");
        int int2 = sum.Toplama.sum(2821, 1976);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4797 + "'", int2 == 4797);
    }

    @Test
    public void test7814() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7814");
        int int2 = sum.Toplama.sum(42411, 19841);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62252 + "'", int2 == 62252);
    }

    @Test
    public void test7815() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7815");
        int int2 = sum.Toplama.sum(2958, 34848);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37806 + "'", int2 == 37806);
    }

    @Test
    public void test7816() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7816");
        int int2 = sum.Toplama.sum(48219, 21275);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69494 + "'", int2 == 69494);
    }

    @Test
    public void test7817() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7817");
        int int2 = sum.Toplama.sum(6305, 195632);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 201937 + "'", int2 == 201937);
    }

    @Test
    public void test7818() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7818");
        int int2 = sum.Toplama.sum(2846, 26296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29142 + "'", int2 == 29142);
    }

    @Test
    public void test7819() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7819");
        int int2 = sum.Toplama.sum(5012, 6092);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11104 + "'", int2 == 11104);
    }

    @Test
    public void test7820() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7820");
        int int2 = sum.Toplama.sum(814, 12887);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13701 + "'", int2 == 13701);
    }

    @Test
    public void test7821() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7821");
        int int2 = sum.Toplama.sum(1840, 32370);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34210 + "'", int2 == 34210);
    }

    @Test
    public void test7822() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7822");
        int int2 = sum.Toplama.sum(44099, 56184);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100283 + "'", int2 == 100283);
    }

    @Test
    public void test7823() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7823");
        int int2 = sum.Toplama.sum(14437, 27349);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41786 + "'", int2 == 41786);
    }

    @Test
    public void test7824() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7824");
        int int2 = sum.Toplama.sum(25631, 746);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26377 + "'", int2 == 26377);
    }

    @Test
    public void test7825() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7825");
        int int2 = sum.Toplama.sum(14556, 39730);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54286 + "'", int2 == 54286);
    }

    @Test
    public void test7826() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7826");
        int int2 = sum.Toplama.sum(49372, 59712);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 109084 + "'", int2 == 109084);
    }

    @Test
    public void test7827() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7827");
        int int2 = sum.Toplama.sum(65143, 43233);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 108376 + "'", int2 == 108376);
    }

    @Test
    public void test7828() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7828");
        int int2 = sum.Toplama.sum(4916, 4299);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9215 + "'", int2 == 9215);
    }

    @Test
    public void test7829() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7829");
        int int2 = sum.Toplama.sum(20505, 3274);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23779 + "'", int2 == 23779);
    }

    @Test
    public void test7830() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7830");
        int int2 = sum.Toplama.sum(15337, 8870);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24207 + "'", int2 == 24207);
    }

    @Test
    public void test7831() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7831");
        int int2 = sum.Toplama.sum(37822, 7996);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45818 + "'", int2 == 45818);
    }

    @Test
    public void test7832() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7832");
        int int2 = sum.Toplama.sum(24087, 557);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24644 + "'", int2 == 24644);
    }

    @Test
    public void test7833() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7833");
        int int2 = sum.Toplama.sum(19606, 4311);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23917 + "'", int2 == 23917);
    }

    @Test
    public void test7834() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7834");
        int int2 = sum.Toplama.sum(72510, 3314);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 75824 + "'", int2 == 75824);
    }

    @Test
    public void test7835() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7835");
        int int2 = sum.Toplama.sum(39625, 52439);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 92064 + "'", int2 == 92064);
    }

    @Test
    public void test7836() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7836");
        int int2 = sum.Toplama.sum(17836, 18496);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36332 + "'", int2 == 36332);
    }

    @Test
    public void test7837() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7837");
        int int2 = sum.Toplama.sum(1101, 25193);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26294 + "'", int2 == 26294);
    }

    @Test
    public void test7838() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7838");
        int int2 = sum.Toplama.sum(25742, 1167);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26909 + "'", int2 == 26909);
    }

    @Test
    public void test7839() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7839");
        int int2 = sum.Toplama.sum(75957, 7568);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 83525 + "'", int2 == 83525);
    }

    @Test
    public void test7840() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7840");
        int int2 = sum.Toplama.sum(413, 4025);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4438 + "'", int2 == 4438);
    }

    @Test
    public void test7841() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7841");
        int int2 = sum.Toplama.sum(10795, 2923);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13718 + "'", int2 == 13718);
    }

    @Test
    public void test7842() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7842");
        int int2 = sum.Toplama.sum(18038, 95689);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 113727 + "'", int2 == 113727);
    }

    @Test
    public void test7843() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7843");
        int int2 = sum.Toplama.sum(52952, 53023);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 105975 + "'", int2 == 105975);
    }

    @Test
    public void test7844() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7844");
        int int2 = sum.Toplama.sum(2215, 954);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3169 + "'", int2 == 3169);
    }

    @Test
    public void test7845() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7845");
        int int2 = sum.Toplama.sum(0, 8738);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8738 + "'", int2 == 8738);
    }

    @Test
    public void test7846() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7846");
        int int2 = sum.Toplama.sum(0, 29725);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29725 + "'", int2 == 29725);
    }

    @Test
    public void test7847() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7847");
        int int2 = sum.Toplama.sum(9119, 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9128 + "'", int2 == 9128);
    }

    @Test
    public void test7848() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7848");
        int int2 = sum.Toplama.sum(11534, 6466);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18000 + "'", int2 == 18000);
    }

    @Test
    public void test7849() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7849");
        int int2 = sum.Toplama.sum(5028, 42557);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47585 + "'", int2 == 47585);
    }

    @Test
    public void test7850() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7850");
        int int2 = sum.Toplama.sum(13737, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13737 + "'", int2 == 13737);
    }

    @Test
    public void test7851() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7851");
        int int2 = sum.Toplama.sum(5973, 23524);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29497 + "'", int2 == 29497);
    }

    @Test
    public void test7852() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7852");
        int int2 = sum.Toplama.sum(86816, 1121);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 87937 + "'", int2 == 87937);
    }

    @Test
    public void test7853() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7853");
        int int2 = sum.Toplama.sum(300, 2556);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2856 + "'", int2 == 2856);
    }

    @Test
    public void test7854() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7854");
        int int2 = sum.Toplama.sum(75931, 59186);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 135117 + "'", int2 == 135117);
    }

    @Test
    public void test7855() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7855");
        int int2 = sum.Toplama.sum(12767, 95914);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 108681 + "'", int2 == 108681);
    }

    @Test
    public void test7856() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7856");
        int int2 = sum.Toplama.sum(746, 4446);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5192 + "'", int2 == 5192);
    }

    @Test
    public void test7857() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7857");
        int int2 = sum.Toplama.sum(44700, 35642);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80342 + "'", int2 == 80342);
    }

    @Test
    public void test7858() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7858");
        int int2 = sum.Toplama.sum(43313, 59792);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 103105 + "'", int2 == 103105);
    }

    @Test
    public void test7859() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7859");
        int int2 = sum.Toplama.sum(73765, 22219);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 95984 + "'", int2 == 95984);
    }

    @Test
    public void test7860() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7860");
        int int2 = sum.Toplama.sum(8120, 22600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30720 + "'", int2 == 30720);
    }

    @Test
    public void test7861() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7861");
        int int2 = sum.Toplama.sum(47349, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47349 + "'", int2 == 47349);
    }

    @Test
    public void test7862() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7862");
        int int2 = sum.Toplama.sum(3301, 28619);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31920 + "'", int2 == 31920);
    }

    @Test
    public void test7863() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7863");
        int int2 = sum.Toplama.sum(0, 3920);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3920 + "'", int2 == 3920);
    }

    @Test
    public void test7864() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7864");
        int int2 = sum.Toplama.sum(1417, 889);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2306 + "'", int2 == 2306);
    }

    @Test
    public void test7865() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7865");
        int int2 = sum.Toplama.sum(77449, 11191);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 88640 + "'", int2 == 88640);
    }

    @Test
    public void test7866() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7866");
        int int2 = sum.Toplama.sum(22021, 41107);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63128 + "'", int2 == 63128);
    }

    @Test
    public void test7867() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7867");
        int int2 = sum.Toplama.sum(3990, 28560);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32550 + "'", int2 == 32550);
    }

    @Test
    public void test7868() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7868");
        int int2 = sum.Toplama.sum(52950, 99490);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 152440 + "'", int2 == 152440);
    }

    @Test
    public void test7869() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7869");
        int int2 = sum.Toplama.sum(8566, 72206);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80772 + "'", int2 == 80772);
    }

    @Test
    public void test7870() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7870");
        int int2 = sum.Toplama.sum(44705, 6642);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51347 + "'", int2 == 51347);
    }

    @Test
    public void test7871() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7871");
        int int2 = sum.Toplama.sum(8442, 3541);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11983 + "'", int2 == 11983);
    }

    @Test
    public void test7872() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7872");
        int int2 = sum.Toplama.sum(39635, 14422);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54057 + "'", int2 == 54057);
    }

    @Test
    public void test7873() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7873");
        int int2 = sum.Toplama.sum(12309, 1943);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14252 + "'", int2 == 14252);
    }

    @Test
    public void test7874() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7874");
        int int2 = sum.Toplama.sum(21058, 62252);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 83310 + "'", int2 == 83310);
    }

    @Test
    public void test7875() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7875");
        int int2 = sum.Toplama.sum(8139, 5354);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13493 + "'", int2 == 13493);
    }

    @Test
    public void test7876() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7876");
        int int2 = sum.Toplama.sum(19606, 34512);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54118 + "'", int2 == 54118);
    }

    @Test
    public void test7877() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7877");
        int int2 = sum.Toplama.sum(3944, 44567);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48511 + "'", int2 == 48511);
    }

    @Test
    public void test7878() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7878");
        int int2 = sum.Toplama.sum(6551, 39528);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46079 + "'", int2 == 46079);
    }

    @Test
    public void test7879() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7879");
        int int2 = sum.Toplama.sum(2561, 33138);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35699 + "'", int2 == 35699);
    }

    @Test
    public void test7880() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7880");
        int int2 = sum.Toplama.sum(374, 9843);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10217 + "'", int2 == 10217);
    }

    @Test
    public void test7881() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7881");
        int int2 = sum.Toplama.sum(12337, 108681);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 121018 + "'", int2 == 121018);
    }

    @Test
    public void test7882() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7882");
        int int2 = sum.Toplama.sum(25825, 33513);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59338 + "'", int2 == 59338);
    }

    @Test
    public void test7883() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7883");
        int int2 = sum.Toplama.sum(3602, 18557);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22159 + "'", int2 == 22159);
    }

    @Test
    public void test7884() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7884");
        int int2 = sum.Toplama.sum(135629, 19026);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 154655 + "'", int2 == 154655);
    }

    @Test
    public void test7885() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7885");
        int int2 = sum.Toplama.sum(37142, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37142 + "'", int2 == 37142);
    }

    @Test
    public void test7886() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7886");
        int int2 = sum.Toplama.sum(33146, 52530);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 85676 + "'", int2 == 85676);
    }

    @Test
    public void test7887() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7887");
        int int2 = sum.Toplama.sum(0, 4055);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4055 + "'", int2 == 4055);
    }

    @Test
    public void test7888() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7888");
        int int2 = sum.Toplama.sum(18601, 125907);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 144508 + "'", int2 == 144508);
    }

    @Test
    public void test7889() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7889");
        int int2 = sum.Toplama.sum(30065, 67672);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97737 + "'", int2 == 97737);
    }

    @Test
    public void test7890() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7890");
        int int2 = sum.Toplama.sum(25631, 6188);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31819 + "'", int2 == 31819);
    }

    @Test
    public void test7891() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7891");
        int int2 = sum.Toplama.sum(9979, 80454);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90433 + "'", int2 == 90433);
    }

    @Test
    public void test7892() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7892");
        int int2 = sum.Toplama.sum(7065, 6659);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13724 + "'", int2 == 13724);
    }

    @Test
    public void test7893() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7893");
        int int2 = sum.Toplama.sum(23917, 9310);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33227 + "'", int2 == 33227);
    }

    @Test
    public void test7894() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7894");
        int int2 = sum.Toplama.sum(2523, 16222);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18745 + "'", int2 == 18745);
    }

    @Test
    public void test7895() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7895");
        int int2 = sum.Toplama.sum(35776, 5078);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40854 + "'", int2 == 40854);
    }

    @Test
    public void test7896() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7896");
        int int2 = sum.Toplama.sum(25130, 23563);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48693 + "'", int2 == 48693);
    }

    @Test
    public void test7897() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7897");
        int int2 = sum.Toplama.sum(0, 45278);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45278 + "'", int2 == 45278);
    }

    @Test
    public void test7898() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7898");
        int int2 = sum.Toplama.sum(48455, 23753);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72208 + "'", int2 == 72208);
    }

    @Test
    public void test7899() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7899");
        int int2 = sum.Toplama.sum(30830, 3933);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34763 + "'", int2 == 34763);
    }

    @Test
    public void test7900() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7900");
        int int2 = sum.Toplama.sum(6051, 34011);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40062 + "'", int2 == 40062);
    }

    @Test
    public void test7901() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7901");
        int int2 = sum.Toplama.sum(30821, 40328);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 71149 + "'", int2 == 71149);
    }

    @Test
    public void test7902() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7902");
        int int2 = sum.Toplama.sum(9986, 41992);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51978 + "'", int2 == 51978);
    }

    @Test
    public void test7903() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7903");
        int int2 = sum.Toplama.sum(4179, 19492);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23671 + "'", int2 == 23671);
    }

    @Test
    public void test7904() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7904");
        int int2 = sum.Toplama.sum(79981, 34316);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 114297 + "'", int2 == 114297);
    }

    @Test
    public void test7905() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7905");
        int int2 = sum.Toplama.sum(20854, 40897);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61751 + "'", int2 == 61751);
    }

    @Test
    public void test7906() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7906");
        int int2 = sum.Toplama.sum(0, 51134);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51134 + "'", int2 == 51134);
    }

    @Test
    public void test7907() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7907");
        int int2 = sum.Toplama.sum(30895, 14841);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45736 + "'", int2 == 45736);
    }

    @Test
    public void test7908() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7908");
        int int2 = sum.Toplama.sum(36041, 47361);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 83402 + "'", int2 == 83402);
    }

    @Test
    public void test7909() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7909");
        int int2 = sum.Toplama.sum(17631, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17631 + "'", int2 == 17631);
    }

    @Test
    public void test7910() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7910");
        int int2 = sum.Toplama.sum(25765, 9971);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35736 + "'", int2 == 35736);
    }

    @Test
    public void test7911() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7911");
        int int2 = sum.Toplama.sum(12454, 49950);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62404 + "'", int2 == 62404);
    }

    @Test
    public void test7912() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7912");
        int int2 = sum.Toplama.sum(4704, 19270);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23974 + "'", int2 == 23974);
    }

    @Test
    public void test7913() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7913");
        int int2 = sum.Toplama.sum(84334, 20869);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 105203 + "'", int2 == 105203);
    }

    @Test
    public void test7914() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7914");
        int int2 = sum.Toplama.sum(37526, 29504);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67030 + "'", int2 == 67030);
    }

    @Test
    public void test7915() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7915");
        int int2 = sum.Toplama.sum(28059, 1680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29739 + "'", int2 == 29739);
    }

    @Test
    public void test7916() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7916");
        int int2 = sum.Toplama.sum(30531, 21258);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51789 + "'", int2 == 51789);
    }

    @Test
    public void test7917() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7917");
        int int2 = sum.Toplama.sum(21738, 17094);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38832 + "'", int2 == 38832);
    }

    @Test
    public void test7918() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7918");
        int int2 = sum.Toplama.sum(15347, 61853);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 77200 + "'", int2 == 77200);
    }

    @Test
    public void test7919() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7919");
        int int2 = sum.Toplama.sum(46131, 79733);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 125864 + "'", int2 == 125864);
    }

    @Test
    public void test7920() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7920");
        int int2 = sum.Toplama.sum(9565, 21065);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30630 + "'", int2 == 30630);
    }

    @Test
    public void test7921() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7921");
        int int2 = sum.Toplama.sum(2162, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2162 + "'", int2 == 2162);
    }

    @Test
    public void test7922() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7922");
        int int2 = sum.Toplama.sum(55848, 8922);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64770 + "'", int2 == 64770);
    }

    @Test
    public void test7923() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7923");
        int int2 = sum.Toplama.sum(21244, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21244 + "'", int2 == 21244);
    }

    @Test
    public void test7924() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7924");
        int int2 = sum.Toplama.sum(954, 32489);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33443 + "'", int2 == 33443);
    }

    @Test
    public void test7925() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7925");
        int int2 = sum.Toplama.sum(9399, 17534);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26933 + "'", int2 == 26933);
    }

    @Test
    public void test7926() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7926");
        int int2 = sum.Toplama.sum(40061, 32260);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72321 + "'", int2 == 72321);
    }

    @Test
    public void test7927() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7927");
        int int2 = sum.Toplama.sum(17910, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17910 + "'", int2 == 17910);
    }

    @Test
    public void test7928() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7928");
        int int2 = sum.Toplama.sum(39101, 88415);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 127516 + "'", int2 == 127516);
    }

    @Test
    public void test7929() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7929");
        int int2 = sum.Toplama.sum(23872, 8317);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32189 + "'", int2 == 32189);
    }

    @Test
    public void test7930() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7930");
        int int2 = sum.Toplama.sum(23582, 315);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23897 + "'", int2 == 23897);
    }

    @Test
    public void test7931() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7931");
        int int2 = sum.Toplama.sum(35172, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35172 + "'", int2 == 35172);
    }

    @Test
    public void test7932() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7932");
        int int2 = sum.Toplama.sum(26576, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26576 + "'", int2 == 26576);
    }

    @Test
    public void test7933() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7933");
        int int2 = sum.Toplama.sum(3495, 6542);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10037 + "'", int2 == 10037);
    }

    @Test
    public void test7934() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7934");
        int int2 = sum.Toplama.sum(14050, 18792);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32842 + "'", int2 == 32842);
    }

    @Test
    public void test7935() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7935");
        int int2 = sum.Toplama.sum(16902, 30787);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47689 + "'", int2 == 47689);
    }

    @Test
    public void test7936() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7936");
        int int2 = sum.Toplama.sum(30217, 30177);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60394 + "'", int2 == 60394);
    }

    @Test
    public void test7937() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7937");
        int int2 = sum.Toplama.sum(50881, 12602);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63483 + "'", int2 == 63483);
    }

    @Test
    public void test7938() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7938");
        int int2 = sum.Toplama.sum(113379, 35510);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 148889 + "'", int2 == 148889);
    }

    @Test
    public void test7939() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7939");
        int int2 = sum.Toplama.sum(21943, 14199);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36142 + "'", int2 == 36142);
    }

    @Test
    public void test7940() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7940");
        int int2 = sum.Toplama.sum(1913, 10104);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12017 + "'", int2 == 12017);
    }

    @Test
    public void test7941() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7941");
        int int2 = sum.Toplama.sum(14566, 1480);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16046 + "'", int2 == 16046);
    }

    @Test
    public void test7942() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7942");
        int int2 = sum.Toplama.sum(0, 52274);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52274 + "'", int2 == 52274);
    }

    @Test
    public void test7943() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7943");
        int int2 = sum.Toplama.sum(45709, 39542);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 85251 + "'", int2 == 85251);
    }

    @Test
    public void test7944() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7944");
        int int2 = sum.Toplama.sum(15129, 45623);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60752 + "'", int2 == 60752);
    }

    @Test
    public void test7945() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7945");
        int int2 = sum.Toplama.sum(27966, 3363);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31329 + "'", int2 == 31329);
    }

    @Test
    public void test7946() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7946");
        int int2 = sum.Toplama.sum(13700, 6538);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20238 + "'", int2 == 20238);
    }

    @Test
    public void test7947() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7947");
        int int2 = sum.Toplama.sum(46457, 37546);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 84003 + "'", int2 == 84003);
    }

    @Test
    public void test7948() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7948");
        int int2 = sum.Toplama.sum(11629, 62983);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 74612 + "'", int2 == 74612);
    }

    @Test
    public void test7949() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7949");
        int int2 = sum.Toplama.sum(76188, 21209);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97397 + "'", int2 == 97397);
    }

    @Test
    public void test7950() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7950");
        int int2 = sum.Toplama.sum(60028, 2949);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62977 + "'", int2 == 62977);
    }

    @Test
    public void test7951() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7951");
        int int2 = sum.Toplama.sum(7483, 10166);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17649 + "'", int2 == 17649);
    }

    @Test
    public void test7952() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7952");
        int int2 = sum.Toplama.sum(21422, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21422 + "'", int2 == 21422);
    }

    @Test
    public void test7953() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7953");
        int int2 = sum.Toplama.sum(62155, 62776);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 124931 + "'", int2 == 124931);
    }

    @Test
    public void test7954() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7954");
        int int2 = sum.Toplama.sum(5633, 17438);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23071 + "'", int2 == 23071);
    }

    @Test
    public void test7955() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7955");
        int int2 = sum.Toplama.sum(33842, 14431);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48273 + "'", int2 == 48273);
    }

    @Test
    public void test7956() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7956");
        int int2 = sum.Toplama.sum(38841, 74134);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 112975 + "'", int2 == 112975);
    }

    @Test
    public void test7957() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7957");
        int int2 = sum.Toplama.sum(23974, 18983);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42957 + "'", int2 == 42957);
    }

    @Test
    public void test7958() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7958");
        int int2 = sum.Toplama.sum(2146, 12656);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14802 + "'", int2 == 14802);
    }

    @Test
    public void test7959() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7959");
        int int2 = sum.Toplama.sum(31219, 27261);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58480 + "'", int2 == 58480);
    }

    @Test
    public void test7960() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7960");
        int int2 = sum.Toplama.sum(72016, 39254);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 111270 + "'", int2 == 111270);
    }

    @Test
    public void test7961() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7961");
        int int2 = sum.Toplama.sum(9578, 20191);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29769 + "'", int2 == 29769);
    }

    @Test
    public void test7962() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7962");
        int int2 = sum.Toplama.sum(54057, 23412);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 77469 + "'", int2 == 77469);
    }

    @Test
    public void test7963() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7963");
        int int2 = sum.Toplama.sum(17825, 23222);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41047 + "'", int2 == 41047);
    }

    @Test
    public void test7964() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7964");
        int int2 = sum.Toplama.sum(16723, 30553);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47276 + "'", int2 == 47276);
    }

    @Test
    public void test7965() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7965");
        int int2 = sum.Toplama.sum(0, 4855);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4855 + "'", int2 == 4855);
    }

    @Test
    public void test7966() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7966");
        int int2 = sum.Toplama.sum(27726, 45459);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 73185 + "'", int2 == 73185);
    }

    @Test
    public void test7967() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7967");
        int int2 = sum.Toplama.sum(10795, 65494);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 76289 + "'", int2 == 76289);
    }

    @Test
    public void test7968() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7968");
        int int2 = sum.Toplama.sum(4025, 20083);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24108 + "'", int2 == 24108);
    }

    @Test
    public void test7969() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7969");
        int int2 = sum.Toplama.sum(43570, 5249);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48819 + "'", int2 == 48819);
    }

    @Test
    public void test7970() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7970");
        int int2 = sum.Toplama.sum(42021, 94835);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 136856 + "'", int2 == 136856);
    }

    @Test
    public void test7971() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7971");
        int int2 = sum.Toplama.sum(11184, 1448);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12632 + "'", int2 == 12632);
    }

    @Test
    public void test7972() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7972");
        int int2 = sum.Toplama.sum(41311, 6716);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48027 + "'", int2 == 48027);
    }

    @Test
    public void test7973() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7973");
        int int2 = sum.Toplama.sum(0, 73185);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 73185 + "'", int2 == 73185);
    }

    @Test
    public void test7974() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7974");
        int int2 = sum.Toplama.sum(0, 9188);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9188 + "'", int2 == 9188);
    }

    @Test
    public void test7975() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7975");
        int int2 = sum.Toplama.sum(0, 5992);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5992 + "'", int2 == 5992);
    }

    @Test
    public void test7976() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7976");
        int int2 = sum.Toplama.sum(3692, 13693);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17385 + "'", int2 == 17385);
    }

    @Test
    public void test7977() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7977");
        int int2 = sum.Toplama.sum(2123, 50847);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52970 + "'", int2 == 52970);
    }

    @Test
    public void test7978() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7978");
        int int2 = sum.Toplama.sum(91584, 15806);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 107390 + "'", int2 == 107390);
    }

    @Test
    public void test7979() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7979");
        int int2 = sum.Toplama.sum(42876, 71050);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 113926 + "'", int2 == 113926);
    }

    @Test
    public void test7980() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7980");
        int int2 = sum.Toplama.sum(408, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 408 + "'", int2 == 408);
    }

    @Test
    public void test7981() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7981");
        int int2 = sum.Toplama.sum(27688, 52015);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 79703 + "'", int2 == 79703);
    }

    @Test
    public void test7982() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7982");
        int int2 = sum.Toplama.sum(64209, 8837);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 73046 + "'", int2 == 73046);
    }

    @Test
    public void test7983() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7983");
        int int2 = sum.Toplama.sum(36773, 13765);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50538 + "'", int2 == 50538);
    }

    @Test
    public void test7984() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7984");
        int int2 = sum.Toplama.sum(4654, 26400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31054 + "'", int2 == 31054);
    }

    @Test
    public void test7985() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7985");
        int int2 = sum.Toplama.sum(1570, 3469);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5039 + "'", int2 == 5039);
    }

    @Test
    public void test7986() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7986");
        int int2 = sum.Toplama.sum(105678, 35922);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 141600 + "'", int2 == 141600);
    }

    @Test
    public void test7987() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7987");
        int int2 = sum.Toplama.sum(0, 18226);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18226 + "'", int2 == 18226);
    }

    @Test
    public void test7988() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7988");
        int int2 = sum.Toplama.sum(0, 17114);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17114 + "'", int2 == 17114);
    }

    @Test
    public void test7989() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7989");
        int int2 = sum.Toplama.sum(0, 35138);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35138 + "'", int2 == 35138);
    }

    @Test
    public void test7990() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7990");
        int int2 = sum.Toplama.sum(73897, 42827);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 116724 + "'", int2 == 116724);
    }

    @Test
    public void test7991() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7991");
        int int2 = sum.Toplama.sum(9204, 108376);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 117580 + "'", int2 == 117580);
    }

    @Test
    public void test7992() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7992");
        int int2 = sum.Toplama.sum(31025, 5952);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36977 + "'", int2 == 36977);
    }

    @Test
    public void test7993() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7993");
        int int2 = sum.Toplama.sum(21387, 20154);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41541 + "'", int2 == 41541);
    }

    @Test
    public void test7994() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7994");
        int int2 = sum.Toplama.sum(39405, 54429);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 93834 + "'", int2 == 93834);
    }

    @Test
    public void test7995() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7995");
        int int2 = sum.Toplama.sum(20644, 31841);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52485 + "'", int2 == 52485);
    }

    @Test
    public void test7996() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7996");
        int int2 = sum.Toplama.sum(6451, 4445);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10896 + "'", int2 == 10896);
    }

    @Test
    public void test7997() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7997");
        int int2 = sum.Toplama.sum(0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test7998() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7998");
        int int2 = sum.Toplama.sum(23540, 84202);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 107742 + "'", int2 == 107742);
    }

    @Test
    public void test7999() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test7999");
        int int2 = sum.Toplama.sum(29073, 21261);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50334 + "'", int2 == 50334);
    }

    @Test
    public void test8000() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest15.test8000");
        int int2 = sum.Toplama.sum(0, 47006);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47006 + "'", int2 == 47006);
    }
}

