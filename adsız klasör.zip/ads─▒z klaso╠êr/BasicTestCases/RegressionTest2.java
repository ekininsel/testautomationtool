import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test1001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1001");
        int int2 = sum.Toplama.sum(2051, 1572);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3623 + "'", int2 == 3623);
    }

    @Test
    public void test1002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1002");
        int int2 = sum.Toplama.sum(877, 3212);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4089 + "'", int2 == 4089);
    }

    @Test
    public void test1003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1003");
        int int2 = sum.Toplama.sum(794, 1121);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1915 + "'", int2 == 1915);
    }

    @Test
    public void test1004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1004");
        int int2 = sum.Toplama.sum(241, 2051);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2292 + "'", int2 == 2292);
    }

    @Test
    public void test1005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1005");
        int int2 = sum.Toplama.sum(1643, 3593);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5236 + "'", int2 == 5236);
    }

    @Test
    public void test1006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1006");
        int int2 = sum.Toplama.sum(7126, 5570);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12696 + "'", int2 == 12696);
    }

    @Test
    public void test1007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1007");
        int int2 = sum.Toplama.sum(1118, 5208);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6326 + "'", int2 == 6326);
    }

    @Test
    public void test1008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1008");
        int int2 = sum.Toplama.sum(514, 1213);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1727 + "'", int2 == 1727);
    }

    @Test
    public void test1009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1009");
        int int2 = sum.Toplama.sum(449, 543);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 992 + "'", int2 == 992);
    }

    @Test
    public void test1010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1010");
        int int2 = sum.Toplama.sum((int) '#', 3495);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3530 + "'", int2 == 3530);
    }

    @Test
    public void test1011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1011");
        int int2 = sum.Toplama.sum(1422, 3737);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5159 + "'", int2 == 5159);
    }

    @Test
    public void test1012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1012");
        int int2 = sum.Toplama.sum(5139, 3553);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8692 + "'", int2 == 8692);
    }

    @Test
    public void test1013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1013");
        int int2 = sum.Toplama.sum(488, 6054);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6542 + "'", int2 == 6542);
    }

    @Test
    public void test1014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1014");
        int int2 = sum.Toplama.sum(6124, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6159 + "'", int2 == 6159);
    }

    @Test
    public void test1015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1015");
        int int2 = sum.Toplama.sum(200, 1260);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1460 + "'", int2 == 1460);
    }

    @Test
    public void test1016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1016");
        int int2 = sum.Toplama.sum(2126, 756);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2882 + "'", int2 == 2882);
    }

    @Test
    public void test1017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1017");
        int int2 = sum.Toplama.sum(3448, 6078);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9526 + "'", int2 == 9526);
    }

    @Test
    public void test1018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1018");
        int int2 = sum.Toplama.sum(2166, 909);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3075 + "'", int2 == 3075);
    }

    @Test
    public void test1019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1019");
        int int2 = sum.Toplama.sum(241, 4311);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4552 + "'", int2 == 4552);
    }

    @Test
    public void test1020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1020");
        int int2 = sum.Toplama.sum(2194, 7608);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9802 + "'", int2 == 9802);
    }

    @Test
    public void test1021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1021");
        int int2 = sum.Toplama.sum(4149, 790);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4939 + "'", int2 == 4939);
    }

    @Test
    public void test1022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1022");
        int int2 = sum.Toplama.sum(468, 12451);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12919 + "'", int2 == 12919);
    }

    @Test
    public void test1023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1023");
        int int2 = sum.Toplama.sum(0, 8344);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8344 + "'", int2 == 8344);
    }

    @Test
    public void test1024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1024");
        int int2 = sum.Toplama.sum(11416, 459);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11875 + "'", int2 == 11875);
    }

    @Test
    public void test1025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1025");
        int int2 = sum.Toplama.sum(110, 2651);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2761 + "'", int2 == 2761);
    }

    @Test
    public void test1026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1026");
        int int2 = sum.Toplama.sum(2102, 9156);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11258 + "'", int2 == 11258);
    }

    @Test
    public void test1027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1027");
        int int2 = sum.Toplama.sum(5807, 3038);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8845 + "'", int2 == 8845);
    }

    @Test
    public void test1028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1028");
        int int2 = sum.Toplama.sum(35, 4451);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4486 + "'", int2 == 4486);
    }

    @Test
    public void test1029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1029");
        int int2 = sum.Toplama.sum(164, 2677);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2841 + "'", int2 == 2841);
    }

    @Test
    public void test1030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1030");
        int int2 = sum.Toplama.sum(8673, 5800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14473 + "'", int2 == 14473);
    }

    @Test
    public void test1031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1031");
        int int2 = sum.Toplama.sum(3696, 4369);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8065 + "'", int2 == 8065);
    }

    @Test
    public void test1032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1032");
        int int2 = sum.Toplama.sum(97, 2289);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2386 + "'", int2 == 2386);
    }

    @Test
    public void test1033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1033");
        int int2 = sum.Toplama.sum(100, 4114);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4214 + "'", int2 == 4214);
    }

    @Test
    public void test1034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1034");
        int int2 = sum.Toplama.sum(877, 5055);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5932 + "'", int2 == 5932);
    }

    @Test
    public void test1035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1035");
        int int2 = sum.Toplama.sum(632, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 632 + "'", int2 == 632);
    }

    @Test
    public void test1036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1036");
        int int2 = sum.Toplama.sum(106, 7608);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7714 + "'", int2 == 7714);
    }

    @Test
    public void test1037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1037");
        int int2 = sum.Toplama.sum(5963, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5973 + "'", int2 == 5973);
    }

    @Test
    public void test1038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1038");
        int int2 = sum.Toplama.sum(2249, 161);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2410 + "'", int2 == 2410);
    }

    @Test
    public void test1039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1039");
        int int2 = sum.Toplama.sum(4042, 4451);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8493 + "'", int2 == 8493);
    }

    @Test
    public void test1040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1040");
        int int2 = sum.Toplama.sum(230, 1203);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1433 + "'", int2 == 1433);
    }

    @Test
    public void test1041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1041");
        int int2 = sum.Toplama.sum(954, 642);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1596 + "'", int2 == 1596);
    }

    @Test
    public void test1042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1042");
        int int2 = sum.Toplama.sum(1446, 1917);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3363 + "'", int2 == 3363);
    }

    @Test
    public void test1043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1043");
        int int2 = sum.Toplama.sum(4042, 1481);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5523 + "'", int2 == 5523);
    }

    @Test
    public void test1044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1044");
        int int2 = sum.Toplama.sum(574, 1265);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1839 + "'", int2 == 1839);
    }

    @Test
    public void test1045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1045");
        int int2 = sum.Toplama.sum(50, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
    }

    @Test
    public void test1046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1046");
        int int2 = sum.Toplama.sum(0, 3841);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3841 + "'", int2 == 3841);
    }

    @Test
    public void test1047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1047");
        int int2 = sum.Toplama.sum(8738, 7232);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15970 + "'", int2 == 15970);
    }

    @Test
    public void test1048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1048");
        int int2 = sum.Toplama.sum(1936, 152);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2088 + "'", int2 == 2088);
    }

    @Test
    public void test1049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1049");
        int int2 = sum.Toplama.sum(0, 548);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 548 + "'", int2 == 548);
    }

    @Test
    public void test1050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1050");
        int int2 = sum.Toplama.sum(6041, 6322);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12363 + "'", int2 == 12363);
    }

    @Test
    public void test1051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1051");
        int int2 = sum.Toplama.sum(632, 809);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1441 + "'", int2 == 1441);
    }

    @Test
    public void test1052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1052");
        int int2 = sum.Toplama.sum(4042, 241);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4283 + "'", int2 == 4283);
    }

    @Test
    public void test1053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1053");
        int int2 = sum.Toplama.sum(1680, 1415);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3095 + "'", int2 == 3095);
    }

    @Test
    public void test1054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1054");
        int int2 = sum.Toplama.sum(5382, 14809);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20191 + "'", int2 == 20191);
    }

    @Test
    public void test1055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1055");
        int int2 = sum.Toplama.sum(6138, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6235 + "'", int2 == 6235);
    }

    @Test
    public void test1056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1056");
        int int2 = sum.Toplama.sum(2045, 240);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2285 + "'", int2 == 2285);
    }

    @Test
    public void test1057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1057");
        int int2 = sum.Toplama.sum(3092, 4768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7860 + "'", int2 == 7860);
    }

    @Test
    public void test1058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1058");
        int int2 = sum.Toplama.sum(296, 6768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7064 + "'", int2 == 7064);
    }

    @Test
    public void test1059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1059");
        int int2 = sum.Toplama.sum(8692, 251);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8943 + "'", int2 == 8943);
    }

    @Test
    public void test1060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1060");
        int int2 = sum.Toplama.sum(260, 53);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 313 + "'", int2 == 313);
    }

    @Test
    public void test1061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1061");
        int int2 = sum.Toplama.sum(2436, 2318);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4754 + "'", int2 == 4754);
    }

    @Test
    public void test1062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1062");
        int int2 = sum.Toplama.sum(17114, 4857);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21971 + "'", int2 == 21971);
    }

    @Test
    public void test1063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1063");
        int int2 = sum.Toplama.sum(1982, 931);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2913 + "'", int2 == 2913);
    }

    @Test
    public void test1064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1064");
        int int2 = sum.Toplama.sum(1881, 9059);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10940 + "'", int2 == 10940);
    }

    @Test
    public void test1065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1065");
        int int2 = sum.Toplama.sum((int) (short) 100, 891);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 991 + "'", int2 == 991);
    }

    @Test
    public void test1066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1066");
        int int2 = sum.Toplama.sum(691, 931);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1622 + "'", int2 == 1622);
    }

    @Test
    public void test1067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1067");
        int int2 = sum.Toplama.sum(1315, 2843);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4158 + "'", int2 == 4158);
    }

    @Test
    public void test1068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1068");
        int int2 = sum.Toplama.sum(1803, 7232);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9035 + "'", int2 == 9035);
    }

    @Test
    public void test1069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1069");
        int int2 = sum.Toplama.sum(2386, 724);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3110 + "'", int2 == 3110);
    }

    @Test
    public void test1070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1070");
        int int2 = sum.Toplama.sum(3850, 12363);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16213 + "'", int2 == 16213);
    }

    @Test
    public void test1071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1071");
        int int2 = sum.Toplama.sum(1185, 538);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1723 + "'", int2 == 1723);
    }

    @Test
    public void test1072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1072");
        int int2 = sum.Toplama.sum(4080, 2636);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6716 + "'", int2 == 6716);
    }

    @Test
    public void test1073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1073");
        int int2 = sum.Toplama.sum(2340, 2205);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4545 + "'", int2 == 4545);
    }

    @Test
    public void test1074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1074");
        int int2 = sum.Toplama.sum(8697, 1342);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10039 + "'", int2 == 10039);
    }

    @Test
    public void test1075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1075");
        int int2 = sum.Toplama.sum(595, 877);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1472 + "'", int2 == 1472);
    }

    @Test
    public void test1076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1076");
        int int2 = sum.Toplama.sum(1840, 5382);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7222 + "'", int2 == 7222);
    }

    @Test
    public void test1077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1077");
        int int2 = sum.Toplama.sum(3740, 3566);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7306 + "'", int2 == 7306);
    }

    @Test
    public void test1078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1078");
        int int2 = sum.Toplama.sum(1296, 2502);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3798 + "'", int2 == 3798);
    }

    @Test
    public void test1079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1079");
        int int2 = sum.Toplama.sum(4916, 3054);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7970 + "'", int2 == 7970);
    }

    @Test
    public void test1080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1080");
        int int2 = sum.Toplama.sum(6136, 1199);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7335 + "'", int2 == 7335);
    }

    @Test
    public void test1081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1081");
        int int2 = sum.Toplama.sum(261, 2272);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2533 + "'", int2 == 2533);
    }

    @Test
    public void test1082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1082");
        int int2 = sum.Toplama.sum(8943, 1622);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10565 + "'", int2 == 10565);
    }

    @Test
    public void test1083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1083");
        int int2 = sum.Toplama.sum(2636, 1995);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4631 + "'", int2 == 4631);
    }

    @Test
    public void test1084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1084");
        int int2 = sum.Toplama.sum(877, 508);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1385 + "'", int2 == 1385);
    }

    @Test
    public void test1085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1085");
        int int2 = sum.Toplama.sum((int) (short) 10, 1161);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1171 + "'", int2 == 1171);
    }

    @Test
    public void test1086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1086");
        int int2 = sum.Toplama.sum(422, 12777);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13199 + "'", int2 == 13199);
    }

    @Test
    public void test1087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1087");
        int int2 = sum.Toplama.sum((int) (byte) 1, 2952);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2953 + "'", int2 == 2953);
    }

    @Test
    public void test1088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1088");
        int int2 = sum.Toplama.sum(3038, 548);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3586 + "'", int2 == 3586);
    }

    @Test
    public void test1089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1089");
        int int2 = sum.Toplama.sum(1877, 3566);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5443 + "'", int2 == 5443);
    }

    @Test
    public void test1090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1090");
        int int2 = sum.Toplama.sum(4847, 6084);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10931 + "'", int2 == 10931);
    }

    @Test
    public void test1091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1091");
        int int2 = sum.Toplama.sum(721, 4445);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5166 + "'", int2 == 5166);
    }

    @Test
    public void test1092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1092");
        int int2 = sum.Toplama.sum(2123, 922);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3045 + "'", int2 == 3045);
    }

    @Test
    public void test1093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1093");
        int int2 = sum.Toplama.sum(5055, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5107 + "'", int2 == 5107);
    }

    @Test
    public void test1094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1094");
        int int2 = sum.Toplama.sum(5236, 14206);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19442 + "'", int2 == 19442);
    }

    @Test
    public void test1095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1095");
        int int2 = sum.Toplama.sum(3950, 1685);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5635 + "'", int2 == 5635);
    }

    @Test
    public void test1096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1096");
        int int2 = sum.Toplama.sum(960, 2022);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2982 + "'", int2 == 2982);
    }

    @Test
    public void test1097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1097");
        int int2 = sum.Toplama.sum(2466, 4539);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7005 + "'", int2 == 7005);
    }

    @Test
    public void test1098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1098");
        int int2 = sum.Toplama.sum(9059, 1713);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10772 + "'", int2 == 10772);
    }

    @Test
    public void test1099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1099");
        int int2 = sum.Toplama.sum(544, 3833);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4377 + "'", int2 == 4377);
    }

    @Test
    public void test1100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1100");
        int int2 = sum.Toplama.sum(804, 2968);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3772 + "'", int2 == 3772);
    }

    @Test
    public void test1101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1101");
        int int2 = sum.Toplama.sum(210, 6328);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6538 + "'", int2 == 6538);
    }

    @Test
    public void test1102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1102");
        int int2 = sum.Toplama.sum(4055, 2788);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6843 + "'", int2 == 6843);
    }

    @Test
    public void test1103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1103");
        int int2 = sum.Toplama.sum(2535, 2905);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5440 + "'", int2 == 5440);
    }

    @Test
    public void test1104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1104");
        int int2 = sum.Toplama.sum(61, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61 + "'", int2 == 61);
    }

    @Test
    public void test1105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1105");
        int int2 = sum.Toplama.sum(6322, 3950);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10272 + "'", int2 == 10272);
    }

    @Test
    public void test1106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1106");
        int int2 = sum.Toplama.sum(3511, 17114);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20625 + "'", int2 == 20625);
    }

    @Test
    public void test1107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1107");
        int int2 = sum.Toplama.sum(1579, 1000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2579 + "'", int2 == 2579);
    }

    @Test
    public void test1108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1108");
        int int2 = sum.Toplama.sum(776, 8697);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9473 + "'", int2 == 9473);
    }

    @Test
    public void test1109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1109");
        int int2 = sum.Toplama.sum(18038, 1877);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19915 + "'", int2 == 19915);
    }

    @Test
    public void test1110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1110");
        int int2 = sum.Toplama.sum(11258, 776);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12034 + "'", int2 == 12034);
    }

    @Test
    public void test1111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1111");
        int int2 = sum.Toplama.sum(1411, 4248);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5659 + "'", int2 == 5659);
    }

    @Test
    public void test1112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1112");
        int int2 = sum.Toplama.sum(7079, 8738);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15817 + "'", int2 == 15817);
    }

    @Test
    public void test1113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1113");
        int int2 = sum.Toplama.sum(5643, 8925);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14568 + "'", int2 == 14568);
    }

    @Test
    public void test1114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1114");
        int int2 = sum.Toplama.sum(5973, 14181);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20154 + "'", int2 == 20154);
    }

    @Test
    public void test1115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1115");
        int int2 = sum.Toplama.sum(3256, 1488);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4744 + "'", int2 == 4744);
    }

    @Test
    public void test1116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1116");
        int int2 = sum.Toplama.sum(6326, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6327 + "'", int2 == 6327);
    }

    @Test
    public void test1117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1117");
        int int2 = sum.Toplama.sum(8084, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8084 + "'", int2 == 8084);
    }

    @Test
    public void test1118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1118");
        int int2 = sum.Toplama.sum(5327, 992);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6319 + "'", int2 == 6319);
    }

    @Test
    public void test1119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1119");
        int int2 = sum.Toplama.sum(300, 2488);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2788 + "'", int2 == 2788);
    }

    @Test
    public void test1120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1120");
        int int2 = sum.Toplama.sum(6621, 4246);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10867 + "'", int2 == 10867);
    }

    @Test
    public void test1121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1121");
        int int2 = sum.Toplama.sum(5859, 792);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6651 + "'", int2 == 6651);
    }

    @Test
    public void test1122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1122");
        int int2 = sum.Toplama.sum(5236, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5236 + "'", int2 == 5236);
    }

    @Test
    public void test1123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1123");
        int int2 = sum.Toplama.sum(9212, 4132);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13344 + "'", int2 == 13344);
    }

    @Test
    public void test1124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1124");
        int int2 = sum.Toplama.sum(13566, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13663 + "'", int2 == 13663);
    }

    @Test
    public void test1125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1125");
        int int2 = sum.Toplama.sum(538, 2978);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3516 + "'", int2 == 3516);
    }

    @Test
    public void test1126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1126");
        int int2 = sum.Toplama.sum(527, 2895);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3422 + "'", int2 == 3422);
    }

    @Test
    public void test1127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1127");
        int int2 = sum.Toplama.sum(1411, 8697);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10108 + "'", int2 == 10108);
    }

    @Test
    public void test1128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1128");
        int int2 = sum.Toplama.sum(6635, 5080);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11715 + "'", int2 == 11715);
    }

    @Test
    public void test1129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1129");
        int int2 = sum.Toplama.sum(4093, 6914);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11007 + "'", int2 == 11007);
    }

    @Test
    public void test1130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1130");
        int int2 = sum.Toplama.sum(1385, 21971);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23356 + "'", int2 == 23356);
    }

    @Test
    public void test1131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1131");
        int int2 = sum.Toplama.sum(1238, 1460);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2698 + "'", int2 == 2698);
    }

    @Test
    public void test1132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1132");
        int int2 = sum.Toplama.sum((int) (byte) -1, 3696);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3695 + "'", int2 == 3695);
    }

    @Test
    public void test1133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1133");
        int int2 = sum.Toplama.sum(1415, 3833);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5248 + "'", int2 == 5248);
    }

    @Test
    public void test1134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1134");
        int int2 = sum.Toplama.sum(1296, 2797);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4093 + "'", int2 == 4093);
    }

    @Test
    public void test1135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1135");
        int int2 = sum.Toplama.sum(3791, 1835);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5626 + "'", int2 == 5626);
    }

    @Test
    public void test1136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1136");
        int int2 = sum.Toplama.sum(4957, 940);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5897 + "'", int2 == 5897);
    }

    @Test
    public void test1137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1137");
        int int2 = sum.Toplama.sum(1903, 4093);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5996 + "'", int2 == 5996);
    }

    @Test
    public void test1138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1138");
        int int2 = sum.Toplama.sum(3511, 381);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3892 + "'", int2 == 3892);
    }

    @Test
    public void test1139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1139");
        int int2 = sum.Toplama.sum(735, 4354);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5089 + "'", int2 == 5089);
    }

    @Test
    public void test1140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1140");
        int int2 = sum.Toplama.sum(5159, 3036);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8195 + "'", int2 == 8195);
    }

    @Test
    public void test1141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1141");
        int int2 = sum.Toplama.sum(99, 412);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 511 + "'", int2 == 511);
    }

    @Test
    public void test1142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1142");
        int int2 = sum.Toplama.sum(4372, 5530);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9902 + "'", int2 == 9902);
    }

    @Test
    public void test1143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1143");
        int int2 = sum.Toplama.sum(995, 9902);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10897 + "'", int2 == 10897);
    }

    @Test
    public void test1144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1144");
        int int2 = sum.Toplama.sum(1204, 5639);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6843 + "'", int2 == 6843);
    }

    @Test
    public void test1145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1145");
        int int2 = sum.Toplama.sum(19442, 909);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20351 + "'", int2 == 20351);
    }

    @Test
    public void test1146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1146");
        int int2 = sum.Toplama.sum(1536, 381);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1917 + "'", int2 == 1917);
    }

    @Test
    public void test1147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1147");
        int int2 = sum.Toplama.sum(2723, 497);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3220 + "'", int2 == 3220);
    }

    @Test
    public void test1148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1148");
        int int2 = sum.Toplama.sum(2982, 1772);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4754 + "'", int2 == 4754);
    }

    @Test
    public void test1149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1149");
        int int2 = sum.Toplama.sum(2134, 2492);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4626 + "'", int2 == 4626);
    }

    @Test
    public void test1150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1150");
        int int2 = sum.Toplama.sum(692, 2761);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3453 + "'", int2 == 3453);
    }

    @Test
    public void test1151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1151");
        int int2 = sum.Toplama.sum(11258, 917);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12175 + "'", int2 == 12175);
    }

    @Test
    public void test1152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1152");
        int int2 = sum.Toplama.sum(11685, 3566);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15251 + "'", int2 == 15251);
    }

    @Test
    public void test1153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1153");
        int int2 = sum.Toplama.sum(964, 9059);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10023 + "'", int2 == 10023);
    }

    @Test
    public void test1154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1154");
        int int2 = sum.Toplama.sum(3527, 12363);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15890 + "'", int2 == 15890);
    }

    @Test
    public void test1155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1155");
        int int2 = sum.Toplama.sum(352, 2723);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3075 + "'", int2 == 3075);
    }

    @Test
    public void test1156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1156");
        int int2 = sum.Toplama.sum(1433, 14473);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15906 + "'", int2 == 15906);
    }

    @Test
    public void test1157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1157");
        int int2 = sum.Toplama.sum(2660, 6651);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9311 + "'", int2 == 9311);
    }

    @Test
    public void test1158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1158");
        int int2 = sum.Toplama.sum(6638, 12777);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19415 + "'", int2 == 19415);
    }

    @Test
    public void test1159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1159");
        int int2 = sum.Toplama.sum(5897, 746);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6643 + "'", int2 == 6643);
    }

    @Test
    public void test1160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1160");
        int int2 = sum.Toplama.sum(1697, 9191);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10888 + "'", int2 == 10888);
    }

    @Test
    public void test1161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1161");
        int int2 = sum.Toplama.sum(2466, 4090);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6556 + "'", int2 == 6556);
    }

    @Test
    public void test1162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1162");
        int int2 = sum.Toplama.sum(2804, 468);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3272 + "'", int2 == 3272);
    }

    @Test
    public void test1163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1163");
        int int2 = sum.Toplama.sum(358, 5523);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5881 + "'", int2 == 5881);
    }

    @Test
    public void test1164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1164");
        int int2 = sum.Toplama.sum(5213, 5973);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11186 + "'", int2 == 11186);
    }

    @Test
    public void test1165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1165");
        int int2 = sum.Toplama.sum(455, 4227);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4682 + "'", int2 == 4682);
    }

    @Test
    public void test1166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1166");
        int int2 = sum.Toplama.sum(188, 1464);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1652 + "'", int2 == 1652);
    }

    @Test
    public void test1167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1167");
        int int2 = sum.Toplama.sum(1276, 2651);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3927 + "'", int2 == 3927);
    }

    @Test
    public void test1168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1168");
        int int2 = sum.Toplama.sum(3516, 3943);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7459 + "'", int2 == 7459);
    }

    @Test
    public void test1169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1169");
        int int2 = sum.Toplama.sum(9991, 295);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10286 + "'", int2 == 10286);
    }

    @Test
    public void test1170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1170");
        int int2 = sum.Toplama.sum(1428, 1982);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3410 + "'", int2 == 3410);
    }

    @Test
    public void test1171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1171");
        int int2 = sum.Toplama.sum(1315, 203);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1518 + "'", int2 == 1518);
    }

    @Test
    public void test1172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1172");
        int int2 = sum.Toplama.sum(1716, 10108);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11824 + "'", int2 == 11824);
    }

    @Test
    public void test1173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1173");
        int int2 = sum.Toplama.sum(14412, 875);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15287 + "'", int2 == 15287);
    }

    @Test
    public void test1174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1174");
        int int2 = sum.Toplama.sum(164, 1110);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1274 + "'", int2 == 1274);
    }

    @Test
    public void test1175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1175");
        int int2 = sum.Toplama.sum(1265, 519);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1784 + "'", int2 == 1784);
    }

    @Test
    public void test1176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1176");
        int int2 = sum.Toplama.sum(5859, 3092);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8951 + "'", int2 == 8951);
    }

    @Test
    public void test1177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1177");
        int int2 = sum.Toplama.sum(9136, 3832);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12968 + "'", int2 == 12968);
    }

    @Test
    public void test1178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1178");
        int int2 = sum.Toplama.sum(149, 4847);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4996 + "'", int2 == 4996);
    }

    @Test
    public void test1179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1179");
        int int2 = sum.Toplama.sum(12175, 511);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12686 + "'", int2 == 12686);
    }

    @Test
    public void test1180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1180");
        int int2 = sum.Toplama.sum(4055, 2587);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6642 + "'", int2 == 6642);
    }

    @Test
    public void test1181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1181");
        int int2 = sum.Toplama.sum(269, 347);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 616 + "'", int2 == 616);
    }

    @Test
    public void test1182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1182");
        int int2 = sum.Toplama.sum(3176, 2953);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6129 + "'", int2 == 6129);
    }

    @Test
    public void test1183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1183");
        int int2 = sum.Toplama.sum(2835, 4653);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7488 + "'", int2 == 7488);
    }

    @Test
    public void test1184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1184");
        int int2 = sum.Toplama.sum(3469, 464);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3933 + "'", int2 == 3933);
    }

    @Test
    public void test1185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1185");
        int int2 = sum.Toplama.sum(1835, 2742);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4577 + "'", int2 == 4577);
    }

    @Test
    public void test1186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1186");
        int int2 = sum.Toplama.sum(2605, 5327);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7932 + "'", int2 == 7932);
    }

    @Test
    public void test1187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1187");
        int int2 = sum.Toplama.sum(4902, 2797);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7699 + "'", int2 == 7699);
    }

    @Test
    public void test1188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1188");
        int int2 = sum.Toplama.sum(4539, 469);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5008 + "'", int2 == 5008);
    }

    @Test
    public void test1189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1189");
        int int2 = sum.Toplama.sum(261, 790);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1051 + "'", int2 == 1051);
    }

    @Test
    public void test1190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1190");
        int int2 = sum.Toplama.sum(10100, 3197);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13297 + "'", int2 == 13297);
    }

    @Test
    public void test1191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1191");
        int int2 = sum.Toplama.sum(4682, 4149);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8831 + "'", int2 == 8831);
    }

    @Test
    public void test1192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1192");
        int int2 = sum.Toplama.sum(392, 2820);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3212 + "'", int2 == 3212);
    }

    @Test
    public void test1193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1193");
        int int2 = sum.Toplama.sum(10786, 369);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11155 + "'", int2 == 11155);
    }

    @Test
    public void test1194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1194");
        int int2 = sum.Toplama.sum(809, 2214);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3023 + "'", int2 == 3023);
    }

    @Test
    public void test1195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1195");
        int int2 = sum.Toplama.sum(88, 1982);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2070 + "'", int2 == 2070);
    }

    @Test
    public void test1196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1196");
        int int2 = sum.Toplama.sum(880, 558);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1438 + "'", int2 == 1438);
    }

    @Test
    public void test1197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1197");
        int int2 = sum.Toplama.sum(261, 3663);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3924 + "'", int2 == 3924);
    }

    @Test
    public void test1198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1198");
        int int2 = sum.Toplama.sum(557, 11072);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11629 + "'", int2 == 11629);
    }

    @Test
    public void test1199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1199");
        int int2 = sum.Toplama.sum(2770, 3169);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5939 + "'", int2 == 5939);
    }

    @Test
    public void test1200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1200");
        int int2 = sum.Toplama.sum(2253, 23356);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25609 + "'", int2 == 25609);
    }

    @Test
    public void test1201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1201");
        int int2 = sum.Toplama.sum(3509, 6054);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9563 + "'", int2 == 9563);
    }

    @Test
    public void test1202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1202");
        int int2 = sum.Toplama.sum(2923, 2851);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5774 + "'", int2 == 5774);
    }

    @Test
    public void test1203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1203");
        int int2 = sum.Toplama.sum(295, 3553);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3848 + "'", int2 == 3848);
    }

    @Test
    public void test1204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1204");
        int int2 = sum.Toplama.sum(3569, 4472);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8041 + "'", int2 == 8041);
    }

    @Test
    public void test1205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1205");
        int int2 = sum.Toplama.sum(8845, 888);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9733 + "'", int2 == 9733);
    }

    @Test
    public void test1206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1206");
        int int2 = sum.Toplama.sum(2352, 3892);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6244 + "'", int2 == 6244);
    }

    @Test
    public void test1207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1207");
        int int2 = sum.Toplama.sum(3775, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3775 + "'", int2 == 3775);
    }

    @Test
    public void test1208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1208");
        int int2 = sum.Toplama.sum(1491, 207);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1698 + "'", int2 == 1698);
    }

    @Test
    public void test1209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1209");
        int int2 = sum.Toplama.sum(5840, 3026);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8866 + "'", int2 == 8866);
    }

    @Test
    public void test1210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1210");
        int int2 = sum.Toplama.sum(4939, 2063);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7002 + "'", int2 == 7002);
    }

    @Test
    public void test1211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1211");
        int int2 = sum.Toplama.sum(692, 1877);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2569 + "'", int2 == 2569);
    }

    @Test
    public void test1212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1212");
        int int2 = sum.Toplama.sum(862, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 862 + "'", int2 == 862);
    }

    @Test
    public void test1213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1213");
        int int2 = sum.Toplama.sum(2579, 687);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3266 + "'", int2 == 3266);
    }

    @Test
    public void test1214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1214");
        int int2 = sum.Toplama.sum(11824, 730);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12554 + "'", int2 == 12554);
    }

    @Test
    public void test1215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1215");
        int int2 = sum.Toplama.sum(7410, 3498);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10908 + "'", int2 == 10908);
    }

    @Test
    public void test1216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1216");
        int int2 = sum.Toplama.sum(3095, 2897);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5992 + "'", int2 == 5992);
    }

    @Test
    public void test1217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1217");
        int int2 = sum.Toplama.sum(2740, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2740 + "'", int2 == 2740);
    }

    @Test
    public void test1218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1218");
        int int2 = sum.Toplama.sum(4902, 5992);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10894 + "'", int2 == 10894);
    }

    @Test
    public void test1219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1219");
        int int2 = sum.Toplama.sum(854, 485);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1339 + "'", int2 == 1339);
    }

    @Test
    public void test1220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1220");
        int int2 = sum.Toplama.sum(4080, 9606);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13686 + "'", int2 == 13686);
    }

    @Test
    public void test1221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1221");
        int int2 = sum.Toplama.sum(9902, 12011);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21913 + "'", int2 == 21913);
    }

    @Test
    public void test1222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1222");
        int int2 = sum.Toplama.sum(6714, 3272);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9986 + "'", int2 == 9986);
    }

    @Test
    public void test1223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1223");
        int int2 = sum.Toplama.sum(5159, 5126);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10285 + "'", int2 == 10285);
    }

    @Test
    public void test1224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1224");
        int int2 = sum.Toplama.sum(2792, 5236);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8028 + "'", int2 == 8028);
    }

    @Test
    public void test1225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1225");
        int int2 = sum.Toplama.sum(5301, 4768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10069 + "'", int2 == 10069);
    }

    @Test
    public void test1226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1226");
        int int2 = sum.Toplama.sum(0, 1441);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1441 + "'", int2 == 1441);
    }

    @Test
    public void test1227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1227");
        int int2 = sum.Toplama.sum(1843, 1287);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3130 + "'", int2 == 3130);
    }

    @Test
    public void test1228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1228");
        int int2 = sum.Toplama.sum(735, 543);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1278 + "'", int2 == 1278);
    }

    @Test
    public void test1229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1229");
        int int2 = sum.Toplama.sum(2150, 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2249 + "'", int2 == 2249);
    }

    @Test
    public void test1230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1230");
        int int2 = sum.Toplama.sum(5807, 753);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6560 + "'", int2 == 6560);
    }

    @Test
    public void test1231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1231");
        int int2 = sum.Toplama.sum(3075, 8925);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12000 + "'", int2 == 12000);
    }

    @Test
    public void test1232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1232");
        int int2 = sum.Toplama.sum(0, 3740);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3740 + "'", int2 == 3740);
    }

    @Test
    public void test1233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1233");
        int int2 = sum.Toplama.sum(1317, 9902);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11219 + "'", int2 == 11219);
    }

    @Test
    public void test1234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1234");
        int int2 = sum.Toplama.sum(23356, 8065);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31421 + "'", int2 == 31421);
    }

    @Test
    public void test1235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1235");
        int int2 = sum.Toplama.sum(486, 261);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 747 + "'", int2 == 747);
    }

    @Test
    public void test1236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1236");
        int int2 = sum.Toplama.sum(855, 707);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1562 + "'", int2 == 1562);
    }

    @Test
    public void test1237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1237");
        int int2 = sum.Toplama.sum(8738, 4916);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13654 + "'", int2 == 13654);
    }

    @Test
    public void test1238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1238");
        int int2 = sum.Toplama.sum(3511, 1843);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5354 + "'", int2 == 5354);
    }

    @Test
    public void test1239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1239");
        int int2 = sum.Toplama.sum(8692, 997);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9689 + "'", int2 == 9689);
    }

    @Test
    public void test1240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1240");
        int int2 = sum.Toplama.sum(351, 4476);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4827 + "'", int2 == 4827);
    }

    @Test
    public void test1241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1241");
        int int2 = sum.Toplama.sum(2526, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2526 + "'", int2 == 2526);
    }

    @Test
    public void test1242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1242");
        int int2 = sum.Toplama.sum(12968, 10063);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23031 + "'", int2 == 23031);
    }

    @Test
    public void test1243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1243");
        int int2 = sum.Toplama.sum(5215, 6124);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11339 + "'", int2 == 11339);
    }

    @Test
    public void test1244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1244");
        int int2 = sum.Toplama.sum(3418, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3418 + "'", int2 == 3418);
    }

    @Test
    public void test1245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1245");
        int int2 = sum.Toplama.sum(20625, 1685);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22310 + "'", int2 == 22310);
    }

    @Test
    public void test1246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1246");
        int int2 = sum.Toplama.sum(1387, 4042);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5429 + "'", int2 == 5429);
    }

    @Test
    public void test1247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1247");
        int int2 = sum.Toplama.sum(1867, 149);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2016 + "'", int2 == 2016);
    }

    @Test
    public void test1248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1248");
        int int2 = sum.Toplama.sum(0, 18038);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18038 + "'", int2 == 18038);
    }

    @Test
    public void test1249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1249");
        int int2 = sum.Toplama.sum(544, 7410);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7954 + "'", int2 == 7954);
    }

    @Test
    public void test1250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1250");
        int int2 = sum.Toplama.sum(0, 940);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 940 + "'", int2 == 940);
    }

    @Test
    public void test1251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1251");
        int int2 = sum.Toplama.sum(4539, 11790);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16329 + "'", int2 == 16329);
    }

    @Test
    public void test1252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1252");
        int int2 = sum.Toplama.sum(433, 1932);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2365 + "'", int2 == 2365);
    }

    @Test
    public void test1253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1253");
        int int2 = sum.Toplama.sum(10821, 1652);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12473 + "'", int2 == 12473);
    }

    @Test
    public void test1254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1254");
        int int2 = sum.Toplama.sum(3832, 2411);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6243 + "'", int2 == 6243);
    }

    @Test
    public void test1255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1255");
        int int2 = sum.Toplama.sum(1460, 8738);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10198 + "'", int2 == 10198);
    }

    @Test
    public void test1256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1256");
        int int2 = sum.Toplama.sum(630, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 630 + "'", int2 == 630);
    }

    @Test
    public void test1257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1257");
        int int2 = sum.Toplama.sum(7970, 931);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8901 + "'", int2 == 8901);
    }

    @Test
    public void test1258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1258");
        int int2 = sum.Toplama.sum(3527, 393);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3920 + "'", int2 == 3920);
    }

    @Test
    public void test1259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1259");
        int int2 = sum.Toplama.sum((int) (byte) 100, 1539);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1639 + "'", int2 == 1639);
    }

    @Test
    public void test1260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1260");
        int int2 = sum.Toplama.sum(3448, 9675);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13123 + "'", int2 == 13123);
    }

    @Test
    public void test1261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1261");
        int int2 = sum.Toplama.sum(3775, 890);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4665 + "'", int2 == 4665);
    }

    @Test
    public void test1262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1262");
        int int2 = sum.Toplama.sum(2962, 3663);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6625 + "'", int2 == 6625);
    }

    @Test
    public void test1263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1263");
        int int2 = sum.Toplama.sum(140, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 140 + "'", int2 == 140);
    }

    @Test
    public void test1264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1264");
        int int2 = sum.Toplama.sum(1095, 1652);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2747 + "'", int2 == 2747);
    }

    @Test
    public void test1265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1265");
        int int2 = sum.Toplama.sum(2030, 8951);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10981 + "'", int2 == 10981);
    }

    @Test
    public void test1266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1266");
        int int2 = sum.Toplama.sum(1278, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1378 + "'", int2 == 1378);
    }

    @Test
    public void test1267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1267");
        int int2 = sum.Toplama.sum(10981, 18038);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29019 + "'", int2 == 29019);
    }

    @Test
    public void test1268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1268");
        int int2 = sum.Toplama.sum(0, 519);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 519 + "'", int2 == 519);
    }

    @Test
    public void test1269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1269");
        int int2 = sum.Toplama.sum(1006, 459);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1465 + "'", int2 == 1465);
    }

    @Test
    public void test1270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1270");
        int int2 = sum.Toplama.sum(790, 2533);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3323 + "'", int2 == 3323);
    }

    @Test
    public void test1271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1271");
        int int2 = sum.Toplama.sum(4545, 1540);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6085 + "'", int2 == 6085);
    }

    @Test
    public void test1272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1272");
        int int2 = sum.Toplama.sum(2311, 4563);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6874 + "'", int2 == 6874);
    }

    @Test
    public void test1273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1273");
        int int2 = sum.Toplama.sum(229, 6971);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7200 + "'", int2 == 7200);
    }

    @Test
    public void test1274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1274");
        int int2 = sum.Toplama.sum(3044, 2923);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5967 + "'", int2 == 5967);
    }

    @Test
    public void test1275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1275");
        int int2 = sum.Toplama.sum(1, 411);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 412 + "'", int2 == 412);
    }

    @Test
    public void test1276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1276");
        int int2 = sum.Toplama.sum(452, 5089);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5541 + "'", int2 == 5541);
    }

    @Test
    public void test1277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1277");
        int int2 = sum.Toplama.sum(315, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 315 + "'", int2 == 315);
    }

    @Test
    public void test1278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1278");
        int int2 = sum.Toplama.sum(7232, 1680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8912 + "'", int2 == 8912);
    }

    @Test
    public void test1279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1279");
        int int2 = sum.Toplama.sum(5041, 12183);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17224 + "'", int2 == 17224);
    }

    @Test
    public void test1280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1280");
        int int2 = sum.Toplama.sum(1877, 455);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2332 + "'", int2 == 2332);
    }

    @Test
    public void test1281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1281");
        int int2 = sum.Toplama.sum(8379, 1639);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10018 + "'", int2 == 10018);
    }

    @Test
    public void test1282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1282");
        int int2 = sum.Toplama.sum(10867, 2466);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13333 + "'", int2 == 13333);
    }

    @Test
    public void test1283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1283");
        int int2 = sum.Toplama.sum(10888, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10888 + "'", int2 == 10888);
    }

    @Test
    public void test1284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1284");
        int int2 = sum.Toplama.sum(3321, 3130);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6451 + "'", int2 == 6451);
    }

    @Test
    public void test1285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1285");
        int int2 = sum.Toplama.sum(3553, 1867);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5420 + "'", int2 == 5420);
    }

    @Test
    public void test1286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1286");
        int int2 = sum.Toplama.sum(1278, 870);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2148 + "'", int2 == 2148);
    }

    @Test
    public void test1287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1287");
        int int2 = sum.Toplama.sum(1965, 756);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2721 + "'", int2 == 2721);
    }

    @Test
    public void test1288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1288");
        int int2 = sum.Toplama.sum(786, 1532);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2318 + "'", int2 == 2318);
    }

    @Test
    public void test1289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1289");
        int int2 = sum.Toplama.sum(5327, 9059);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14386 + "'", int2 == 14386);
    }

    @Test
    public void test1290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1290");
        int int2 = sum.Toplama.sum(1, 412);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 413 + "'", int2 == 413);
    }

    @Test
    public void test1291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1291");
        int int2 = sum.Toplama.sum(392, 4640);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5032 + "'", int2 == 5032);
    }

    @Test
    public void test1292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1292");
        int int2 = sum.Toplama.sum(1265, 3048);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4313 + "'", int2 == 4313);
    }

    @Test
    public void test1293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1293");
        int int2 = sum.Toplama.sum(4369, 2166);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6535 + "'", int2 == 6535);
    }

    @Test
    public void test1294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1294");
        int int2 = sum.Toplama.sum(3422, 4247);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7669 + "'", int2 == 7669);
    }

    @Test
    public void test1295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1295");
        int int2 = sum.Toplama.sum(1315, 4682);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5997 + "'", int2 == 5997);
    }

    @Test
    public void test1296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1296");
        int int2 = sum.Toplama.sum(642, 1037);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1679 + "'", int2 == 1679);
    }

    @Test
    public void test1297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1297");
        int int2 = sum.Toplama.sum(2446, 5166);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7612 + "'", int2 == 7612);
    }

    @Test
    public void test1298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1298");
        int int2 = sum.Toplama.sum(3418, 2252);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5670 + "'", int2 == 5670);
    }

    @Test
    public void test1299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1299");
        int int2 = sum.Toplama.sum(4957, 2355);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7312 + "'", int2 == 7312);
    }

    @Test
    public void test1300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1300");
        int int2 = sum.Toplama.sum(8925, 3075);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12000 + "'", int2 == 12000);
    }

    @Test
    public void test1301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1301");
        int int2 = sum.Toplama.sum(1041, 8912);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9953 + "'", int2 == 9953);
    }

    @Test
    public void test1302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1302");
        int int2 = sum.Toplama.sum(1427, 1417);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2844 + "'", int2 == 2844);
    }

    @Test
    public void test1303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1303");
        int int2 = sum.Toplama.sum(3321, 3487);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6808 + "'", int2 == 6808);
    }

    @Test
    public void test1304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1304");
        int int2 = sum.Toplama.sum(459, 1203);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1662 + "'", int2 == 1662);
    }

    @Test
    public void test1305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1305");
        int int2 = sum.Toplama.sum(3310, 4315);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7625 + "'", int2 == 7625);
    }

    @Test
    public void test1306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1306");
        int int2 = sum.Toplama.sum(4283, 985);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5268 + "'", int2 == 5268);
    }

    @Test
    public void test1307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1307");
        int int2 = sum.Toplama.sum(4310, 1343);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5653 + "'", int2 == 5653);
    }

    @Test
    public void test1308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1308");
        int int2 = sum.Toplama.sum(1365, 8943);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10308 + "'", int2 == 10308);
    }

    @Test
    public void test1309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1309");
        int int2 = sum.Toplama.sum(4229, 2437);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6666 + "'", int2 == 6666);
    }

    @Test
    public void test1310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1310");
        int int2 = sum.Toplama.sum(1716, 10018);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11734 + "'", int2 == 11734);
    }

    @Test
    public void test1311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1311");
        int int2 = sum.Toplama.sum(739, 2660);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3399 + "'", int2 == 3399);
    }

    @Test
    public void test1312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1312");
        int int2 = sum.Toplama.sum(14809, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14809 + "'", int2 == 14809);
    }

    @Test
    public void test1313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1313");
        int int2 = sum.Toplama.sum(2359, 197);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2556 + "'", int2 == 2556);
    }

    @Test
    public void test1314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1314");
        int int2 = sum.Toplama.sum(0, 29019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29019 + "'", int2 == 29019);
    }

    @Test
    public void test1315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1315");
        int int2 = sum.Toplama.sum(2810, 2414);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5224 + "'", int2 == 5224);
    }

    @Test
    public void test1316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1316");
        int int2 = sum.Toplama.sum(5032, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5032 + "'", int2 == 5032);
    }

    @Test
    public void test1317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1317");
        int int2 = sum.Toplama.sum(12000, 1204);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13204 + "'", int2 == 13204);
    }

    @Test
    public void test1318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1318");
        int int2 = sum.Toplama.sum(0, 2504);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2504 + "'", int2 == 2504);
    }

    @Test
    public void test1319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1319");
        int int2 = sum.Toplama.sum(1840, 7030);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8870 + "'", int2 == 8870);
    }

    @Test
    public void test1320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1320");
        int int2 = sum.Toplama.sum(8697, 2253);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10950 + "'", int2 == 10950);
    }

    @Test
    public void test1321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1321");
        int int2 = sum.Toplama.sum(5041, 1698);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6739 + "'", int2 == 6739);
    }

    @Test
    public void test1322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1322");
        int int2 = sum.Toplama.sum(20154, 576);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20730 + "'", int2 == 20730);
    }

    @Test
    public void test1323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1323");
        int int2 = sum.Toplama.sum(2677, 251);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2928 + "'", int2 == 2928);
    }

    @Test
    public void test1324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1324");
        int int2 = sum.Toplama.sum(9689, 3807);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13496 + "'", int2 == 13496);
    }

    @Test
    public void test1325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1325");
        int int2 = sum.Toplama.sum(2355, 96);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2451 + "'", int2 == 2451);
    }

    @Test
    public void test1326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1326");
        int int2 = sum.Toplama.sum(753, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 753 + "'", int2 == 753);
    }

    @Test
    public void test1327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1327");
        int int2 = sum.Toplama.sum(4996, 6078);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11074 + "'", int2 == 11074);
    }

    @Test
    public void test1328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1328");
        int int2 = sum.Toplama.sum(251, 721);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 972 + "'", int2 == 972);
    }

    @Test
    public void test1329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1329");
        int int2 = sum.Toplama.sum(9367, 737);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10104 + "'", int2 == 10104);
    }

    @Test
    public void test1330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1330");
        int int2 = sum.Toplama.sum(5512, 2636);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8148 + "'", int2 == 8148);
    }

    @Test
    public void test1331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1331");
        int int2 = sum.Toplama.sum(5008, 7329);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12337 + "'", int2 == 12337);
    }

    @Test
    public void test1332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1332");
        int int2 = sum.Toplama.sum(11074, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11074 + "'", int2 == 11074);
    }

    @Test
    public void test1333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1333");
        int int2 = sum.Toplama.sum(1536, 931);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2467 + "'", int2 == 2467);
    }

    @Test
    public void test1334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1334");
        int int2 = sum.Toplama.sum(0, 164);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 164 + "'", int2 == 164);
    }

    @Test
    public void test1335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1335");
        int int2 = sum.Toplama.sum(1087, 3553);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4640 + "'", int2 == 4640);
    }

    @Test
    public void test1336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1336");
        int int2 = sum.Toplama.sum(2635, 1339);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3974 + "'", int2 == 3974);
    }

    @Test
    public void test1337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1337");
        int int2 = sum.Toplama.sum(938, 3092);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4030 + "'", int2 == 4030);
    }

    @Test
    public void test1338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1338");
        int int2 = sum.Toplama.sum(5107, 50);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5157 + "'", int2 == 5157);
    }

    @Test
    public void test1339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1339");
        int int2 = sum.Toplama.sum(0, 6593);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6593 + "'", int2 == 6593);
    }

    @Test
    public void test1340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1340");
        int int2 = sum.Toplama.sum(0, 2451);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2451 + "'", int2 == 2451);
    }

    @Test
    public void test1341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1341");
        int int2 = sum.Toplama.sum(4582, 2451);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7033 + "'", int2 == 7033);
    }

    @Test
    public void test1342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1342");
        int int2 = sum.Toplama.sum(5236, 3363);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8599 + "'", int2 == 8599);
    }

    @Test
    public void test1343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1343");
        int int2 = sum.Toplama.sum(7126, 9212);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16338 + "'", int2 == 16338);
    }

    @Test
    public void test1344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1344");
        int int2 = sum.Toplama.sum(9136, 2252);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11388 + "'", int2 == 11388);
    }

    @Test
    public void test1345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1345");
        int int2 = sum.Toplama.sum(5523, 188);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5711 + "'", int2 == 5711);
    }

    @Test
    public void test1346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1346");
        int int2 = sum.Toplama.sum(2359, 1190);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3549 + "'", int2 == 3549);
    }

    @Test
    public void test1347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1347");
        int int2 = sum.Toplama.sum(1622, 50);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1672 + "'", int2 == 1672);
    }

    @Test
    public void test1348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1348");
        int int2 = sum.Toplama.sum(1680, 1735);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3415 + "'", int2 == 3415);
    }

    @Test
    public void test1349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1349");
        int int2 = sum.Toplama.sum(0, 4521);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4521 + "'", int2 == 4521);
    }

    @Test
    public void test1350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1350");
        int int2 = sum.Toplama.sum(5268, 1342);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6610 + "'", int2 == 6610);
    }

    @Test
    public void test1351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1351");
        int int2 = sum.Toplama.sum(10198, 4521);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14719 + "'", int2 == 14719);
    }

    @Test
    public void test1352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1352");
        int int2 = sum.Toplama.sum(0, 8308);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8308 + "'", int2 == 8308);
    }

    @Test
    public void test1353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1353");
        int int2 = sum.Toplama.sum(2411, 15817);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18228 + "'", int2 == 18228);
    }

    @Test
    public void test1354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1354");
        int int2 = sum.Toplama.sum(4744, 2841);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7585 + "'", int2 == 7585);
    }

    @Test
    public void test1355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1355");
        int int2 = sum.Toplama.sum(3135, 106);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3241 + "'", int2 == 3241);
    }

    @Test
    public void test1356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1356");
        int int2 = sum.Toplama.sum(395, 1182);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1577 + "'", int2 == 1577);
    }

    @Test
    public void test1357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1357");
        int int2 = sum.Toplama.sum(2446, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2446 + "'", int2 == 2446);
    }

    @Test
    public void test1358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1358");
        int int2 = sum.Toplama.sum(3943, 3056);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6999 + "'", int2 == 6999);
    }

    @Test
    public void test1359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1359");
        int int2 = sum.Toplama.sum(2102, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2102 + "'", int2 == 2102);
    }

    @Test
    public void test1360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1360");
        int int2 = sum.Toplama.sum(5335, 2504);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7839 + "'", int2 == 7839);
    }

    @Test
    public void test1361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1361");
        int int2 = sum.Toplama.sum(4786, 3740);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8526 + "'", int2 == 8526);
    }

    @Test
    public void test1362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1362");
        int int2 = sum.Toplama.sum(9191, 486);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9677 + "'", int2 == 9677);
    }

    @Test
    public void test1363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1363");
        int int2 = sum.Toplama.sum(3323, 5643);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8966 + "'", int2 == 8966);
    }

    @Test
    public void test1364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1364");
        int int2 = sum.Toplama.sum(3403, 421);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3824 + "'", int2 == 3824);
    }

    @Test
    public void test1365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1365");
        int int2 = sum.Toplama.sum(964, 393);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1357 + "'", int2 == 1357);
    }

    @Test
    public void test1366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1366");
        int int2 = sum.Toplama.sum(1365, 4552);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5917 + "'", int2 == 5917);
    }

    @Test
    public void test1367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1367");
        int int2 = sum.Toplama.sum(1265, 739);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2004 + "'", int2 == 2004);
    }

    @Test
    public void test1368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1368");
        int int2 = sum.Toplama.sum(2466, 5530);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7996 + "'", int2 == 7996);
    }

    @Test
    public void test1369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1369");
        int int2 = sum.Toplama.sum(9563, 2761);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12324 + "'", int2 == 12324);
    }

    @Test
    public void test1370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1370");
        int int2 = sum.Toplama.sum(10039, 2747);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12786 + "'", int2 == 12786);
    }

    @Test
    public void test1371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1371");
        int int2 = sum.Toplama.sum(1532, 5399);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6931 + "'", int2 == 6931);
    }

    @Test
    public void test1372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1372");
        int int2 = sum.Toplama.sum(5403, 4215);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9618 + "'", int2 == 9618);
    }

    @Test
    public void test1373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1373");
        int int2 = sum.Toplama.sum(2067, 680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2747 + "'", int2 == 2747);
    }

    @Test
    public void test1374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1374");
        int int2 = sum.Toplama.sum(4132, 12919);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17051 + "'", int2 == 17051);
    }

    @Test
    public void test1375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1375");
        int int2 = sum.Toplama.sum(17051, 2556);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19607 + "'", int2 == 19607);
    }

    @Test
    public void test1376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1376");
        int int2 = sum.Toplama.sum(997, 53);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1050 + "'", int2 == 1050);
    }

    @Test
    public void test1377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1377");
        int int2 = sum.Toplama.sum(8808, 14206);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23014 + "'", int2 == 23014);
    }

    @Test
    public void test1378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1378");
        int int2 = sum.Toplama.sum(3403, 1622);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5025 + "'", int2 == 5025);
    }

    @Test
    public void test1379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1379");
        int int2 = sum.Toplama.sum(20154, 3026);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23180 + "'", int2 == 23180);
    }

    @Test
    public void test1380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1380");
        int int2 = sum.Toplama.sum(2579, 3766);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6345 + "'", int2 == 6345);
    }

    @Test
    public void test1381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1381");
        int int2 = sum.Toplama.sum(51, 888);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 939 + "'", int2 == 939);
    }

    @Test
    public void test1382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1382");
        int int2 = sum.Toplama.sum(7316, 4542);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11858 + "'", int2 == 11858);
    }

    @Test
    public void test1383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1383");
        int int2 = sum.Toplama.sum(4299, 650);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4949 + "'", int2 == 4949);
    }

    @Test
    public void test1384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1384");
        int int2 = sum.Toplama.sum(4582, 1271);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5853 + "'", int2 == 5853);
    }

    @Test
    public void test1385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1385");
        int int2 = sum.Toplama.sum(7335, 4315);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11650 + "'", int2 == 11650);
    }

    @Test
    public void test1386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1386");
        int int2 = sum.Toplama.sum(1203, 7329);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8532 + "'", int2 == 8532);
    }

    @Test
    public void test1387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1387");
        int int2 = sum.Toplama.sum(3740, 5659);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9399 + "'", int2 == 9399);
    }

    @Test
    public void test1388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1388");
        int int2 = sum.Toplama.sum(1365, 964);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2329 + "'", int2 == 2329);
    }

    @Test
    public void test1389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1389");
        int int2 = sum.Toplama.sum(2134, 11074);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13208 + "'", int2 == 13208);
    }

    @Test
    public void test1390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1390");
        int int2 = sum.Toplama.sum(1976, 9986);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11962 + "'", int2 == 11962);
    }

    @Test
    public void test1391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1391");
        int int2 = sum.Toplama.sum(7312, 1139);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8451 + "'", int2 == 8451);
    }

    @Test
    public void test1392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1392");
        int int2 = sum.Toplama.sum(251, 7335);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7586 + "'", int2 == 7586);
    }

    @Test
    public void test1393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1393");
        int int2 = sum.Toplama.sum(0, 1520);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1520 + "'", int2 == 1520);
    }

    @Test
    public void test1394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1394");
        int int2 = sum.Toplama.sum(1943, 4542);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6485 + "'", int2 == 6485);
    }

    @Test
    public void test1395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1395");
        int int2 = sum.Toplama.sum(2698, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2698 + "'", int2 == 2698);
    }

    @Test
    public void test1396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1396");
        int int2 = sum.Toplama.sum(804, 8951);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9755 + "'", int2 == 9755);
    }

    @Test
    public void test1397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1397");
        int int2 = sum.Toplama.sum(2368, 6574);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8942 + "'", int2 == 8942);
    }

    @Test
    public void test1398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1398");
        int int2 = sum.Toplama.sum(19442, 11715);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31157 + "'", int2 == 31157);
    }

    @Test
    public void test1399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1399");
        int int2 = sum.Toplama.sum(0, 50);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
    }

    @Test
    public void test1400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1400");
        int int2 = sum.Toplama.sum(1177, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1177 + "'", int2 == 1177);
    }

    @Test
    public void test1401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1401");
        int int2 = sum.Toplama.sum(6999, 746);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7745 + "'", int2 == 7745);
    }

    @Test
    public void test1402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1402");
        int int2 = sum.Toplama.sum(6239, 3036);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9275 + "'", int2 == 9275);
    }

    @Test
    public void test1403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1403");
        int int2 = sum.Toplama.sum(4114, 1958);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6072 + "'", int2 == 6072);
    }

    @Test
    public void test1404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1404");
        int int2 = sum.Toplama.sum(13435, 9755);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23190 + "'", int2 == 23190);
    }

    @Test
    public void test1405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1405");
        int int2 = sum.Toplama.sum(8526, 3220);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11746 + "'", int2 == 11746);
    }

    @Test
    public void test1406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1406");
        int int2 = sum.Toplama.sum(3040, 129);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3169 + "'", int2 == 3169);
    }

    @Test
    public void test1407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1407");
        int int2 = sum.Toplama.sum(5533, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5533 + "'", int2 == 5533);
    }

    @Test
    public void test1408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1408");
        int int2 = sum.Toplama.sum(12314, 3048);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15362 + "'", int2 == 15362);
    }

    @Test
    public void test1409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1409");
        int int2 = sum.Toplama.sum(3091, 3527);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6618 + "'", int2 == 6618);
    }

    @Test
    public void test1410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1410");
        int int2 = sum.Toplama.sum(0, 5139);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5139 + "'", int2 == 5139);
    }

    @Test
    public void test1411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1411");
        int int2 = sum.Toplama.sum(4563, 995);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5558 + "'", int2 == 5558);
    }

    @Test
    public void test1412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1412");
        int int2 = sum.Toplama.sum(6084, 575);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6659 + "'", int2 == 6659);
    }

    @Test
    public void test1413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1413");
        int int2 = sum.Toplama.sum(5939, 20730);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26669 + "'", int2 == 26669);
    }

    @Test
    public void test1414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1414");
        int int2 = sum.Toplama.sum(227, 5025);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5252 + "'", int2 == 5252);
    }

    @Test
    public void test1415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1415");
        int int2 = sum.Toplama.sum(3256, 12968);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16224 + "'", int2 == 16224);
    }

    @Test
    public void test1416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1416");
        int int2 = sum.Toplama.sum(3061, 216);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3277 + "'", int2 == 3277);
    }

    @Test
    public void test1417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1417");
        int int2 = sum.Toplama.sum(4169, 2285);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6454 + "'", int2 == 6454);
    }

    @Test
    public void test1418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1418");
        int int2 = sum.Toplama.sum(1963, 5322);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7285 + "'", int2 == 7285);
    }

    @Test
    public void test1419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1419");
        int int2 = sum.Toplama.sum(574, 5639);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6213 + "'", int2 == 6213);
    }

    @Test
    public void test1420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1420");
        int int2 = sum.Toplama.sum(459, 2365);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2824 + "'", int2 == 2824);
    }

    @Test
    public void test1421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1421");
        int int2 = sum.Toplama.sum(9191, 7586);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16777 + "'", int2 == 16777);
    }

    @Test
    public void test1422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1422");
        int int2 = sum.Toplama.sum(4410, 6971);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11381 + "'", int2 == 11381);
    }

    @Test
    public void test1423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1423");
        int int2 = sum.Toplama.sum(7996, 6635);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14631 + "'", int2 == 14631);
    }

    @Test
    public void test1424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1424");
        int int2 = sum.Toplama.sum(3167, 3422);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6589 + "'", int2 == 6589);
    }

    @Test
    public void test1425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1425");
        int int2 = sum.Toplama.sum(0, 31421);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31421 + "'", int2 == 31421);
    }

    @Test
    public void test1426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1426");
        int int2 = sum.Toplama.sum(2056, 8966);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11022 + "'", int2 == 11022);
    }

    @Test
    public void test1427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1427");
        int int2 = sum.Toplama.sum(269, 3427);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3696 + "'", int2 == 3696);
    }

    @Test
    public void test1428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1428");
        int int2 = sum.Toplama.sum(2223, 3403);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5626 + "'", int2 == 5626);
    }

    @Test
    public void test1429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1429");
        int int2 = sum.Toplama.sum(6502, 10931);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17433 + "'", int2 == 17433);
    }

    @Test
    public void test1430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1430");
        int int2 = sum.Toplama.sum(1491, 6085);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7576 + "'", int2 == 7576);
    }

    @Test
    public void test1431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1431");
        int int2 = sum.Toplama.sum(2249, 691);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2940 + "'", int2 == 2940);
    }

    @Test
    public void test1432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1432");
        int int2 = sum.Toplama.sum(902, 1839);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2741 + "'", int2 == 2741);
    }

    @Test
    public void test1433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1433");
        int int2 = sum.Toplama.sum(6808, 1006);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7814 + "'", int2 == 7814);
    }

    @Test
    public void test1434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1434");
        int int2 = sum.Toplama.sum(1311, 4310);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5621 + "'", int2 == 5621);
    }

    @Test
    public void test1435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1435");
        int int2 = sum.Toplama.sum(3924, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3924 + "'", int2 == 3924);
    }

    @Test
    public void test1436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1436");
        int int2 = sum.Toplama.sum(0, 1982);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1982 + "'", int2 == 1982);
    }

    @Test
    public void test1437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1437");
        int int2 = sum.Toplama.sum(5635, 4387);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10022 + "'", int2 == 10022);
    }

    @Test
    public void test1438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1438");
        int int2 = sum.Toplama.sum(5284, 854);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6138 + "'", int2 == 6138);
    }

    @Test
    public void test1439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1439");
        int int2 = sum.Toplama.sum(1110, 1472);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2582 + "'", int2 == 2582);
    }

    @Test
    public void test1440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1440");
        int int2 = sum.Toplama.sum(650, 4337);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4987 + "'", int2 == 4987);
    }

    @Test
    public void test1441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1441");
        int int2 = sum.Toplama.sum(1960, 522);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2482 + "'", int2 == 2482);
    }

    @Test
    public void test1442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1442");
        int int2 = sum.Toplama.sum(4227, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4227 + "'", int2 == 4227);
    }

    @Test
    public void test1443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1443");
        int int2 = sum.Toplama.sum((int) 'a', 557);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 654 + "'", int2 == 654);
    }

    @Test
    public void test1444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1444");
        int int2 = sum.Toplama.sum((int) '4', 14568);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14620 + "'", int2 == 14620);
    }

    @Test
    public void test1445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1445");
        int int2 = sum.Toplama.sum(11219, 8785);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20004 + "'", int2 == 20004);
    }

    @Test
    public void test1446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1446");
        int int2 = sum.Toplama.sum(2659, 624);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3283 + "'", int2 == 3283);
    }

    @Test
    public void test1447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1447");
        int int2 = sum.Toplama.sum(8942, 64);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9006 + "'", int2 == 9006);
    }

    @Test
    public void test1448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1448");
        int int2 = sum.Toplama.sum(31157, 2616);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33773 + "'", int2 == 33773);
    }

    @Test
    public void test1449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1449");
        int int2 = sum.Toplama.sum(1171, 8866);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10037 + "'", int2 == 10037);
    }

    @Test
    public void test1450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1450");
        int int2 = sum.Toplama.sum(7839, 676);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8515 + "'", int2 == 8515);
    }

    @Test
    public void test1451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1451");
        int int2 = sum.Toplama.sum(14719, 6643);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21362 + "'", int2 == 21362);
    }

    @Test
    public void test1452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1452");
        int int2 = sum.Toplama.sum(972, 296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1268 + "'", int2 == 1268);
    }

    @Test
    public void test1453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1453");
        int int2 = sum.Toplama.sum(5157, 561);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5718 + "'", int2 == 5718);
    }

    @Test
    public void test1454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1454");
        int int2 = sum.Toplama.sum(707, 5060);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5767 + "'", int2 == 5767);
    }

    @Test
    public void test1455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1455");
        int int2 = sum.Toplama.sum(1277, 585);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1862 + "'", int2 == 1862);
    }

    @Test
    public void test1456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1456");
        int int2 = sum.Toplama.sum(0, 1531);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1531 + "'", int2 == 1531);
    }

    @Test
    public void test1457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1457");
        int int2 = sum.Toplama.sum(2788, 888);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3676 + "'", int2 == 3676);
    }

    @Test
    public void test1458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1458");
        int int2 = sum.Toplama.sum(814, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 846 + "'", int2 == 846);
    }

    @Test
    public void test1459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1459");
        int int2 = sum.Toplama.sum(7839, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7839 + "'", int2 == 7839);
    }

    @Test
    public void test1460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1460");
        int int2 = sum.Toplama.sum(1260, 464);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1724 + "'", int2 == 1724);
    }

    @Test
    public void test1461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1461");
        int int2 = sum.Toplama.sum(812, 3503);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4315 + "'", int2 == 4315);
    }

    @Test
    public void test1462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1462");
        int int2 = sum.Toplama.sum(491, 610);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1101 + "'", int2 == 1101);
    }

    @Test
    public void test1463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1463");
        int int2 = sum.Toplama.sum(3277, 392);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3669 + "'", int2 == 3669);
    }

    @Test
    public void test1464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1464");
        int int2 = sum.Toplama.sum(13663, 2446);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16109 + "'", int2 == 16109);
    }

    @Test
    public void test1465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1465");
        int int2 = sum.Toplama.sum(519, 347);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 866 + "'", int2 == 866);
    }

    @Test
    public void test1466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1466");
        int int2 = sum.Toplama.sum(5354, 547);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5901 + "'", int2 == 5901);
    }

    @Test
    public void test1467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1467");
        int int2 = sum.Toplama.sum(7954, 739);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8693 + "'", int2 == 8693);
    }

    @Test
    public void test1468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1468");
        int int2 = sum.Toplama.sum(1666, 2897);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4563 + "'", int2 == 4563);
    }

    @Test
    public void test1469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1469");
        int int2 = sum.Toplama.sum(5429, 6850);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12279 + "'", int2 == 12279);
    }

    @Test
    public void test1470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1470");
        int int2 = sum.Toplama.sum(7745, 9311);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17056 + "'", int2 == 17056);
    }

    @Test
    public void test1471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1471");
        int int2 = sum.Toplama.sum(6030, 50);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6080 + "'", int2 == 6080);
    }

    @Test
    public void test1472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1472");
        int int2 = sum.Toplama.sum(3933, 999);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4932 + "'", int2 == 4932);
    }

    @Test
    public void test1473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1473");
        int int2 = sum.Toplama.sum(5299, 3266);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8565 + "'", int2 == 8565);
    }

    @Test
    public void test1474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1474");
        int int2 = sum.Toplama.sum(5711, 2252);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7963 + "'", int2 == 7963);
    }

    @Test
    public void test1475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1475");
        int int2 = sum.Toplama.sum(3696, 1396);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5092 + "'", int2 == 5092);
    }

    @Test
    public void test1476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1476");
        int int2 = sum.Toplama.sum(4337, 2289);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6626 + "'", int2 == 6626);
    }

    @Test
    public void test1477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1477");
        int int2 = sum.Toplama.sum(12363, 4372);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16735 + "'", int2 == 16735);
    }

    @Test
    public void test1478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1478");
        int int2 = sum.Toplama.sum(4149, 2194);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6343 + "'", int2 == 6343);
    }

    @Test
    public void test1479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1479");
        int int2 = sum.Toplama.sum(17224, 359);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17583 + "'", int2 == 17583);
    }

    @Test
    public void test1480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1480");
        int int2 = sum.Toplama.sum(294, 3422);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3716 + "'", int2 == 3716);
    }

    @Test
    public void test1481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1481");
        int int2 = sum.Toplama.sum(5021, 1965);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6986 + "'", int2 == 6986);
    }

    @Test
    public void test1482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1482");
        int int2 = sum.Toplama.sum(5963, 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6062 + "'", int2 == 6062);
    }

    @Test
    public void test1483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1483");
        int int2 = sum.Toplama.sum(0, 575);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 575 + "'", int2 == 575);
    }

    @Test
    public void test1484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1484");
        int int2 = sum.Toplama.sum(1622, 4597);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6219 + "'", int2 == 6219);
    }

    @Test
    public void test1485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1485");
        int int2 = sum.Toplama.sum(10037, 359);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10396 + "'", int2 == 10396);
    }

    @Test
    public void test1486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1486");
        int int2 = sum.Toplama.sum(4486, 3012);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7498 + "'", int2 == 7498);
    }

    @Test
    public void test1487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1487");
        int int2 = sum.Toplama.sum(5327, 786);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6113 + "'", int2 == 6113);
    }

    @Test
    public void test1488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1488");
        int int2 = sum.Toplama.sum(7814, 9212);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17026 + "'", int2 == 17026);
    }

    @Test
    public void test1489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1489");
        int int2 = sum.Toplama.sum(4996, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5028 + "'", int2 == 5028);
    }

    @Test
    public void test1490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1490");
        int int2 = sum.Toplama.sum(3448, 2504);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5952 + "'", int2 == 5952);
    }

    @Test
    public void test1491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1491");
        int int2 = sum.Toplama.sum(1839, 486);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2325 + "'", int2 == 2325);
    }

    @Test
    public void test1492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1492");
        int int2 = sum.Toplama.sum(2414, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2414 + "'", int2 == 2414);
    }

    @Test
    public void test1493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1493");
        int int2 = sum.Toplama.sum(3541, 129);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3670 + "'", int2 == 3670);
    }

    @Test
    public void test1494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1494");
        int int2 = sum.Toplama.sum(5967, 117);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6084 + "'", int2 == 6084);
    }

    @Test
    public void test1495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1495");
        int int2 = sum.Toplama.sum(3737, 1631);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5368 + "'", int2 == 5368);
    }

    @Test
    public void test1496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1496");
        int int2 = sum.Toplama.sum(5440, 4476);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9916 + "'", int2 == 9916);
    }

    @Test
    public void test1497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1497");
        int int2 = sum.Toplama.sum(2735, 5635);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8370 + "'", int2 == 8370);
    }

    @Test
    public void test1498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1498");
        int int2 = sum.Toplama.sum(3974, 812);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4786 + "'", int2 == 4786);
    }

    @Test
    public void test1499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1499");
        int int2 = sum.Toplama.sum(5952, 4093);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10045 + "'", int2 == 10045);
    }

    @Test
    public void test1500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1500");
        int int2 = sum.Toplama.sum(8477, 3832);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12309 + "'", int2 == 12309);
    }
}

