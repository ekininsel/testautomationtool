import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test3501() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3501");
        int int2 = sum.Toplama.sum(29157, 3124);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32281 + "'", int2 == 32281);
    }

    @Test
    public void test3502() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3502");
        int int2 = sum.Toplama.sum(5673, 26159);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31832 + "'", int2 == 31832);
    }

    @Test
    public void test3503() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3503");
        int int2 = sum.Toplama.sum(0, 7996);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7996 + "'", int2 == 7996);
    }

    @Test
    public void test3504() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3504");
        int int2 = sum.Toplama.sum(24495, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24495 + "'", int2 == 24495);
    }

    @Test
    public void test3505() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3505");
        int int2 = sum.Toplama.sum(0, 28913);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28913 + "'", int2 == 28913);
    }

    @Test
    public void test3506() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3506");
        int int2 = sum.Toplama.sum(8808, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8808 + "'", int2 == 8808);
    }

    @Test
    public void test3507() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3507");
        int int2 = sum.Toplama.sum(19036, 37396);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56432 + "'", int2 == 56432);
    }

    @Test
    public void test3508() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3508");
        int int2 = sum.Toplama.sum(24991, 1585);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26576 + "'", int2 == 26576);
    }

    @Test
    public void test3509() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3509");
        int int2 = sum.Toplama.sum(12175, 12578);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24753 + "'", int2 == 24753);
    }

    @Test
    public void test3510() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3510");
        int int2 = sum.Toplama.sum(1970, 9212);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11182 + "'", int2 == 11182);
    }

    @Test
    public void test3511() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3511");
        int int2 = sum.Toplama.sum(8245, 10108);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18353 + "'", int2 == 18353);
    }

    @Test
    public void test3512() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3512");
        int int2 = sum.Toplama.sum(48527, 527);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49054 + "'", int2 == 49054);
    }

    @Test
    public void test3513() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3513");
        int int2 = sum.Toplama.sum(13955, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13987 + "'", int2 == 13987);
    }

    @Test
    public void test3514() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3514");
        int int2 = sum.Toplama.sum(1277, 1370);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2647 + "'", int2 == 2647);
    }

    @Test
    public void test3515() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3515");
        int int2 = sum.Toplama.sum(5368, 8709);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14077 + "'", int2 == 14077);
    }

    @Test
    public void test3516() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3516");
        int int2 = sum.Toplama.sum(12439, 6454);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18893 + "'", int2 == 18893);
    }

    @Test
    public void test3517() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3517");
        int int2 = sum.Toplama.sum(24224, 5067);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29291 + "'", int2 == 29291);
    }

    @Test
    public void test3518() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3518");
        int int2 = sum.Toplama.sum(20969, 27774);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48743 + "'", int2 == 48743);
    }

    @Test
    public void test3519() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3519");
        int int2 = sum.Toplama.sum(1747, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1747 + "'", int2 == 1747);
    }

    @Test
    public void test3520() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3520");
        int int2 = sum.Toplama.sum(4754, 6585);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11339 + "'", int2 == 11339);
    }

    @Test
    public void test3521() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3521");
        int int2 = sum.Toplama.sum(1780, 44099);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45879 + "'", int2 == 45879);
    }

    @Test
    public void test3522() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3522");
        int int2 = sum.Toplama.sum(6239, 5967);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12206 + "'", int2 == 12206);
    }

    @Test
    public void test3523() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3523");
        int int2 = sum.Toplama.sum(26159, 2347);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28506 + "'", int2 == 28506);
    }

    @Test
    public void test3524() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3524");
        int int2 = sum.Toplama.sum(2932, 2701);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5633 + "'", int2 == 5633);
    }

    @Test
    public void test3525() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3525");
        int int2 = sum.Toplama.sum(2895, 7790);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10685 + "'", int2 == 10685);
    }

    @Test
    public void test3526() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3526");
        int int2 = sum.Toplama.sum(4215, 39421);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43636 + "'", int2 == 43636);
    }
}

