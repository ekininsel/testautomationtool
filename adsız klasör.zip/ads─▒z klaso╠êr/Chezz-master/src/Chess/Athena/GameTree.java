package Chess.Athena;

import Chess.Game.GameManager;
import Chess.Utils.SettingsObject;

/**
 * @author Thomas
 * @date 29/04/2017
 * <p>
 * Project: Chezz
 * Package: Chess.Athena
 */
public class GameTree
{
	private Node root;

	private GameTree (SettingsObject so)
	{

	}
}
