import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class InvalidHashExceptionTest7 {

    public static boolean debug = false;

    @Test
    public void test3501() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3501");
        java.lang.Throwable throwable2 = null;
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException3 = new Chess.Exceptions.Checked.InvalidHashException(throwable2);
        java.lang.Class<?> wildcardClass4 = ınvalidHashException3.getClass();
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException5 = new Chess.Exceptions.Checked.InvalidHashException((java.lang.Throwable) ınvalidHashException3);
        java.lang.Throwable throwable6 = null;
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException7 = new Chess.Exceptions.Checked.InvalidHashException(throwable6);
        java.lang.Class<?> wildcardClass8 = ınvalidHashException7.getClass();
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException9 = new Chess.Exceptions.Checked.InvalidHashException((java.lang.Throwable) ınvalidHashException7);
        ınvalidHashException3.addSuppressed((java.lang.Throwable) ınvalidHashException9);
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException11 = new Chess.Exceptions.Checked.InvalidHashException("hi!", (java.lang.Throwable) ınvalidHashException3);
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException12 = new Chess.Exceptions.Checked.InvalidHashException("", (java.lang.Throwable) ınvalidHashException11);
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException13 = new Chess.Exceptions.Checked.InvalidHashException((java.lang.Throwable) ınvalidHashException11);
        java.lang.Class<?> wildcardClass14 = ınvalidHashException11.getClass();
        java.lang.Class<?> wildcardClass15 = ınvalidHashException11.getClass();
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException16 = new Chess.Exceptions.Checked.InvalidHashException((java.lang.Throwable) ınvalidHashException11);
        java.lang.Class<?> wildcardClass17 = ınvalidHashException16.getClass();
        java.lang.Throwable[] throwableArray18 = ınvalidHashException16.getSuppressed();
        java.lang.Throwable throwable20 = null;
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException21 = new Chess.Exceptions.Checked.InvalidHashException(throwable20);
        java.lang.Class<?> wildcardClass22 = ınvalidHashException21.getClass();
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException23 = new Chess.Exceptions.Checked.InvalidHashException((java.lang.Throwable) ınvalidHashException21);
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException25 = new Chess.Exceptions.Checked.InvalidHashException("Chess.Exceptions.Checked.InvalidHashException");
        java.lang.String str26 = ınvalidHashException25.toString();
        ınvalidHashException21.addSuppressed((java.lang.Throwable) ınvalidHashException25);
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException28 = new Chess.Exceptions.Checked.InvalidHashException("Chess.Exceptions.Checked.InvalidHashException", (java.lang.Throwable) ınvalidHashException25);
        ınvalidHashException16.addSuppressed((java.lang.Throwable) ınvalidHashException28);
        java.lang.Class<?> wildcardClass30 = ınvalidHashException28.getClass();
        java.lang.Throwable throwable31 = null;
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException32 = new Chess.Exceptions.Checked.InvalidHashException(throwable31);
        java.lang.Class<?> wildcardClass33 = ınvalidHashException32.getClass();
        java.lang.Class<?> wildcardClass34 = ınvalidHashException32.getClass();
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException35 = new Chess.Exceptions.Checked.InvalidHashException((java.lang.Throwable) ınvalidHashException32);
        ınvalidHashException28.addSuppressed((java.lang.Throwable) ınvalidHashException35);
        java.lang.Class<?> wildcardClass37 = ınvalidHashException35.getClass();
        java.lang.String str38 = ınvalidHashException35.toString();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException" + "'", str26.equals("Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException"));
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException" + "'", str38.equals("Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException"));
    }

    @Test
    public void test3502() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test3502");
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException4 = new Chess.Exceptions.Checked.InvalidHashException("Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException");
        java.lang.Throwable[] throwableArray5 = ınvalidHashException4.getSuppressed();
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException6 = new Chess.Exceptions.Checked.InvalidHashException("Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException: hi!", (java.lang.Throwable) ınvalidHashException4);
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException7 = new Chess.Exceptions.Checked.InvalidHashException("Chess.Exceptions.Checked.InvalidHashException", (java.lang.Throwable) ınvalidHashException6);
        java.lang.Throwable[] throwableArray8 = ınvalidHashException6.getSuppressed();
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException9 = new Chess.Exceptions.Checked.InvalidHashException((java.lang.Throwable) ınvalidHashException6);
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException10 = new Chess.Exceptions.Checked.InvalidHashException((java.lang.Throwable) ınvalidHashException6);
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException11 = new Chess.Exceptions.Checked.InvalidHashException("Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException", (java.lang.Throwable) ınvalidHashException10);
        java.lang.String str12 = ınvalidHashException11.toString();
        java.lang.Class<?> wildcardClass13 = ınvalidHashException11.getClass();
        java.lang.Throwable throwable20 = null;
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException21 = new Chess.Exceptions.Checked.InvalidHashException(throwable20);
        java.lang.Class<?> wildcardClass22 = ınvalidHashException21.getClass();
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException23 = new Chess.Exceptions.Checked.InvalidHashException((java.lang.Throwable) ınvalidHashException21);
        java.lang.String str24 = ınvalidHashException23.toString();
        java.lang.String str25 = ınvalidHashException23.toString();
        java.lang.String str26 = ınvalidHashException23.toString();
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException27 = new Chess.Exceptions.Checked.InvalidHashException((java.lang.Throwable) ınvalidHashException23);
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException28 = new Chess.Exceptions.Checked.InvalidHashException("hi!", (java.lang.Throwable) ınvalidHashException23);
        java.lang.Class<?> wildcardClass29 = ınvalidHashException28.getClass();
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException30 = new Chess.Exceptions.Checked.InvalidHashException("hi!", (java.lang.Throwable) ınvalidHashException28);
        java.lang.Throwable[] throwableArray31 = ınvalidHashException30.getSuppressed();
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException32 = new Chess.Exceptions.Checked.InvalidHashException("Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException: hi!", (java.lang.Throwable) ınvalidHashException30);
        java.lang.Throwable throwable33 = null;
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException34 = new Chess.Exceptions.Checked.InvalidHashException(throwable33);
        java.lang.Class<?> wildcardClass35 = ınvalidHashException34.getClass();
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException36 = new Chess.Exceptions.Checked.InvalidHashException((java.lang.Throwable) ınvalidHashException34);
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException37 = new Chess.Exceptions.Checked.InvalidHashException();
        ınvalidHashException36.addSuppressed((java.lang.Throwable) ınvalidHashException37);
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException39 = new Chess.Exceptions.Checked.InvalidHashException((java.lang.Throwable) ınvalidHashException37);
        java.lang.Throwable throwable42 = null;
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException43 = new Chess.Exceptions.Checked.InvalidHashException(throwable42);
        java.lang.Class<?> wildcardClass44 = ınvalidHashException43.getClass();
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException45 = new Chess.Exceptions.Checked.InvalidHashException((java.lang.Throwable) ınvalidHashException43);
        java.lang.Throwable throwable46 = null;
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException47 = new Chess.Exceptions.Checked.InvalidHashException(throwable46);
        java.lang.Class<?> wildcardClass48 = ınvalidHashException47.getClass();
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException49 = new Chess.Exceptions.Checked.InvalidHashException((java.lang.Throwable) ınvalidHashException47);
        ınvalidHashException43.addSuppressed((java.lang.Throwable) ınvalidHashException49);
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException51 = new Chess.Exceptions.Checked.InvalidHashException("hi!", (java.lang.Throwable) ınvalidHashException43);
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException52 = new Chess.Exceptions.Checked.InvalidHashException("", (java.lang.Throwable) ınvalidHashException51);
        java.lang.Class<?> wildcardClass53 = ınvalidHashException52.getClass();
        ınvalidHashException39.addSuppressed((java.lang.Throwable) ınvalidHashException52);
        java.lang.Class<?> wildcardClass55 = ınvalidHashException39.getClass();
        java.lang.Class<?> wildcardClass56 = ınvalidHashException39.getClass();
        ınvalidHashException30.addSuppressed((java.lang.Throwable) ınvalidHashException39);
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException58 = new Chess.Exceptions.Checked.InvalidHashException("Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException: ", (java.lang.Throwable) ınvalidHashException30);
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException59 = new Chess.Exceptions.Checked.InvalidHashException("Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException: ", (java.lang.Throwable) ınvalidHashException58);
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException60 = new Chess.Exceptions.Checked.InvalidHashException("Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException", (java.lang.Throwable) ınvalidHashException59);
        ınvalidHashException11.addSuppressed((java.lang.Throwable) ınvalidHashException59);
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException64 = new Chess.Exceptions.Checked.InvalidHashException("Chess.Exceptions.Checked.InvalidHashException: hi!");
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException65 = new Chess.Exceptions.Checked.InvalidHashException((java.lang.Throwable) ınvalidHashException64);
        Chess.Exceptions.Checked.InvalidHashException ınvalidHashException66 = new Chess.Exceptions.Checked.InvalidHashException("Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException: hi!", (java.lang.Throwable) ınvalidHashException65);
        ınvalidHashException11.addSuppressed((java.lang.Throwable) ınvalidHashException66);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException" + "'", str12.equals("Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException"));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException" + "'", str24.equals("Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException" + "'", str25.equals("Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException" + "'", str26.equals("Chess.Exceptions.Checked.InvalidHashException: Chess.Exceptions.Checked.InvalidHashException"));
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(wildcardClass56);
    }
}

