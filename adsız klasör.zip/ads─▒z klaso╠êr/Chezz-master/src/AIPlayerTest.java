import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ AIPlayerTest0.class, AIPlayerTest1.class, AIPlayerTest2.class, AIPlayerTest3.class, AIPlayerTest4.class, AIPlayerTest5.class, AIPlayerTest6.class, AIPlayerTest7.class, AIPlayerTest8.class, AIPlayerTest9.class, AIPlayerTest10.class })
public class AIPlayerTest {
}

