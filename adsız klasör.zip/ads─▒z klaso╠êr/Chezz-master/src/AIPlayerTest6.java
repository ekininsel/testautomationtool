import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AIPlayerTest6 {

    public static boolean debug = false;

    @Test
    public void test3001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3001");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3002");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager5 = null;
        try {
            Chess.Game.Move move6 = aIPlayer2.playTurn(gameManager5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test3003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3003");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, (int) ' ');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3004");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3005");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager7 = null;
        try {
            Chess.Game.Move move8 = aIPlayer2.playTurn(gameManager7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test3006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3006");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3007");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3008");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3009");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3010");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3011");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, (int) 'a');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3012");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3013");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3014");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3015");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) -1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3016");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3017");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3018");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3019");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3020");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 1, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager7 = null;
        try {
            Chess.Game.Move move8 = aIPlayer2.playTurn(gameManager7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test3021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3021");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3022");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3023");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', (int) ' ');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3024");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3025");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager7 = null;
        try {
            Chess.Game.Move move8 = aIPlayer2.playTurn(gameManager7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test3026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3026");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3027");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3028");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3029");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3030");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3031");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager7 = null;
        try {
            Chess.Game.Move move8 = aIPlayer2.playTurn(gameManager7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test3032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3032");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager4 = null;
        try {
            Chess.Game.Move move5 = aIPlayer2.playTurn(gameManager4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test3033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3033");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3034");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, (int) (short) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3035");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3036");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3037");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, (int) (short) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager7 = null;
        try {
            Chess.Game.Move move8 = aIPlayer2.playTurn(gameManager7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test3038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3038");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, (int) 'a');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3039");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3040");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3041");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager6 = null;
        try {
            Chess.Game.Move move7 = aIPlayer2.playTurn(gameManager6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test3042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3042");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3043");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3044");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager7 = null;
        try {
            Chess.Game.Move move8 = aIPlayer2.playTurn(gameManager7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test3045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3045");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 1, (int) ' ');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3046");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (int) ' ');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3047");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3048");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3049");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3050");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3051");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3052");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3053");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager6 = null;
        try {
            Chess.Game.Move move7 = aIPlayer2.playTurn(gameManager6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test3054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3054");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager5 = null;
        try {
            Chess.Game.Move move6 = aIPlayer2.playTurn(gameManager5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test3055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3055");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3056");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, (int) 'a');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3057");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3058");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3059");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3060");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3061");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3062");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3063");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3064");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3065");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3066");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3067");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3068");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3069");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3070");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) -1, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3071");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3072");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3073");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager5 = null;
        try {
            Chess.Game.Move move6 = aIPlayer2.playTurn(gameManager5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test3074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3074");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3075");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3076");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3077");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3078");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass20 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager21 = null;
        try {
            Chess.Game.Move move22 = aIPlayer2.playTurn(gameManager21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test3079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3079");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 1, 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3080");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3081");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager6 = null;
        try {
            Chess.Game.Move move7 = aIPlayer2.playTurn(gameManager6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test3082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3082");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, (int) (short) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager19 = null;
        try {
            Chess.Game.Move move20 = aIPlayer2.playTurn(gameManager19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test3083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3083");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3084");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3085");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (int) 'a');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3086");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3087");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test3088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3088");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3089");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test3090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3090");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3091");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test3092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3092");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3093");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3094");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, (int) ' ');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3095");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3096");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3097");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3098");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) (short) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3099");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3100");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3101");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 1, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3102");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) (short) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3103");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3104");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3105");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3106");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager7 = null;
        try {
            Chess.Game.Move move8 = aIPlayer2.playTurn(gameManager7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test3107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3107");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3108");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3109");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3110");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) 'a');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3111");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3112");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3113");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager6 = null;
        try {
            Chess.Game.Move move7 = aIPlayer2.playTurn(gameManager6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test3114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3114");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3115");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3116");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3117");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3118");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 1, (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3119");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3120");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3121");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3122");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3123");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3124");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', (int) 'a');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3125");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3126");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3127");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 1, (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3128");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3129");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, (int) ' ');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3130");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3131");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3132");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3133");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3134");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3135");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', (int) 'a');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3136");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3137");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 1, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3138");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 1, (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3139");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3140");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3141");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3142");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 1, (int) ' ');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test3143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3143");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager19 = null;
        try {
            Chess.Game.Move move20 = aIPlayer2.playTurn(gameManager19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test3144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3144");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3145");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 1, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3146");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3147");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3148");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 1, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3149");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) -1, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3150");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager17 = null;
        try {
            Chess.Game.Move move18 = aIPlayer2.playTurn(gameManager17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test3151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3151");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3152");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager7 = null;
        try {
            Chess.Game.Move move8 = aIPlayer2.playTurn(gameManager7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test3153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3153");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3154");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 1, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3155");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 1, (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3156");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3157");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager5 = null;
        try {
            Chess.Game.Move move6 = aIPlayer2.playTurn(gameManager5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test3158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3158");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, (int) 'a');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3159");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 1, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3160");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3161");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) 'a');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3162");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3163");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3164");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) -1, (int) 'a');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager18 = null;
        try {
            Chess.Game.Move move19 = aIPlayer2.playTurn(gameManager18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test3165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3165");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3166");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3167");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3168");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3169");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3170");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 1, (int) 'a');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3171");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3172");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3173");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3174");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager5 = null;
        try {
            Chess.Game.Move move6 = aIPlayer2.playTurn(gameManager5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test3175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3175");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3176");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3177");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3178");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, (int) ' ');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3179");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager17 = null;
        try {
            Chess.Game.Move move18 = aIPlayer2.playTurn(gameManager17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test3180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3180");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3181");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3182");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager19 = null;
        try {
            Chess.Game.Move move20 = aIPlayer2.playTurn(gameManager19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test3183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3183");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test3184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3184");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3185");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3186");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3187");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3188");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3189");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3190");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3191");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3192");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3193");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3194");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3195");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 1, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3196");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager17 = null;
        try {
            Chess.Game.Move move18 = aIPlayer2.playTurn(gameManager17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test3197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3197");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3198");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager7 = null;
        try {
            Chess.Game.Move move8 = aIPlayer2.playTurn(gameManager7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test3199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3199");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 1, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3200");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3201");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3202");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) -1, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3203");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3204");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager7 = null;
        try {
            Chess.Game.Move move8 = aIPlayer2.playTurn(gameManager7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test3205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3205");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager7 = null;
        try {
            Chess.Game.Move move8 = aIPlayer2.playTurn(gameManager7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test3206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3206");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3207");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3208");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3209");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (int) (short) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3210");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager17 = null;
        try {
            Chess.Game.Move move18 = aIPlayer2.playTurn(gameManager17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test3211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3211");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 1, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3212");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3213");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3214");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass20 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass21 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager22 = null;
        try {
            Chess.Game.Move move23 = aIPlayer2.playTurn(gameManager22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test3215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3215");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3216");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager7 = null;
        try {
            Chess.Game.Move move8 = aIPlayer2.playTurn(gameManager7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test3217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3217");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, (int) (short) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager18 = null;
        try {
            Chess.Game.Move move19 = aIPlayer2.playTurn(gameManager18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test3218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3218");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3219");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) -1, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager7 = null;
        try {
            Chess.Game.Move move8 = aIPlayer2.playTurn(gameManager7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test3220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3220");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3221");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3222");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3223");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', (int) (short) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3224");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3225");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3226");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3227");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3228");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3229");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3230");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 1, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3231");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3232");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3233");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, (int) (short) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3234");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager7 = null;
        try {
            Chess.Game.Move move8 = aIPlayer2.playTurn(gameManager7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test3235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3235");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3236");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager18 = null;
        try {
            Chess.Game.Move move19 = aIPlayer2.playTurn(gameManager18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test3237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3237");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3238");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager7 = null;
        try {
            Chess.Game.Move move8 = aIPlayer2.playTurn(gameManager7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test3239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3239");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3240");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3241");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3242");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3243");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3244");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3245");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test3246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3246");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 1, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3247");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 1, (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3248");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager20 = null;
        try {
            Chess.Game.Move move21 = aIPlayer2.playTurn(gameManager20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test3249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3249");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test3250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3250");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3251");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3252");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3253");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3254");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3255");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3256");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', (int) (short) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3257");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3258");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, (int) ' ');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3259");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3260");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3261");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3262");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, (int) 'a');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3263");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 1, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3264");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3265");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test3266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3266");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test3267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3267");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager7 = null;
        try {
            Chess.Game.Move move8 = aIPlayer2.playTurn(gameManager7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test3268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3268");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 1, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3269");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3270");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3271");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3272");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 1, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3273");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3274");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3275");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3276");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3277");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 1, (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3278");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3279");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, (int) ' ');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3280");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3281");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager5 = null;
        try {
            Chess.Game.Move move6 = aIPlayer2.playTurn(gameManager5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test3282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3282");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager17 = null;
        try {
            Chess.Game.Move move18 = aIPlayer2.playTurn(gameManager17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test3283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3283");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3284");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', (int) (short) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3285");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3286");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3287");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3288");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test3289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3289");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) (short) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3290");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3291");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3292");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3293");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 1, (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3294");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager17 = null;
        try {
            Chess.Game.Move move18 = aIPlayer2.playTurn(gameManager17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test3295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3295");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3296");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test3297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3297");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3298");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3299");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, (int) (short) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager19 = null;
        try {
            Chess.Game.Move move20 = aIPlayer2.playTurn(gameManager19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test3300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3300");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3301");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3302");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3303");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3304");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3305");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3306");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager19 = null;
        try {
            Chess.Game.Move move20 = aIPlayer2.playTurn(gameManager19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test3307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3307");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3308");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 1, (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3309");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, (int) ' ');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3310");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3311");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager17 = null;
        try {
            Chess.Game.Move move18 = aIPlayer2.playTurn(gameManager17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test3312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3312");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (int) (short) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3313");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3314");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager17 = null;
        try {
            Chess.Game.Move move18 = aIPlayer2.playTurn(gameManager17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test3315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3315");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test3316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3316");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) -1, (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3317");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager19 = null;
        try {
            Chess.Game.Move move20 = aIPlayer2.playTurn(gameManager19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test3318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3318");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3319");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager20 = null;
        try {
            Chess.Game.Move move21 = aIPlayer2.playTurn(gameManager20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test3320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3320");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3321");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3322");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3323");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', (int) ' ');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3324");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3325");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager20 = null;
        try {
            Chess.Game.Move move21 = aIPlayer2.playTurn(gameManager20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test3326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3326");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3327");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3328");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3329");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) -1, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3330");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3331");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager17 = null;
        try {
            Chess.Game.Move move18 = aIPlayer2.playTurn(gameManager17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test3332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3332");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3333");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager18 = null;
        try {
            Chess.Game.Move move19 = aIPlayer2.playTurn(gameManager18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test3334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3334");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, (int) (short) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager5 = null;
        try {
            Chess.Game.Move move6 = aIPlayer2.playTurn(gameManager5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test3335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3335");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) -1, (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3336");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager18 = null;
        try {
            Chess.Game.Move move19 = aIPlayer2.playTurn(gameManager18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test3337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3337");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test3338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3338");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3339");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3340");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager17 = null;
        try {
            Chess.Game.Move move18 = aIPlayer2.playTurn(gameManager17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test3341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3341");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3342");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) (short) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3343");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3344");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3345");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3346");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, (int) (short) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3347");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) -1, (int) ' ');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3348");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3349");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager6 = null;
        try {
            Chess.Game.Move move7 = aIPlayer2.playTurn(gameManager6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test3350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3350");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test3351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3351");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, (int) ' ');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3352");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3353");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3354");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3355");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3356");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3357");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 1, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3358");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3359");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3360");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager18 = null;
        try {
            Chess.Game.Move move19 = aIPlayer2.playTurn(gameManager18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test3361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3361");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) ' ');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3362");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', (int) 'a');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3363");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 1, (int) (short) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3364");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3365");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager7 = null;
        try {
            Chess.Game.Move move8 = aIPlayer2.playTurn(gameManager7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test3366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3366");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3367");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3368");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, (int) 'a');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3369");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3370");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3371");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3372");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3373");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3374");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 1, (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3375");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, (int) 'a');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3376");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3377");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, (int) (short) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3378");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) -1, (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3379");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3380");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3381");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3382");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3383");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3384");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3385");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, (int) 'a');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager17 = null;
        try {
            Chess.Game.Move move18 = aIPlayer2.playTurn(gameManager17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test3386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3386");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 1, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3387");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3388");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3389");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager17 = null;
        try {
            Chess.Game.Move move18 = aIPlayer2.playTurn(gameManager17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test3390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3390");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager6 = null;
        try {
            Chess.Game.Move move7 = aIPlayer2.playTurn(gameManager6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test3391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3391");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 1, (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3392");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 1, (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3393");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3394");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager17 = null;
        try {
            Chess.Game.Move move18 = aIPlayer2.playTurn(gameManager17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test3395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3395");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) 'a');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3396");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3397");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3398");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3399");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3400");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3401");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3402");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager17 = null;
        try {
            Chess.Game.Move move18 = aIPlayer2.playTurn(gameManager17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test3403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3403");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3404");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager17 = null;
        try {
            Chess.Game.Move move18 = aIPlayer2.playTurn(gameManager17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test3405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3405");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager19 = null;
        try {
            Chess.Game.Move move20 = aIPlayer2.playTurn(gameManager19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test3406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3406");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager5 = null;
        try {
            Chess.Game.Move move6 = aIPlayer2.playTurn(gameManager5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test3407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3407");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) (short) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3408");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test3409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3409");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, (int) (short) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3410");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager17 = null;
        try {
            Chess.Game.Move move18 = aIPlayer2.playTurn(gameManager17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test3411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3411");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager7 = null;
        try {
            Chess.Game.Move move8 = aIPlayer2.playTurn(gameManager7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test3412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3412");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 1, (int) ' ');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3413");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager20 = null;
        try {
            Chess.Game.Move move21 = aIPlayer2.playTurn(gameManager20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test3414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3414");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3415");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3416");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3417");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 1, (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3418");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, (int) ' ');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3419");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3420");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3421");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) -1, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3422");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) 'a');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3423");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager18 = null;
        try {
            Chess.Game.Move move19 = aIPlayer2.playTurn(gameManager18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test3424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3424");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager17 = null;
        try {
            Chess.Game.Move move18 = aIPlayer2.playTurn(gameManager17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test3425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3425");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3426");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3427");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, (int) (short) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3428");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) -1, 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3429");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 1, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3430");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3431");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager17 = null;
        try {
            Chess.Game.Move move18 = aIPlayer2.playTurn(gameManager17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test3432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3432");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3433");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, (int) 'a');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test3434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3434");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3435");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, (int) ' ');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3436");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3437");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3438");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3439");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3440");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, (int) ' ');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3441");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3442");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3443");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3444");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3445");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3446");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) ' ');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager19 = null;
        try {
            Chess.Game.Move move20 = aIPlayer2.playTurn(gameManager19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test3447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3447");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3448");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3449");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3450");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3451");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3452");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3453");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3454");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 1, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test3455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3455");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3456");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3457");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager6 = null;
        try {
            Chess.Game.Move move7 = aIPlayer2.playTurn(gameManager6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test3458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3458");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test3459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3459");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3460");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) -1, (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager18 = null;
        try {
            Chess.Game.Move move19 = aIPlayer2.playTurn(gameManager18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test3461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3461");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3462");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3463");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager6 = null;
        try {
            Chess.Game.Move move7 = aIPlayer2.playTurn(gameManager6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test3464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3464");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3465");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3466");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 1, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager17 = null;
        try {
            Chess.Game.Move move18 = aIPlayer2.playTurn(gameManager17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test3467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3467");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass20 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass21 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager22 = null;
        try {
            Chess.Game.Move move23 = aIPlayer2.playTurn(gameManager22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test3468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3468");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3469");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3470");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test3471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3471");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3472");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3473");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager9 = null;
        try {
            Chess.Game.Move move10 = aIPlayer2.playTurn(gameManager9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test3474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3474");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3475");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, (int) (short) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager20 = null;
        try {
            Chess.Game.Move move21 = aIPlayer2.playTurn(gameManager20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test3476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3476");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager19 = null;
        try {
            Chess.Game.Move move20 = aIPlayer2.playTurn(gameManager19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test3477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3477");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3478");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, (int) 'a');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3479");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', (int) (short) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3480");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3481");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3482");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3483");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3484");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3485");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager8 = null;
        try {
            Chess.Game.Move move9 = aIPlayer2.playTurn(gameManager8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test3486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3486");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3487");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager17 = null;
        try {
            Chess.Game.Move move18 = aIPlayer2.playTurn(gameManager17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test3488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3488");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) -1, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3489");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager18 = null;
        try {
            Chess.Game.Move move19 = aIPlayer2.playTurn(gameManager18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test3490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3490");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test3491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3491");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test3492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3492");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test3493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3493");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test3494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3494");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3495");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass20 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager21 = null;
        try {
            Chess.Game.Move move22 = aIPlayer2.playTurn(gameManager21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test3496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3496");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test3497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3497");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager19 = null;
        try {
            Chess.Game.Move move20 = aIPlayer2.playTurn(gameManager19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test3498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3498");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager11 = null;
        try {
            Chess.Game.Move move12 = aIPlayer2.playTurn(gameManager11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test3499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3499");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test3500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test3500");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) -1, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }
}

