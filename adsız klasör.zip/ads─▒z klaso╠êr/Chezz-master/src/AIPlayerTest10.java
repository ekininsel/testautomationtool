import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AIPlayerTest10 {

    public static boolean debug = false;

    @Test
    public void test5001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5001");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass20 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test5002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5002");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager17 = null;
        try {
            Chess.Game.Move move18 = aIPlayer2.playTurn(gameManager17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test5003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5003");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager20 = null;
        try {
            Chess.Game.Move move21 = aIPlayer2.playTurn(gameManager20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test5004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5004");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test5005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5005");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test5006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5006");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) 'a');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager18 = null;
        try {
            Chess.Game.Move move19 = aIPlayer2.playTurn(gameManager18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test5007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5007");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test5008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5008");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, (int) 'a');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager18 = null;
        try {
            Chess.Game.Move move19 = aIPlayer2.playTurn(gameManager18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test5009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5009");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test5010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5010");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test5011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5011");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) (short) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager18 = null;
        try {
            Chess.Game.Move move19 = aIPlayer2.playTurn(gameManager18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test5012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5012");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test5013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5013");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test5014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5014");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 1, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test5015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5015");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, (int) 'a');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test5016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5016");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test5017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5017");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 1, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test5018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5018");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager19 = null;
        try {
            Chess.Game.Move move20 = aIPlayer2.playTurn(gameManager19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test5019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5019");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) -1, (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test5020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5020");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test5021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5021");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 1, (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test5022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5022");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) -1, (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass20 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass21 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test5023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5023");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test5024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5024");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test5025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5025");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass20 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass21 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test5026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5026");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test5027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5027");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test5028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5028");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager19 = null;
        try {
            Chess.Game.Move move20 = aIPlayer2.playTurn(gameManager19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test5029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5029");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test5030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5030");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test5031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5031");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test5032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5032");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass20 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass21 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass22 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager23 = null;
        try {
            Chess.Game.Move move24 = aIPlayer2.playTurn(gameManager23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test5033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5033");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager19 = null;
        try {
            Chess.Game.Move move20 = aIPlayer2.playTurn(gameManager19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test5034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5034");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test5035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5035");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager14 = null;
        try {
            Chess.Game.Move move15 = aIPlayer2.playTurn(gameManager14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test5036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5036");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test5037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5037");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 1, (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass20 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass21 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test5038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5038");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test5039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5039");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test5040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5040");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager18 = null;
        try {
            Chess.Game.Move move19 = aIPlayer2.playTurn(gameManager18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test5041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5041");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(0, (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test5042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5042");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test5043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5043");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager12 = null;
        try {
            Chess.Game.Move move13 = aIPlayer2.playTurn(gameManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test5044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5044");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test5045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5045");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test5046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5046");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test5047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5047");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 1, (int) '4');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test5048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5048");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass20 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass21 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass22 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test5049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5049");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) -1, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager18 = null;
        try {
            Chess.Game.Move move19 = aIPlayer2.playTurn(gameManager18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test5050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5050");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 0, (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test5051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5051");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 1, (int) (short) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test5052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5052");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager17 = null;
        try {
            Chess.Game.Move move18 = aIPlayer2.playTurn(gameManager17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test5053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5053");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test5054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5054");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(100, (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test5055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5055");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test5056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5056");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass20 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass21 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass22 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass23 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass24 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass25 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass26 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass27 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass28 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager29 = null;
        try {
            Chess.Game.Move move30 = aIPlayer2.playTurn(gameManager29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

    @Test
    public void test5057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5057");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) -1, (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test5058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5058");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test5059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5059");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, (int) (byte) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test5060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5060");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '4', 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test5061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5061");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass20 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test5062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5062");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager10 = null;
        try {
            Chess.Game.Move move11 = aIPlayer2.playTurn(gameManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test5063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5063");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, (int) ' ');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test5064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5064");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test5065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5065");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test5066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5066");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 1, (int) ' ');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test5067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5067");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 10, (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test5068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5068");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) ' ');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test5069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5069");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass20 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass21 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test5070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5070");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test5071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5071");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 100, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass20 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass21 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass22 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass23 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass24 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass25 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass26 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass27 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass28 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass29 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass30 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(wildcardClass30);
    }

    @Test
    public void test5072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5072");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test5073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5073");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 1, (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager17 = null;
        try {
            Chess.Game.Move move18 = aIPlayer2.playTurn(gameManager17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test5074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5074");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager15 = null;
        try {
            Chess.Game.Move move16 = aIPlayer2.playTurn(gameManager15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test5075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5075");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) (short) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager20 = null;
        try {
            Chess.Game.Move move21 = aIPlayer2.playTurn(gameManager20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test5076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5076");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 100, (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test5077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5077");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager17 = null;
        try {
            Chess.Game.Move move18 = aIPlayer2.playTurn(gameManager17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test5078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5078");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) ' ', (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test5079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5079");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(1, 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass20 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass21 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test5080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5080");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((-1), (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test5081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5081");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, 100);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager20 = null;
        try {
            Chess.Game.Move move21 = aIPlayer2.playTurn(gameManager20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test5082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5082");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer(10, (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test5083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5083");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 10, (-1));
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test5084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5084");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) -1, 1);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test5085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5085");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (short) 1, (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test5086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5086");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) -1, (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass18 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass19 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager20 = null;
        try {
            Chess.Game.Move move21 = aIPlayer2.playTurn(gameManager20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test5087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5087");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) 'a', (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager13 = null;
        try {
            Chess.Game.Move move14 = aIPlayer2.playTurn(gameManager13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test5088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5088");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 0, (int) (byte) 0);
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass16 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass17 = aIPlayer2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test5089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test5089");
        Chess.Athena.AIPlayer aIPlayer2 = new Chess.Athena.AIPlayer((int) (byte) 1, (int) '#');
        java.lang.Class<?> wildcardClass3 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass4 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass5 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass6 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass7 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass8 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass9 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass10 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass11 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass12 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass13 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass14 = aIPlayer2.getClass();
        java.lang.Class<?> wildcardClass15 = aIPlayer2.getClass();
        Chess.Game.GameManager gameManager16 = null;
        try {
            Chess.Game.Move move17 = aIPlayer2.playTurn(gameManager16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }
}

