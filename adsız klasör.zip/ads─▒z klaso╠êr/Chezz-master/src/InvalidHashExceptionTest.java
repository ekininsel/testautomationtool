import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ InvalidHashExceptionTest0.class, InvalidHashExceptionTest1.class, InvalidHashExceptionTest2.class, InvalidHashExceptionTest3.class, InvalidHashExceptionTest4.class, InvalidHashExceptionTest5.class, InvalidHashExceptionTest6.class, InvalidHashExceptionTest7.class })
public class InvalidHashExceptionTest {
}

