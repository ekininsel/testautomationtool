import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class GameStateTest5 {

    public static boolean debug = false;

    @Test
    public void test2501() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2501");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = gameState12.getClass();
        java.lang.Class<?> wildcardClass14 = gameState12.getClass();
        java.lang.Class<?> wildcardClass15 = gameState12.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test2502() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2502");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = gameState19.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2503() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2503");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        java.lang.Class<?> wildcardClass24 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test2504() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2504");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = gameState15.getClass();
        java.lang.Class<?> wildcardClass17 = gameState15.getClass();
        java.lang.Class<?> wildcardClass18 = gameState15.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test2505() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2505");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        java.lang.Class<?> wildcardClass24 = moveList1.getClass();
        Chess.Athena.GameState gameState25 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test2506() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2506");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2507() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2507");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass24 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test2508() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2508");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = gameState16.getClass();
        java.lang.Class<?> wildcardClass18 = gameState16.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test2509() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2509");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass24 = gameState23.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test2510() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2510");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        Chess.Athena.GameState gameState5 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test2511() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2511");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = gameState20.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2512() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2512");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test2513() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2513");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        java.lang.Class<?> wildcardClass24 = moveList1.getClass();
        Chess.Athena.GameState gameState25 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState26 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test2514() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2514");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = gameState18.getClass();
        java.lang.Class<?> wildcardClass20 = gameState18.getClass();
        java.lang.Class<?> wildcardClass21 = gameState18.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2515() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2515");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test2516() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2516");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = gameState19.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2517() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2517");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test2518() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2518");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState25 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState26 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test2519() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2519");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test2520() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2520");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = gameState9.getClass();
        java.lang.Class<?> wildcardClass11 = gameState9.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test2521() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2521");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = gameState14.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test2522() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2522");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = gameState20.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2523() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2523");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test2524() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2524");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test2525() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2525");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test2526() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2526");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test2527() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2527");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass22 = gameState21.getClass();
        java.lang.Class<?> wildcardClass23 = gameState21.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test2528() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2528");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test2529() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2529");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2530() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2530");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = gameState18.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test2531() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2531");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test2532() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2532");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2533() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2533");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass24 = moveList1.getClass();
        Chess.Athena.GameState gameState25 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test2534() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2534");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2535() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2535");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test2536() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2536");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        Chess.Athena.GameState gameState5 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = gameState12.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test2537() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2537");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = gameState16.getClass();
        java.lang.Class<?> wildcardClass18 = gameState16.getClass();
        java.lang.Class<?> wildcardClass19 = gameState16.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test2538() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2538");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState25 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState26 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass27 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

    @Test
    public void test2539() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2539");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test2540() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2540");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2541() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2541");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2542() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2542");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        java.lang.Class<?> wildcardClass24 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test2543() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2543");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState4 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = gameState16.getClass();
        java.lang.Class<?> wildcardClass18 = gameState16.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test2544() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2544");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test2545() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2545");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2546() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2546");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState25 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass26 = gameState25.getClass();
        java.lang.Class<?> wildcardClass27 = gameState25.getClass();
        java.lang.Class<?> wildcardClass28 = gameState25.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

    @Test
    public void test2547() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2547");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2548() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2548");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test2549() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2549");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = gameState18.getClass();
        java.lang.Class<?> wildcardClass20 = gameState18.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2550() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2550");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass25 = gameState24.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test2551() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2551");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState25 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test2552() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2552");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test2553() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2553");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test2554() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2554");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = gameState16.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test2555() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2555");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass24 = moveList1.getClass();
        Chess.Athena.GameState gameState25 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass26 = gameState25.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test2556() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2556");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = gameState15.getClass();
        java.lang.Class<?> wildcardClass17 = gameState15.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test2557() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2557");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = gameState18.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test2558() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2558");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass24 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test2559() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2559");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test2560() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2560");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass22 = gameState21.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test2561() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2561");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test2562() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2562");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState4 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState5 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test2563() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2563");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test2564() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2564");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2565() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2565");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test2566() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2566");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test2567() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2567");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        java.lang.Class<?> wildcardClass24 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test2568() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2568");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState25 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test2569() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2569");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = gameState17.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test2570() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2570");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = gameState17.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test2571() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2571");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test2572() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2572");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test2573() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2573");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test2574() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2574");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = gameState15.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test2575() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2575");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test2576() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2576");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        Chess.Athena.GameState gameState5 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test2577() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2577");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2578() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2578");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass22 = gameState21.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test2579() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2579");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2580() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2580");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test2581() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2581");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test2582() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2582");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = gameState17.getClass();
        java.lang.Class<?> wildcardClass19 = gameState17.getClass();
        java.lang.Class<?> wildcardClass20 = gameState17.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2583() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2583");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2584() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2584");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = gameState14.getClass();
        java.lang.Class<?> wildcardClass16 = gameState14.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test2585() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2585");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test2586() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2586");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState25 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState26 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test2587() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2587");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test2588() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2588");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState25 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState26 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test2589() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2589");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = gameState19.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2590() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2590");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test2591() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2591");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass22 = gameState21.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test2592() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2592");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = gameState20.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2593() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2593");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test2594() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2594");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test2595() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2595");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState4 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState5 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test2596() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2596");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass24 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test2597() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2597");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass25 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test2598() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2598");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass25 = gameState24.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test2599() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2599");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = gameState20.getClass();
        java.lang.Class<?> wildcardClass22 = gameState20.getClass();
        java.lang.Class<?> wildcardClass23 = gameState20.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test2600() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2600");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test2601() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2601");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2602() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2602");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test2603() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2603");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = gameState19.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2604() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2604");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test2605() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2605");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test2606() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2606");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test2607() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2607");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        java.lang.Class<?> wildcardClass24 = moveList1.getClass();
        java.lang.Class<?> wildcardClass25 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test2608() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2608");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test2609() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2609");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2610() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2610");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2611() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2611");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test2612() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2612");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        Chess.Athena.GameState gameState5 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test2613() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2613");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState25 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test2614() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2614");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = gameState17.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test2615() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2615");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2616() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2616");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test2617() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2617");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass25 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test2618() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2618");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = gameState15.getClass();
        java.lang.Class<?> wildcardClass17 = gameState15.getClass();
        java.lang.Class<?> wildcardClass18 = gameState15.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test2619() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2619");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test2620() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2620");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState25 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState26 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState27 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass28 = gameState27.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

    @Test
    public void test2621() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2621");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test2622() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2622");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test2623() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2623");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test2624() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2624");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test2625() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2625");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test2626() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2626");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test2627() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2627");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2628() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2628");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2629() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2629");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test2630() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2630");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        Chess.Athena.GameState gameState5 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test2631() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2631");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2632() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2632");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = gameState20.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2633() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2633");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2634() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2634");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2635() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2635");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState4 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test2636() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2636");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = gameState18.getClass();
        java.lang.Class<?> wildcardClass20 = gameState18.getClass();
        java.lang.Class<?> wildcardClass21 = gameState18.getClass();
        java.lang.Class<?> wildcardClass22 = gameState18.getClass();
        java.lang.Class<?> wildcardClass23 = gameState18.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test2637() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2637");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test2638() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2638");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = gameState19.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2639() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2639");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2640() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2640");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        Chess.Athena.GameState gameState5 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = gameState12.getClass();
        java.lang.Class<?> wildcardClass14 = gameState12.getClass();
        java.lang.Class<?> wildcardClass15 = gameState12.getClass();
        java.lang.Class<?> wildcardClass16 = gameState12.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test2641() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2641");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test2642() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2642");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test2643() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2643");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test2644() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2644");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test2645() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2645");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2646() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2646");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test2647() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2647");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass24 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test2648() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2648");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2649() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2649");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test2650() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2650");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test2651() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2651");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState4 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test2652() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2652");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2653() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2653");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test2654() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2654");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = gameState20.getClass();
        java.lang.Class<?> wildcardClass22 = gameState20.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test2655() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2655");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        Chess.Athena.GameState gameState5 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test2656() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2656");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState4 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test2657() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2657");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test2658() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2658");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        Chess.Athena.GameState gameState5 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test2659() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2659");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2660() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2660");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState25 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2661() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2661");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        Chess.Athena.GameState gameState5 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test2662() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2662");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState25 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState26 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test2663() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2663");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        Chess.Athena.GameState gameState5 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = gameState13.getClass();
        java.lang.Class<?> wildcardClass15 = gameState13.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test2664() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2664");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = gameState19.getClass();
        java.lang.Class<?> wildcardClass21 = gameState19.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2665() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2665");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2666() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2666");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test2667() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2667");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2668() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2668");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test2669() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2669");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test2670() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2670");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2671() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2671");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2672() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2672");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test2673() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2673");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2674() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2674");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = gameState15.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test2675() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2675");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass24 = moveList1.getClass();
        java.lang.Class<?> wildcardClass25 = moveList1.getClass();
        Chess.Athena.GameState gameState26 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState27 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState28 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test2676() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2676");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass24 = moveList1.getClass();
        Chess.Athena.GameState gameState25 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass26 = gameState25.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test2677() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2677");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test2678() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2678");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2679() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2679");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState4 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState5 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test2680() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2680");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        java.lang.Class<?> wildcardClass24 = moveList1.getClass();
        java.lang.Class<?> wildcardClass25 = moveList1.getClass();
        Chess.Athena.GameState gameState26 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test2681() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2681");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState25 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState26 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState27 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState28 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState29 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass30 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass30);
    }

    @Test
    public void test2682() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2682");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        Chess.Athena.GameState gameState5 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test2683() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2683");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        Chess.Athena.GameState gameState5 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test2684() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2684");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = gameState20.getClass();
        java.lang.Class<?> wildcardClass22 = gameState20.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test2685() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2685");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test2686() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2686");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        Chess.Athena.GameState gameState5 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test2687() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2687");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test2688() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2688");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test2689() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2689");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = gameState18.getClass();
        java.lang.Class<?> wildcardClass20 = gameState18.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2690() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2690");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2691() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2691");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass22 = gameState21.getClass();
        java.lang.Class<?> wildcardClass23 = gameState21.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test2692() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2692");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test2693() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2693");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2694() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2694");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass25 = gameState24.getClass();
        java.lang.Class<?> wildcardClass26 = gameState24.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test2695() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2695");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test2696() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2696");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass24 = gameState23.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test2697() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2697");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = gameState16.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test2698() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2698");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = gameState14.getClass();
        java.lang.Class<?> wildcardClass16 = gameState14.getClass();
        java.lang.Class<?> wildcardClass17 = gameState14.getClass();
        java.lang.Class<?> wildcardClass18 = gameState14.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test2699() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2699");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test2700() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2700");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = gameState13.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test2701() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2701");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test2702() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2702");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        Chess.Athena.GameState gameState5 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test2703() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2703");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = gameState18.getClass();
        java.lang.Class<?> wildcardClass20 = gameState18.getClass();
        java.lang.Class<?> wildcardClass21 = gameState18.getClass();
        java.lang.Class<?> wildcardClass22 = gameState18.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test2704() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2704");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2705() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2705");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass22 = gameState21.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test2706() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2706");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass23 = gameState22.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test2707() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2707");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test2708() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2708");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test2709() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2709");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test2710() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2710");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass25 = moveList1.getClass();
        Chess.Athena.GameState gameState26 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test2711() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2711");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2712() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2712");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass24 = moveList1.getClass();
        java.lang.Class<?> wildcardClass25 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test2713() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2713");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2714() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2714");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2715() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2715");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        java.lang.Class<?> wildcardClass24 = moveList1.getClass();
        java.lang.Class<?> wildcardClass25 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test2716() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2716");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass23 = gameState22.getClass();
        java.lang.Class<?> wildcardClass24 = gameState22.getClass();
        java.lang.Class<?> wildcardClass25 = gameState22.getClass();
        java.lang.Class<?> wildcardClass26 = gameState22.getClass();
        java.lang.Class<?> wildcardClass27 = gameState22.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

    @Test
    public void test2717() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2717");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = gameState18.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test2718() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2718");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass24 = gameState23.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test2719() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2719");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test2720() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2720");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test2721() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2721");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test2722() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2722");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = gameState18.getClass();
        java.lang.Class<?> wildcardClass20 = gameState18.getClass();
        java.lang.Class<?> wildcardClass21 = gameState18.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2723() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2723");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = gameState19.getClass();
        java.lang.Class<?> wildcardClass21 = gameState19.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2724() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2724");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test2725() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2725");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test2726() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2726");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test2727() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2727");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass25 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test2728() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2728");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        Chess.Athena.GameState gameState5 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test2729() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2729");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        java.lang.Class<?> wildcardClass24 = moveList1.getClass();
        Chess.Athena.GameState gameState25 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass26 = moveList1.getClass();
        java.lang.Class<?> wildcardClass27 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

    @Test
    public void test2730() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2730");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test2731() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2731");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        java.lang.Class<?> wildcardClass24 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test2732() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2732");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test2733() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2733");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = gameState12.getClass();
        java.lang.Class<?> wildcardClass14 = gameState12.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test2734() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2734");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test2735() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2735");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test2736() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2736");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = gameState18.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test2737() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2737");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = gameState20.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test2738() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2738");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test2739() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2739");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test2740() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2740");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test2741() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2741");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        Chess.Athena.GameState gameState5 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test2742() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2742");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test2743() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2743");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test2744() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2744");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test2745() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2745");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test2746() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2746");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = gameState18.getClass();
        java.lang.Class<?> wildcardClass20 = gameState18.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2747() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2747");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState4 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test2748() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2748");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test2749() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2749");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = gameState20.getClass();
        java.lang.Class<?> wildcardClass22 = gameState20.getClass();
        java.lang.Class<?> wildcardClass23 = gameState20.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test2750() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2750");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test2751() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2751");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2752() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2752");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2753() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2753");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test2754() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2754");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test2755() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2755");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass24 = moveList1.getClass();
        Chess.Athena.GameState gameState25 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass26 = moveList1.getClass();
        java.lang.Class<?> wildcardClass27 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

    @Test
    public void test2756() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2756");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test2757() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2757");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        Chess.Athena.GameState gameState20 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass21 = moveList1.getClass();
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test2758() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2758");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2759() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2759");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = gameState19.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2760() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2760");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        java.lang.Class<?> wildcardClass23 = moveList1.getClass();
        Chess.Athena.GameState gameState24 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test2761() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2761");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        Chess.Athena.GameState gameState5 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test2762() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2762");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass22 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test2763() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2763");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        java.lang.Class<?> wildcardClass13 = moveList1.getClass();
        Chess.Athena.GameState gameState14 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test2764() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2764");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        Chess.Athena.GameState gameState6 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass7 = moveList1.getClass();
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass10 = moveList1.getClass();
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass12 = moveList1.getClass();
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test2765() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2765");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        Chess.Athena.GameState gameState9 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass11 = moveList1.getClass();
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test2766() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2766");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState8 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        Chess.Athena.GameState gameState15 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass16 = moveList1.getClass();
        Chess.Athena.GameState gameState17 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass18 = moveList1.getClass();
        java.lang.Class<?> wildcardClass19 = moveList1.getClass();
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test2767() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2767");
        Chess.Game.Move[] moveArray0 = new Chess.Game.Move[] {};
        java.util.ArrayList<Chess.Game.Move> moveList1 = new java.util.ArrayList<Chess.Game.Move>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<Chess.Game.Move>) moveList1, moveArray0);
        Chess.Athena.GameState gameState3 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass4 = moveList1.getClass();
        java.lang.Class<?> wildcardClass5 = moveList1.getClass();
        java.lang.Class<?> wildcardClass6 = moveList1.getClass();
        Chess.Athena.GameState gameState7 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass8 = moveList1.getClass();
        java.lang.Class<?> wildcardClass9 = moveList1.getClass();
        Chess.Athena.GameState gameState10 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState11 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState12 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState13 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass14 = moveList1.getClass();
        java.lang.Class<?> wildcardClass15 = moveList1.getClass();
        Chess.Athena.GameState gameState16 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass17 = moveList1.getClass();
        Chess.Athena.GameState gameState18 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState19 = new Chess.Athena.GameState(moveList1);
        java.lang.Class<?> wildcardClass20 = moveList1.getClass();
        Chess.Athena.GameState gameState21 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState22 = new Chess.Athena.GameState(moveList1);
        Chess.Athena.GameState gameState23 = new Chess.Athena.GameState(moveList1);
        org.junit.Assert.assertNotNull(moveArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }
}

