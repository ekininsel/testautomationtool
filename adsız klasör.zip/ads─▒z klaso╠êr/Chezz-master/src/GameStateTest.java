import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ GameStateTest0.class, GameStateTest1.class, GameStateTest2.class, GameStateTest3.class, GameStateTest4.class, GameStateTest5.class })
public class GameStateTest {
}

