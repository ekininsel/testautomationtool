package Chess.Game;

import static org.junit.Assert.*;

/**
 * Created by thomas on 22/02/17.
 */
public class MovesetsTest
{

}